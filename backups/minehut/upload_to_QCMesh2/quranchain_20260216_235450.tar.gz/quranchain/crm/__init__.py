"""
CRM Package for QuranChain AI Workforce
© QuranChain™ | Omar Mohammad Abunadi™
"""

from .database import *
