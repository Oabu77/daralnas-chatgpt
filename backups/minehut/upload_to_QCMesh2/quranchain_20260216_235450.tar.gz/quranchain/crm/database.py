"""
QuranChain™ CRM Database
© QuranChain™ | Omar Mohammad Abunadi™

Central CRM system for lead, deal, merchant, and revenue tracking.
All AI agents report into this system.
"""

import os
import sqlite3
import json
import sys
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, asdict
from enum import Enum

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Add project root to path
sys.path.insert(0, "/home/omar/Desktop/QuranChain")

COPYRIGHT = "© QuranChain™ | Omar Mohammad Abunadi™"

# ═══════════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════════

class LeadStatus(Enum):
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    WON = "won"
    LOST = "lost"

class DealStage(Enum):
    DISCOVERY = "discovery"
    QUALIFICATION = "qualification"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"

class MerchantStatus(Enum):
    PENDING = "pending"
    ONBOARDING = "onboarding"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    CHURNED = "churned"

class LeadSource(Enum):
    WEBSITE = "website"
    REFERRAL = "referral"
    MARKETING_AI = "marketing_ai"
    SALES_AI = "sales_ai"
    PARTNER = "partner"
    ORGANIC = "organic"
    PAID_AD = "paid_ad"
    EVENT = "event"

# ═══════════════════════════════════════════════════════════════
# DATA CLASSES
# ═══════════════════════════════════════════════════════════════

@dataclass
class Lead:
    id: Optional[int]
    name: str
    email: str
    company: Optional[str]
    phone: Optional[str]
    source: str
    status: str
    score: int  # 0-100
    notes: Optional[str]
    assigned_to: Optional[str]  # AI agent or human
    created_at: str
    updated_at: str
    opted_in: bool  # CRITICAL: Must be True for outreach
    opt_in_timestamp: Optional[str]

@dataclass
class Deal:
    id: Optional[int]
    lead_id: int
    name: str
    stage: str
    deal_value: float
    currency: str
    probability: int  # 0-100
    expected_close_date: Optional[str]
    product: str  # quranchain_pay, dar_al_nas, etc.
    assigned_to: Optional[str]
    notes: Optional[str]
    created_at: str
    updated_at: str

@dataclass
class Merchant:
    id: Optional[int]
    business_name: str
    contact_name: str
    email: str
    phone: Optional[str]
    status: str
    api_key_issued: bool
    monthly_volume: float
    onboarded_at: Optional[str]
    onboarded_by: Optional[str]  # AI agent ID
    created_at: str

@dataclass
class RevenueEvent:
    id: Optional[int]
    source: str  # Which service/product
    merchant_id: Optional[int]
    amount: float
    currency: str
    fee_collected: float
    founder_royalty: float
    ai_agent: Optional[str]
    description: str
    timestamp: str

# ═══════════════════════════════════════════════════════════════
# CRM DATABASE
# ═══════════════════════════════════════════════════════════════

class CRMDatabase:
    """Central CRM database - NOW CLOUD-HOSTED on DarCloud"""

    def __init__(self, db_name: str = "crm"):
        self.db_name = db_name
        self._init_direct_db()

    def _init_direct_db(self):
        """Initialize CRM database using direct SQLite (no cloud dependency)"""
        try:
            # Use local SQLite database directly
            logger.info(f"Using local SQLite database: crm/{self.db_name}.db")

            # Define schema
            schema = {
                "leads": """
                    CREATE TABLE IF NOT EXISTS leads (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        email TEXT UNIQUE NOT NULL,
                        company TEXT,
                        phone TEXT,
                        source TEXT NOT NULL,
                        status TEXT DEFAULT 'new',
                        score INTEGER DEFAULT 0,
                        notes TEXT,
                        assigned_to TEXT,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        opted_in INTEGER DEFAULT 0,
                        opt_in_timestamp TEXT
                    )
                """,
                "deals": """
                    CREATE TABLE IF NOT EXISTS deals (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        lead_id INTEGER,
                        name TEXT NOT NULL,
                        stage TEXT DEFAULT 'discovery',
                        deal_value REAL DEFAULT 0,
                        currency TEXT DEFAULT 'USD',
                        probability INTEGER DEFAULT 0,
                        expected_close_date TEXT,
                        product TEXT,
                        assigned_to TEXT,
                        notes TEXT,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    )
                """,
                "merchants": """
                    CREATE TABLE IF NOT EXISTS merchants (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        business_name TEXT NOT NULL,
                        contact_name TEXT NOT NULL,
                        email TEXT UNIQUE NOT NULL,
                        phone TEXT,
                        status TEXT DEFAULT 'pending',
                        api_key_issued INTEGER DEFAULT 0,
                        monthly_volume REAL DEFAULT 0,
                        onboarded_at TEXT,
                        onboarded_by TEXT,
                        created_at TEXT NOT NULL
                    )
                """,
                "revenue_events": """
                    CREATE TABLE IF NOT EXISTS revenue_events (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        source TEXT NOT NULL,
                        merchant_id INTEGER,
                        amount REAL NOT NULL,
                        currency TEXT DEFAULT 'USD',
                        type TEXT NOT NULL,
                        founder_share REAL DEFAULT 0,
                        ai_validator_share REAL DEFAULT 0,
                        hardware_host_share REAL DEFAULT 0,
                        ecosystem_share REAL DEFAULT 0,
                        zakat_share REAL DEFAULT 0,
                        created_at TEXT NOT NULL
                    )
                """
            }

            # Execute schema creation using direct SQLite
            db_path = f"crm/{self.db_name}.db"
            os.makedirs("crm", exist_ok=True)
            
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            for table_name, create_sql in schema.items():
                cursor.execute(create_sql)
            
            conn.commit()
            conn.close()

            print(f"✅ CRM Database initialized: {db_path}")
            logger.info(f"Direct SQLite mode - no cloud dependency")

        except Exception as e:
            print(f"Failed to initialize CRM database: {e}")
            raise
    
    # ─────────────────────────────────────────────────────────────
    # LEAD OPERATIONS
    # ─────────────────────────────────────────────────────────────
    
    def create_lead(self, lead: Lead) -> int:
        """Create a new lead in cloud database"""
        data = {
            "name": lead.name,
            "email": lead.email,
            "company": lead.company,
            "phone": lead.phone,
            "source": lead.source,
            "status": lead.status,
            "score": lead.score,
            "notes": lead.notes,
            "assigned_to": lead.assigned_to,
            "created_at": lead.created_at,
            "updated_at": lead.updated_at,
            "opted_in": 1 if lead.opted_in else 0,
            "opt_in_timestamp": lead.opt_in_timestamp
        }

        store_database_data(self.db_name, "leads", data)

        # Get the inserted ID
        results = get_database_data(self.db_name, "leads", "email = ?", (lead.email,))
        return results[0]["id"] if results else 0
        conn.commit()
        conn.close()
        return lead_id
    
    def get_lead(self, lead_id: int) -> Optional[Lead]:
        """Get lead from cloud database"""
        results = get_database_data(self.db_name, "leads", "id = ?", (lead_id,))

        if results:
            row = results[0]
            return Lead(
                id=row["id"],
                name=row["name"],
                email=row["email"],
                company=row["company"],
                phone=row["phone"],
                source=row["source"],
                status=row["status"],
                score=row["score"],
                notes=row["notes"],
                assigned_to=row["assigned_to"],
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                opted_in=bool(row["opted_in"]),
                opt_in_timestamp=row["opt_in_timestamp"]
            )
        return None
    
    def get_lead_by_email(self, email: str) -> Optional[Lead]:
        """Get a lead by email"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM leads WHERE email = ?", (email,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return Lead(
                id=row[0], name=row[1], email=row[2], company=row[3],
                phone=row[4], source=row[5], status=row[6], score=row[7],
                notes=row[8], assigned_to=row[9], created_at=row[10],
                updated_at=row[11], opted_in=bool(row[12]), opt_in_timestamp=row[13]
            )
        return None
    
    def update_lead_status(self, lead_id: int, status: str, notes: Optional[str] = None):
        """Update lead status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if notes:
            cursor.execute("""
                UPDATE leads SET status = ?, notes = ?, updated_at = ?
                WHERE id = ?
            """, (status, notes, datetime.utcnow().isoformat(), lead_id))
        else:
            cursor.execute("""
                UPDATE leads SET status = ?, updated_at = ?
                WHERE id = ?
            """, (status, datetime.utcnow().isoformat(), lead_id))
        
        conn.commit()
        conn.close()
    
    def get_leads_by_status(self, status: str) -> List[Lead]:
        """Get all leads with a specific status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM leads WHERE status = ?", (status,))
        rows = cursor.fetchall()
        conn.close()
        
        return [Lead(
            id=row[0], name=row[1], email=row[2], company=row[3],
            phone=row[4], source=row[5], status=row[6], score=row[7],
            notes=row[8], assigned_to=row[9], created_at=row[10],
            updated_at=row[11], opted_in=bool(row[12]), opt_in_timestamp=row[13]
        ) for row in rows]
    
    def get_opted_in_leads(self) -> List[Lead]:
        """Get all leads who have opted in for communications"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM leads WHERE opted_in = 1")
        rows = cursor.fetchall()
        conn.close()
        
        return [Lead(
            id=row[0], name=row[1], email=row[2], company=row[3],
            phone=row[4], source=row[5], status=row[6], score=row[7],
            notes=row[8], assigned_to=row[9], created_at=row[10],
            updated_at=row[11], opted_in=bool(row[12]), opt_in_timestamp=row[13]
        ) for row in rows]
    
    # ─────────────────────────────────────────────────────────────
    # DEAL OPERATIONS
    # ─────────────────────────────────────────────────────────────
    
    def create_deal(self, deal: Deal) -> int:
        """Create a new deal"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO deals 
            (lead_id, name, stage, deal_value, currency, probability,
             expected_close_date, product, assigned_to, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            deal.lead_id, deal.name, deal.stage, deal.deal_value,
            deal.currency, deal.probability, deal.expected_close_date,
            deal.product, deal.assigned_to, deal.notes,
            deal.created_at, deal.updated_at
        ))
        
        deal_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return deal_id
    
    def update_deal_stage(self, deal_id: int, stage: str, probability: int):
        """Update deal stage and probability"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE deals SET stage = ?, probability = ?, updated_at = ?
            WHERE id = ?
        """, (stage, probability, datetime.utcnow().isoformat(), deal_id))
        conn.commit()
        conn.close()
    
    def close_deal(self, deal_id: int, won: bool, final_value: float):
        """Close a deal as won or lost"""
        stage = DealStage.CLOSED_WON.value if won else DealStage.CLOSED_LOST.value
        probability = 100 if won else 0
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE deals SET stage = ?, probability = ?, deal_value = ?, updated_at = ?
            WHERE id = ?
        """, (stage, probability, final_value, datetime.utcnow().isoformat(), deal_id))
        conn.commit()
        conn.close()
    
    def get_pipeline(self) -> Dict[str, List[Dict]]:
        """Get full sales pipeline"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT d.*, l.name as lead_name, l.company 
            FROM deals d
            LEFT JOIN leads l ON d.lead_id = l.id
            WHERE d.stage NOT IN ('closed_won', 'closed_lost')
            ORDER BY d.deal_value DESC
        """)
        rows = cursor.fetchall()
        conn.close()
        
        pipeline = {stage.value: [] for stage in DealStage if stage.value not in ['closed_won', 'closed_lost']}
        
        for row in rows:
            deal = {
                "id": row[0], "lead_id": row[1], "name": row[2],
                "stage": row[3], "deal_value": row[4], "currency": row[5],
                "probability": row[6], "product": row[8],
                "lead_name": row[13], "company": row[14]
            }
            if row[3] in pipeline:
                pipeline[row[3]].append(deal)
        
        return pipeline
    
    def get_pipeline_value(self) -> Dict[str, float]:
        """Get pipeline value by stage"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT stage, SUM(deal_value * probability / 100) as weighted_value,
                   SUM(deal_value) as total_value, COUNT(*) as deal_count
            FROM deals
            WHERE stage NOT IN ('closed_won', 'closed_lost')
            GROUP BY stage
        """)
        rows = cursor.fetchall()
        conn.close()
        
        return {
            row[0]: {
                "weighted_value": row[1] or 0,
                "total_value": row[2] or 0,
                "count": row[3]
            } for row in rows
        }
    
    # ─────────────────────────────────────────────────────────────
    # MERCHANT OPERATIONS
    # ─────────────────────────────────────────────────────────────
    
    def create_merchant(self, merchant: Merchant) -> int:
        """Create a new merchant"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO merchants 
            (business_name, contact_name, email, phone, status, api_key_issued,
             monthly_volume, onboarded_at, onboarded_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            merchant.business_name, merchant.contact_name, merchant.email,
            merchant.phone, merchant.status, 1 if merchant.api_key_issued else 0,
            merchant.monthly_volume, merchant.onboarded_at, merchant.onboarded_by,
            merchant.created_at
        ))
        
        merchant_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return merchant_id
    
    def update_merchant_status(self, merchant_id: int, status: str):
        """Update merchant status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE merchants SET status = ? WHERE id = ?", (status, merchant_id))
        conn.commit()
        conn.close()
    
    def get_active_merchants(self) -> List[Merchant]:
        """Get all active merchants"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM merchants WHERE status = 'active'")
        rows = cursor.fetchall()
        conn.close()
        
        return [Merchant(
            id=row[0], business_name=row[1], contact_name=row[2],
            email=row[3], phone=row[4], status=row[5],
            api_key_issued=bool(row[6]), monthly_volume=row[7],
            onboarded_at=row[8], onboarded_by=row[9], created_at=row[10]
        ) for row in rows]
    
    def get_merchant_count_by_status(self) -> Dict[str, int]:
        """Get merchant count by status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT status, COUNT(*) FROM merchants GROUP BY status")
        rows = cursor.fetchall()
        conn.close()
        return {row[0]: row[1] for row in rows}
    
    # ─────────────────────────────────────────────────────────────
    # REVENUE OPERATIONS
    # ─────────────────────────────────────────────────────────────
    
    def record_revenue(self, event: RevenueEvent) -> int:
        """Record a revenue event in cloud database"""
        data = {
            "source": event.source,
            "merchant_id": event.merchant_id,
            "amount": event.amount,
            "currency": event.currency,
            "fee_collected": event.fee_collected,
            "founder_royalty": event.founder_royalty,
            "ai_agent": event.ai_agent,
            "description": event.description,
            "timestamp": event.timestamp
        }

        store_database_data(self.db_name, "revenue_events", data)

        # Store revenue snapshot in cloud
        from darcloud_storage_client import store_revenue_snapshot
        revenue_data = {
            "total_revenue": event.amount,
            "founder_royalty": event.founder_royalty,
            "fee_collected": event.fee_collected,
            "source": event.source,
            "ai_agent": event.ai_agent,
            "timestamp": event.timestamp
        }
        store_revenue_snapshot(revenue_data)

        # Get inserted ID
        results = get_database_data(self.db_name, "revenue_events", "source = ? AND amount = ? ORDER BY id DESC LIMIT 1",
                                   (event.source, event.amount))
        return results[0]["id"] if results else 0
        conn.close()
        return event_id
    
    def get_revenue_summary(self, days: int = 30) -> Dict[str, Any]:
        """Get revenue summary for the last N days"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                SUM(amount) as total_amount,
                SUM(fee_collected) as total_fees,
                SUM(founder_royalty) as total_royalty,
                COUNT(*) as event_count
            FROM revenue_events
            WHERE timestamp >= datetime('now', ?)
        """, (f"-{days} days",))
        
        row = cursor.fetchone()
        
        cursor.execute("""
            SELECT source, SUM(amount) as total
            FROM revenue_events
            WHERE timestamp >= datetime('now', ?)
            GROUP BY source
            ORDER BY total DESC
        """, (f"-{days} days",))
        
        by_source = {r[0]: r[1] for r in cursor.fetchall()}
        
        cursor.execute("""
            SELECT ai_agent, SUM(amount) as total
            FROM revenue_events
            WHERE timestamp >= datetime('now', ?) AND ai_agent IS NOT NULL
            GROUP BY ai_agent
        """, (f"-{days} days",))
        
        by_agent = {r[0]: r[1] for r in cursor.fetchall()}
        
        conn.close()
        
        return {
            "period_days": days,
            "total_revenue": row[0] or 0,
            "total_fees": row[1] or 0,
            "founder_royalty": row[2] or 0,
            "transaction_count": row[3] or 0,
            "by_source": by_source,
            "by_ai_agent": by_agent
        }
    
    # ─────────────────────────────────────────────────────────────
    # ACTIVITY LOGGING
    # ─────────────────────────────────────────────────────────────
    
    def log_activity(self, entity_type: str, entity_id: int, action: str, 
                     details: Dict, performed_by: str):
        """Log an activity"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO activities (entity_type, entity_id, action, details, performed_by, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (entity_type, entity_id, action, json.dumps(details), 
              performed_by, datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
    
    # ─────────────────────────────────────────────────────────────
    # DASHBOARD METRICS
    # ─────────────────────────────────────────────────────────────
    
    def get_dashboard_metrics(self) -> Dict[str, Any]:
        """Get all metrics for dashboard"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Lead metrics
        cursor.execute("SELECT COUNT(*) FROM leads")
        total_leads = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM leads WHERE status = 'won'")
        converted_leads = cursor.fetchone()[0]
        
        # Deal metrics
        cursor.execute("""
            SELECT SUM(deal_value) FROM deals WHERE stage = 'closed_won'
        """)
        closed_revenue = cursor.fetchone()[0] or 0
        
        cursor.execute("""
            SELECT SUM(deal_value * probability / 100) FROM deals
            WHERE stage NOT IN ('closed_won', 'closed_lost')
        """)
        pipeline_weighted = cursor.fetchone()[0] or 0
        
        # Merchant metrics
        cursor.execute("SELECT COUNT(*) FROM merchants WHERE status = 'active'")
        active_merchants = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(monthly_volume) FROM merchants WHERE status = 'active'")
        merchant_volume = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return {
            "leads": {
                "total": total_leads,
                "converted": converted_leads,
                "conversion_rate": (converted_leads / total_leads * 100) if total_leads > 0 else 0
            },
            "deals": {
                "closed_revenue": closed_revenue,
                "pipeline_weighted": pipeline_weighted
            },
            "merchants": {
                "active": active_merchants,
                "monthly_volume": merchant_volume
            },
            "timestamp": datetime.utcnow().isoformat(),
            "copyright": COPYRIGHT
        }


# Initialize singleton
crm = CRMDatabase()


if __name__ == "__main__":
    print(f"QuranChain CRM Database")
    print(COPYRIGHT)
    print(f"\nDatabase location: {DB_PATH}")
    
    # Test connection
    metrics = crm.get_dashboard_metrics()
    print(f"\nDashboard Metrics:")
    print(json.dumps(metrics, indent=2))
