#!/usr/bin/env python3
"""
🕌 QURANCHAIN BLOCKCHAIN HOST - DarCloud Integration
Hosts QuranChain blockchain node within DarCloud infrastructure
© QuranChain™ | DarCloud™ | Omar Mohammad Abunadi™
"""

import os
import sys
import time
import subprocess
import signal
import logging
from blockchain_logging_handler import setup_blockchain_logging
from pathlib import Path
import json
from datetime import datetime

# Configure logging
setup_blockchain_logging()
logger = logging.getLogger(__name__)

class QuranChainBlockchainHost:
    """Hosts QuranChain blockchain node within DarCloud"""

    def __init__(self):
        self.process = None
        self.running = False
        self.start_time = None
        self.quranchaind_path = "/home/omar/go/bin/quranchaind"
        self.home_dir = os.path.expanduser("~/.quranchain")
        self.config = {
            "chain_id": "quranchain-1",
            "moniker": "QuranChain-DarCloud-Host",
            "seeds": [],
            "persistent_peers": []
        }

        logger.info("🕌 QuranChain Blockchain Host initialized")
        logger.info(f"   Binary: {self.quranchaind_path}")
        logger.info(f"   Home: {self.home_dir}")
        logger.info(f"   Chain ID: {self.config['chain_id']}")

    def check_binary(self):
        """Check if quranchaind binary exists"""
        if not os.path.exists(self.quranchaind_path):
            logger.error(f"❌ QuranChain binary not found: {self.quranchaind_path}")
            return False
        return True

    def check_home_dir(self):
        """Check if blockchain home directory exists"""
        if not os.path.exists(self.home_dir):
            logger.warning(f"⚠️  Blockchain home directory not found: {self.home_dir}")
            logger.info("   Creating home directory...")
            os.makedirs(self.home_dir, exist_ok=True)
            return False  # Need to initialize
        return True

    def initialize_node(self):
        """Initialize the blockchain node if needed"""
        try:
            logger.info("🔧 Initializing QuranChain node...")

            # Initialize node
            cmd = [
                self.quranchaind_path, "init", self.config["moniker"],
                "--chain-id", self.config["chain_id"],
                "--home", self.home_dir
            ]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                logger.error(f"❌ Failed to initialize node: {result.stderr}")
                return False

            logger.info("✅ Node initialized successfully")

            # Copy genesis file if it exists
            genesis_src = "/home/omar/Desktop/QuranChain/genesis_final.json"
            genesis_dst = os.path.join(self.home_dir, "config", "genesis.json")

            if os.path.exists(genesis_src):
                os.makedirs(os.path.dirname(genesis_dst), exist_ok=True)
                import shutil
                shutil.copy2(genesis_src, genesis_dst)
                logger.info("✅ Genesis file copied")
            else:
                logger.warning("⚠️  Genesis file not found, node may not start properly")

            return True

        except Exception as e:
            logger.error(f"❌ Initialization failed: {e}")
            return False

    def start_node(self):
        """Start the blockchain node"""
        try:
            if not self.check_binary():
                return False

            if not self.check_home_dir():
                if not self.initialize_node():
                    return False

            logger.info("🚀 Starting QuranChain blockchain node...")

            # Start the node
            cmd = [
                self.quranchaind_path, "start",
                "--home", self.home_dir,
                "--log_level", "info",
                "--minimum-gas-prices", "0.0001uquran"
            ]

            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            self.running = True
            self.start_time = datetime.now()

            logger.info("✅ QuranChain blockchain node started")
            logger.info(f"   PID: {self.process.pid}")
            logger.info(f"   Home: {self.home_dir}")
            logger.info(f"   Chain ID: {self.config['chain_id']}")

            return True

        except Exception as e:
            logger.error(f"❌ Failed to start blockchain node: {e}")
            return False

    def stop_node(self):
        """Stop the blockchain node"""
        if self.process and self.running:
            logger.info("🛑 Stopping QuranChain blockchain node...")

            try:
                self.process.terminate()
                self.process.wait(timeout=10)
                logger.info("✅ Blockchain node stopped gracefully")
            except subprocess.TimeoutExpired:
                logger.warning("⚠️  Node didn't stop gracefully, forcing...")
                self.process.kill()
                logger.info("✅ Blockchain node force-stopped")

            self.running = False
            self.process = None

    def get_status(self):
        """Get blockchain node status"""
        status = {
            "service": "quranchain_blockchain",
            "running": self.running,
            "pid": self.process.pid if self.process else None,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "uptime_seconds": (datetime.now() - self.start_time).total_seconds() if self.start_time else 0,
            "home_dir": self.home_dir,
            "chain_id": self.config["chain_id"],
            "binary_path": self.quranchaind_path
        }

        return status

    def monitor_node(self):
        """Monitor the blockchain node health"""
        while self.running:
            try:
                if self.process and self.process.poll() is not None:
                    logger.error(f"❌ Blockchain node crashed with code: {self.process.returncode}")
                    # Auto-restart logic would go here
                    break

                # Check if RPC is responding
                import requests
                try:
                    response = requests.get("https://cosmos.quranchain.io/health", timeout=5)
                    if response.status_code != 200:
                        logger.warning("⚠️  RPC health check failed")
                except:
                    logger.warning("⚠️  Cannot connect to RPC endpoint")

                time.sleep(30)  # Check every 30 seconds

            except Exception as e:
                logger.error(f"❌ Monitoring error: {e}")
                time.sleep(10)

def main():
    """Main function"""
    print("🕌 QuranChain Blockchain Host - DarCloud Integration")
    print("=" * 60)

    host = QuranChainBlockchainHost()

    def signal_handler(signum, frame):
        print("\n🛑 Shutdown signal received...")
        host.stop_node()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        if host.start_node():
            print("✅ Blockchain node started successfully")
            print("🔍 Monitoring node health...")
            print("Press Ctrl+C to stop")

            # Start monitoring in background
            import threading
            monitor_thread = threading.Thread(target=host.monitor_node, daemon=True)
            monitor_thread.start()

            # Keep main thread alive
            while host.running:
                time.sleep(1)

        else:
            print("❌ Failed to start blockchain node")
            sys.exit(1)

    except KeyboardInterrupt:
        print("\n🛑 Stopping blockchain host...")
        host.stop_node()
        print("✅ Blockchain host stopped")

if __name__ == "__main__":
    main()