#!/usr/bin/env python3
"""
🔧📱 QURANCHAIN AI MOBILE REPAIR SYSTEM
=====================================================
Comprehensive auto-repair for all AI programs on mobile devices
Supports: iPhone, Android, MeshTalk Devices, DarCloud Mobile Clients

Features:
- Auto-detect and repair all AI agent failures
- Cross-platform mobile deployment
- Remote healing via DarCloud Mesh
- 24/7 autonomous monitoring
- Founder: Omar Mohammad Abunadi™
=====================================================
"""

import os
import sys
import time
import json
import requests
import subprocess
import logging
import asyncio
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

# Project root setup
PROJECT_ROOT = Path("/home/omar/Desktop/QuranChain")
sys.path.insert(0, str(PROJECT_ROOT))

# Import advanced toolkit
from advanced_agent_toolkit import (
    AdvancedAgentToolkit, Task, TaskPriority, TaskStatus
)

# Logging setup
LOG_DIR = PROJECT_ROOT / "logs" / "mobile_repair"
LOG_DIR.mkdir(parents=True, exist_ok=True)

setup_blockchain_logging()
logger = logging.getLogger(__name__)


class ServiceStatus(Enum):
    """Service health status"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    FAILED = "failed"
    UNKNOWN = "unknown"
    REPAIRING = "repairing"


class DeploymentTarget(Enum):
    """Mobile deployment targets"""
    IPHONE = "iphone"
    ANDROID = "android"
    MESHTALK_DEVICE = "meshtalk_device"
    DARCLOUD_MOBILE = "darcloud_mobile"
    LOCALHOST = "localhost"


@dataclass
class AIAgent:
    """AI Agent configuration"""
    name: str
    script_path: str
    port: Optional[int] = None
    health_endpoint: str = "/health"
    required_for_mobile: bool = True
    auto_restart: bool = True
    priority: int = 5  # 1-10, 10 = highest
    mobile_compatible: bool = True
    
    def __post_init__(self):
        self.full_path = PROJECT_ROOT / self.script_path
        self.pid_file = LOG_DIR / f"{self.name.replace(' ', '_').lower()}.pid"
        self.log_file = LOG_DIR / f"{self.name.replace(' ', '_').lower()}.log"


@dataclass
class RepairAction:
    """Repair action record"""
    timestamp: datetime
    agent_name: str
    issue: str
    action_taken: str
    success: bool
    details: Dict = field(default_factory=dict)


class AIRepairEngine:
    """
    Comprehensive AI repair and deployment engine for mobile devices
    Enhanced with autonomous planning and execution capabilities
    """
    
    def __init__(self):
        self.agents: List[AIAgent] = self._define_ai_agents()
        self.repair_history: List[RepairAction] = []
        self.mobile_connections: Dict[str, Dict] = {}
        self.auto_repair_enabled = True
        
        # Initialize advanced toolkit for autonomous operations
        self.toolkit = AdvancedAgentToolkit("mobile_repair_engine")
        
        logger.info("🚀 AI Mobile Repair Engine initialized")
        logger.info(f"📱 Monitoring {len(self.agents)} AI agents")
        logger.info(f"🧠 Advanced toolkit loaded with {len(self.toolkit.list_tools())} tools")
    
    def _define_ai_agents(self) -> List[AIAgent]:
        """Define all AI agents in the ecosystem"""
        return [
            # Core AI Workforce
            AIAgent("AI Agent Orchestrator", "ai_workforce/ai_agent_orchestrator.py", 5000, priority=10),
            AIAgent("Fungi Mesh Agent", "ai_workforce/fungi_mesh_agent.py", 5001, priority=9),
            AIAgent("MeshTalk OS Agent", "ai_workforce/meshtalk_os_agent.py", 5002, priority=9),
            AIAgent("Docker Container Agent", "ai_workforce/docker_container_agent.py", 5003, priority=8),
            AIAgent("Auto Deploy Agent", "ai_workforce/auto_launch_deploy_agent.py", 5004, priority=8),
            AIAgent("Dedicated Server Agent", "ai_workforce/dedicated_server_agent.py", 5005, priority=7),
            
            # Revenue AI Agents
            AIAgent("Marketing AI", "organized/ai_agents/marketing_ai_agent.py", 5060, priority=9),
            AIAgent("Sales AI", "ai_workforce/sales_ai_agent.py", None, priority=8),
            AIAgent("Omar AI", "organized/ai_agents/omar_ai.py", None, priority=10),
            AIAgent("QuranChain AI", "organized/ai_agents/quranchain_ai.py", None, priority=10),
            
            # Infrastructure AI
            AIAgent("Security AI", "ai_workforce/security_ai_agent.py", 5010, priority=10),
            AIAgent("IT Operations AI", "ai_workforce/it_operations_ai_agent.py", 5011, priority=8),
            AIAgent("Optimization AI", "ai_workforce/optimization_ai_agent.py", 5012, priority=7),
            
            # Mobile-Specific AI
            AIAgent("MeshTalk Telecom AI", "ai_workforce/meshtalk_telecom_ai_agent.py", 5020, priority=9),
            AIAgent("DarCloud Mobile AI", "darcloud_persistent_ai_service.py", 8888, priority=9),
            AIAgent("Autonomous AI", "autonomous_ai_agent.py", 9000, priority=10),
            
            # Specialized Tools
            AIAgent("Payment Expert", "ai_workforce/payment_tools_expert.py", None, priority=7),
            AIAgent("API Error Manager", "ai_workforce/api_error_manager_agent.py", None, priority=8),
            AIAgent("DevOps Expert", "ai_workforce/devops_tools_expert.py", None, priority=6),
        ]
    
    def check_agent_health(self, agent: AIAgent) -> Tuple[ServiceStatus, Optional[str]]:
        """Check health status of an AI agent"""
        try:
            # Check if process is running
            if agent.pid_file.exists():
                try:
                    with open(agent.pid_file) as f:
                        pid = int(f.read().strip())
                    
                    # Check if PID is still alive
                    os.kill(pid, 0)  # Doesn't actually kill, just checks
                except (ProcessLookupError, ValueError):
                    return ServiceStatus.FAILED, "Process not running (stale PID)"
            else:
                return ServiceStatus.FAILED, "No PID file found"
            
            # Check HTTP health if port is available
            if agent.port:
                try:
                    response = requests.get(
                        f"http://127.0.0.1:{agent.port}{agent.health_endpoint}",
                        timeout=2
                    )
                    if response.status_code == 200:
                        return ServiceStatus.HEALTHY, "OK"
                    else:
                        return ServiceStatus.DEGRADED, f"HTTP {response.status_code}"
                except requests.exceptions.RequestException as e:
                    return ServiceStatus.DEGRADED, f"Health check failed: {str(e)}"
            
            return ServiceStatus.HEALTHY, "Process running"
            
        except Exception as e:
            return ServiceStatus.UNKNOWN, f"Health check error: {str(e)}"
    
    def repair_agent(self, agent: AIAgent, issue: str) -> bool:
        """Repair a failed AI agent"""
        logger.warning(f"🔧 Repairing {agent.name}: {issue}")
        
        try:
            # Step 1: Kill any existing processes
            if agent.pid_file.exists():
                try:
                    with open(agent.pid_file) as f:
                        old_pid = int(f.read().strip())
                    os.kill(old_pid, 9)
                    logger.info(f"  ✓ Killed old process (PID {old_pid})")
                except Exception:
                    pass
                agent.pid_file.unlink(missing_ok=True)
            
            # Kill by port if available
            if agent.port:
                try:
                    result = subprocess.run(
                        f"lsof -ti:{agent.port} | xargs kill -9",
                        shell=True,
                        capture_output=True
                    )
                except Exception:
                    pass
            
            time.sleep(2)
            
            # Step 2: Restart the agent
            if not agent.full_path.exists():
                logger.error(f"  ✗ Agent script not found: {agent.full_path}")
                self._record_repair(agent.name, issue, "Script not found", False)
                return False
            
            cmd = [
                sys.executable,
                str(agent.full_path)
            ]
            
            # Start process in background
            with open(agent.log_file, 'a') as log:
                process = subprocess.Popen(
                    cmd,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    cwd=PROJECT_ROOT,
                    start_new_session=True
                )
            
            # Save PID
            agent.pid_file.write_text(str(process.pid))
            
            # Wait and verify
            time.sleep(3)
            status, msg = self.check_agent_health(agent)
            
            if status in [ServiceStatus.HEALTHY, ServiceStatus.DEGRADED]:
                logger.info(f"  ✓ Successfully repaired {agent.name}")
                self._record_repair(agent.name, issue, f"Restarted (PID {process.pid})", True)
                return True
            else:
                logger.error(f"  ✗ Repair failed for {agent.name}: {msg}")
                self._record_repair(agent.name, issue, f"Restart failed: {msg}", False)
                return False
                
        except Exception as e:
            logger.error(f"  ✗ Exception during repair: {e}")
            self._record_repair(agent.name, issue, f"Exception: {str(e)}", False)
            return False
    
    def _record_repair(self, agent_name: str, issue: str, action: str, success: bool):
        """Record repair action in history"""
        repair = RepairAction(
            timestamp=datetime.now(),
            agent_name=agent_name,
            issue=issue,
            action_taken=action,
            success=success
        )
        self.repair_history.append(repair)
        
        # Save to file
        history_file = LOG_DIR / "repair_history.json"
        history_data = {
            "repairs": [
                {
                    "timestamp": r.timestamp.isoformat(),
                    "agent": r.agent_name,
                    "issue": r.issue,
                    "action": r.action_taken,
                    "success": r.success
                }
                for r in self.repair_history[-100:]  # Keep last 100
            ]
        }
        history_file.write_text(json.dumps(history_data, indent=2))
    
    def scan_and_repair_all(self) -> Dict:
        """Scan all agents and repair failures using autonomous planning"""
        logger.info("🔍 Starting comprehensive AI agent health scan...")
        logger.info("🧠 Using autonomous planning for optimal repair strategy...")
        
        results = {
            "total_agents": len(self.agents),
            "healthy": 0,
            "repaired": 0,
            "failed_repairs": 0,
            "degraded": 0,
            "details": [],
            "autonomous_actions": []
        }
        
        # Create autonomous repair plan
        repair_plan_task = self.toolkit.create_task(
            description=f"Scan and repair {len(self.agents)} AI agents with priority-based execution",
            priority=TaskPriority.CRITICAL
        )
        
        # Sort by priority (highest first)
        sorted_agents = sorted(self.agents, key=lambda a: a.priority, reverse=True)
        
        for agent in sorted_agents:
            status, msg = self.check_agent_health(agent)
            
            detail = {
                "name": agent.name,
                "status": status.value,
                "message": msg,
                "priority": agent.priority
            }
            
            if status == ServiceStatus.HEALTHY:
                results["healthy"] += 1
                logger.info(f"✅ {agent.name}: {msg}")
                
            elif status == ServiceStatus.DEGRADED:
                results["degraded"] += 1
                logger.warning(f"⚠️  {agent.name}: {msg}")
                
                if agent.auto_restart:
                    if self.repair_agent(agent, msg):
                        results["repaired"] += 1
                        detail["repaired"] = True
                    else:
                        results["failed_repairs"] += 1
                        detail["repaired"] = False
            
            elif status in [ServiceStatus.FAILED, ServiceStatus.UNKNOWN]:
                logger.error(f"❌ {agent.name}: {msg}")
                
                if agent.auto_restart:
                    if self.repair_agent(agent, msg):
                        results["repaired"] += 1
                        detail["repaired"] = True
                    else:
                        results["failed_repairs"] += 1
                        detail["repaired"] = False
            
            results["details"].append(detail)
        
        return results
    
    def deploy_to_mobile(self, target: DeploymentTarget) -> bool:
        """Deploy AI agents to mobile device"""
        logger.info(f"📱 Deploying to {target.value}...")
        
        try:
            if target == DeploymentTarget.IPHONE:
                return self._deploy_to_iphone()
            elif target == DeploymentTarget.ANDROID:
                return self._deploy_to_android()
            elif target == DeploymentTarget.MESHTALK_DEVICE:
                return self._deploy_to_meshtalk()
            elif target == DeploymentTarget.DARCLOUD_MOBILE:
                return self._deploy_to_darcloud()
            else:
                logger.warning(f"Unknown deployment target: {target}")
                return False
        except Exception as e:
            logger.error(f"Deployment failed: {e}")
            return False
    
    def _deploy_to_iphone(self) -> bool:
        """Deploy to iPhone via DarCloud bridge"""
        logger.info("📱 Deploying to iPhone...")
        
        # Use the FORCE_IPHONE_CONNECTION system
        script = PROJECT_ROOT / "FORCE_IPHONE_CONNECTION.py"
        if script.exists():
            result = subprocess.run([sys.executable, str(script)], capture_output=True)
            return result.returncode == 0
        return False
    
    def _deploy_to_android(self) -> bool:
        """Deploy to Android via MeshTalk"""
        logger.info("📱 Deploying to Android...")
        
        # Deploy via MeshTalk gateway
        try:
            response = requests.post(
                "http://127.0.0.1:8091/deploy/android",
                json={"agents": [a.name for a in self.agents if a.mobile_compatible]},
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Android deployment failed: {e}")
            return False
    
    def _deploy_to_meshtalk(self) -> bool:
        """Deploy to MeshTalk device"""
        logger.info("📱 Deploying to MeshTalk Device...")
        
        # Deploy through MeshTalk OS network
        try:
            response = requests.post(
                "http://127.0.0.1:8090/deploy/meshtalk",
                json={"agents": [a.name for a in self.agents if a.mobile_compatible]},
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            logger.error(f"MeshTalk deployment failed: {e}")
            return False
    
    def _deploy_to_darcloud(self) -> bool:
        """Deploy to DarCloud mobile clients"""
        logger.info("☁️ Deploying to DarCloud Mobile...")
        
        # Deploy via DarCloud persistent AI service
        try:
            response = requests.post(
                "http://127.0.0.1:8888/deploy/mobile",
                json={"agents": [a.name for a in self.agents if a.mobile_compatible]},
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            logger.error(f"DarCloud deployment failed: {e}")
            return False
    
    def continuous_monitoring(self, interval: int = 300):
        """Run continuous monitoring and auto-repair"""
        logger.info(f"🔄 Starting continuous monitoring (interval: {interval}s)")
        
        cycle = 0
        while True:
            try:
                cycle += 1
                logger.info(f"\n{'='*60}")
                logger.info(f"🔍 Monitoring Cycle #{cycle}")
                logger.info(f"{'='*60}")
                
                results = self.scan_and_repair_all()
                
                logger.info(f"\n📊 Cycle Summary:")
                logger.info(f"   Total Agents: {results['total_agents']}")
                logger.info(f"   ✅ Healthy: {results['healthy']}")
                logger.info(f"   🔧 Repaired: {results['repaired']}")
                logger.info(f"   ❌ Failed Repairs: {results['failed_repairs']}")
                logger.info(f"   ⚠️  Degraded: {results['degraded']}")
                
                # Save cycle report
                report_file = LOG_DIR / f"cycle_{cycle}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                report_file.write_text(json.dumps(results, indent=2))
                
                time.sleep(interval)
                
            except KeyboardInterrupt:
                logger.info("\n⏹️  Monitoring stopped by user")
                break
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                time.sleep(60)


def main():
    """Main entry point"""
    print("""
╔════════════════════════════════════════════════════════════╗
║  🔧📱 QURANCHAIN AI MOBILE REPAIR SYSTEM                 ║
║                                                            ║
║  Auto-Repair & Deploy for All AI Programs                 ║
║  Founder: Omar Mohammad Abunadi™                          ║
╚════════════════════════════════════════════════════════════╝
    """)
    
    engine = AIRepairEngine()
    
    # Run initial scan and repair
    logger.info("🚀 Running initial health check and repair...")
    results = engine.scan_and_repair_all()
    
    print(f"\n📊 Initial Scan Results:")
    print(f"   Total Agents: {results['total_agents']}")
    print(f"   ✅ Healthy: {results['healthy']}")
    print(f"   🔧 Repaired: {results['repaired']}")
    print(f"   ❌ Failed Repairs: {results['failed_repairs']}")
    print(f"   ⚠️  Degraded: {results['degraded']}")
    
    # Deploy to mobile if requested
    if "--deploy-iphone" in sys.argv:
        engine.deploy_to_mobile(DeploymentTarget.IPHONE)
    if "--deploy-android" in sys.argv:
        engine.deploy_to_mobile(DeploymentTarget.ANDROID)
    if "--deploy-meshtalk" in sys.argv:
        engine.deploy_to_mobile(DeploymentTarget.MESHTALK_DEVICE)
    if "--deploy-darcloud" in sys.argv:
        engine.deploy_to_mobile(DeploymentTarget.DARCLOUD_MOBILE)
    
    # Start continuous monitoring if requested
    if "--monitor" in sys.argv or "--continuous" in sys.argv:
        interval = 300  # 5 minutes default
        if "--interval" in sys.argv:
            idx = sys.argv.index("--interval")
            interval = int(sys.argv[idx + 1])
        
        engine.continuous_monitoring(interval)
    
    logger.info("✅ AI Mobile Repair System completed")


if __name__ == "__main__":
    main()
