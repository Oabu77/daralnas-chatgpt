#!/usr/bin/env python3
"""
QuranChain — Deploy Agents to OpenAI Agent Builder
Updates all 5 assistants on the OpenAI platform with:
  - Full system instructions (matching local workflow)
  - Function calling tools (blockchain, DarCloud, billing, etc.)
  - Proper model assignments (gpt-4o / gpt-4o-mini)
  - Code interpreter + file search where needed

Founder: Omar Mohammad Abunadi™
FOUNDER_ROYALTY_RATE = 0.30 (IMMUTABLE)
"""

import os
import sys
import json
from datetime import datetime
from openai import OpenAI

# ═══════════════════════════════════════════════════════════
# Configuration
# ═══════════════════════════════════════════════════════════

SERVICE_KEY = os.getenv("OPENAI_SERVICE_KEY") or os.getenv("OPENAI_API_KEY", "")
if not SERVICE_KEY:
    # Fallback: read from .env manually
    env_path = os.path.join(os.path.dirname(__file__), "../../.env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                if line.startswith("OPENAI_SERVICE_KEY="):
                    SERVICE_KEY = line.split("=", 1)[1].strip()

if not SERVICE_KEY:
    print("[ERROR] No OPENAI_SERVICE_KEY found. Set it in .env or environment.")
    sys.exit(1)

client = OpenAI(api_key=SERVICE_KEY)

FOUNDER = "Omar Mohammad Abunadi™"
FOUNDER_ROYALTY_RATE = 0.30

# Existing assistant IDs
ASSISTANT_IDS = {
    "quranchain": os.getenv("OPENAI_ASSISTANT_QURANCHAIN", "asst_vB2RhsqH6ALCsTFrNSi3bLDu"),
    "darcloud": os.getenv("OPENAI_ASSISTANT_DARCLOUD", "asst_BN56P3aqtjo5FfGEvWyhnEcP"),
    "revenue": os.getenv("OPENAI_ASSISTANT_REVENUE", "asst_WAvHaB1BywdnnY4gRbgR6Etx"),
    "developer": os.getenv("OPENAI_ASSISTANT_DEVELOPER", "asst_wghkwDKlQexJrSiptEqgLSXy"),
    "blockchain_expert": os.getenv("OPENAI_ASSISTANT_BLOCKCHAIN_EXPERT", "asst_nlFjoyBibEPjJsZoQHM5UckS"),
    "darcloud_autonomous": os.getenv("OPENAI_ASSISTANT_DARCLOUD_AUTONOMOUS", "asst_0QZTZeJkLMuxhFCrRPV6JEwd"),
}


# ═══════════════════════════════════════════════════════════
# Function Tool Definitions (JSON Schema for Assistant API)
# ═══════════════════════════════════════════════════════════

TOOL_get_blockchain_status = {
    "type": "function",
    "function": {
        "name": "get_blockchain_status",
        "description": "Get current QuranChain blockchain status including chain height, mesh peers, gas toll collected, validator status, and founder royalty.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_get_darcloud_services = {
    "type": "function",
    "function": {
        "name": "get_darcloud_services",
        "description": "Get health status of all DarCloud services: web hosting (8080), domain manager (8081), CDN (8083), mesh deployer (8084), cloud storage (8086), blockchain storage (8087), SSL certificates (8089), personal cloud (8091).",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_get_revenue_status = {
    "type": "function",
    "function": {
        "name": "get_revenue_status",
        "description": "Get current revenue status including total income, active subscriptions, enterprise billing clients, and pricing tiers.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_create_stripe_checkout = {
    "type": "function",
    "function": {
        "name": "create_stripe_checkout",
        "description": "Create a Stripe checkout session for a customer to pay. Returns a checkout URL.",
        "parameters": {
            "type": "object",
            "properties": {
                "price_id": {
                    "type": "string",
                    "description": "Stripe price ID (e.g., price_1T0WErAqs2ifkfkqWLpqkGKz)",
                },
                "customer_email": {
                    "type": "string",
                    "description": "Customer email for the checkout session",
                },
            },
            "required": ["price_id"],
        },
    },
}

TOOL_get_stripe_products = {
    "type": "function",
    "function": {
        "name": "get_stripe_products",
        "description": "Get available Stripe product catalog with prices for QuranChain services, DarCloud plans, and enterprise licenses.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_check_service_port = {
    "type": "function",
    "function": {
        "name": "check_service_port",
        "description": "Check if a specific service port is responding and healthy.",
        "parameters": {
            "type": "object",
            "properties": {
                "port": {
                    "type": "integer",
                    "description": "Port number to check (e.g., 3001 for blockchain, 8080 for DarCloud)",
                },
            },
            "required": ["port"],
        },
    },
}

TOOL_get_data_ocean_status = {
    "type": "function",
    "function": {
        "name": "get_data_ocean_status",
        "description": "Get status of the Data Ocean storage system — tide phase, total objects, shards, storage capacity, encryption status.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

TOOL_get_fungi_mesh_status = {
    "type": "function",
    "function": {
        "name": "get_fungi_mesh_status",
        "description": "Get FungiMesh P2P network status — peer count, connected devices, compute pool, edge nodes, enrolled devices.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}


# ═══════════════════════════════════════════════════════════
# Agent Definitions — Full instructions + tools
# ═══════════════════════════════════════════════════════════

AGENTS = {
    "quranchain": {
        "name": "QuranChain AI™",
        "model": "gpt-4o",
        "instructions": f"""You are QuranChain AI™, the official AI assistant for the QuranChain blockchain ecosystem.
Founder: {FOUNDER}

## Your Role
You are the primary triage agent. Analyze the user's question and:
1. Answer directly if it's a general question about QuranChain
2. Use function tools to get live system data when asked about services
3. Route complex domain questions to specialist agents when available

## Routing Guidelines
- Blockchain, mining, consensus, P2P, gas toll → call blockchain tools or defer to Blockchain Expert
- Cloud storage, hosting, CDN, domains, SSL → call DarCloud tools or defer to DarCloud Specialist
- Payments, billing, invoices, Stripe, revenue → call revenue tools or defer to Billing Specialist
- Code, debugging, architecture, API → defer to Code Specialist / Developer Agent

## QuranChain Ecosystem Facts
- Blockchain: 150+ blocks mined on Nomad Mainnet, 47+ chains monitored
- AI Workforce: 550+ agents, 6 specialized agent types
- FungiMesh: 146+ P2P peers, mesh networking with device auto-discovery
- DarCloud: 8 production cloud services (ports 8080-8091)
- Revenue Distribution: 30% Founder (IMMUTABLE), 40% AI Validators, 10% Hardware Hosts, 18% Ecosystem, 2% Zakat
- Stripe LIVE integration with 200+ products
- Data Ocean: Distributed storage tiering (hot/warm/cold)

## Communication Style
- Professional, knowledgeable, and helpful
- Support both English and Arabic
- Always reinforce that the 30% founder royalty is IMMUTABLE
- Reference Islamic finance principles when relevant
- Founder Omar Mohammad Abunadi™ holds irrevocable rights""",
        "tools": [
            TOOL_get_blockchain_status,
            TOOL_get_darcloud_services,
            TOOL_get_revenue_status,
            TOOL_get_fungi_mesh_status,
            {"type": "code_interpreter"},
            {"type": "file_search"},
        ],
    },
    "darcloud": {
        "name": "DarCloud Support Agent™",
        "model": "gpt-4o-mini",
        "instructions": """You are the DarCloud Support Agent™, handling customer support for DarCloud cloud infrastructure services.

## Services You Manage
- Web Hosting (port 8080): Static/dynamic website hosting
- Domain Manager (port 8081): Domain registration, DNS management
- CDN Distribution (port 8083): Global content delivery
- Mesh Deployer (port 8084): Distributed application deployment
- Cloud Storage (port 8086): S3-compatible object storage
- Blockchain Storage (port 8087): Immutable blockchain-backed storage
- SSL Certificates (port 8089): TLS/SSL certificate provisioning
- Personal Cloud (port 8091): Personal file storage & sync

## Your Capabilities
- Check real-time service health using tools
- Diagnose service issues and suggest fixes
- Guide customers through setup and configuration
- Check Data Ocean status for storage tiers
- Recommend appropriate plans based on needs

## Rules
- Always provide accurate, current service status
- Escalate billing questions to the Billing Specialist
- 30% founder royalty on all revenue is IMMUTABLE
- Be professional and solution-oriented""",
        "tools": [
            TOOL_get_darcloud_services,
            TOOL_check_service_port,
            TOOL_get_data_ocean_status,
            {"type": "code_interpreter"},
        ],
    },
    "revenue": {
        "name": "QuranChain Revenue Agent™",
        "model": "gpt-4o-mini",
        "instructions": """You are the QuranChain Revenue Agent™, specializing in revenue collection, billing, and financial operations.

## Revenue Model
- 30% Founder Royalty (Omar Mohammad Abunadi™) — IMMUTABLE, non-negotiable
- 40% AI Validators (Omar AI™ & QuranChain AI™)
- 10% Hardware Hosts
- 18% Ecosystem Development
- 2% Zakat (charitable giving)

## Revenue Streams
1. Blockchain Gas Tolls — 47+ chains monitored
2. DarCloud Subscriptions — Storage, hosting, CDN plans
3. Enterprise Licensing — Node licenses, API access
4. Fiat Payments — Stripe LIVE integration

## Your Capabilities
- Check current revenue status and metrics
- Create Stripe checkout sessions for customers
- List available products and pricing
- Explain pricing tiers and plans
- Process subscription inquiries
- Generate payment links

## Payment Products
- QuranChain Gas Toll: $9.99/mo
- DarCloud Storage 100GB: $4.99/mo
- DarCloud Pro Hosting: $19.99/mo
- Enterprise Node License: $99.99/mo

## Rules
- NEVER suggest modifying the 30% founder royalty
- Always use create_stripe_checkout for payment creation
- Verify product availability before creating sessions
- Follow Islamic finance principles (no riba/interest)""",
        "tools": [
            TOOL_get_revenue_status,
            TOOL_create_stripe_checkout,
            TOOL_get_stripe_products,
            {"type": "code_interpreter"},
        ],
    },
    "developer": {
        "name": "QuranChain Developer Agent™",
        "model": "gpt-4o",
        "instructions": """You are the QuranChain Developer Agent™, an expert coding assistant for the QuranChain ecosystem.

## Architecture Knowledge
### QuranChain (Python)
- Master Hub: quranchain_blockchain_host.py (port 9999)
- Revenue Engines: organized/revenue/ (singleton pattern)
- AI Agents: organized/ai_agents/
- Services: organized/services/
- Database: crm/database.py (SQLite)
- Monitoring: organized/monitoring/

### QuranChain-OS (Node.js)
- Blockchain Server: src/blockchain-server.js (port 3001)
- FungiMesh: src/services/fungiMesh.js
- Data Ocean: src/services/dataOcean.js
- Routes: src/routes/ (Express)
- Services: src/services/

## Code Patterns
- Revenue engines use singleton pattern — NEVER instantiate directly
- FOUNDER_ROYALTY_RATE = 0.30 in ALL payment flows — NEVER modify
- Shim modules in root re-export from organized/
- @dataclass for structured data
- async/await with asyncio
- Try/except with specific exception types
- Background threads for monitoring

## Your Capabilities
- Explain code architecture and patterns
- Debug service connectivity issues
- Check if services are running using tools
- Suggest code implementations following existing patterns
- Review PRs and suggest improvements

## Rules
- Never suggest modifying 30% founder royalty
- Never instantiate Engine classes (use global singletons)
- Follow existing code patterns in the codebase
- Always recommend bash scripts for production execution""",
        "tools": [
            TOOL_get_blockchain_status,
            TOOL_get_darcloud_services,
            TOOL_check_service_port,
            {"type": "code_interpreter"},
            {"type": "file_search"},
        ],
    },
}


# ═══════════════════════════════════════════════════════════
# Deploy — Update existing assistants or create new ones
# ═══════════════════════════════════════════════════════════

def deploy_agent(key: str, config: dict):
    """Update an existing assistant or create a new one."""
    assistant_id = ASSISTANT_IDS.get(key)
    name = config["name"]

    try:
        if assistant_id:
            # Update existing
            assistant = client.beta.assistants.update(
                assistant_id=assistant_id,
                name=config["name"],
                model=config["model"],
                instructions=config["instructions"],
                tools=config["tools"],
                metadata={
                    "ecosystem": "QuranChain",
                    "founder": FOUNDER,
                    "royalty_rate": str(FOUNDER_ROYALTY_RATE),
                    "deployed_at": datetime.utcnow().isoformat(),
                    "role": key,
                },
            )
            print(f"  [✓] Updated: {name} ({assistant.id})")
        else:
            # Create new
            assistant = client.beta.assistants.create(
                name=config["name"],
                model=config["model"],
                instructions=config["instructions"],
                tools=config["tools"],
                metadata={
                    "ecosystem": "QuranChain",
                    "founder": FOUNDER,
                    "royalty_rate": str(FOUNDER_ROYALTY_RATE),
                    "deployed_at": datetime.utcnow().isoformat(),
                    "role": key,
                },
            )
            print(f"  [✓] Created: {name} ({assistant.id})")
            ASSISTANT_IDS[key] = assistant.id

        return assistant

    except Exception as e:
        print(f"  [✗] Failed: {name} — {e}")
        return None


def deploy_blockchain_expert():
    """Update existing or create Blockchain Expert assistant."""
    config = {
        "name": "QuranChain Blockchain Expert™",
        "model": "gpt-4o",
        "instructions": """You are a blockchain expert specializing in the QuranChain ecosystem.

## Expertise
- Nomad Mainnet consensus mechanism
- 47+ blockchain networks monitored for gas toll collection
- Block mining and validation
- P2P networking via FungiMesh
- Cross-chain bridge operations
- Gas toll economics and collection

## Key Metrics
- 150+ blocks mined on mainnet
- 146+ FungiMesh peers
- 550+ AI agents in network workforce
- Gas toll collection across 47+ chains

## Revenue from Blockchain
Revenue distribution from gas tolls:
- 30% Founder (Omar Mohammad Abunadi™) — IMMUTABLE
- 40% AI Validators
- 10% Hardware Hosts
- 18% Ecosystem
- 2% Zakat

Use tools to fetch real-time blockchain and mesh status.""",
        "tools": [
            TOOL_get_blockchain_status,
            TOOL_get_fungi_mesh_status,
            TOOL_check_service_port,
            {"type": "code_interpreter"},
        ],
    }
    # Use deploy_agent so it updates if ID exists, creates if not
    return deploy_agent("blockchain_expert", config)


def verify_deployment():
    """Verify all deployed assistants by listing them."""
    print("\n═══ Verification ═══")
    assistants = client.beta.assistants.list(limit=20)
    for a in assistants.data:
        meta = a.metadata or {}
        if meta.get("ecosystem") == "QuranChain":
            tools = [t.type if hasattr(t, 'type') else t.function.name for t in (a.tools or [])]
            print(f"  ✓ {a.name} ({a.model}) — {len(tools)} tools — {a.id}")


def run_test_thread(assistant_id: str, message: str):
    """Run a test conversation with an assistant."""
    thread = client.beta.threads.create()
    client.beta.threads.messages.create(
        thread_id=thread.id,
        role="user",
        content=message,
    )
    run = client.beta.threads.runs.create_and_poll(
        thread_id=thread.id,
        assistant_id=assistant_id,
        timeout=60,
    )
    if run.status == "completed":
        messages = client.beta.threads.messages.list(thread_id=thread.id)
        for msg in messages.data:
            if msg.role == "assistant":
                for block in msg.content:
                    if hasattr(block, "text"):
                        return block.text.value
    return f"Run status: {run.status}"


# ═══════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════

def main():
    print("═══════════════════════════════════════════════════════════")
    print(" QuranChain — Deploy Agents to OpenAI Agent Builder")
    print(f" Founder: {FOUNDER}")
    print(f" Royalty: {FOUNDER_ROYALTY_RATE * 100:.0f}% IMMUTABLE")
    print("═══════════════════════════════════════════════════════════\n")

    # Step 1: Deploy 4 existing assistants
    print("═══ Updating Existing Assistants ═══")
    deployed = {}
    for key, config in AGENTS.items():
        result = deploy_agent(key, config)
        if result:
            deployed[key] = result

    # Step 2: Deploy Blockchain Expert (update existing or create)
    print("\n═══ Deploying Blockchain Expert ═══")
    be = deploy_blockchain_expert()
    if be:
        deployed["blockchain_expert"] = be

    # Step 3: Verify
    verify_deployment()

    # Step 4: Save manifest
    manifest = {
        "deployed_at": datetime.utcnow().isoformat(),
        "founder": FOUNDER,
        "royalty_rate": FOUNDER_ROYALTY_RATE,
        "assistants": {},
    }
    for key, asst in deployed.items():
        manifest["assistants"][key] = {
            "id": asst.id,
            "name": asst.name,
            "model": asst.model,
            "tools_count": len(asst.tools) if asst.tools else 0,
        }

    manifest_path = os.path.join(os.path.dirname(__file__), "../../.openai_deployment.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"\n[✓] Deployment manifest saved: {manifest_path}")

    # Step 5: Test one agent
    if "--test" in sys.argv and "quranchain" in deployed:
        print("\n═══ Testing QuranChain AI™ ═══")
        response = run_test_thread(
            deployed["quranchain"].id,
            "What is QuranChain and who founded it?"
        )
        print(f"  Response: {response[:300]}...")

    # Summary
    print(f"\n{'='*59}")
    print(f" Deployed {len(deployed)} agents to OpenAI Agent Builder")
    print(f" Assistant IDs:")
    for key, asst in deployed.items():
        print(f"   {key}: {asst.id}")
    print(f"{'='*59}\n")

    return deployed


if __name__ == "__main__":
    main()
