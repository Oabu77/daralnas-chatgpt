#!/usr/bin/env python3
"""
QuranChain AI™ — SDK Client Library
External applications use this to connect to the Agent Workflow.

Usage:
    from quranchain_agent_sdk import QuranChainAgentClient

    client = QuranChainAgentClient("http://localhost:9200")
    response = client.chat("What is QuranChain?")
    print(response)

    # Async
    async with QuranChainAgentClient("http://localhost:9200") as client:
        response = await client.achat("Check DarCloud status")

Founder: Omar Mohammad Abunadi™
FOUNDER_ROYALTY_RATE = 0.30 (IMMUTABLE)
"""

import json
import asyncio
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field, asdict

logger = logging.getLogger("quranchain-sdk")

# ═══════════════════════════════════════════════════════════
# Response Models
# ═══════════════════════════════════════════════════════════

@dataclass
class AgentResponse:
    """Response from the agent workflow."""
    success: bool
    response: str
    agent: str = ""
    error: str = ""
    context: Dict[str, Any] = field(default_factory=dict)

    @property
    def text(self) -> str:
        return self.response

    def __str__(self) -> str:
        return self.response

    def __bool__(self) -> bool:
        return self.success


@dataclass
class AgentInfo:
    """Agent metadata."""
    name: str
    model: str
    role: str
    capabilities: List[str] = field(default_factory=list)
    assistant_id: str = ""


@dataclass
class ServiceStatus:
    """Service health status."""
    name: str
    port: int
    status: str
    healthy: bool = False


# ═══════════════════════════════════════════════════════════
# Synchronous Client
# ═══════════════════════════════════════════════════════════

class QuranChainAgentClient:
    """
    SDK client for the QuranChain AI Agent Workflow API.
    
    Supports both sync and async usage:
        client = QuranChainAgentClient()
        client.chat("Hello")           # sync
        await client.achat("Hello")    # async
    """

    def __init__(self, base_url: str = "http://localhost:9200", timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = None
        self._conversation: List[Dict] = []

    # ─── Sync methods ───────────────────────────────────

    def chat(self, message: str, user_id: str = "sdk_user", language: str = "en") -> AgentResponse:
        """Send a message and get a response."""
        import requests
        try:
            r = requests.post(
                f"{self.base_url}/api/agents/chat",
                json={"message": message, "user_id": user_id, "language": language},
                timeout=self.timeout,
            )
            data = r.json()
            return AgentResponse(
                success=data.get("success", False),
                response=data.get("response", ""),
                agent=data.get("agent", ""),
                error=data.get("error", ""),
                context=data.get("context", {}),
            )
        except Exception as e:
            return AgentResponse(success=False, response="", error=str(e))

    def conversation(self, message: str, user_id: str = "sdk_user") -> AgentResponse:
        """Multi-turn conversation — maintains history."""
        import requests
        self._conversation.append({"role": "user", "content": message})
        try:
            r = requests.post(
                f"{self.base_url}/api/agents/conversation",
                json={"messages": self._conversation, "user_id": user_id},
                timeout=self.timeout,
            )
            data = r.json()
            if data.get("success"):
                self._conversation.append({"role": "assistant", "content": data["response"]})
            return AgentResponse(
                success=data.get("success", False),
                response=data.get("response", ""),
                error=data.get("error", ""),
            )
        except Exception as e:
            return AgentResponse(success=False, response="", error=str(e))

    def list_agents(self) -> List[AgentInfo]:
        """List all available agents."""
        import requests
        try:
            r = requests.get(f"{self.base_url}/api/agents/list", timeout=self.timeout)
            data = r.json()
            return [
                AgentInfo(
                    name=a["name"], model=a["model"], role=a["role"],
                    capabilities=a.get("capabilities", []),
                    assistant_id=a.get("assistant_id", ""),
                ) for a in data.get("agents", [])
            ]
        except:
            return []

    def health(self) -> Dict[str, Any]:
        """Check server health."""
        import requests
        try:
            return requests.get(f"{self.base_url}/health", timeout=5).json()
        except:
            return {"status": "unreachable"}

    def service_status(self) -> List[ServiceStatus]:
        """Get status of all backend services."""
        import requests
        try:
            r = requests.get(f"{self.base_url}/api/agents/status", timeout=self.timeout)
            data = r.json()
            return [
                ServiceStatus(
                    name=name,
                    port=info.get("port", 0),
                    status=info.get("status", "unknown"),
                    healthy=info.get("status") == "UP",
                ) for name, info in data.get("services", {}).items()
            ]
        except:
            return []

    def reset_conversation(self):
        """Clear conversation history."""
        self._conversation.clear()

    # ─── Async methods ──────────────────────────────────

    async def achat(self, message: str, user_id: str = "sdk_user", language: str = "en") -> AgentResponse:
        """Async: Send a message and get a response."""
        import aiohttp
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    f"{self.base_url}/api/agents/chat",
                    json={"message": message, "user_id": user_id, "language": language},
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                ) as r:
                    data = await r.json()
                    return AgentResponse(
                        success=data.get("success", False),
                        response=data.get("response", ""),
                        agent=data.get("agent", ""),
                        error=data.get("error", ""),
                        context=data.get("context", {}),
                    )
            except Exception as e:
                return AgentResponse(success=False, response="", error=str(e))

    async def aconversation(self, message: str, user_id: str = "sdk_user") -> AgentResponse:
        """Async: Multi-turn conversation."""
        import aiohttp
        self._conversation.append({"role": "user", "content": message})
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    f"{self.base_url}/api/agents/conversation",
                    json={"messages": self._conversation, "user_id": user_id},
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                ) as r:
                    data = await r.json()
                    if data.get("success"):
                        self._conversation.append({"role": "assistant", "content": data["response"]})
                    return AgentResponse(
                        success=data.get("success", False),
                        response=data.get("response", ""),
                        error=data.get("error", ""),
                    )
            except Exception as e:
                return AgentResponse(success=False, response="", error=str(e))

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


# ═══════════════════════════════════════════════════════════
# Convenience — run from command line
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    client = QuranChainAgentClient()
    h = client.health()
    print(f"Server: {h.get('status', 'unknown')}")

    if len(sys.argv) > 1:
        msg = " ".join(sys.argv[1:])
    else:
        msg = "What is QuranChain?"

    print(f"\nYou: {msg}")
    resp = client.chat(msg)
    if resp.success:
        print(f"Agent ({resp.agent}): {resp.response}")
    else:
        print(f"Error: {resp.error}")
