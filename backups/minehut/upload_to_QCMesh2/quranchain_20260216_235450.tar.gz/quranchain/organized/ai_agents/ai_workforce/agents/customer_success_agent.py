"""
Customer Success AI Agent - Client Retention & Growth
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- Customer onboarding assistance
- Usage analytics and optimization recommendations
- Churn prediction and prevention
- Upsell/cross-sell opportunities
- Customer feedback analysis
- Support ticket prioritization

Constraints:
- Human oversight for sensitive customer interactions
- Privacy compliance (GDPR, CCPA)
- No unsolicited contact without consent
"""

import asyncio
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import uuid
import re

import sys
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from organized.ai_agents.ai_workforce.core.base_agent import (
    BaseAgent, AgentAction, ActionType, ApprovalLevel, AgentStatus
)
from organized.ai_agents.ai_workforce.core.message_bus import get_message_bus, Message, MessagePriority


@dataclass
class CustomerProfile:
    """Customer profile and engagement data"""
    customer_id: str
    name: str
    email: str
    company: Optional[str]
    signup_date: str
    last_login: str
    usage_score: int  # 0-100
    satisfaction_score: int  # 0-100
    churn_risk: str  # low, medium, high
    lifetime_value: float
    support_tickets: int
    feature_usage: Dict[str, int]
    status: str  # active, at_risk, churned


@dataclass
class SupportTicket:
    """Customer support ticket"""
    ticket_id: str
    customer_id: str
    subject: str
    description: str
    priority: str  # low, medium, high, urgent
    status: str  # open, in_progress, resolved, closed
    category: str
    assigned_agent: Optional[str]
    created_at: str
    resolved_at: Optional[str]
    satisfaction_rating: Optional[int]


@dataclass
class GrowthOpportunity:
    """Upsell/cross-sell opportunity"""
    opportunity_id: str
    customer_id: str
    opportunity_type: str  # upsell, cross_sell, expansion
    product_service: str
    estimated_value: float
    confidence_score: int  # 0-100
    timeline: str  # immediate, short_term, long_term
    status: str  # identified, proposed, accepted, rejected


class CustomerSuccessAgent(BaseAgent):
    """
    Customer Success AI Agent for client retention and growth.

    This agent:
    - Monitors customer usage and satisfaction
    - Predicts and prevents churn
    - Identifies upsell/cross-sell opportunities
    - Prioritizes support tickets
    - Provides personalized recommendations
    """

    def __init__(self, agent_id: str):
        super().__init__(agent_id, "Customer Success AI")
        self.customers: Dict[str, CustomerProfile] = {}
        self.tickets: Dict[str, SupportTicket] = {}
        self.opportunities: Dict[str, GrowthOpportunity] = {}
        self.db_path = f"/home/omar/Desktop/QuranChain/prod_databases/customer_success_{agent_id}.db"
        self._init_database()

    def _init_database(self):
        """Initialize customer success database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            # Customers table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS customers (
                    customer_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL,
                    company TEXT,
                    signup_date TEXT,
                    last_login TEXT,
                    usage_score INTEGER,
                    satisfaction_score INTEGER,
                    churn_risk TEXT,
                    lifetime_value REAL,
                    support_tickets INTEGER,
                    feature_usage TEXT,
                    status TEXT
                )
            ''')

            # Support tickets table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS support_tickets (
                    ticket_id TEXT PRIMARY KEY,
                    customer_id TEXT,
                    subject TEXT,
                    description TEXT,
                    priority TEXT,
                    status TEXT,
                    category TEXT,
                    assigned_agent TEXT,
                    created_at TEXT,
                    resolved_at TEXT,
                    satisfaction_rating INTEGER,
                    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
                )
            ''')

            # Growth opportunities table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS growth_opportunities (
                    opportunity_id TEXT PRIMARY KEY,
                    customer_id TEXT,
                    opportunity_type TEXT,
                    product_service TEXT,
                    estimated_value REAL,
                    confidence_score INTEGER,
                    timeline TEXT,
                    status TEXT,
                    created_at TEXT,
                    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
                )
            ''')

            conn.commit()

    async def run_cycle(self) -> Dict[str, Any]:
        """Run customer success operations cycle"""
        if not self.is_active:
            return {"status": "inactive"}

        cycle_results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions_taken": [],
            "metrics": self.get_metrics()
        }

        try:
            # Analyze customer health
            health_analysis = await self._analyze_customer_health()
            cycle_results["customer_health_analysis"] = health_analysis

            # Predict churn risk
            churn_predictions = await self._predict_churn_risk()
            cycle_results["churn_predictions"] = churn_predictions

            # Identify growth opportunities
            opportunities = await self._identify_growth_opportunities()
            cycle_results["growth_opportunities"] = opportunities

            # Prioritize support tickets
            ticket_priorities = await self._prioritize_support_tickets()
            cycle_results["ticket_priorities"] = ticket_priorities

            # Generate personalized recommendations
            recommendations = await self._generate_recommendations()
            cycle_results["recommendations"] = recommendations

            cycle_results["status"] = "completed"

        except Exception as e:
            cycle_results["status"] = "error"
            cycle_results["error"] = str(e)

        cycle_results["cycle_end"] = datetime.utcnow().isoformat()
        return cycle_results

    async def _analyze_customer_health(self) -> Dict[str, Any]:
        """Analyze overall customer health"""
        # Mock analysis - in production would analyze real usage data
        health_scores = {
            "healthy_customers": 85,
            "at_risk_customers": 12,
            "unhealthy_customers": 3,
            "average_satisfaction": 4.2,
            "average_usage_score": 78
        }

        # Create actions for at-risk customers
        for customer_id, customer in self.customers.items():
            if customer.churn_risk == "high":
                action = AgentAction(
                    action_id=str(uuid.uuid4()),
                    action_type=ActionType.CUSTOMER_OUTREACH,
                    description=f"High churn risk customer: {customer.name}",
                    priority=MessagePriority.HIGH,
                    approval_level=ApprovalLevel.MANAGER,
                    metadata={
                        "customer_id": customer_id,
                        "risk_level": "high",
                        "recommended_action": "personalized_outreach"
                    }
                )
                await self.submit_action(action)

        return health_scores

    async def _predict_churn_risk(self) -> List[Dict[str, Any]]:
        """Predict customer churn risk"""
        predictions = []

        for customer_id, customer in self.customers.items():
            # Simple churn prediction logic
            risk_factors = 0

            if customer.usage_score < 50:
                risk_factors += 2
            if customer.satisfaction_score < 70:
                risk_factors += 2
            if customer.support_tickets > 5:
                risk_factors += 1
            if (datetime.utcnow() - datetime.fromisoformat(customer.last_login)).days > 30:
                risk_factors += 2

            if risk_factors >= 4:
                risk_level = "high"
            elif risk_factors >= 2:
                risk_level = "medium"
            else:
                risk_level = "low"

            # Update customer risk
            customer.churn_risk = risk_level

            predictions.append({
                "customer_id": customer_id,
                "name": customer.name,
                "current_risk": risk_level,
                "risk_factors": risk_factors,
                "confidence": min(95, 60 + (risk_factors * 10))
            })

        return predictions

    async def _identify_growth_opportunities(self) -> List[Dict[str, Any]]:
        """Identify upsell and cross-sell opportunities"""
        opportunities = []

        for customer_id, customer in self.customers.items():
            # Mock opportunity identification
            if customer.usage_score > 80 and customer.lifetime_value < 10000:
                # High usage but low LTV - potential for premium services
                opportunity = GrowthOpportunity(
                    opportunity_id=str(uuid.uuid4()),
                    customer_id=customer_id,
                    opportunity_type="upsell",
                    product_service="Premium Support Package",
                    estimated_value=299.99,
                    confidence_score=85,
                    timeline="short_term",
                    status="identified"
                )

                self.opportunities[opportunity.opportunity_id] = opportunity

                opportunities.append({
                    "opportunity_id": opportunity.opportunity_id,
                    "customer_name": customer.name,
                    "type": opportunity.opportunity_type,
                    "product": opportunity.product_service,
                    "estimated_value": opportunity.estimated_value,
                    "confidence": opportunity.confidence_score
                })

        return opportunities

    async def _prioritize_support_tickets(self) -> List[Dict[str, Any]]:
        """Prioritize support tickets based on customer value and urgency"""
        prioritized_tickets = []

        for ticket_id, ticket in self.tickets.items():
            if ticket.status != "open":
                continue

            # Calculate priority score
            priority_score = 0

            # Customer lifetime value factor
            customer = self.customers.get(ticket.customer_id)
            if customer:
                priority_score += min(50, customer.lifetime_value / 200)  # Max 50 points

            # Urgency factor
            if ticket.priority == "urgent":
                priority_score += 40
            elif ticket.priority == "high":
                priority_score += 30
            elif ticket.priority == "medium":
                priority_score += 20
            else:
                priority_score += 10

            # Category factor
            if ticket.category in ["billing", "security", "data_loss"]:
                priority_score += 20

            ticket.priority_score = priority_score
            prioritized_tickets.append({
                "ticket_id": ticket_id,
                "subject": ticket.subject,
                "customer_name": self.customers.get(ticket.customer_id, {}).get("name", "Unknown"),
                "priority_score": priority_score,
                "category": ticket.category,
                "created_at": ticket.created_at
            })

        # Sort by priority score descending
        prioritized_tickets.sort(key=lambda x: x["priority_score"], reverse=True)

        return prioritized_tickets[:10]  # Top 10

    async def _generate_recommendations(self) -> List[Dict[str, Any]]:
        """Generate personalized customer recommendations"""
        recommendations = []

        for customer_id, customer in self.customers.items():
            recs = []

            # Usage-based recommendations
            if customer.usage_score < 60:
                recs.append({
                    "type": "usage_optimization",
                    "title": "Increase Feature Adoption",
                    "description": "Consider using advanced features to maximize value",
                    "priority": "medium"
                })

            # Support-based recommendations
            if customer.support_tickets > 3:
                recs.append({
                    "type": "support_optimization",
                    "title": "Consider Premium Support",
                    "description": "Reduce resolution time with priority support",
                    "priority": "high"
                })

            # Growth recommendations
            if customer.lifetime_value < 5000:
                recs.append({
                    "type": "growth_opportunity",
                    "title": "Explore Advanced Features",
                    "description": "Unlock additional capabilities with premium plans",
                    "priority": "medium"
                })

            if recs:
                recommendations.append({
                    "customer_id": customer_id,
                    "customer_name": customer.name,
                    "recommendations": recs
                })

        return recommendations

    def get_metrics(self) -> Dict[str, Any]:
        """Get customer success metrics"""
        total_customers = len(self.customers)
        active_customers = sum(1 for c in self.customers.values() if c.status == "active")
        at_risk_customers = sum(1 for c in self.customers.values() if c.churn_risk in ["medium", "high"])
        open_tickets = sum(1 for t in self.tickets.values() if t.status in ["open", "in_progress"])

        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "total_customers": total_customers,
            "active_customers": active_customers,
            "at_risk_customers": at_risk_customers,
            "customer_retention_rate": (active_customers / total_customers * 100) if total_customers > 0 else 0,
            "open_support_tickets": open_tickets,
            "average_satisfaction": sum(c.satisfaction_score for c in self.customers.values()) / total_customers if total_customers > 0 else 0,
            "total_opportunities": len(self.opportunities),
            "revenue_attributed": 0.0,  # Would be calculated from actual data
            "commission_earned": 0.0,   # Would be calculated from actual data
            "tasks_executed": 0,        # Would be tracked
            "last_updated": datetime.utcnow().isoformat()
        }

    def add_customer(self, customer_data: Dict[str, Any]) -> str:
        """Add a new customer"""
        customer_id = str(uuid.uuid4())

        customer = CustomerProfile(
            customer_id=customer_id,
            name=customer_data.get("name", ""),
            email=customer_data.get("email", ""),
            company=customer_data.get("company"),
            signup_date=datetime.utcnow().isoformat(),
            last_login=datetime.utcnow().isoformat(),
            usage_score=customer_data.get("usage_score", 50),
            satisfaction_score=customer_data.get("satisfaction_score", 80),
            churn_risk="low",
            lifetime_value=customer_data.get("lifetime_value", 0.0),
            support_tickets=0,
            feature_usage=customer_data.get("feature_usage", {}),
            status="active"
        )

        self.customers[customer_id] = customer

        # Save to database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO customers
                (customer_id, name, email, company, signup_date, last_login,
                 usage_score, satisfaction_score, churn_risk, lifetime_value,
                 support_tickets, feature_usage, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                customer.customer_id, customer.name, customer.email, customer.company,
                customer.signup_date, customer.last_login, customer.usage_score,
                customer.satisfaction_score, customer.churn_risk, customer.lifetime_value,
                customer.support_tickets, json.dumps(customer.feature_usage), customer.status
            ))
            conn.commit()

        return customer_id

    def create_support_ticket(self, ticket_data: Dict[str, Any]) -> str:
        """Create a new support ticket"""
        ticket_id = str(uuid.uuid4())

        ticket = SupportTicket(
            ticket_id=ticket_id,
            customer_id=ticket_data.get("customer_id", ""),
            subject=ticket_data.get("subject", ""),
            description=ticket_data.get("description", ""),
            priority=ticket_data.get("priority", "medium"),
            status="open",
            category=ticket_data.get("category", "general"),
            assigned_agent=None,
            created_at=datetime.utcnow().isoformat(),
            resolved_at=None,
            satisfaction_rating=None
        )

        self.tickets[ticket_id] = ticket

        # Update customer support ticket count
        if ticket.customer_id in self.customers:
            self.customers[ticket.customer_id].support_tickets += 1

        # Save to database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO support_tickets
                (ticket_id, customer_id, subject, description, priority, status,
                 category, assigned_agent, created_at, resolved_at, satisfaction_rating)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                ticket.ticket_id, ticket.customer_id, ticket.subject, ticket.description,
                ticket.priority, ticket.status, ticket.category, ticket.assigned_agent,
                ticket.created_at, ticket.resolved_at, ticket.satisfaction_rating
            ))
            conn.commit()

        return ticket_id