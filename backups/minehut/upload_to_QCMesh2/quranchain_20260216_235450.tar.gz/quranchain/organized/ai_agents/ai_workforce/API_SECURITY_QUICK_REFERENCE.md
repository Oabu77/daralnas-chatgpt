# Agent API Security - Quick Reference Card

© QuranChain™ | Omar Mohammad Abunadi™

## 🔐 What's New

All 7 AI agents now automatically secure their own APIs with enterprise-grade security.

**Files Added:**
- `core/api_security.py` - Security components
- `core/security_config.py` - Configuration
- `core/security_integration.py` - Flask integration
- `AGENT_API_SECURITY_GUIDE.md` - Full guide
- `INTEGRATION_TEMPLATE.py` - How to integrate
- This file - Quick reference

## 🚀 Quick Start (3 Steps)

### Step 1: Update Agent Flask App Creation
```python
from ai_workforce.core.security_integration import create_secured_flask_app

app = Flask(__name__)
app, security_mgr = create_secured_flask_app(
    agent_id=agent.agent_id,
    agent_name="Marketing AI",
    app=app
)
# Done! Security is enabled.
```

### Step 2: Generate API Key for External Services
```python
api_key = security_mgr.generate_api_key(
    "webhook_processor",
    expires_in_days=90,
    permissions=["leads.create", "campaigns.view"]
)
```

### Step 3: Use API Key in Requests
```python
requests.post(
    "http://localhost:7300/lead/capture",
    json={"email": "user@example.com", "name": "John"},
    headers={"X-API-Key": api_key}
)
```

## 📊 Security Levels

| Level | Auth | Signature | Rate Limit | Example |
|-------|------|-----------|-----------|---------|
| **Public** | None | No | 1000/hr | `/health` |
| **Authenticated** | API Key/JWT | No | 100/hr | `/lead/capture` |
| **Authorized** | API Key/JWT | No | 50/hr | `/campaign/draft` |
| **Critical** | API Key/JWT | Yes | 10/hr | `/campaign/deploy` |

## 🔑 Authentication Methods

### API Key (Simplest)
```bash
curl -H "X-API-Key: qc_marketing_..." http://localhost:7300/lead/capture
```

### JWT Token
```bash
curl -H "Authorization: Bearer eyJ0eXAi..." http://localhost:7300/analytics
```

### Request Signing (Most Secure)
```python
sig_headers = security_mgr.sign_request("POST", "/deploy", body)
headers = {
    "X-API-Key": api_key,
    "X-Signature": sig_headers["X-Signature"],
    "X-Timestamp": sig_headers["X-Timestamp"]
}
```

## 🎯 Common Tasks

### Generate API Key
```python
key = security_mgr.generate_api_key(
    "service_name",
    expires_in_days=90,
    permissions=["leads.create", "metrics.view"]
)
```

### Create JWT Token
```python
token = security_mgr.create_jwt_token(
    data={"user_id": "123", "role": "admin"},
    expires_in_hours=24
)
```

### Check API Keys
```python
keys = security_mgr.get_api_keys()
for key in keys:
    print(f"{key['name']}: {key['created_at']}")
```

### Revoke API Key
```python
security_mgr.revoke_api_key("old_service_name")
```

### View Security Report
```python
report = security_mgr.get_security_report()
print(json.dumps(report, indent=2))
```

### Update Rate Limit
```python
from ai_workforce.core.security_config import SecurityConfigManager
config_mgr = SecurityConfigManager()
config_mgr.update_config(
    "marketing_ai",
    {"default_rate_limit": 200}
)
```

## 📋 Standard Permissions

**Read Only:**
- `health.check`
- `metrics.view`
- `analytics.view`
- `leads.view`

**Write:**
- `leads.create`
- `campaigns.create`
- `campaigns.edit`
- `campaigns.deploy` (critical)
- `deals.close` (critical)

**Admin:**
- `api_keys.manage`
- `security.configure`
- `services.restart` (critical)
- `logs.view`

## ⚠️ Rate Limits

**Default**: 100 requests/hour per API key

**Overrides:**
- `/health` → 1000/hour (public)
- `/campaign/deploy` → 10/hour (critical)
- `/analytics/attribution` → 100/hour

**When Limited**: HTTP 429 response
```json
{
  "error": "Rate limit exceeded",
  "limit": 100,
  "remaining": 0,
  "reset_at": 1673432400
}
```

## 🔍 Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| "Authentication required" | Missing API key or JWT | Add `X-API-Key` or `Authorization` header |
| "Invalid or expired token" | Token expired or key revoked | Get new token/key |
| "Permission denied" | Missing required permission | Generate key with required permission |
| "Rate limit exceeded" | Too many requests | Wait for reset time or increase limit |
| "Invalid signature" | Bad HMAC signature | Verify signing method |

## 🛡️ Security Best Practices

✅ **Do:**
- Rotate API keys every 90 days
- Use specific permissions (least privilege)
- Monitor failed auth attempts
- Set expiration on all keys
- Log all API access

❌ **Don't:**
- Commit API keys to git
- Use same key for multiple services
- Share keys over email/chat
- Create keys without expiration
- Ignore rate limit errors

## 📞 Support

| Question | Answer |
|----------|--------|
| How do I generate a key? | `security_mgr.generate_api_key(...)` |
| Which auth method to use? | API Key for services, JWT for web/mobile |
| How to set permissions? | Specify in `generate_api_key(..., permissions=[...])` |
| What if I exceed rate limit? | Wait until `reset_at` time or get limit increased |
| How to debug failed auth? | Check agent logs for "auth_failed" entries |

## 📖 Full Documentation

- **Complete Guide**: `AGENT_API_SECURITY_GUIDE.md`
- **Implementation Examples**: `AGENT_SECURITY_IMPLEMENTATION.py`
- **Integration Template**: `INTEGRATION_TEMPLATE.py`
- **Code API Docs**: `core/api_security.py` docstrings

## 🚨 Critical Security Files

| File | Purpose | Protection |
|------|---------|-----------|
| `.agent_keys/` | API key storage | 0600 permissions |
| `.agent_security_configs/` | Security configs | 0600 permissions |
| Agent logs | Access audit trail | Append-only |

⚠️ **Remember**: Never commit `.agent_keys/` or `.agent_security_configs/` to git!

## ✅ Implementation Checklist

Agent updates needed:
- [ ] Marketing AI (7300)
- [ ] Sales AI (7301)
- [ ] Onboarding AI (9003)
- [ ] Optimization AI (9004)
- [ ] IT Ops AI (9005)
- [ ] Security AI (9006)
- [ ] Orchestrator (9090)

For each agent:
- [ ] Add import: `from ai_workforce.core.security_integration import create_secured_flask_app`
- [ ] Add security wrap: `app, security_mgr = create_secured_flask_app(...)`
- [ ] Generate initial API keys for external services
- [ ] Update services calling agent APIs to use API keys
- [ ] Test endpoints with API key headers
- [ ] Monitor security logs

## 🎓 Learning Path

1. **Read**: This quick reference (5 min)
2. **Study**: `AGENT_API_SECURITY_GUIDE.md` (15 min)
3. **Code**: `INTEGRATION_TEMPLATE.py` (10 min)
4. **Implement**: Update one agent (10 min)
5. **Test**: Call agent API with API key (5 min)
6. **Scale**: Update remaining agents (30 min)
7. **Monitor**: Check logs and metrics (ongoing)

---

**Last Updated**: 2024-01-13  
**Status**: Production Ready  
**Version**: 1.0  

🔐 **All agents now secure their own APIs automatically!** 🚀
