"""
QuranChain™ IT Operations AI Agent
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- Service health monitoring
- Auto-healing (restart failed services)
- Backup validation
- CI/CD management
- Infrastructure cost tracking
- Governance enforcement

Constraints:
- Production deployments require approval
- Cannot modify governance rules
- Must respect kill-switch
"""

import os
import sys
import json
import subprocess
import psutil
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
import requests
import time

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from organized.ai_agents.ai_workforce.shared.base_agent import (
    BaseAIAgent, AgentType, ActionSeverity,
    COPYRIGHT, FOUNDER_ROYALTY_RATE
)


# ═══════════════════════════════════════════════════════════════
# SERVICE DEFINITIONS
# ═══════════════════════════════════════════════════════════════

SERVICES = {
    "quranchain_core": {"port": 5006, "critical": True},
    "fungi_mesh": {"port": 6000, "critical": False},
    "multi_currency": {"port": 6001, "critical": False},
    "takaful_insurance": {"port": 7070, "critical": True},
    "dar_al_nas_api": {"port": 7080, "critical": True},
    "meshtalk_telecom": {"port": 7090, "critical": False},
    "stripe_integration": {"port": 7200, "critical": True},
    "twilio_gateway": {"port": 7201, "critical": False},
    "quranchain_pay": {"port": 8080, "critical": True},
    "gateway_api": {"port": 8088, "critical": True},
    "quantum_blockchain": {"port": 9999, "critical": False},
    # AI Workforce agents
    "marketing_ai": {"port": 7300, "critical": False},
    "sales_ai": {"port": 7301, "critical": False},
    "onboarding_ai": {"port": 7302, "critical": False},
    "optimization_ai": {"port": 7303, "critical": False},
}


@dataclass
class ServiceStatus:
    """Service health status"""
    name: str
    port: int
    status: str  # healthy, unhealthy, down
    response_time_ms: Optional[float]
    last_check: str
    uptime_percent: float


@dataclass
class Incident:
    """System incident"""
    id: str
    service: str
    severity: str  # critical, warning, info
    description: str
    detected_at: str
    resolved_at: Optional[str]
    auto_remediated: bool


class ITOpsAI(BaseAIAgent):
    """
    IT Operations AI Agent.
    
    Monitors, maintains, and auto-heals the QuranChain infrastructure.
    """
    
    def __init__(self, agent_id: Optional[str] = None):
        super().__init__(AgentType.IT_OPS, agent_id)
        self.incidents: List[Incident] = []
        self.service_history: Dict[str, List[Dict]] = {name: [] for name in SERVICES}
    
    def _execute_internal(self, action: str, details: Dict[str, Any]) -> Any:
        """Execute IT ops actions"""
        
        if action == "health_check":
            return self._health_check(details)
        elif action == "check_all_services":
            return self._check_all_services()
        elif action == "restart_service":
            return self._restart_service(details)
        elif action == "auto_heal":
            return self._auto_heal(details)
        elif action == "validate_backups":
            return self._validate_backups()
        elif action == "check_disk_space":
            return self._check_disk_space()
        elif action == "check_memory":
            return self._check_memory()
        elif action == "get_system_metrics":
            return self._get_system_metrics()
        elif action == "check_governance":
            return self._check_governance()
        elif action == "generate_status_report":
            return self._generate_status_report()
        else:
            raise ValueError(f"Unknown action: {action}")
    
    def _health_check(self, details: Dict) -> Dict:
        """Check health of a specific service"""
        service_name = details.get("service")
        service_config = SERVICES.get(service_name)
        
        if not service_config:
            return {"success": False, "reason": "unknown_service"}
        
        port = service_config["port"]
        start_time = time.time()
        
        try:
            response = requests.get(
                f"http://localhost:{port}/health",
                timeout=5
            )
            response_time = (time.time() - start_time) * 1000
            
            if response.status_code == 200:
                status = "healthy"
            else:
                status = "unhealthy"
        except requests.exceptions.ConnectionError:
            status = "down"
            response_time = None
        except requests.exceptions.Timeout:
            status = "unhealthy"
            response_time = 5000
        
        result = ServiceStatus(
            name=service_name,
            port=port,
            status=status,
            response_time_ms=response_time,
            last_check=datetime.utcnow().isoformat(),
            uptime_percent=self._calculate_uptime(service_name)
        )
        
        # Record in history
        self.service_history[service_name].append({
            "status": status,
            "response_time": response_time,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        # Keep only last 100 checks
        self.service_history[service_name] = self.service_history[service_name][-100:]
        
        self.logger.info(f"Health check {service_name}: {status}")
        
        return {
            "success": True,
            "service": service_name,
            "port": port,
            "status": status,
            "response_time_ms": response_time,
            "critical": service_config["critical"]
        }
    
    def _calculate_uptime(self, service_name: str) -> float:
        """Calculate uptime percentage from history"""
        history = self.service_history.get(service_name, [])
        if not history:
            return 100.0
        
        healthy_count = sum(1 for h in history if h["status"] == "healthy")
        return (healthy_count / len(history)) * 100
    
    def _check_all_services(self) -> Dict:
        """Check health of all services"""
        results = {}
        critical_down = []
        warnings = []
        
        for service_name, config in SERVICES.items():
            check = self._health_check({"service": service_name})
            results[service_name] = check
            
            if check["status"] == "down":
                if config["critical"]:
                    critical_down.append(service_name)
                else:
                    warnings.append(service_name)
            elif check["status"] == "unhealthy":
                warnings.append(service_name)
        
        # Count by status
        healthy = sum(1 for r in results.values() if r["status"] == "healthy")
        unhealthy = sum(1 for r in results.values() if r["status"] == "unhealthy")
        down = sum(1 for r in results.values() if r["status"] == "down")
        
        return {
            "success": True,
            "summary": {
                "total": len(SERVICES),
                "healthy": healthy,
                "unhealthy": unhealthy,
                "down": down
            },
            "critical_down": critical_down,
            "warnings": warnings,
            "services": results,
            "checked_at": datetime.utcnow().isoformat()
        }
    
    def _restart_service(self, details: Dict) -> Dict:
        """
        Restart a service.
        CAUTION: Critical services require approval.
        """
        service_name = details.get("service")
        service_config = SERVICES.get(service_name)
        
        if not service_config:
            return {"success": False, "reason": "unknown_service"}
        
        # Critical services need higher approval
        if service_config["critical"] and not details.get("approved"):
            self.logger.warning(f"Critical service restart requires approval: {service_name}")
            return {
                "success": False,
                "reason": "requires_approval",
                "message": f"Restarting critical service {service_name} requires human approval"
            }
        
        # Attempt restart
        self.logger.info(f"Attempting to restart {service_name}")
        
        # Create incident
        incident = Incident(
            id=f"INC{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            service=service_name,
            severity="warning",
            description=f"Service restart initiated",
            detected_at=datetime.utcnow().isoformat(),
            resolved_at=None,
            auto_remediated=True
        )
        self.incidents.append(incident)
        
        # In production, this would actually restart the service
        # For now, we simulate success
        restart_success = True  # Would check actual restart
        
        if restart_success:
            incident.resolved_at = datetime.utcnow().isoformat()
            self.logger.info(f"Service {service_name} restarted successfully")
        
        return {
            "success": restart_success,
            "service": service_name,
            "incident_id": incident.id,
            "message": "Service restart initiated" if restart_success else "Restart failed"
        }
    
    def _auto_heal(self, details: Dict) -> Dict:
        """
        Automatically heal failing services.
        Only non-critical services are auto-healed.
        """
        healed = []
        failed = []
        skipped = []
        
        # Check all services
        all_status = self._check_all_services()
        
        for service_name, status in all_status["services"].items():
            if status["status"] != "healthy":
                config = SERVICES[service_name]
                
                if config["critical"]:
                    # Don't auto-heal critical services
                    skipped.append({
                        "service": service_name,
                        "reason": "critical_service_requires_approval"
                    })
                    self.logger.warning(f"Skipping auto-heal for critical service: {service_name}")
                else:
                    # Attempt auto-heal
                    restart = self._restart_service({
                        "service": service_name,
                        "approved": False  # Non-critical can be auto-approved
                    })
                    
                    if restart.get("success"):
                        healed.append(service_name)
                    else:
                        failed.append(service_name)
        
        return {
            "success": True,
            "healed": healed,
            "failed": failed,
            "skipped": skipped,
            "summary": f"Healed {len(healed)}, Failed {len(failed)}, Skipped {len(skipped)}"
        }
    
    def _validate_backups(self) -> Dict:
        """Validate backup integrity"""
        backup_dir = os.path.expanduser("~/Desktop/QuranChain/backups")
        
        backups = []
        if os.path.exists(backup_dir):
            for filename in os.listdir(backup_dir):
                filepath = os.path.join(backup_dir, filename)
                if os.path.isfile(filepath):
                    stat = os.stat(filepath)
                    backups.append({
                        "filename": filename,
                        "size_mb": stat.st_size / (1024 * 1024),
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                    })
        
        # Check for recent backup
        recent_backup = False
        if backups:
            latest = max(backups, key=lambda x: x["modified"])
            latest_time = datetime.fromisoformat(latest["modified"])
            recent_backup = (datetime.utcnow() - latest_time).days < 1
        
        return {
            "success": True,
            "backup_count": len(backups),
            "backups": backups,
            "recent_backup_exists": recent_backup,
            "backup_directory": backup_dir,
            "validated_at": datetime.utcnow().isoformat()
        }
    
    def _check_disk_space(self) -> Dict:
        """Check disk space usage"""
        disk = psutil.disk_usage("/")
        
        warning = disk.percent > 80
        critical = disk.percent > 90
        
        return {
            "success": True,
            "total_gb": disk.total / (1024**3),
            "used_gb": disk.used / (1024**3),
            "free_gb": disk.free / (1024**3),
            "percent_used": disk.percent,
            "status": "critical" if critical else ("warning" if warning else "healthy"),
            "checked_at": datetime.utcnow().isoformat()
        }
    
    def _check_memory(self) -> Dict:
        """Check memory usage"""
        mem = psutil.virtual_memory()
        
        warning = mem.percent > 80
        critical = mem.percent > 90
        
        return {
            "success": True,
            "total_gb": mem.total / (1024**3),
            "used_gb": mem.used / (1024**3),
            "available_gb": mem.available / (1024**3),
            "percent_used": mem.percent,
            "status": "critical" if critical else ("warning" if warning else "healthy"),
            "checked_at": datetime.utcnow().isoformat()
        }
    
    def _get_system_metrics(self) -> Dict:
        """Get comprehensive system metrics"""
        cpu_percent = psutil.cpu_percent(interval=1)
        
        return {
            "success": True,
            "cpu_percent": cpu_percent,
            "memory": self._check_memory(),
            "disk": self._check_disk_space(),
            "load_average": os.getloadavg() if hasattr(os, "getloadavg") else None,
            "process_count": len(psutil.pids()),
            "collected_at": datetime.utcnow().isoformat()
        }
    
    def _check_governance(self) -> Dict:
        """Check governance system health"""
        governance_checks = {
            "kill_switch_responsive": False,
            "approval_system_active": False,
            "logging_active": True,
            "royalty_enforcement": True
        }
        
        # Check kill switch
        try:
            from organized.ai_agents.ai_workforce.shared.base_agent import GovernanceChecker
            gc = GovernanceChecker()
            governance_checks["kill_switch_responsive"] = True
            governance_checks["kill_switch_active"] = gc.check_kill_switch()
            governance_checks["approval_system_active"] = True
        except Exception as e:
            self.logger.error(f"Governance check failed: {e}")
        
        compliant = all([
            governance_checks["kill_switch_responsive"],
            governance_checks["approval_system_active"],
            governance_checks["logging_active"],
            governance_checks["royalty_enforcement"]
        ])
        
        return {
            "success": True,
            "checks": governance_checks,
            "compliant": compliant,
            "checked_at": datetime.utcnow().isoformat()
        }
    
    def _generate_status_report(self) -> Dict:
        """Generate comprehensive system status report"""
        services = self._check_all_services()
        system = self._get_system_metrics()
        governance = self._check_governance()
        backups = self._validate_backups()
        
        report = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    SYSTEM STATUS REPORT                                       ║
║                    {COPYRIGHT}                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║ Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}                                        ║
╠══════════════════════════════════════════════════════════════════════════════╣

SERVICE HEALTH
────────────────────────────────────────────────────────────────────────────────
Total Services: {services['summary']['total']}
Healthy: {services['summary']['healthy']} ✅
Unhealthy: {services['summary']['unhealthy']} ⚠️
Down: {services['summary']['down']} ❌

Critical Services Down: {', '.join(services['critical_down']) or 'None'}

SYSTEM RESOURCES
────────────────────────────────────────────────────────────────────────────────
CPU Usage: {system['cpu_percent']:.1f}%
Memory: {system['memory']['percent_used']:.1f}% ({system['memory']['used_gb']:.1f}/{system['memory']['total_gb']:.1f} GB)
Disk: {system['disk']['percent_used']:.1f}% ({system['disk']['used_gb']:.1f}/{system['disk']['total_gb']:.1f} GB)

GOVERNANCE STATUS
────────────────────────────────────────────────────────────────────────────────
Kill Switch: {'🔴 ACTIVE' if governance['checks'].get('kill_switch_active') else '🟢 INACTIVE'}
Approval System: {'✅ Active' if governance['checks']['approval_system_active'] else '❌ Down'}
Logging: {'✅ Active' if governance['checks']['logging_active'] else '❌ Down'}
Royalty Enforcement: {'✅ Active' if governance['checks']['royalty_enforcement'] else '❌ Down'}
Overall: {'✅ COMPLIANT' if governance['compliant'] else '❌ NON-COMPLIANT'}

BACKUP STATUS
────────────────────────────────────────────────────────────────────────────────
Backup Count: {backups['backup_count']}
Recent Backup: {'✅ Yes' if backups['recent_backup_exists'] else '⚠️ No recent backup'}

RECENT INCIDENTS
────────────────────────────────────────────────────────────────────────────────
"""
        for incident in self.incidents[-5:]:
            status = "✅ Resolved" if incident.resolved_at else "🔴 Open"
            report += f"  [{incident.severity.upper()}] {incident.service}: {incident.description} - {status}\n"
        
        if not self.incidents:
            report += "  No recent incidents\n"
        
        report += """
════════════════════════════════════════════════════════════════════════════════
"""
        return {
            "success": True,
            "report": report,
            "services": services,
            "system": system,
            "governance": governance,
            "backups": backups
        }
    
    def run_cycle(self) -> Dict[str, Any]:
        """Run one IT ops cycle"""
        results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions": []
        }
        
        # Check all services
        services = self.execute_action("check_all_services", {}, ActionSeverity.LOW)
        results["actions"].append({"action": "check_all_services", "result": services})
        
        # Auto-heal if needed
        if services.get("result", {}).get("summary", {}).get("down", 0) > 0:
            heal = self.execute_action("auto_heal", {}, ActionSeverity.MEDIUM)
            results["actions"].append({"action": "auto_heal", "result": heal})
        
        # Check system resources
        system = self.execute_action("get_system_metrics", {}, ActionSeverity.LOW)
        results["actions"].append({"action": "system_metrics", "result": system})
        
        # Check governance
        governance = self.execute_action("check_governance", {}, ActionSeverity.HIGH)
        results["actions"].append({"action": "check_governance", "result": governance})
        
        results["cycle_end"] = datetime.utcnow().isoformat()
        results["metrics"] = self.get_metrics()
        
        return results


# ═══════════════════════════════════════════════════════════════
# IT OPS AI SERVICE
# ═══════════════════════════════════════════════════════════════

from flask import Flask, request, jsonify

def create_itops_api(agent: ITOpsAI) -> Flask:
    """Create Flask API for IT Ops AI"""
    app = Flask(__name__)
    
    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({
            "status": "healthy",
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type.value,
            "copyright": COPYRIGHT
        })
    
    @app.route("/services", methods=["GET"])
    def check_all_services():
        """Check all service health"""
        result = agent.execute_action("check_all_services", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/service/<service_name>", methods=["GET"])
    def check_service(service_name):
        """Check specific service health"""
        result = agent.execute_action(
            "health_check",
            {"service": service_name},
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/service/<service_name>/restart", methods=["POST"])
    def restart_service(service_name):
        """Restart a service"""
        data = request.json or {}
        result = agent.execute_action(
            "restart_service",
            {"service": service_name, "approved": data.get("approved", False)},
            ActionSeverity.HIGH
        )
        return jsonify(result)
    
    @app.route("/auto-heal", methods=["POST"])
    def auto_heal():
        """Trigger auto-heal"""
        result = agent.execute_action("auto_heal", {}, ActionSeverity.MEDIUM)
        return jsonify(result)
    
    @app.route("/system/metrics", methods=["GET"])
    def system_metrics():
        """Get system metrics"""
        result = agent.execute_action("get_system_metrics", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/system/disk", methods=["GET"])
    def disk_space():
        """Check disk space"""
        result = agent.execute_action("check_disk_space", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/system/memory", methods=["GET"])
    def memory_usage():
        """Check memory usage"""
        result = agent.execute_action("check_memory", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/backups", methods=["GET"])
    def validate_backups():
        """Validate backups"""
        result = agent.execute_action("validate_backups", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/governance", methods=["GET"])
    def check_governance():
        """Check governance health"""
        result = agent.execute_action("check_governance", {}, ActionSeverity.HIGH)
        return jsonify(result)
    
    @app.route("/report", methods=["GET"])
    def get_report():
        """Get full status report"""
        result = agent.execute_action("generate_status_report", {}, ActionSeverity.LOW)
        if result.get("success"):
            return result["result"]["report"], 200, {"Content-Type": "text/plain"}
        return jsonify(result)
    
    @app.route("/incidents", methods=["GET"])
    def get_incidents():
        """Get recent incidents"""
        return jsonify({
            "incidents": [
                {
                    "id": i.id,
                    "service": i.service,
                    "severity": i.severity,
                    "description": i.description,
                    "detected_at": i.detected_at,
                    "resolved_at": i.resolved_at,
                    "auto_remediated": i.auto_remediated
                }
                for i in agent.incidents[-20:]
            ]
        })
    
    @app.route("/metrics", methods=["GET"])
    def get_metrics():
        """Get agent metrics"""
        return jsonify(agent.get_metrics())
    
    return app


if __name__ == "__main__":
    print(f"Starting IT Operations AI Agent")
    print(COPYRIGHT)
    
    agent = ITOpsAI()
    app = create_itops_api(agent)
    
    print(f"\nAgent ID: {agent.agent_id}")
    print(f"Monitoring {len(SERVICES)} services")
    print(f"\nStarting API on port 9005...")
    
    app.run(host="0.0.0.0", port=9005, debug=False)
