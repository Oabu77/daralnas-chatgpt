"""
Agent API Security Implementation Guide & Examples
© QuranChain™ | Omar Mohammad Abunadi™

Shows how to integrate API security into agent Flask applications.
All agents follow this pattern for consistent, automatic security.
"""

from flask import Flask, request, jsonify
from typing import Optional
import logging

# Example: How to secure a Marketing AI agent's API

# OPTION 1: MINIMAL INTEGRATION (recommended for most agents)
def create_secure_marketing_api_minimal(agent) -> Flask:
    """
    Minimal integration: Add security to existing Flask app
    
    This is the simplest way to add security - just wrap your app creation
    """
    from ai_workforce.core.security_integration import (
        AgentAPISecurityManager, create_secured_flask_app
    )
    
    # Create your Flask app normally
    app = Flask(__name__)
    
    # Wrap it with security - that's it!
    app, security_mgr = create_secured_flask_app(
        agent_id=agent.agent_id,
        agent_name="Marketing AI",
        app=app
    )
    
    # Your routes now have automatic security
    @app.route("/health", methods=["GET"])
    def health():
        """Public endpoint - no auth required"""
        return jsonify({"status": "healthy"})
    
    @app.route("/lead/capture", methods=["POST"])
    def capture_lead():
        """Protected endpoint - requires API key or JWT"""
        # Security is applied automatically!
        data = request.json
        return jsonify({"captured": True, "lead_id": "lead_123"})
    
    @app.route("/campaign/deploy", methods=["POST"])
    def deploy_campaign():
        """Critical endpoint - requires signature verification"""
        # Signature is verified automatically!
        data = request.json
        return jsonify({"deployed": True})
    
    # Return both app and security manager
    return app, security_mgr


# OPTION 2: FULL CONTROL INTEGRATION (for complex security needs)
def create_secure_marketing_api_full(agent) -> Flask:
    """
    Full control: Explicitly apply security to specific endpoints
    
    Use this for fine-grained control over endpoint security
    """
    from ai_workforce.core.security_integration import AgentAPISecurityManager
    
    # Create Flask app
    app = Flask(__name__)
    
    # Create security manager (separate from app)
    security_mgr = AgentAPISecurityManager(
        agent_id=agent.agent_id,
        agent_name="Marketing AI"
    )
    
    # Apply global security settings (headers, CORS, logging)
    security_mgr.apply_security(app)
    
    # Public endpoints - no protection needed
    @app.route("/health", methods=["GET"])
    def health():
        """Public health check"""
        return jsonify({"status": "healthy"})
    
    # Protected endpoints - manually apply security
    @app.route("/lead/capture", methods=["POST"])
    def capture_lead():
        """Protected with authentication"""
        protected = security_mgr.protect_endpoint(
            lambda: _capture_lead_impl(request.json),
            "/lead/capture"
        )
        return protected()
    
    @app.route("/campaign/deploy", methods=["POST"])
    def deploy_campaign():
        """Protected with authentication AND signature verification"""
        protected = security_mgr.protect_endpoint(
            lambda: _deploy_campaign_impl(request.json),
            "/campaign/deploy"
        )
        return protected()
    
    return app, security_mgr


def _capture_lead_impl(data):
    """Implementation of lead capture logic"""
    return jsonify({
        "captured": True,
        "lead_id": "lead_123",
        "timestamp": "2024-01-13T10:00:00Z"
    })


def _deploy_campaign_impl(data):
    """Implementation of campaign deployment logic"""
    return jsonify({
        "deployed": True,
        "campaign_id": "camp_456"
    })


# USAGE EXAMPLES FOR EXTERNAL SERVICES

def example_external_service_setup():
    """
    How external services authenticate to agent APIs
    """
    
    print("\n" + "="*80)
    print("EXTERNAL SERVICE AUTHENTICATION EXAMPLES")
    print("="*80)
    
    # SCENARIO 1: Using API Key
    print("\n1. USING API KEY")
    print("-" * 40)
    print("""
External service (e.g., webhook processor):
    
    import requests
    
    # Get API key from security manager
    api_key = security_mgr.generate_api_key(
        key_name="webhook_processor",
        expires_in_days=90,
        permissions=["leads.create", "campaigns.view"]
    )
    
    # Use API key in requests
    response = requests.post(
        "http://localhost:7300/lead/capture",
        json={"email": "user@example.com", "name": "John"},
        headers={"X-API-Key": api_key}
    )
    """)
    
    # SCENARIO 2: Using JWT
    print("\n2. USING JWT TOKEN")
    print("-" * 40)
    print("""
External service:
    
    # Get JWT token from security manager
    token = security_mgr.create_jwt_token(
        data={"service": "dashboard", "role": "viewer"},
        expires_in_hours=24
    )
    
    # Use JWT in Authorization header
    response = requests.get(
        "http://localhost:7300/analytics/attribution",
        headers={"Authorization": f"Bearer {token}"}
    )
    """)
    
    # SCENARIO 3: Using Request Signing
    print("\n3. USING REQUEST SIGNING (HMAC)")
    print("-" * 40)
    print("""
External service (for critical operations):
    
    import requests
    import json
    
    # Prepare request
    method = "POST"
    path = "/campaign/deploy"
    body = json.dumps({"campaign_id": "camp_123"})
    
    # Get signature headers from security manager
    sig_headers = security_mgr.sign_request(method, path, body)
    
    # Use API key + signature for maximum security
    response = requests.post(
        "http://localhost:7300/campaign/deploy",
        data=body,
        headers={
            "X-API-Key": api_key,
            "X-Signature": sig_headers["X-Signature"],
            "X-Timestamp": sig_headers["X-Timestamp"],
            "Content-Type": "application/json"
        }
    )
    """)


def example_endpoint_configuration():
    """
    How to configure security for different endpoint types
    """
    
    print("\n" + "="*80)
    print("ENDPOINT SECURITY CONFIGURATION EXAMPLES")
    print("="*80)
    
    config_examples = {
        "/health": {
            "security_level": "public",
            "description": "No auth required, high rate limit (public info)",
            "rate_limit": 1000
        },
        "/lead/capture": {
            "security_level": "authenticated",
            "description": "API key or JWT required (create data)",
            "rate_limit": 50
        },
        "/campaign/draft": {
            "security_level": "authorized",
            "description": "API key required + specific permission check",
            "rate_limit": 20,
            "required_permission": "campaigns.create"
        },
        "/campaign/deploy": {
            "security_level": "critical",
            "description": "API key + JWT + request signature required",
            "rate_limit": 10,
            "require_signature": True,
            "required_permission": "campaigns.deploy"
        }
    }
    
    for endpoint, config in config_examples.items():
        print(f"\n{endpoint}")
        print(f"  Security Level: {config['security_level']}")
        print(f"  Description:   {config['description']}")
        print(f"  Rate Limit:    {config['rate_limit']} req/hour")
        if config.get("required_permission"):
            print(f"  Permission:    {config['required_permission']}")
        if config.get("require_signature"):
            print(f"  Requires:      HMAC signature + timestamp")


def example_permissions_system():
    """
    How to use permissions for fine-grained access control
    """
    
    print("\n" + "="*80)
    print("PERMISSIONS SYSTEM EXAMPLES")
    print("="*80)
    
    # Define permission sets
    permission_sets = {
        "viewer": {
            "description": "Read-only access",
            "permissions": [
                "health.check",
                "metrics.view",
                "analytics.view"
            ]
        },
        "operator": {
            "description": "Can create and manage campaigns",
            "permissions": [
                "health.check",
                "metrics.view",
                "analytics.view",
                "leads.create",
                "campaigns.create",
                "campaigns.view",
                "campaigns.edit"
            ]
        },
        "admin": {
            "description": "Full access",
            "permissions": [
                "health.check",
                "metrics.view",
                "analytics.view",
                "leads.create",
                "leads.delete",
                "campaigns.create",
                "campaigns.edit",
                "campaigns.delete",
                "campaigns.deploy",
                "api_keys.manage",
                "security.configure"
            ]
        }
    }
    
    for role, config in permission_sets.items():
        print(f"\n{role.upper()}")
        print(f"  {config['description']}")
        for perm in config['permissions']:
            print(f"    • {perm}")


def example_security_report():
    """
    Example of security report from agent
    """
    
    print("\n" + "="*80)
    print("AGENT SECURITY REPORT EXAMPLE")
    print("="*80)
    
    report = {
        "agent_id": "marketing_ai_7300",
        "agent_name": "Marketing AI",
        "authentication": {
            "api_keys_enabled": True,
            "jwt_enabled": True,
            "request_signing_enabled": True,
            "active_api_keys": 5
        },
        "rate_limiting": {
            "default_limit": 100,
            "window_seconds": 3600
        },
        "protected_endpoints": 8,
        "cors": {
            "allowed_origins": ["https://quranchain.com", "https://dashboard.quranchain.com"],
            "allow_credentials": True
        },
        "recent_activity": {
            "auth_failures_24h": 3,
            "rate_limit_hits_24h": 0,
            "api_keys_created_24h": 2,
            "api_keys_revoked_24h": 0
        }
    }
    
    import json
    print(json.dumps(report, indent=2))


def example_api_key_rotation():
    """
    Best practice: Regular API key rotation
    """
    
    print("\n" + "="*80)
    print("API KEY ROTATION BEST PRACTICES")
    print("="*80)
    
    print("""
1. SET EXPIRATION
   • New keys: expires_in_days=90
   • Critical services: expires_in_days=30
   • Never use non-expiring keys in production

2. ROTATION SCHEDULE
   • Monthly: Review and rotate all API keys
   • Quarterly: Rotate all service account keys
   • Immediately: If key is suspected compromised

3. IMPLEMENTATION
   api_key_1 = security_mgr.generate_api_key(
       key_name="service_v1",
       expires_in_days=90,
       permissions=["leads.create"]
   )
   
   # When rotating
   api_key_2 = security_mgr.generate_api_key(
       key_name="service_v2",
       expires_in_days=90,
       permissions=["leads.create"]
   )
   
   # Update service, then revoke old key
   security_mgr.revoke_api_key("service_v1")

4. MONITORING
   # Check for soon-to-expire keys
   keys = security_mgr.get_api_keys()
   for key in keys:
       if needs_rotation(key['expires_at']):
           alert_team(key['name'])
    """)


def example_logging_and_monitoring():
    """
    Security logging and monitoring setup
    """
    
    print("\n" + "="*80)
    print("LOGGING AND MONITORING EXAMPLES")
    print("="*80)
    
    print("""
AUTOMATIC LOGGING:
  ✓ All requests logged with method, path, remote_addr
  ✓ Authentication method tracked (API key vs JWT)
  ✓ Rate limit violations logged
  ✓ Failed authentication attempts logged
  ✓ Request signatures verified and logged

MONITORING QUERIES:
  1. Recent auth failures
     SELECT * FROM agent_logs WHERE event='auth_failed' 
     ORDER BY timestamp DESC LIMIT 100
  
  2. API key usage
     SELECT api_key_name, COUNT(*) as requests 
     FROM agent_logs WHERE auth_method='api_key'
     GROUP BY api_key_name
  
  3. Rate limit violations
     SELECT identifier, COUNT(*) as violations
     FROM rate_limit_logs WHERE violation=True
     GROUP BY identifier
  
  4. Endpoint access patterns
     SELECT path, method, COUNT(*) as requests
     FROM agent_logs
     GROUP BY path, method
     ORDER BY requests DESC

ALERTS TO SET UP:
  • 10+ failed auth attempts in 5 minutes → Investigate
  • Rate limit exceeded 100+ times in hour → Check DDoS
  • New API key created → Log and notify ops
  • API key revoked → Ensure service updated
    """)


if __name__ == "__main__":
    print("\n🔐 QuranChain Agent API Security - Implementation Guide\n")
    
    example_endpoint_configuration()
    example_permissions_system()
    example_security_report()
    example_external_service_setup()
    example_api_key_rotation()
    example_logging_and_monitoring()
    
    print("\n" + "="*80)
    print("For detailed integration, see:")
    print("  • ai_workforce/core/api_security.py")
    print("  • ai_workforce/core/security_config.py")
    print("  • ai_workforce/core/security_integration.py")
    print("="*80 + "\n")
