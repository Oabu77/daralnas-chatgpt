"""
Base AI Agent Framework
© QuranChain™ | Omar Mohammad Abunadi™

All AI agents inherit from this base class which enforces:
- Governance compliance
- Kill-switch integration
- Audit logging
- Rate limiting
- Human approval gates
"""

import asyncio
import json
import hashlib
import sqlite3
from datetime import datetime, timedelta
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional, Dict, List, Any, Callable
from pathlib import Path
import logging
import uuid

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


class AgentStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"
    KILLED = "killed"
    AWAITING_APPROVAL = "awaiting_approval"


class ActionType(Enum):
    READ = "read"
    WRITE = "write"
    SEND = "send"
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    TRANSFER = "transfer"
    APPROVE = "approve"


class ApprovalLevel(Enum):
    NONE = 0          # Auto-approved
    LOW = 1           # Logged only
    MEDIUM = 2        # Requires async approval
    HIGH = 3          # Requires sync approval (blocks)
    CRITICAL = 4      # Requires root approval + MFA


@dataclass
class AgentAction:
    """Represents a single action taken by an agent"""
    action_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = ""
    action_type: ActionType = ActionType.READ
    description: str = ""
    target: str = ""
    data: Dict = field(default_factory=dict)
    approval_level: ApprovalLevel = ApprovalLevel.NONE
    approved: bool = False
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    executed: bool = False
    executed_at: Optional[str] = None
    result: Optional[Dict] = None
    error: Optional[str] = None
    revenue_impact: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class AgentMetrics:
    """Metrics tracked for each agent"""
    tasks_executed: int = 0
    tasks_failed: int = 0
    leads_generated: int = 0
    deals_influenced: int = 0
    deals_closed: int = 0
    revenue_attributed: float = 0.0
    errors: int = 0
    escalations: int = 0
    uptime_seconds: float = 0.0
    cost_incurred: float = 0.0
    
    @property
    def roi(self) -> float:
        if self.cost_incurred == 0:
            return 0.0
        return (self.revenue_attributed - self.cost_incurred) / self.cost_incurred * 100


class BaseAgent(ABC):
    """
    Base class for all AI workforce agents.
    
    Enforces:
    - Governance rules
    - Kill-switch compliance
    - Audit logging
    - Rate limiting
    - Human approval gates
    """
    
    # Class-level kill switch
    _global_kill_switch = False
    
    def __init__(
        self,
        agent_id: str,
        agent_name: str,
        agent_type: str,
        db_path: str = "/home/omar/Desktop/QuranChain/ai_workforce/workforce.db",
        max_actions_per_minute: int = 60,
        max_revenue_action: float = 1000.0,  # Requires approval above this
        owner: str = "Omar Mohammad Abunadi"
    ):
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.agent_type = agent_type
        self.db_path = db_path
        self.max_actions_per_minute = max_actions_per_minute
        self.max_revenue_action = max_revenue_action
        self.owner = owner
        
        self.status = AgentStatus.IDLE
        self.metrics = AgentMetrics()
        self.logger = logging.getLogger(f"Agent.{agent_name}")
        self.started_at: Optional[datetime] = None
        self._action_timestamps: List[datetime] = []
        self._pending_approvals: Dict[str, AgentAction] = {}
        
        # Initialize database
        self._init_database()
        self._register_agent()
    
    def _init_database(self):
        """Initialize SQLite database for agent data"""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Agents table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agents (
                agent_id TEXT PRIMARY KEY,
                agent_name TEXT NOT NULL,
                agent_type TEXT NOT NULL,
                status TEXT DEFAULT 'idle',
                owner TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_active TEXT,
                config TEXT
            )
        """)
        
        # Actions audit log
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS actions (
                action_id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                action_type TEXT NOT NULL,
                description TEXT,
                target TEXT,
                data TEXT,
                approval_level INTEGER,
                approved INTEGER DEFAULT 0,
                approved_by TEXT,
                approved_at TEXT,
                executed INTEGER DEFAULT 0,
                executed_at TEXT,
                result TEXT,
                error TEXT,
                revenue_impact REAL DEFAULT 0,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (agent_id) REFERENCES agents(agent_id)
            )
        """)
        
        # Metrics history
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                metrics TEXT NOT NULL,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (agent_id) REFERENCES agents(agent_id)
            )
        """)
        
        # Pending approvals
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pending_approvals (
                action_id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                action_data TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT,
                status TEXT DEFAULT 'pending',
                FOREIGN KEY (agent_id) REFERENCES agents(agent_id)
            )
        """)
        
        # Kill switch state
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS kill_switch (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                active INTEGER DEFAULT 0,
                activated_by TEXT,
                activated_at TEXT,
                reason TEXT
            )
        """)
        
        # Insert default kill switch state if not exists
        cursor.execute("""
            INSERT OR IGNORE INTO kill_switch (id, active) VALUES (1, 0)
        """)
        
        conn.commit()
        conn.close()
    
    def _register_agent(self):
        """Register agent in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO agents (agent_id, agent_name, agent_type, owner, status)
            VALUES (?, ?, ?, ?, ?)
        """, (self.agent_id, self.agent_name, self.agent_type, self.owner, self.status.value))
        
        conn.commit()
        conn.close()
        self.logger.info(f"Agent {self.agent_name} registered with ID {self.agent_id}")
    
    def check_kill_switch(self) -> bool:
        """Check if kill switch is active"""
        if BaseAgent._global_kill_switch:
            return True
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT active FROM kill_switch WHERE id = 1")
        result = cursor.fetchone()
        conn.close()
        
        return result[0] == 1 if result else False
    
    def activate_kill_switch(self, reason: str, activated_by: str = "system"):
        """Activate the kill switch"""
        BaseAgent._global_kill_switch = True
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE kill_switch SET active = 1, activated_by = ?, activated_at = ?, reason = ?
            WHERE id = 1
        """, (activated_by, datetime.utcnow().isoformat(), reason))
        conn.commit()
        conn.close()
        
        self.logger.critical(f"KILL SWITCH ACTIVATED by {activated_by}: {reason}")
        self.status = AgentStatus.KILLED
    
    def deactivate_kill_switch(self, deactivated_by: str):
        """Deactivate kill switch (requires root approval)"""
        BaseAgent._global_kill_switch = False
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE kill_switch SET active = 0 WHERE id = 1")
        conn.commit()
        conn.close()
        
        self.logger.info(f"Kill switch deactivated by {deactivated_by}")
    
    def _check_rate_limit(self) -> bool:
        """Check if agent is within rate limits"""
        now = datetime.utcnow()
        minute_ago = now - timedelta(minutes=1)
        
        # Clean old timestamps
        self._action_timestamps = [
            ts for ts in self._action_timestamps if ts > minute_ago
        ]
        
        return len(self._action_timestamps) < self.max_actions_per_minute
    
    def _record_action(self, action: AgentAction):
        """Record action to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO actions (
                action_id, agent_id, action_type, description, target, data,
                approval_level, approved, approved_by, approved_at, executed,
                executed_at, result, error, revenue_impact, timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            action.action_id,
            action.agent_id,
            action.action_type.value,
            action.description,
            action.target,
            json.dumps(action.data),
            action.approval_level.value,
            1 if action.approved else 0,
            action.approved_by,
            action.approved_at,
            1 if action.executed else 0,
            action.executed_at,
            json.dumps(action.result) if action.result else None,
            action.error,
            action.revenue_impact,
            action.timestamp
        ))
        
        conn.commit()
        conn.close()
    
    def _get_approval_level(self, action: AgentAction) -> ApprovalLevel:
        """Determine required approval level for an action"""
        # Money transfers always require high approval
        if action.action_type == ActionType.TRANSFER:
            if action.revenue_impact > 10000:
                return ApprovalLevel.CRITICAL
            elif action.revenue_impact > 1000:
                return ApprovalLevel.HIGH
            elif action.revenue_impact > 100:
                return ApprovalLevel.MEDIUM
            return ApprovalLevel.LOW
        
        # Deletions require medium approval
        if action.action_type == ActionType.DELETE:
            return ApprovalLevel.MEDIUM
        
        # Sending messages requires low approval
        if action.action_type == ActionType.SEND:
            return ApprovalLevel.LOW
        
        # Reads are auto-approved
        if action.action_type == ActionType.READ:
            return ApprovalLevel.NONE
        
        return ApprovalLevel.LOW
    
    async def request_approval(self, action: AgentAction) -> bool:
        """Request human approval for an action"""
        action.approval_level = self._get_approval_level(action)
        
        if action.approval_level == ApprovalLevel.NONE:
            action.approved = True
            action.approved_by = "auto"
            action.approved_at = datetime.utcnow().isoformat()
            return True
        
        # Store in pending approvals
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        expires_at = (datetime.utcnow() + timedelta(hours=24)).isoformat()
        
        cursor.execute("""
            INSERT INTO pending_approvals (action_id, agent_id, action_data, expires_at)
            VALUES (?, ?, ?, ?)
        """, (action.action_id, self.agent_id, json.dumps(asdict(action), default=str), expires_at))
        
        conn.commit()
        conn.close()
        
        self._pending_approvals[action.action_id] = action
        self.logger.info(f"Approval requested for action {action.action_id}: {action.description}")
        
        # For HIGH and CRITICAL, block until approved
        if action.approval_level in [ApprovalLevel.HIGH, ApprovalLevel.CRITICAL]:
            self.status = AgentStatus.AWAITING_APPROVAL
            self.metrics.escalations += 1
            return False
        
        # For MEDIUM and LOW, log and continue
        return action.approval_level == ApprovalLevel.LOW
    
    async def execute_action(self, action: AgentAction) -> Optional[Dict]:
        """Execute an action with full governance compliance"""
        action.agent_id = self.agent_id
        
        # Check kill switch
        if self.check_kill_switch():
            self.logger.error("Kill switch is active - action blocked")
            action.error = "Kill switch active"
            self._record_action(action)
            return None
        
        # Check rate limit
        if not self._check_rate_limit():
            self.logger.warning("Rate limit exceeded - action delayed")
            action.error = "Rate limit exceeded"
            self._record_action(action)
            return None
        
        # Request approval if needed
        approved = await self.request_approval(action)
        if not approved and action.approval_level.value >= ApprovalLevel.HIGH.value:
            self.logger.info(f"Action {action.action_id} awaiting approval")
            return None
        
        # Execute the action
        try:
            action.approved = True
            action.approved_at = datetime.utcnow().isoformat()
            
            result = await self._execute_action_impl(action)
            
            action.executed = True
            action.executed_at = datetime.utcnow().isoformat()
            action.result = result
            
            # Update metrics
            self.metrics.tasks_executed += 1
            self.metrics.revenue_attributed += action.revenue_impact
            self._action_timestamps.append(datetime.utcnow())
            
            self.logger.info(f"Action executed: {action.description}")
            
        except Exception as e:
            action.error = str(e)
            self.metrics.tasks_failed += 1
            self.metrics.errors += 1
            self.logger.error(f"Action failed: {e}")
        
        # Record action
        self._record_action(action)
        
        return action.result
    
    @abstractmethod
    async def _execute_action_impl(self, action: AgentAction) -> Dict:
        """Implementation-specific action execution"""
        pass
    
    async def start(self):
        """Start the agent"""
        if self.check_kill_switch():
            self.logger.error("Cannot start - kill switch is active")
            return
        
        self.status = AgentStatus.RUNNING
        self.started_at = datetime.utcnow()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE agents SET status = ?, last_active = ? WHERE agent_id = ?",
            (self.status.value, datetime.utcnow().isoformat(), self.agent_id)
        )
        conn.commit()
        conn.close()
        
        self.logger.info(f"Agent {self.agent_name} started")
        
        # Run the agent loop
        await self.run()
    
    async def stop(self):
        """Stop the agent gracefully"""
        self.status = AgentStatus.IDLE
        
        if self.started_at:
            self.metrics.uptime_seconds += (datetime.utcnow() - self.started_at).total_seconds()
        
        # Save metrics
        self._save_metrics()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE agents SET status = ?, last_active = ? WHERE agent_id = ?",
            (self.status.value, datetime.utcnow().isoformat(), self.agent_id)
        )
        conn.commit()
        conn.close()
        
        self.logger.info(f"Agent {self.agent_name} stopped")
    
    def _save_metrics(self):
        """Save current metrics to history"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO metrics_history (agent_id, metrics) VALUES (?, ?)",
            (self.agent_id, json.dumps(asdict(self.metrics)))
        )
        conn.commit()
        conn.close()
    
    def get_metrics(self) -> Dict:
        """Get current metrics as dict"""
        return {
            **asdict(self.metrics),
            "roi_percentage": self.metrics.roi,
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "status": self.status.value
        }
    
    @abstractmethod
    async def run(self):
        """Main agent loop - must be implemented by subclasses"""
        pass
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Return list of agent capabilities"""
        pass
