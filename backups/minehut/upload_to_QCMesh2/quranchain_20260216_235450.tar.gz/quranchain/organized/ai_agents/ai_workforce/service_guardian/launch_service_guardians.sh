#!/usr/bin/env bash
set -e
REPO_ROOT="/home/omar/Desktop/QuranChain"
LOG_DIR="$REPO_ROOT/logs/ai_workforce/service_guardians"
mkdir -p "$LOG_DIR"

# Usage: ./launch_service_guardians.sh
# Starts guardian agents for critical services. Adjust as needed.

start_guardian() {
  local name="$1"; shift
  local target_port="$1"; shift
  local health_path="$1"; shift
  local script_path="$1"; shift
  local listen_port="$1"; shift
  local log_file="$LOG_DIR/${name}_guardian.log"

  echo "Starting guardian for $name (target:$target_port, listens:$listen_port)" | tee -a "$log_file"
  nohup python3 "$REPO_ROOT/organized/ai_agents/ai_workforce/service_guardian/guardian_agent.py" \
    --name "$name" \
    --target-port "$target_port" \
    --health-path "$health_path" \
    --script-path "$script_path" \
    --check-interval 10 \
    --listen-port "$listen_port" \
    >> "$log_file" 2>&1 &
}

# Guardians mapping (service_name target_port health_path script_path listen_port)
start_guardian "dar_al_nas_api" 7080 "/api/health" "dar_al_nas_api_server.py" 9300
start_guardian "financial_general" 8101 "/status" "financial_general.py" 9301
start_guardian "real_estate_general" 8102 "/status" "real_estate_general.py" 9302
start_guardian "fungi_mesh_payment" 6000 "/health" "organized/blockchain/fungi_mesh_payment_processor.py" 9303
start_guardian "takaful_insurance" 7070 "/health" "organized/services/takaful_insurance.py" 9304

# Example: add more guardians as needed
# start_guardian "gateway_8088" 8088 "/health" "organized/gateways/card_processor_8088.py" 9305
# start_guardian "gateway_8090" 8090 "/health" "organized/gateways/card_processor_8090.py" 9306

echo "All configured service guardians launched."