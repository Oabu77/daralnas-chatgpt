"""
Agent API Security Layer
© QuranChain™ | Omar Mohammad Abunadi™

Provides JWT tokens, API key validation, request signing, and rate limiting
for all AI agent endpoints. Each agent automatically secures its own APIs.
"""

import os
import json
import time
import hmac
import hashlib
import secrets
import jwt
from datetime import datetime, timedelta
from functools import wraps
from typing import Optional, Dict, Any, Callable, Tuple
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class TokenType(Enum):
    """Types of security tokens"""
    API_KEY = "api_key"
    JWT = "jwt"
    BEARER = "bearer"
    HMAC = "hmac"


class SecurityLevel(Enum):
    """Security levels for endpoints"""
    PUBLIC = "public"              # No authentication
    AUTHENTICATED = "authenticated" # API key or JWT required
    AUTHORIZED = "authorized"       # Role-based authorization required
    CRITICAL = "critical"          # Multi-factor verification required


class APIKeyManager:
    """Manages secure API keys for agents"""
    
    def __init__(self, agent_id: str, storage_path: str = ".agent_keys"):
        self.agent_id = agent_id
        self.storage_path = storage_path
        self.keys_file = os.path.join(storage_path, f"{agent_id}_keys.json")
        os.makedirs(storage_path, exist_ok=True)
        self.keys: Dict[str, Dict[str, Any]] = {}
        self._load_keys()
    
    def _load_keys(self) -> None:
        """Load keys from secure storage"""
        if os.path.exists(self.keys_file):
            try:
                with open(self.keys_file, 'r') as f:
                    self.keys = json.load(f)
                logger.info(f"Loaded {len(self.keys)} API keys for {self.agent_id}")
            except Exception as e:
                logger.error(f"Failed to load keys: {e}")
    
    def _save_keys(self) -> None:
        """Save keys to secure storage"""
        try:
            os.makedirs(self.storage_path, exist_ok=True)
            with open(self.keys_file, 'w') as f:
                json.dump(self.keys, f, indent=2)
            # Restrict file permissions to owner only
            os.chmod(self.keys_file, 0o600)
            logger.info(f"Saved API keys for {self.agent_id}")
        except Exception as e:
            logger.error(f"Failed to save keys: {e}")
    
    def generate_key(
        self,
        key_name: str,
        expires_in_days: Optional[int] = None,
        permissions: Optional[list] = None
    ) -> str:
        """
        Generate a new secure API key
        
        Args:
            key_name: Human-readable name for the key
            expires_in_days: Days until key expires (None = never expires)
            permissions: List of permitted actions/endpoints
        
        Returns:
            Generated API key (secret, only shown once)
        """
        api_key = f"qc_{self.agent_id}_{secrets.token_urlsafe(32)}"
        
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        self.keys[key_hash] = {
            "name": key_name,
            "created_at": datetime.utcnow().isoformat(),
            "last_used": None,
            "permissions": permissions or [],
            "active": True
        }
        
        if expires_in_days:
            expires_at = datetime.utcnow() + timedelta(days=expires_in_days)
            self.keys[key_hash]["expires_at"] = expires_at.isoformat()
        
        self._save_keys()
        logger.info(f"Generated API key '{key_name}' for {self.agent_id}")
        
        return api_key
    
    def validate_key(self, api_key: str, required_permission: Optional[str] = None) -> Tuple[bool, Optional[Dict]]:
        """
        Validate an API key
        
        Args:
            api_key: The API key to validate
            required_permission: Required permission for this request
        
        Returns:
            Tuple of (is_valid, key_metadata)
        """
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        if key_hash not in self.keys:
            return False, None
        
        key_data = self.keys[key_hash]
        
        # Check if key is active
        if not key_data.get("active", True):
            logger.warning(f"Inactive API key used: {key_data.get('name')}")
            return False, None
        
        # Check expiration
        if "expires_at" in key_data:
            expires_at = datetime.fromisoformat(key_data["expires_at"])
            if datetime.utcnow() > expires_at:
                logger.warning(f"Expired API key used: {key_data.get('name')}")
                return False, None
        
        # Check permissions
        if required_permission and required_permission not in key_data.get("permissions", []):
            logger.warning(f"Insufficient permissions: {key_data.get('name')} for {required_permission}")
            return False, None
        
        # Update last used timestamp
        key_data["last_used"] = datetime.utcnow().isoformat()
        self._save_keys()
        
        return True, key_data
    
    def revoke_key(self, key_name: str) -> bool:
        """Revoke an API key by name"""
        for key_hash, key_data in self.keys.items():
            if key_data.get("name") == key_name:
                key_data["active"] = False
                self._save_keys()
                logger.info(f"Revoked API key: {key_name}")
                return True
        return False
    
    def list_keys(self) -> list:
        """List all keys (without exposing secrets)"""
        return [
            {
                "name": v.get("name"),
                "created_at": v.get("created_at"),
                "last_used": v.get("last_used"),
                "active": v.get("active"),
                "expires_at": v.get("expires_at")
            }
            for v in self.keys.values()
        ]


class JWTTokenManager:
    """Manages JWT tokens for agents"""
    
    def __init__(self, agent_id: str, secret_key: Optional[str] = None):
        self.agent_id = agent_id
        # Use provided secret or generate from environment/defaults
        self.secret_key = secret_key or os.getenv(
            f"JWT_SECRET_{agent_id.upper()}",
            f"default_secret_{agent_id}_{secrets.token_urlsafe(32)}"
        )
        self.algorithm = "HS256"
    
    def create_token(
        self,
        data: Dict[str, Any],
        expires_in_hours: int = 24,
        token_type: str = "access"
    ) -> str:
        """
        Create a JWT token
        
        Args:
            data: Claims to include in token
            expires_in_hours: Token expiration time
            token_type: Type of token (access, refresh, etc.)
        
        Returns:
            Encoded JWT token
        """
        payload = {
            "agent_id": self.agent_id,
            "type": token_type,
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(hours=expires_in_hours),
        }
        payload.update(data)
        
        token = jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
        logger.info(f"Created {token_type} token for {self.agent_id}")
        return token
    
    def verify_token(self, token: str) -> Tuple[bool, Optional[Dict]]:
        """
        Verify and decode a JWT token
        
        Args:
            token: The JWT token to verify
        
        Returns:
            Tuple of (is_valid, decoded_payload)
        """
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return True, payload
        except jwt.ExpiredSignatureError:
            logger.warning("Expired JWT token")
            return False, None
        except jwt.InvalidTokenError as e:
            logger.warning(f"Invalid JWT token: {e}")
            return False, None


class RequestSigner:
    """Signs requests with HMAC for integrity verification"""
    
    def __init__(self, agent_id: str, signing_secret: Optional[str] = None):
        self.agent_id = agent_id
        self.signing_secret = signing_secret or os.getenv(
            f"SIGNING_SECRET_{agent_id.upper()}",
            secrets.token_urlsafe(32)
        )
    
    def sign_request(
        self,
        method: str,
        path: str,
        body: Optional[str] = None,
        timestamp: Optional[int] = None
    ) -> str:
        """
        Sign a request for integrity verification
        
        Args:
            method: HTTP method (GET, POST, etc.)
            path: Request path
            body: Request body (optional)
            timestamp: Unix timestamp (defaults to now)
        
        Returns:
            HMAC signature
        """
        if timestamp is None:
            timestamp = int(time.time())
        
        # Build signing string: METHOD|PATH|TIMESTAMP|BODY
        signing_string = f"{method}|{path}|{timestamp}"
        if body:
            signing_string += f"|{body}"
        
        signature = hmac.new(
            self.signing_secret.encode(),
            signing_string.encode(),
            hashlib.sha256
        ).hexdigest()
        
        return signature
    
    def verify_signature(
        self,
        method: str,
        path: str,
        signature: str,
        timestamp: int,
        body: Optional[str] = None,
        max_age_seconds: int = 300
    ) -> bool:
        """
        Verify request signature
        
        Args:
            method: HTTP method
            path: Request path
            signature: Signature to verify
            timestamp: Request timestamp
            body: Request body
            max_age_seconds: Maximum age of request (default 5 minutes)
        
        Returns:
            True if signature is valid
        """
        # Check timestamp freshness
        current_time = int(time.time())
        if abs(current_time - timestamp) > max_age_seconds:
            logger.warning(f"Request timestamp too old: {timestamp}")
            return False
        
        # Verify signature
        expected_signature = self.sign_request(method, path, body, timestamp)
        is_valid = hmac.compare_digest(signature, expected_signature)
        
        if not is_valid:
            logger.warning("Invalid request signature")
        
        return is_valid


class RateLimiter:
    """Rate limiting for agent endpoints"""
    
    def __init__(self, agent_id: str, default_limit: int = 100, window_seconds: int = 3600):
        self.agent_id = agent_id
        self.default_limit = default_limit
        self.window_seconds = window_seconds
        self.request_history: Dict[str, list] = {}
    
    def is_allowed(self, identifier: str, limit: Optional[int] = None) -> Tuple[bool, Dict]:
        """
        Check if request is allowed under rate limit
        
        Args:
            identifier: Unique identifier (API key hash, client IP, etc.)
            limit: Custom limit for this identifier
        
        Returns:
            Tuple of (is_allowed, rate_limit_info)
        """
        limit = limit or self.default_limit
        now = time.time()
        cutoff = now - self.window_seconds
        
        # Initialize or get request history
        if identifier not in self.request_history:
            self.request_history[identifier] = []
        
        # Remove old requests outside window
        self.request_history[identifier] = [
            ts for ts in self.request_history[identifier]
            if ts > cutoff
        ]
        
        request_count = len(self.request_history[identifier])
        is_allowed = request_count < limit
        
        if is_allowed:
            self.request_history[identifier].append(now)
        
        info = {
            "limit": limit,
            "remaining": max(0, limit - request_count - 1),
            "reset_at": int(cutoff + self.window_seconds),
            "allowed": is_allowed
        }
        
        return is_allowed, info


# Flask Decorators for Agent APIs

def require_auth(token_manager: JWTTokenManager = None, api_key_manager: APIKeyManager = None):
    """
    Decorator to require authentication on Flask endpoints
    
    Checks for: Authorization header with Bearer token or X-API-Key header
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from flask import request, jsonify
            
            # Check for JWT Bearer token
            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
                if token_manager:
                    is_valid, payload = token_manager.verify_token(token)
                    if is_valid:
                        request.user = payload
                        return f(*args, **kwargs)
                return jsonify({"error": "Invalid or expired token"}), 401
            
            # Check for API Key
            api_key = request.headers.get("X-API-Key")
            if api_key and api_key_manager:
                is_valid, key_data = api_key_manager.validate_key(api_key)
                if is_valid:
                    request.user = {"type": "api_key", "key_name": key_data.get("name")}
                    return f(*args, **kwargs)
                return jsonify({"error": "Invalid or expired API key"}), 401
            
            return jsonify({"error": "Authentication required"}), 401
        
        return decorated_function
    return decorator


def require_permission(permission: str):
    """
    Decorator to check if user has required permission
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from flask import jsonify
            
            if not hasattr(request, 'user'):
                return jsonify({"error": "Not authenticated"}), 401
            
            user_permissions = request.user.get("permissions", [])
            if permission not in user_permissions:
                return jsonify({"error": f"Permission denied: {permission}"}), 403
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator


def rate_limit(limiter: RateLimiter, limit: Optional[int] = None):
    """
    Decorator to apply rate limiting to endpoints
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from flask import request, jsonify
            
            # Use API key or IP as identifier
            api_key = request.headers.get("X-API-Key", "")
            identifier = api_key or request.remote_addr
            
            is_allowed, rate_info = limiter.is_allowed(identifier, limit)
            
            if not is_allowed:
                response = jsonify({
                    "error": "Rate limit exceeded",
                    "rate_limit": rate_info
                })
                response.status_code = 429
                return response
            
            # Add rate limit info to response headers
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator


def verify_signature(signer: RequestSigner):
    """
    Decorator to verify request signatures
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from flask import request, jsonify
            
            # Get signature from header
            signature = request.headers.get("X-Signature")
            timestamp = request.headers.get("X-Timestamp")
            
            if not signature or not timestamp:
                return jsonify({"error": "Missing signature or timestamp"}), 400
            
            try:
                timestamp = int(timestamp)
            except ValueError:
                return jsonify({"error": "Invalid timestamp"}), 400
            
            # Get body for verification
            body = request.get_data(as_text=True) if request.data else None
            
            if not signer.verify_signature(
                request.method,
                request.path,
                signature,
                timestamp,
                body
            ):
                return jsonify({"error": "Invalid signature"}), 401
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator
