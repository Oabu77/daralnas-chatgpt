"""
Content Creation AI Agent - Marketing & Documentation Content
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- Marketing content creation and optimization
- Technical documentation and tutorials
- Educational content about Islamic finance
- Social media content and campaigns
- Blog posts and articles
- Video scripts and presentation materials

Constraints:
- Content must align with Islamic principles
- Maintain brand consistency
- Ensure technical accuracy
- Respect copyright and intellectual property
"""

import asyncio
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import uuid
import re

import sys
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from organized.ai_agents.ai_workforce.core.base_agent import (
    BaseAgent, AgentAction, ActionType, ApprovalLevel, AgentStatus
)
from organized.ai_agents.ai_workforce.core.message_bus import get_message_bus, Message, MessagePriority


@dataclass
class ContentPiece:
    """Content piece for creation or management"""
    content_id: str
    title: str
    content_type: str  # blog_post, social_media, documentation, video_script, presentation
    category: str  # marketing, educational, technical, promotional
    target_audience: str  # developers, businesses, general_public, islamic_scholars
    status: str  # draft, review, approved, published, archived
    content: str
    tags: List[str]
    word_count: int
    created_at: str
    published_at: Optional[str]
    engagement_metrics: Dict[str, Any]


@dataclass
class ContentCampaign:
    """Content marketing campaign"""
    campaign_id: str
    name: str
    objective: str  # brand_awareness, lead_generation, education, engagement
    target_platforms: List[str]  # linkedin, twitter, youtube, blog, website
    content_pieces: List[str]  # Content piece IDs
    start_date: str
    end_date: Optional[str]
    budget: float
    performance_metrics: Dict[str, Any]
    status: str  # planning, active, completed, paused


@dataclass
class ContentTemplate:
    """Content creation template"""
    template_id: str
    name: str
    content_type: str
    template_structure: str
    variables: List[str]
    usage_count: int
    created_at: str


class ContentCreationAgent(BaseAgent):
    """
    Content Creation AI Agent for marketing and documentation content.

    This agent:
    - Creates marketing and educational content
    - Manages content campaigns
    - Maintains content templates
    - Tracks content performance
    - Ensures Islamic compliance in content
    """

    def __init__(self, agent_id: str):
        super().__init__(agent_id, "Content Creation AI")
        self.content_pieces: Dict[str, ContentPiece] = {}
        self.content_campaigns: Dict[str, ContentCampaign] = {}
        self.content_templates: Dict[str, ContentTemplate] = {}
        self.db_path = f"/home/omar/Desktop/QuranChain/prod_databases/content_creation_{agent_id}.db"
        self.islamic_content_guidelines = self._load_islamic_guidelines()
        self.brand_voice = self._load_brand_voice()
        self._init_database()
        self._init_templates()

    def _load_islamic_guidelines(self) -> Dict[str, Any]:
        """Load Islamic content guidelines"""
        return {
            "prohibited_content": [
                "Interest-based financial products",
                "Speculative investments",
                "Haram industries promotion",
                "Misleading Islamic claims"
            ],
            "required_elements": [
                "Sharia compliance verification",
                "Ethical investment principles",
                "Transparency in operations",
                "Community benefit focus"
            ],
            "tone_guidelines": [
                "Respectful and professional",
                "Education-focused",
                "Inclusive language",
                "Avoid controversial topics"
            ]
        }

    def _load_brand_voice(self) -> Dict[str, Any]:
        """Load brand voice guidelines"""
        return {
            "primary_voice": "Educational and authoritative",
            "secondary_voice": "Innovative and trustworthy",
            "key_messages": [
                "Islamic finance innovation",
                "Blockchain technology for good",
                "Ethical financial solutions",
                "Community-driven development"
            ],
            "brand_values": ["Islamic compliance", "Innovation", "Transparency", "Community"]
        }

    def _init_database(self):
        """Initialize content creation database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            # Content pieces table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS content_pieces (
                    content_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    content_type TEXT,
                    category TEXT,
                    target_audience TEXT,
                    status TEXT,
                    content TEXT,
                    tags TEXT,
                    word_count INTEGER,
                    created_at TEXT,
                    published_at TEXT,
                    engagement_metrics TEXT
                )
            ''')

            # Content campaigns table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS content_campaigns (
                    campaign_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    objective TEXT,
                    target_platforms TEXT,
                    content_pieces TEXT,
                    start_date TEXT,
                    end_date TEXT,
                    budget REAL,
                    performance_metrics TEXT,
                    status TEXT
                )
            ''')

            # Content templates table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS content_templates (
                    template_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    content_type TEXT,
                    template_structure TEXT,
                    variables TEXT,
                    usage_count INTEGER,
                    created_at TEXT
                )
            ''')

            conn.commit()

    def _init_templates(self):
        """Initialize content templates"""
        templates = [
            {
                "name": "Islamic Finance Explainer",
                "content_type": "blog_post",
                "template_structure": """
# {topic_title}

## Introduction
{introduction_paragraph}

## What is Islamic Finance?
{explanation_paragraph}

## Key Principles
- {principle_1}
- {principle_2}
- {principle_3}

## How QuranChain Implements This
{implementation_paragraph}

## Benefits for Businesses
{benefits_list}

## Conclusion
{conclusion_paragraph}

*Disclaimer: This content is for educational purposes only and does not constitute financial advice.*
                """,
                "variables": ["topic_title", "introduction_paragraph", "explanation_paragraph",
                            "principle_1", "principle_2", "principle_3", "implementation_paragraph",
                            "benefits_list", "conclusion_paragraph"]
            },
            {
                "name": "Technical Tutorial",
                "content_type": "documentation",
                "template_structure": """
# {tutorial_title}

## Overview
{overview_description}

## Prerequisites
{prerequisites_list}

## Step-by-Step Guide

### Step 1: {step_1_title}
{step_1_description}
```bash
{step_1_code}
```

### Step 2: {step_2_title}
{step_2_description}
```bash
{step_2_code}
```

### Step 3: {step_3_title}
{step_3_description}
```bash
{step_3_code}
```

## Troubleshooting
{common_issues}

## Next Steps
{next_steps}

## Additional Resources
{resources_list}
                """,
                "variables": ["tutorial_title", "overview_description", "prerequisites_list",
                            "step_1_title", "step_1_description", "step_1_code",
                            "step_2_title", "step_2_description", "step_2_code",
                            "step_3_title", "step_3_description", "step_3_code",
                            "common_issues", "next_steps", "resources_list"]
            },
            {
                "name": "Social Media Post",
                "content_type": "social_media",
                "template_structure": """
🌙 {hook_question}

{educational_fact}

#IslamicFinance #Blockchain #QuranChain #EthicalFinance

Learn more: {link}

{call_to_action}
                """,
                "variables": ["hook_question", "educational_fact", "link", "call_to_action"]
            }
        ]

        for template_data in templates:
            template = ContentTemplate(
                template_id=str(uuid.uuid4()),
                name=template_data["name"],
                content_type=template_data["content_type"],
                template_structure=template_data["template_structure"],
                variables=template_data["variables"],
                usage_count=0,
                created_at=datetime.utcnow().isoformat()
            )
            self.content_templates[template.template_id] = template

    async def run_cycle(self) -> Dict[str, Any]:
        """Run content creation operations cycle"""
        if not self.is_active:
            return {"status": "inactive"}

        cycle_results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions_taken": [],
            "metrics": self.get_metrics()
        }

        try:
            # Generate content calendar
            content_calendar = await self._generate_content_calendar()
            cycle_results["content_calendar"] = content_calendar

            # Create scheduled content
            content_creation = await self._create_scheduled_content()
            cycle_results["content_creation"] = content_creation

            # Manage content campaigns
            campaign_management = await self._manage_content_campaigns()
            cycle_results["campaign_management"] = campaign_management

            # Analyze content performance
            performance_analysis = await self._analyze_content_performance()
            cycle_results["performance_analysis"] = performance_analysis

            # Update content strategy
            strategy_updates = await self._update_content_strategy()
            cycle_results["strategy_updates"] = strategy_updates

            cycle_results["status"] = "completed"

        except Exception as e:
            cycle_results["status"] = "error"
            cycle_results["error"] = str(e)

        cycle_results["cycle_end"] = datetime.utcnow().isoformat()
        return cycle_results

    async def _generate_content_calendar(self) -> Dict[str, Any]:
        """Generate content calendar for upcoming period"""
        calendar_results = {
            "calendar_period": "next_30_days",
            "planned_content": [],
            "content_gaps": [],
            "platform_distribution": {}
        }

        # Plan content for next 30 days
        platforms = ["linkedin", "twitter", "blog", "youtube", "newsletter"]
        content_types = ["educational", "technical", "promotional", "engagement"]

        for day in range(30):
            publish_date = datetime.utcnow() + timedelta(days=day)

            # Determine content type for this day
            content_type = content_types[day % len(content_types)]

            # Select appropriate platform
            platform = platforms[day % len(platforms)]

            planned_content = {
                "date": publish_date.strftime("%Y-%m-%d"),
                "content_type": content_type,
                "platform": platform,
                "topic": self._generate_topic_idea(content_type),
                "status": "planned"
            }

            calendar_results["planned_content"].append(planned_content)

            # Track platform distribution
            if platform not in calendar_results["platform_distribution"]:
                calendar_results["platform_distribution"][platform] = 0
            calendar_results["platform_distribution"][platform] += 1

        # Identify content gaps
        current_content_types = set(c["content_type"] for c in calendar_results["planned_content"])
        missing_types = set(content_types) - current_content_types
        if missing_types:
            calendar_results["content_gaps"] = list(missing_types)

        return calendar_results

    def _generate_topic_idea(self, content_type: str) -> str:
        """Generate topic idea based on content type"""
        topic_ideas = {
            "educational": [
                "Understanding Islamic Banking Principles",
                "The Role of Blockchain in Ethical Finance",
                "Zakat Calculation in Modern Finance",
                "Risk Sharing vs Risk Transfer in Islamic Finance"
            ],
            "technical": [
                "Setting Up Your First Islamic Blockchain Wallet",
                "API Integration Guide for QuranChain",
                "Smart Contracts in Islamic Finance",
                "Security Best Practices for Islamic FinTech"
            ],
            "promotional": [
                "Why Choose QuranChain for Islamic Finance",
                "Success Stories: Businesses Using Islamic Blockchain",
                "QuranChain Platform Features Overview",
                "Partner Showcase: Islamic Financial Institutions"
            ],
            "engagement": [
                "Islamic Finance Questions Answered",
                "Community Spotlight: Islamic FinTech Innovators",
                "Industry Trends in Islamic Blockchain",
                "Q&A: Common Islamic Finance Misconceptions"
            ]
        }

        ideas = topic_ideas.get(content_type, ["General Islamic Finance Topic"])
        return ideas[len(self.content_pieces) % len(ideas)]  # Rotate through ideas

    async def _create_scheduled_content(self) -> Dict[str, Any]:
        """Create content pieces according to schedule"""
        creation_results = {
            "content_created": 0,
            "content_types": {},
            "islamic_compliance_checked": 0,
            "content_queued_for_review": 0
        }

        # Create content for high-priority topics
        priority_topics = [
            "Islamic Finance Fundamentals",
            "QuranChain Platform Overview",
            "Technical Integration Guide",
            "Community Success Stories"
        ]

        for topic in priority_topics:
            content_piece = await self._create_content_piece(
                title=topic,
                content_type="blog_post",
                category="educational",
                target_audience="general_public"
            )

            if content_piece:
                self.content_pieces[content_piece.content_id] = content_piece
                creation_results["content_created"] += 1

                content_type = content_piece.content_type
                if content_type not in creation_results["content_types"]:
                    creation_results["content_types"][content_type] = 0
                creation_results["content_types"][content_type] += 1

                creation_results["islamic_compliance_checked"] += 1
                creation_results["content_queued_for_review"] += 1

        return creation_results

    async def _create_content_piece(self, title: str, content_type: str,
                                  category: str, target_audience: str) -> Optional[ContentPiece]:
        """Create a content piece using templates"""
        # Select appropriate template
        template = None
        for t in self.content_templates.values():
            if t.content_type == content_type:
                template = t
                break

        if not template:
            return None

        # Generate content using template
        content = await self._generate_content_from_template(template, title, category, target_audience)

        # Check Islamic compliance
        compliance_check = self._check_islamic_compliance(content)
        if not compliance_check["compliant"]:
            # Revise content for compliance
            content = self._revise_for_compliance(content, compliance_check["issues"])

        content_piece = ContentPiece(
            content_id=str(uuid.uuid4()),
            title=title,
            content_type=content_type,
            category=category,
            target_audience=target_audience,
            status="draft",
            content=content,
            tags=self._generate_content_tags(title, content),
            word_count=len(content.split()),
            created_at=datetime.utcnow().isoformat(),
            published_at=None,
            engagement_metrics={}
        )

        return content_piece

    async def _generate_content_from_template(self, template: ContentTemplate,
                                            title: str, category: str, audience: str) -> str:
        """Generate content using template"""
        content = template.template_structure

        # Fill in template variables
        if template.name == "Islamic Finance Explainer":
            content = content.replace("{topic_title}", title)
            content = content.replace("{introduction_paragraph}",
                f"Welcome to an exploration of {title.lower()}, a fundamental concept in Islamic finance.")
            content = content.replace("{explanation_paragraph}",
                "Islamic finance is a financial system that operates according to Islamic principles, avoiding interest and promoting ethical investments.")
            content = content.replace("{principle_1}", "No interest (riba) in transactions")
            content = content.replace("{principle_2}", "Risk sharing between parties")
            content = content.replace("{principle_3}", "Prohibition of excessive uncertainty")
            content = content.replace("{implementation_paragraph}",
                "QuranChain implements these principles through blockchain technology, ensuring transparent and compliant financial transactions.")
            content = content.replace("{benefits_list}",
                "- Ethical investment opportunities\n- Transparent transaction tracking\n- Community-focused financial solutions")
            content = content.replace("{conclusion_paragraph}",
                "Islamic finance offers a viable alternative to conventional banking, promoting ethical and sustainable financial practices.")

        elif template.name == "Technical Tutorial":
            content = content.replace("{tutorial_title}", title)
            content = content.replace("{overview_description}",
                f"This tutorial will guide you through {title.lower()} in the QuranChain ecosystem.")
            content = content.replace("{prerequisites_list}",
                "- Basic understanding of blockchain\n- QuranChain account\n- Development environment")
            # Fill in tutorial steps (simplified)
            content = content.replace("{step_1_title}", "Setup Environment")
            content = content.replace("{step_1_description}", "Install necessary dependencies")
            content = content.replace("{step_1_code}", "npm install quranchain-sdk")
            content = content.replace("{next_steps}", "Explore advanced features in our documentation")

        elif template.name == "Social Media Post":
            content = content.replace("{hook_question}", f"Did you know about {title}?")
            content = content.replace("{educational_fact}",
                f"Islamic finance principles guide {title.lower()} towards ethical outcomes.")
            content = content.replace("{link}", "https://quranchain.com/learn-more")
            content = content.replace("{call_to_action}", "Share your thoughts below! 💭")

        return content

    def _check_islamic_compliance(self, content: str) -> Dict[str, Any]:
        """Check content for Islamic compliance"""
        issues = []

        content_lower = content.lower()

        # Check for prohibited content
        for prohibited in self.islamic_content_guidelines["prohibited_content"]:
            if prohibited.lower() in content_lower:
                issues.append(f"Contains reference to prohibited topic: {prohibited}")

        # Check for required elements
        required_found = 0
        for required in self.islamic_content_guidelines["required_elements"]:
            if required.lower().replace(" ", "") in content_lower.replace(" ", ""):
                required_found += 1

        if required_found < 2:
            issues.append("Missing key Islamic finance principles or compliance references")

        return {
            "compliant": len(issues) == 0,
            "issues": issues,
            "compliance_score": max(0, 100 - (len(issues) * 20))
        }

    def _revise_for_compliance(self, content: str, issues: List[str]) -> str:
        """Revise content to address compliance issues"""
        revised_content = content

        for issue in issues:
            if "prohibited topic" in issue:
                # Remove or replace prohibited content
                revised_content = revised_content.replace("interest", "profit sharing")
                revised_content = revised_content.replace("riba", "Islamic principles")
            elif "Missing key" in issue:
                # Add compliance disclaimer
                disclaimer = "\n\n*This content adheres to Islamic finance principles and Sharia compliance standards.*"
                if disclaimer not in revised_content:
                    revised_content += disclaimer

        return revised_content

    def _generate_content_tags(self, title: str, content: str) -> List[str]:
        """Generate relevant tags for content"""
        tags = ["QuranChain", "IslamicFinance", "Blockchain"]

        # Add topic-specific tags
        title_lower = title.lower()
        if "tutorial" in title_lower or "guide" in title_lower:
            tags.append("Tutorial")
        if "islamic" in title_lower:
            tags.append("ShariaCompliant")
        if "technical" in title_lower:
            tags.append("Technical")
        if "finance" in title_lower:
            tags.append("FinTech")

        return tags

    async def _manage_content_campaigns(self) -> Dict[str, Any]:
        """Manage content marketing campaigns"""
        campaign_results = {
            "active_campaigns": 0,
            "campaigns_completed": 0,
            "total_reach": 0,
            "engagement_rate": 0
        }

        for campaign in self.content_campaigns.values():
            if campaign.status == "active":
                campaign_results["active_campaigns"] += 1

                # Mock campaign performance tracking
                campaign.performance_metrics["reach"] = campaign.performance_metrics.get("reach", 0) + 100
                campaign.performance_metrics["engagement"] = campaign.performance_metrics.get("engagement", 0) + 10

                campaign_results["total_reach"] += campaign.performance_metrics["reach"]

            elif campaign.status == "completed":
                campaign_results["campaigns_completed"] += 1

        # Calculate engagement rate
        if campaign_results["total_reach"] > 0:
            total_engagement = sum(c.performance_metrics.get("engagement", 0)
                                 for c in self.content_campaigns.values())
            campaign_results["engagement_rate"] = (total_engagement / campaign_results["total_reach"]) * 100

        return campaign_results

    async def _analyze_content_performance(self) -> Dict[str, Any]:
        """Analyze content performance and engagement"""
        analysis_results = {
            "total_content_pieces": len(self.content_pieces),
            "published_content": sum(1 for c in self.content_pieces.values() if c.status == "published"),
            "top_performing_content": [],
            "content_type_performance": {},
            "engagement_trends": []
        }

        # Analyze content type performance
        for content in self.content_pieces.values():
            if content.status == "published":
                content_type = content.content_type
                if content_type not in analysis_results["content_type_performance"]:
                    analysis_results["content_type_performance"][content_type] = {
                        "count": 0,
                        "total_engagement": 0,
                        "avg_engagement": 0
                    }

                analysis_results["content_type_performance"][content_type]["count"] += 1
                engagement = content.engagement_metrics.get("total_engagement", 0)
                analysis_results["content_type_performance"][content_type]["total_engagement"] += engagement

        # Calculate averages
        for content_type, data in analysis_results["content_type_performance"].items():
            if data["count"] > 0:
                data["avg_engagement"] = data["total_engagement"] / data["count"]

        # Identify top performing content
        published_content = [c for c in self.content_pieces.values() if c.status == "published"]
        sorted_content = sorted(published_content,
                              key=lambda c: c.engagement_metrics.get("total_engagement", 0),
                              reverse=True)

        for content in sorted_content[:5]:
            analysis_results["top_performing_content"].append({
                "title": content.title,
                "content_type": content.content_type,
                "engagement": content.engagement_metrics.get("total_engagement", 0),
                "published_date": content.published_at
            })

        return analysis_results

    async def _update_content_strategy(self) -> Dict[str, Any]:
        """Update content strategy based on performance"""
        strategy_updates = {
            "strategy_adjustments": [],
            "new_content_focus": [],
            "platform_optimization": []
        }

        # Analyze performance data
        performance_data = await self._analyze_content_performance()

        # Adjust strategy based on performance
        if performance_data["content_type_performance"]:
            best_performing = max(performance_data["content_type_performance"].items(),
                                key=lambda x: x[1]["avg_engagement"])

            strategy_updates["strategy_adjustments"].append({
                "adjustment": f"Increase focus on {best_performing[0]} content",
                "reason": f"Highest engagement rate: {best_performing[1]['avg_engagement']:.1f}"
            })

        # Identify content gaps
        content_types = ["blog_post", "social_media", "video_script", "documentation"]
        existing_types = set(c.content_type for c in self.content_pieces.values())

        missing_types = set(content_types) - existing_types
        if missing_types:
            strategy_updates["new_content_focus"].extend(list(missing_types))

        # Platform optimization
        platform_performance = {}
        for content in self.content_pieces.values():
            if content.published_at:
                # Mock platform assignment
                platform = "blog" if content.content_type == "blog_post" else "social"
                if platform not in platform_performance:
                    platform_performance[platform] = {"engagement": 0, "count": 0}

                platform_performance[platform]["engagement"] += content.engagement_metrics.get("total_engagement", 0)
                platform_performance[platform]["count"] += 1

        if platform_performance:
            best_platform = max(platform_performance.items(),
                              key=lambda x: x[1]["engagement"] / max(x[1]["count"], 1))
            strategy_updates["platform_optimization"].append({
                "platform": best_platform[0],
                "recommendation": "Increase content production for this platform"
            })

        return strategy_updates

    def get_metrics(self) -> Dict[str, Any]:
        """Get content creation metrics"""
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "total_content_pieces": len(self.content_pieces),
            "published_content": sum(1 for c in self.content_pieces.values() if c.status == "published"),
            "draft_content": sum(1 for c in self.content_pieces.values() if c.status == "draft"),
            "total_campaigns": len(self.content_campaigns),
            "active_campaigns": sum(1 for c in self.content_campaigns.values() if c.status == "active"),
            "content_templates": len(self.content_templates),
            "total_word_count": sum(c.word_count for c in self.content_pieces.values()),
            "average_engagement": 0,  # Would calculate from engagement metrics
            "islamic_compliance_score": 95,  # Would calculate from compliance checks
            "content_created_this_month": 0,  # Would track monthly metrics
            "commission_earned": 0.0,   # Would be calculated from content impact
            "tasks_executed": 0,        # Would be tracked
            "last_updated": datetime.utcnow().isoformat()
        }