"""
Agent API Security - Integration Template

© QuranChain™ | Omar Mohammad Abunadi™

Copy this template into each agent's main application file.
Shows how to integrate security with minimal code changes.
"""

# ============================================================================
# TEMPLATE: How to update marketing_ai/agent.py
# ============================================================================

# BEFORE (old code):
# ==================
"""
from flask import Flask, request, jsonify

def create_marketing_api(agent: MarketingAI) -> Flask:
    app = Flask(__name__)
    
    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "healthy"})
    
    @app.route("/lead/capture", methods=["POST"])
    def capture_lead():
        data = request.json
        # ... process lead ...
        return jsonify(result)
    
    return app
"""

# AFTER (new code with security):
# =================================

from flask import Flask, request, jsonify
from ai_workforce.core.security_integration import create_secured_flask_app

def create_marketing_api(agent: MarketingAI) -> Flask:
    """Create Flask API for Marketing AI with built-in security"""
    
    app = Flask(__name__)
    
    # STEP 1: Wrap app with security (1 line!)
    app, security_mgr = create_secured_flask_app(
        agent_id=agent.agent_id,
        agent_name="Marketing AI",
        app=app
    )
    
    # STEP 2: Define endpoints as before - security is automatic!
    
    @app.route("/health", methods=["GET"])
    def health():
        """Public endpoint - no auth required"""
        return jsonify({
            "status": "healthy",
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type.value,
            "copyright": COPYRIGHT
        })
    
    @app.route("/lead/capture", methods=["POST"])
    def capture_lead():
        """Protected endpoint - auth required automatically"""
        data = request.json
        
        # Validation
        if not data.get("email") or not data.get("name"):
            return jsonify({"error": "email and name required"}), 400
        
        if not data.get("opted_in"):
            return jsonify({
                "error": "Opt-in consent required",
                "message": "Lead must explicitly opt-in for communications"
            }), 400
        
        result = agent.execute_action(
            "capture_lead",
            data,
            ActionSeverity.LOW,
            revenue_impact=0
        )
        
        return jsonify(result)
    
    @app.route("/content/landing", methods=["POST"])
    def generate_landing():
        """Protected endpoint with auth"""
        data = request.json
        result = agent.execute_action(
            "create_landing_page",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/campaign/draft", methods=["POST"])
    def draft_campaign():
        """Protected with higher rate limit restriction"""
        data = request.json
        result = agent.execute_action(
            "draft_email_campaign",
            data,
            ActionSeverity.MEDIUM
        )
        return jsonify(result)
    
    @app.route("/analytics/attribution", methods=["GET"])
    def get_attribution():
        """Protected - retrieve only"""
        result = agent.execute_action(
            "analyze_attribution",
            {},
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/metrics", methods=["GET"])
    def get_metrics():
        """Protected endpoint"""
        return jsonify(agent.get_metrics())
    
    @app.route("/report", methods=["GET"])
    def get_report():
        """Protected endpoint"""
        return agent.generate_report(), 200, {"Content-Type": "text/plain"}
    
    # STEP 3 (Optional): Expose security management for admins
    
    @app.route("/security/keys", methods=["GET"])
    def list_api_keys():
        """List active API keys (auth required)"""
        if not request.headers.get("X-API-Key"):
            return jsonify({"error": "Unauthorized"}), 401
        
        keys = security_mgr.get_api_keys()
        return jsonify({"keys": keys})
    
    @app.route("/security/report", methods=["GET"])
    def security_report():
        """Get security configuration report (auth required)"""
        if not request.headers.get("X-API-Key"):
            return jsonify({"error": "Unauthorized"}), 401
        
        report = security_mgr.get_security_report()
        return jsonify(report)
    
    return app


# ============================================================================
# TEMPLATE: Update the if __name__ == "__main__" block
# ============================================================================

if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    logger.info("Starting Marketing AI Agent")
    logger.info(COPYRIGHT)
    
    # Create agent
    agent = MarketingAI()
    logger.info(f"Agent ID: {agent.agent_id}")
    logger.info(f"Commission Rate: {agent.commission_rate * 100}%")
    
    # Create API with security
    app = create_marketing_api(agent)
    logger.info("API created with security enabled")
    
    # Start Flask server
    # This will:
    # ✓ Enable API key authentication
    # ✓ Enable JWT token support
    # ✓ Enforce rate limiting
    # ✓ Log all requests
    # ✓ Add security headers
    # ✓ Require auth on protected endpoints
    
    logger.info("\n" + "="*80)
    logger.info("🔐 SECURITY ENABLED ON ALL ENDPOINTS")
    logger.info("="*80)
    logger.info("\nPublic endpoints (no auth required):")
    logger.info("  GET  /health")
    logger.info("\nProtected endpoints (API key or JWT required):")
    logger.info("  POST /lead/capture")
    logger.info("  POST /content/landing")
    logger.info("  POST /campaign/draft")
    logger.info("  GET  /analytics/attribution")
    logger.info("  GET  /metrics")
    logger.info("  GET  /report")
    logger.info("\nAdmin endpoints:")
    logger.info("  GET  /security/keys        (requires auth)")
    logger.info("  GET  /security/report      (requires auth)")
    logger.info("\nTo get an API key:")
    logger.info("  See: AGENT_API_SECURITY_GUIDE.md")
    logger.info("="*80 + "\n")
    
    app.run(
        host="0.0.0.0",
        port=7300,
        debug=False
    )


# ============================================================================
# TEMPLATE: For other agents (Sales, Onboarding, etc.)
# ============================================================================

# All other agents follow the same pattern:
# 1. Import create_secured_flask_app
# 2. Wrap app creation with it
# 3. Define routes as normal
# 4. Security is applied automatically

# Example for Sales AI:
"""
from ai_workforce.core.security_integration import create_secured_flask_app

def create_sales_api(agent: SalesAI) -> Flask:
    app = Flask(__name__)
    
    # ADD THIS LINE:
    app, security_mgr = create_secured_flask_app(
        agent_id=agent.agent_id,
        agent_name="Sales AI",
        app=app
    )
    
    # Define routes normally - security is automatic
    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "healthy"})
    
    @app.route("/opportunities", methods=["GET"])
    def get_opportunities():
        return jsonify(agent.get_opportunities())
    
    @app.route("/proposal/create", methods=["POST"])
    def create_proposal():
        return jsonify(agent.create_proposal(request.json))
    
    @app.route("/deal/close", methods=["POST"])
    def close_deal():
        # Critical endpoint - requires signature
        return jsonify(agent.close_deal(request.json))
    
    return app
"""


# ============================================================================
# TEMPLATE: Using Security Manager in Your Agent Logic
# ============================================================================

# If you need to generate API keys or tokens within the agent:

class SalesAI:
    def __init__(self):
        self.agent_id = "sales_ai_7301"
        self.security_mgr = None  # Will be set after app creation
    
    def onboard_partner(self, partner_data):
        """When onboarding a partner, generate API key for them"""
        
        # Generate unique API key for this partner
        api_key = self.security_mgr.generate_api_key(
            key_name=f"partner_{partner_data['partner_id']}",
            expires_in_days=365,
            permissions=[
                "leads.view",
                "deals.view",
                "proposals.view"
            ]
        )
        
        # Store API key for partner
        partner_data['api_key'] = api_key
        
        return {
            "partner_id": partner_data['partner_id'],
            "api_key": api_key,
            "message": "API key generated successfully"
        }
    
    def create_proposal(self, data):
        """Create proposal - critical operation"""
        
        # Generate JWT token for proposal signing
        proposal_id = data['proposal_id']
        signature_token = self.security_mgr.create_jwt_token(
            data={
                "proposal_id": proposal_id,
                "agent_id": self.agent_id,
                "timestamp": datetime.utcnow().isoformat()
            },
            expires_in_hours=24
        )
        
        return {
            "proposal_id": proposal_id,
            "signed_token": signature_token,
            "status": "created"
        }


# ============================================================================
# TEMPLATE: Calling Agent APIs from Other Services
# ============================================================================

# For services that call the Marketing AI API:

import requests

def call_marketing_api_example():
    """Example of calling agent API with security"""
    
    # Get API key (generated by agent)
    api_key = "qc_marketing_ai_abc123def456..."
    
    # Example 1: Health check (public)
    response = requests.get("http://localhost:7300/health")
    print(response.json())
    # Output: {"status": "healthy", "agent_id": "...", ...}
    
    # Example 2: Capture lead (requires auth)
    response = requests.post(
        "http://localhost:7300/lead/capture",
        json={
            "email": "prospect@example.com",
            "name": "Jane Doe",
            "opted_in": True
        },
        headers={"X-API-Key": api_key}
    )
    print(response.json())
    # Output: {"captured": True, "lead_id": "lead_123", ...}
    
    # Example 3: Get metrics (requires auth)
    response = requests.get(
        "http://localhost:7300/metrics",
        headers={"X-API-Key": api_key}
    )
    print(response.json())
    # Output: {"leads_today": 42, "campaigns_deployed": 5, ...}
    
    # Example 4: Rate limit example
    response = requests.get(
        "http://localhost:7300/analytics/attribution",
        headers={"X-API-Key": api_key}
    )
    if response.status_code == 429:
        print("Rate limit exceeded!")
        print(response.json())
        # Output: {"error": "Rate limit exceeded", "reset_at": 1673432400}
    else:
        print(response.json())


# ============================================================================
# SUMMARY OF CHANGES
# ============================================================================

"""
MINIMAL CODE CHANGES REQUIRED:

1. Add import at top:
   from ai_workforce.core.security_integration import create_secured_flask_app

2. In your Flask app creation function, add ONE line:
   app, security_mgr = create_secured_flask_app(agent_id, agent_name, app)

3. That's it! All endpoints now have:
   ✓ API key authentication
   ✓ JWT token support
   ✓ Rate limiting (default 100/hour)
   ✓ Security headers (CORS, XSS, etc.)
   ✓ Request logging
   ✓ Permission checks
   ✓ Rate limit responses

BACKWARD COMPATIBLE:
   • Existing routes work unchanged
   • Public endpoints still accessible without auth
   • Protected endpoints now require API key
   • No breaking changes to response format

BENEFITS:
   • Enterprise-grade API security
   • Automatic protection for all endpoints
   • Fine-grained access control
   • Complete audit trail
   • Rate limiting to prevent abuse
   • JWT token support for modern apps
   • HMAC request signing for critical ops

TESTING:
   Before:  curl http://localhost:7300/health
   After:   curl http://localhost:7300/health  (still works!)
   
   Before:  curl http://localhost:7300/lead/capture -X POST (no auth)
   After:   curl http://localhost:7300/lead/capture -X POST (requires API key)
            curl http://localhost:7300/lead/capture \\
              -H "X-API-Key: qc_marketing_..." -X POST (works!)
"""
