"""
Email Templates for AI Marketing
================================
Pre-approved email templates for lead nurturing
"""

EMAIL_TEMPLATES = {
    # Initial Outreach - QuranChain Pay
    "quranchain_pay_intro": {
        "subject": "Pay Less Than Stripe — Keep More of Your Revenue",
        "body": """Hi {name},

I noticed your business is processing payments through traditional processors. What if you could cut your fees in half?

QuranChain Pay offers:
✅ 1.9% transaction fees (vs Stripe's 2.9%)
✅ Same-day settlements
✅ No hidden fees
✅ Enterprise-grade security

For a business processing $50K/month, that's $6,000+ savings per year.

Want to see a 5-minute demo?

Best,
QuranChain Pay Team

---
Reply STOP to unsubscribe
""",
        "type": "cold_outreach",
        "approved": True
    },
    
    # Follow-up Sequence
    "follow_up_1": {
        "subject": "Quick question about your payment processing",
        "body": """Hi {name},

Just following up on my previous email about QuranChain Pay.

Quick question: What's your biggest frustration with your current payment processor?

Most merchants tell us:
- High fees eating into margins
- Slow settlements hurting cash flow  
- Poor customer support when issues arise

We've solved all three. Happy to show you how.

Best,
QuranChain Pay Team
""",
        "type": "follow_up",
        "approved": True,
        "delay_days": 3
    },
    
    "follow_up_2": {
        "subject": "Saving {business_name} ${estimated_savings}/year",
        "body": """Hi {name},

I ran the numbers for a business like yours.

Based on typical processing volume, you could save approximately ${estimated_savings} per year by switching to QuranChain Pay.

No long-term contracts. Switch anytime.

15-minute setup call?

Best,
QuranChain Pay Team
""",
        "type": "follow_up",
        "approved": True,
        "delay_days": 5
    },
    
    # Dar Al Nas Templates
    "dar_al_nas_intro": {
        "subject": "Islamic Banking Without Riba - Now Available",
        "body": """Assalamu Alaikum {name},

Are you tired of conventional banks that profit from interest?

Dar Al Nas is different:
🕌 100% Sharia-compliant
🚫 No riba (interest) - ever
🤝 Profit-sharing based on real economic activity
✅ Certified by qualified Islamic scholars

Services include:
- Halal checking & savings
- Murabaha home financing (3% fixed markup)
- Takaful cooperative insurance
- Zakat calculator & distribution

Join thousands of Muslims banking the halal way.

Wa Alaikum Assalam,
Dar Al Nas Team
""",
        "type": "cold_outreach",
        "approved": True
    },
    
    # Waitlist Confirmation
    "waitlist_confirm": {
        "subject": "You're on the {product_name} waitlist!",
        "body": """Hi {name},

Thank you for joining the {product_name} waitlist!

You're currently #{position} in line. We're onboarding merchants in batches to ensure the best experience.

What to expect:
1. We'll email you when your spot opens (usually 1-2 weeks)
2. Quick 15-minute setup call
3. Same-day activation

In the meantime, here are some resources:
- [FAQ] Common questions answered
- [Guide] How to prepare for migration
- [Calculator] See your potential savings

Reply to this email if you have any questions!

Best,
{product_name} Team
""",
        "type": "transactional",
        "approved": True
    },
    
    # Onboarding Complete
    "onboarding_complete": {
        "subject": "Welcome to {product_name} - You're Live!",
        "body": """Hi {name},

Congratulations! Your {product_name} account is now active.

Your Details:
- Merchant ID: {merchant_id}
- API Keys: Sent separately (check spam)
- Dashboard: https://dashboard.quranchain.com

Quick Start:
1. Log into your dashboard
2. Complete KYC verification (5 minutes)
3. Start accepting payments!

Support: support@quranchain.com
Docs: https://docs.quranchain.com

Welcome to the family!

Best,
{product_name} Team
""",
        "type": "transactional",
        "approved": True
    },
    
    # Upsell - Premium Features
    "upsell_premium": {
        "subject": "{name}, unlock advanced features",
        "body": """Hi {name},

You've been using {product_name} for {days_active} days and processed ${total_volume}.

Ready to level up? Our Growth plan includes:
✅ Multi-currency support (15+ currencies)
✅ Advanced analytics dashboard
✅ Priority settlement (2-hour vs same-day)
✅ Dedicated account manager

Upgrade now and get 20% off your first 3 months.

Best,
{product_name} Team
""",
        "type": "upsell",
        "approved": True
    },
    
    # Re-engagement
    "reengagement": {
        "subject": "We miss you, {name}",
        "body": """Hi {name},

We noticed you haven't processed a transaction in {inactive_days} days.

Everything okay? We're here to help if you're having any issues.

Common questions:
- Integration help? Reply to this email
- Pricing concerns? Let's discuss options
- Technical issues? Our support team is standing by

We'd love to have you back.

Best,
{product_name} Team
""",
        "type": "reengagement",
        "approved": True
    }
}

# Sequence definitions
EMAIL_SEQUENCES = {
    "quranchain_pay_new_lead": {
        "emails": [
            {"template": "quranchain_pay_intro", "day": 0},
            {"template": "follow_up_1", "day": 3},
            {"template": "follow_up_2", "day": 7},
        ],
        "max_emails": 3,
        "stop_on_reply": True
    },
    "dar_al_nas_waitlist": {
        "emails": [
            {"template": "dar_al_nas_intro", "day": 0},
            {"template": "waitlist_confirm", "day": 0},
        ],
        "max_emails": 2,
        "stop_on_reply": False
    },
    "post_onboarding": {
        "emails": [
            {"template": "onboarding_complete", "day": 0},
            {"template": "upsell_premium", "day": 30},
        ],
        "max_emails": 2,
        "stop_on_reply": False
    }
}

def get_template(template_name: str) -> dict:
    """Get an email template by name."""
    return EMAIL_TEMPLATES.get(template_name)

def render_template(template_name: str, variables: dict) -> dict:
    """Render an email template with variables."""
    template = EMAIL_TEMPLATES.get(template_name)
    if not template:
        return None
    
    rendered = {
        "subject": template["subject"].format(**variables),
        "body": template["body"].format(**variables),
        "type": template["type"]
    }
    return rendered

def get_sequence(sequence_name: str) -> dict:
    """Get an email sequence by name."""
    return EMAIL_SEQUENCES.get(sequence_name)
