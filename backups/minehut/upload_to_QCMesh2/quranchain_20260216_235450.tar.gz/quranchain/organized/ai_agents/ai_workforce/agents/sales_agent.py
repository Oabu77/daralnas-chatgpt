"""
Sales AI Agent - Revenue Closure
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- CRM management
- Lead qualification (BANT-style)
- Proposal drafting
- Contract preparation (templates only)
- Follow-ups with opted-in leads
- Scheduling calls or demos

Constraints:
- No misrepresentation
- No price deviation without approval
- Escalate to human closers when deal size threshold exceeded
"""

import asyncio
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict, field
from enum import Enum
import uuid

import sys
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from organized.ai_agents.ai_workforce.core.base_agent import (
    BaseAgent, AgentAction, ActionType, ApprovalLevel, AgentStatus
)
from organized.ai_agents.ai_workforce.core.message_bus import get_message_bus, Message, MessagePriority


class DealStage(Enum):
    LEAD = "lead"
    QUALIFIED = "qualified"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"


class ActivityType(Enum):
    EMAIL = "email"
    CALL = "call"
    MEETING = "meeting"
    DEMO = "demo"
    PROPOSAL_SENT = "proposal_sent"
    CONTRACT_SENT = "contract_sent"
    FOLLOW_UP = "follow_up"


@dataclass
class Deal:
    """Sales deal/opportunity"""
    deal_id: str
    lead_id: str
    contact_email: str
    contact_name: Optional[str]
    company: Optional[str]
    stage: DealStage
    value: float
    probability: int  # 0-100
    expected_close_date: str
    owner: str  # ai or human
    products: List[str]
    notes: str
    created_at: str
    updated_at: str
    closed_at: Optional[str] = None
    close_reason: Optional[str] = None
    
    @property
    def weighted_value(self) -> float:
        return self.value * (self.probability / 100)


@dataclass
class Activity:
    """Sales activity record"""
    activity_id: str
    deal_id: str
    activity_type: ActivityType
    subject: str
    description: str
    scheduled_at: Optional[str]
    completed_at: Optional[str]
    outcome: Optional[str]
    created_at: str


@dataclass
class Proposal:
    """Sales proposal"""
    proposal_id: str
    deal_id: str
    title: str
    products: List[Dict]  # {product, description, price, quantity}
    subtotal: float
    discount: float
    discount_approved: bool
    total: float
    founder_royalty: float  # 30% of profit
    terms: str
    valid_until: str
    status: str  # draft, sent, viewed, accepted, rejected, expired
    created_at: str


# Pricing catalog (approved prices)
PRODUCT_CATALOG = {
    "quranchain_pay_basic": {
        "name": "QuranChain Pay - Basic",
        "description": "Payment processing up to $10,000/month",
        "monthly_price": 49.00,
        "setup_fee": 0,
        "transaction_fee": 0.029  # 2.9%
    },
    "quranchain_pay_pro": {
        "name": "QuranChain Pay - Professional",
        "description": "Payment processing up to $100,000/month",
        "monthly_price": 199.00,
        "setup_fee": 0,
        "transaction_fee": 0.025  # 2.5%
    },
    "quranchain_pay_enterprise": {
        "name": "QuranChain Pay - Enterprise",
        "description": "Unlimited payment processing",
        "monthly_price": 499.00,
        "setup_fee": 500.00,
        "transaction_fee": 0.018  # 1.8%
    },
    "dar_al_nas_personal": {
        "name": "Dar Al Nas - Personal Account",
        "description": "Islamic banking account",
        "monthly_price": 0,
        "setup_fee": 0,
        "minimum_balance": 100.00
    },
    "dar_al_nas_business": {
        "name": "Dar Al Nas - Business Account",
        "description": "Islamic business banking",
        "monthly_price": 29.00,
        "setup_fee": 0,
        "minimum_balance": 1000.00
    },
    "takaful_basic": {
        "name": "Takaful Insurance - Basic",
        "description": "Islamic insurance coverage",
        "monthly_price": 79.00,
        "coverage": 50000.00
    },
    "takaful_family": {
        "name": "Takaful Insurance - Family",
        "description": "Family coverage plan",
        "monthly_price": 199.00,
        "coverage": 200000.00
    },
    "halal_wealth_starter": {
        "name": "Halal Wealth Club - Starter",
        "description": "Sharia-compliant investing",
        "monthly_price": 9.99,
        "minimum_investment": 100.00
    },
    "halal_wealth_premium": {
        "name": "Halal Wealth Club - Premium",
        "description": "Premium investment services",
        "monthly_price": 49.99,
        "minimum_investment": 10000.00
    }
}

# Deal size threshold for human escalation
HUMAN_ESCALATION_THRESHOLD = 10000.00


class SalesAgent(BaseAgent):
    """
    Sales AI Agent for revenue closure.
    
    This agent:
    - Manages the sales pipeline
    - Qualifies leads using BANT
    - Creates and sends proposals
    - Follows up with prospects
    - Escalates large deals to humans
    - Tracks revenue attribution
    """
    
    def __init__(self):
        super().__init__(
            agent_id="sales-ai-001",
            agent_name="Sales AI",
            agent_type="revenue_closure",
            max_actions_per_minute=60,
            max_revenue_action=HUMAN_ESCALATION_THRESHOLD
        )
        
        self._init_sales_db()
        self.message_bus = get_message_bus()
        
        # Subscribe to new leads
        self.message_bus.subscribe("new_lead", self._handle_new_lead)
    
    def _init_sales_db(self):
        """Initialize sales-specific tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Deals table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sales_deals (
                deal_id TEXT PRIMARY KEY,
                lead_id TEXT,
                contact_email TEXT NOT NULL,
                contact_name TEXT,
                company TEXT,
                stage TEXT DEFAULT 'lead',
                value REAL DEFAULT 0,
                probability INTEGER DEFAULT 10,
                expected_close_date TEXT,
                owner TEXT DEFAULT 'ai',
                products TEXT,
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT,
                closed_at TEXT,
                close_reason TEXT
            )
        """)
        
        # Activities table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sales_activities (
                activity_id TEXT PRIMARY KEY,
                deal_id TEXT NOT NULL,
                activity_type TEXT NOT NULL,
                subject TEXT,
                description TEXT,
                scheduled_at TEXT,
                completed_at TEXT,
                outcome TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (deal_id) REFERENCES sales_deals(deal_id)
            )
        """)
        
        # Proposals table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sales_proposals (
                proposal_id TEXT PRIMARY KEY,
                deal_id TEXT NOT NULL,
                title TEXT,
                products TEXT,
                subtotal REAL,
                discount REAL DEFAULT 0,
                discount_approved INTEGER DEFAULT 0,
                total REAL,
                founder_royalty REAL,
                terms TEXT,
                valid_until TEXT,
                status TEXT DEFAULT 'draft',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (deal_id) REFERENCES sales_deals(deal_id)
            )
        """)
        
        # Pipeline metrics
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sales_pipeline (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                snapshot_date TEXT DEFAULT CURRENT_TIMESTAMP,
                total_deals INTEGER,
                total_value REAL,
                weighted_value REAL,
                by_stage TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def get_capabilities(self) -> List[str]:
        return [
            "lead_qualification",
            "deal_management",
            "proposal_creation",
            "activity_tracking",
            "follow_up_scheduling",
            "pipeline_management",
            "revenue_forecasting",
            "contract_preparation"
        ]
    
    async def _execute_action_impl(self, action: AgentAction) -> Dict:
        """Execute sales-specific actions"""
        action_handlers = {
            "create_deal": self._create_deal,
            "update_deal": self._update_deal,
            "qualify_lead": self._qualify_lead,
            "create_proposal": self._create_proposal,
            "send_proposal": self._send_proposal,
            "log_activity": self._log_activity,
            "schedule_followup": self._schedule_followup,
            "close_deal": self._close_deal,
            "get_pipeline": self._get_pipeline,
            "forecast_revenue": self._forecast_revenue,
        }
        
        handler = action_handlers.get(action.target)
        if handler:
            return await handler(action.data)
        
        return {"error": f"Unknown action: {action.target}"}
    
    async def _handle_new_lead(self, message: Message):
        """Handle new leads from Marketing AI"""
        lead_data = message.payload
        
        self.logger.info(f"Received new lead: {lead_data.get('email')}")
        
        # Create a deal from the lead
        await self.create_deal(
            lead_id=lead_data.get("lead_id"),
            contact_email=lead_data.get("email"),
            contact_name=lead_data.get("name"),
            company=lead_data.get("company"),
            source=lead_data.get("source")
        )
    
    async def create_deal(
        self,
        lead_id: str,
        contact_email: str,
        contact_name: Optional[str] = None,
        company: Optional[str] = None,
        source: Optional[str] = None
    ) -> Deal:
        """Create a new deal from a lead"""
        
        action = AgentAction(
            action_type=ActionType.CREATE,
            description=f"Create deal for {contact_email}",
            target="create_deal",
            data={
                "lead_id": lead_id,
                "contact_email": contact_email,
                "contact_name": contact_name,
                "company": company,
                "source": source
            },
            approval_level=ApprovalLevel.NONE
        )
        
        result = await self.execute_action(action)
        return result
    
    async def _create_deal(self, data: Dict) -> Dict:
        """Internal deal creation"""
        deal = Deal(
            deal_id=str(uuid.uuid4()),
            lead_id=data.get("lead_id", ""),
            contact_email=data.get("contact_email"),
            contact_name=data.get("contact_name"),
            company=data.get("company"),
            stage=DealStage.LEAD,
            value=0,
            probability=10,
            expected_close_date=(datetime.utcnow() + timedelta(days=30)).isoformat(),
            owner="ai",
            products=[],
            notes=f"Source: {data.get('source', 'unknown')}",
            created_at=datetime.utcnow().isoformat(),
            updated_at=datetime.utcnow().isoformat()
        )
        
        # Save to database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO sales_deals (
                deal_id, lead_id, contact_email, contact_name, company,
                stage, value, probability, expected_close_date, owner,
                products, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            deal.deal_id,
            deal.lead_id,
            deal.contact_email,
            deal.contact_name,
            deal.company,
            deal.stage.value,
            deal.value,
            deal.probability,
            deal.expected_close_date,
            deal.owner,
            json.dumps(deal.products),
            deal.notes,
            deal.created_at,
            deal.updated_at
        ))
        
        conn.commit()
        conn.close()
        
        self.logger.info(f"Deal created: {deal.deal_id}")
        
        # Schedule initial follow-up
        await self._schedule_initial_followup(deal)
        
        return {
            **asdict(deal),
            "stage": deal.stage.value
        }
    
    async def _schedule_initial_followup(self, deal: Deal):
        """Schedule initial follow-up activity"""
        activity = Activity(
            activity_id=str(uuid.uuid4()),
            deal_id=deal.deal_id,
            activity_type=ActivityType.FOLLOW_UP,
            subject=f"Initial contact with {deal.contact_name or deal.contact_email}",
            description="Send welcome email and schedule discovery call",
            scheduled_at=(datetime.utcnow() + timedelta(hours=1)).isoformat(),
            completed_at=None,
            outcome=None,
            created_at=datetime.utcnow().isoformat()
        )
        
        await self._save_activity(activity)
    
    async def _save_activity(self, activity: Activity):
        """Save activity to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO sales_activities (
                activity_id, deal_id, activity_type, subject, description,
                scheduled_at, completed_at, outcome, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            activity.activity_id,
            activity.deal_id,
            activity.activity_type.value,
            activity.subject,
            activity.description,
            activity.scheduled_at,
            activity.completed_at,
            activity.outcome,
            activity.created_at
        ))
        
        conn.commit()
        conn.close()
    
    async def _update_deal(self, data: Dict) -> Dict:
        """Update deal information"""
        deal_id = data.get("deal_id")
        updates = data.get("updates", {})
        
        # Check if deal value exceeds threshold - escalate to human
        new_value = updates.get("value", 0)
        if new_value > HUMAN_ESCALATION_THRESHOLD:
            updates["owner"] = "human"
            self.logger.info(f"Deal {deal_id} escalated to human (value: ${new_value})")
            self.metrics.escalations += 1
        
        # Build update query
        set_clauses = []
        values = []
        for key, value in updates.items():
            if key in ["stage", "value", "probability", "expected_close_date", "owner", "products", "notes"]:
                set_clauses.append(f"{key} = ?")
                values.append(json.dumps(value) if key == "products" else value)
        
        set_clauses.append("updated_at = ?")
        values.append(datetime.utcnow().isoformat())
        values.append(deal_id)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(f"""
            UPDATE sales_deals SET {', '.join(set_clauses)} WHERE deal_id = ?
        """, values)
        
        conn.commit()
        conn.close()
        
        return {"deal_id": deal_id, "updated": True, "changes": updates}
    
    async def _qualify_lead(self, data: Dict) -> Dict:
        """Qualify a lead using BANT methodology"""
        deal_id = data.get("deal_id")
        
        # Get deal info
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM sales_deals WHERE deal_id = ?", (deal_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return {"error": "Deal not found"}
        
        # BANT scoring based on provided data
        bant = {
            "budget": {
                "score": data.get("budget_score", 0),
                "notes": data.get("budget_notes", "")
            },
            "authority": {
                "score": data.get("authority_score", 0),
                "notes": data.get("authority_notes", "")
            },
            "need": {
                "score": data.get("need_score", 0),
                "notes": data.get("need_notes", "")
            },
            "timeline": {
                "score": data.get("timeline_score", 0),
                "notes": data.get("timeline_notes", "")
            }
        }
        
        total_score = sum(item["score"] for item in bant.values())
        qualified = total_score >= 60
        
        # Determine new stage and probability
        if qualified:
            new_stage = "qualified"
            probability = min(30 + (total_score - 60), 50)
        else:
            new_stage = "lead"
            probability = max(10, total_score // 4)
        
        # Update deal
        await self._update_deal({
            "deal_id": deal_id,
            "updates": {
                "stage": new_stage,
                "probability": probability,
                "notes": f"BANT Score: {total_score}/100"
            }
        })
        
        return {
            "deal_id": deal_id,
            "bant_scores": bant,
            "total_score": total_score,
            "qualified": qualified,
            "new_stage": new_stage,
            "probability": probability,
            "recommended_products": self._recommend_products(bant)
        }
    
    def _recommend_products(self, bant: Dict) -> List[str]:
        """Recommend products based on BANT scores"""
        recommendations = []
        budget_score = bant["budget"]["score"]
        
        if budget_score >= 80:
            recommendations.append("quranchain_pay_enterprise")
            recommendations.append("takaful_family")
            recommendations.append("halal_wealth_premium")
        elif budget_score >= 50:
            recommendations.append("quranchain_pay_pro")
            recommendations.append("takaful_basic")
            recommendations.append("halal_wealth_starter")
        else:
            recommendations.append("quranchain_pay_basic")
            recommendations.append("dar_al_nas_personal")
        
        return recommendations
    
    async def create_proposal(
        self,
        deal_id: str,
        products: List[str],
        discount: float = 0,
        custom_terms: Optional[str] = None
    ) -> Proposal:
        """Create a sales proposal"""
        
        # Calculate if discount needs approval
        approval_level = ApprovalLevel.NONE
        if discount > 0:
            if discount > 0.20:  # >20% needs high approval
                approval_level = ApprovalLevel.HIGH
            elif discount > 0.10:  # >10% needs medium approval
                approval_level = ApprovalLevel.MEDIUM
            else:
                approval_level = ApprovalLevel.LOW
        
        action = AgentAction(
            action_type=ActionType.CREATE,
            description=f"Create proposal for deal {deal_id}",
            target="create_proposal",
            data={
                "deal_id": deal_id,
                "products": products,
                "discount": discount,
                "custom_terms": custom_terms
            },
            approval_level=approval_level
        )
        
        result = await self.execute_action(action)
        return result
    
    async def _create_proposal(self, data: Dict) -> Dict:
        """Internal proposal creation"""
        deal_id = data.get("deal_id")
        product_ids = data.get("products", [])
        discount = data.get("discount", 0)
        custom_terms = data.get("custom_terms")
        
        # Build line items from catalog
        line_items = []
        subtotal = 0
        
        for product_id in product_ids:
            if product_id in PRODUCT_CATALOG:
                product = PRODUCT_CATALOG[product_id]
                monthly = product.get("monthly_price", 0)
                setup = product.get("setup_fee", 0)
                annual = (monthly * 12) + setup
                
                line_items.append({
                    "product_id": product_id,
                    "name": product["name"],
                    "description": product["description"],
                    "monthly_price": monthly,
                    "setup_fee": setup,
                    "annual_value": annual
                })
                
                subtotal += annual
        
        # Apply discount
        discount_amount = subtotal * discount
        total = subtotal - discount_amount
        
        # Calculate founder royalty (30% of profit, assuming 40% margin)
        profit_margin = 0.40
        profit = total * profit_margin
        founder_royalty = profit * 0.30
        
        proposal = Proposal(
            proposal_id=str(uuid.uuid4()),
            deal_id=deal_id,
            title=f"QuranChain™ Services Proposal",
            products=line_items,
            subtotal=subtotal,
            discount=discount_amount,
            discount_approved=discount <= 0.10,  # Auto-approve up to 10%
            total=total,
            founder_royalty=founder_royalty,
            terms=custom_terms or self._get_standard_terms(),
            valid_until=(datetime.utcnow() + timedelta(days=30)).isoformat(),
            status="draft",
            created_at=datetime.utcnow().isoformat()
        )
        
        # Save proposal
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO sales_proposals (
                proposal_id, deal_id, title, products, subtotal, discount,
                discount_approved, total, founder_royalty, terms, valid_until, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            proposal.proposal_id,
            proposal.deal_id,
            proposal.title,
            json.dumps(proposal.products),
            proposal.subtotal,
            proposal.discount,
            1 if proposal.discount_approved else 0,
            proposal.total,
            proposal.founder_royalty,
            proposal.terms,
            proposal.valid_until,
            proposal.status,
            proposal.created_at
        ))
        
        # Update deal value
        cursor.execute(
            "UPDATE sales_deals SET value = ?, stage = 'proposal', updated_at = ? WHERE deal_id = ?",
            (total, datetime.utcnow().isoformat(), deal_id)
        )
        
        conn.commit()
        conn.close()
        
        return asdict(proposal)
    
    def _get_standard_terms(self) -> str:
        """Get standard proposal terms"""
        return """
TERMS AND CONDITIONS

1. PAYMENT TERMS
   - Monthly subscriptions billed on the 1st of each month
   - Annual plans paid upfront receive 15% discount
   - All prices in USD

2. SERVICE LEVEL AGREEMENT
   - 99.9% uptime guarantee
   - 24/7 customer support
   - 30-day money-back guarantee

3. SHARIA COMPLIANCE
   - All services certified Sharia-compliant
   - No interest (riba) charged
   - Profit-sharing model applied

4. CANCELLATION
   - Monthly plans: Cancel anytime with 30-day notice
   - Annual plans: Pro-rated refund available

5. DATA PROTECTION
   - GDPR compliant
   - Data encrypted at rest and in transit
   - No data sold to third parties

© 2025 QuranChain™ | Omar Mohammad Abunadi™
"""
    
    async def _send_proposal(self, data: Dict) -> Dict:
        """Send proposal to prospect (requires approval for large deals)"""
        proposal_id = data.get("proposal_id")
        
        # Get proposal
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM sales_proposals WHERE proposal_id = ?", (proposal_id,))
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return {"error": "Proposal not found"}
        
        total = row[7]  # total column
        
        # Update proposal status
        cursor.execute(
            "UPDATE sales_proposals SET status = 'sent' WHERE proposal_id = ?",
            (proposal_id,)
        )
        
        conn.commit()
        conn.close()
        
        # Log activity
        deal_id = row[1]
        activity = Activity(
            activity_id=str(uuid.uuid4()),
            deal_id=deal_id,
            activity_type=ActivityType.PROPOSAL_SENT,
            subject=f"Proposal sent: ${total:.2f}",
            description=f"Proposal {proposal_id} sent to prospect",
            scheduled_at=None,
            completed_at=datetime.utcnow().isoformat(),
            outcome="sent",
            created_at=datetime.utcnow().isoformat()
        )
        await self._save_activity(activity)
        
        return {
            "proposal_id": proposal_id,
            "status": "sent",
            "total": total,
            "sent_at": datetime.utcnow().isoformat()
        }
    
    async def _log_activity(self, data: Dict) -> Dict:
        """Log a sales activity"""
        activity = Activity(
            activity_id=str(uuid.uuid4()),
            deal_id=data.get("deal_id"),
            activity_type=ActivityType[data.get("activity_type", "FOLLOW_UP").upper()],
            subject=data.get("subject", ""),
            description=data.get("description", ""),
            scheduled_at=data.get("scheduled_at"),
            completed_at=data.get("completed_at"),
            outcome=data.get("outcome"),
            created_at=datetime.utcnow().isoformat()
        )
        
        await self._save_activity(activity)
        
        return asdict(activity)
    
    async def _schedule_followup(self, data: Dict) -> Dict:
        """Schedule a follow-up activity"""
        deal_id = data.get("deal_id")
        days_out = data.get("days_out", 3)
        subject = data.get("subject", "Follow-up")
        
        activity = Activity(
            activity_id=str(uuid.uuid4()),
            deal_id=deal_id,
            activity_type=ActivityType.FOLLOW_UP,
            subject=subject,
            description=data.get("description", ""),
            scheduled_at=(datetime.utcnow() + timedelta(days=days_out)).isoformat(),
            completed_at=None,
            outcome=None,
            created_at=datetime.utcnow().isoformat()
        )
        
        await self._save_activity(activity)
        
        return {
            "scheduled": True,
            "activity_id": activity.activity_id,
            "scheduled_for": activity.scheduled_at
        }
    
    async def _close_deal(self, data: Dict) -> Dict:
        """Close a deal (won or lost)"""
        deal_id = data.get("deal_id")
        won = data.get("won", False)
        reason = data.get("reason", "")
        revenue = data.get("revenue", 0)
        
        # For won deals with revenue, calculate royalty
        if won and revenue > 0:
            action = AgentAction(
                action_type=ActionType.TRANSFER,
                description=f"Close won deal {deal_id} with revenue ${revenue}",
                target="close_deal",
                data=data,
                revenue_impact=revenue,
                approval_level=ApprovalLevel.HIGH if revenue > HUMAN_ESCALATION_THRESHOLD else ApprovalLevel.MEDIUM
            )
            result = await self.execute_action(action)
            return result
        
        # Lost deals don't need special approval
        return await self._close_deal_impl(data)
    
    async def _close_deal_impl(self, data: Dict) -> Dict:
        """Internal deal closing logic"""
        deal_id = data.get("deal_id")
        won = data.get("won", False)
        reason = data.get("reason", "")
        revenue = data.get("revenue", 0)
        
        stage = "closed_won" if won else "closed_lost"
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE sales_deals SET 
                stage = ?, 
                closed_at = ?, 
                close_reason = ?,
                value = ?,
                probability = ?,
                updated_at = ?
            WHERE deal_id = ?
        """, (
            stage,
            datetime.utcnow().isoformat(),
            reason,
            revenue if won else 0,
            100 if won else 0,
            datetime.utcnow().isoformat(),
            deal_id
        ))
        
        conn.commit()
        conn.close()
        
        # Update metrics
        if won:
            self.metrics.deals_closed += 1
            self.metrics.revenue_attributed += revenue
            
            # Notify for revenue attribution
            await self.message_bus.publish(Message(
                topic="deal_closed",
                payload={
                    "deal_id": deal_id,
                    "revenue": revenue,
                    "founder_royalty": revenue * 0.40 * 0.30,  # 30% of 40% margin
                    "closed_at": datetime.utcnow().isoformat()
                },
                source_agent=self.agent_id,
                priority=MessagePriority.HIGH
            ))
        
        return {
            "deal_id": deal_id,
            "stage": stage,
            "revenue": revenue if won else 0,
            "closed_at": datetime.utcnow().isoformat()
        }
    
    async def _get_pipeline(self, data: Dict) -> Dict:
        """Get sales pipeline summary"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get deals by stage
        cursor.execute("""
            SELECT stage, COUNT(*), SUM(value), SUM(value * probability / 100)
            FROM sales_deals
            WHERE stage NOT IN ('closed_won', 'closed_lost')
            GROUP BY stage
        """)
        
        by_stage = {}
        total_deals = 0
        total_value = 0
        weighted_value = 0
        
        for row in cursor.fetchall():
            stage, count, value, weighted = row
            by_stage[stage] = {
                "count": count,
                "value": value or 0,
                "weighted_value": weighted or 0
            }
            total_deals += count
            total_value += value or 0
            weighted_value += weighted or 0
        
        # Get closed deals (last 30 days)
        cursor.execute("""
            SELECT COUNT(*), SUM(value) FROM sales_deals
            WHERE stage = 'closed_won' AND closed_at > datetime('now', '-30 days')
        """)
        won_row = cursor.fetchone()
        
        cursor.execute("""
            SELECT COUNT(*) FROM sales_deals
            WHERE stage = 'closed_lost' AND closed_at > datetime('now', '-30 days')
        """)
        lost_row = cursor.fetchone()
        
        conn.close()
        
        pipeline = {
            "total_deals": total_deals,
            "total_value": total_value,
            "weighted_value": weighted_value,
            "by_stage": by_stage,
            "last_30_days": {
                "won_deals": won_row[0] if won_row else 0,
                "won_revenue": won_row[1] if won_row and won_row[1] else 0,
                "lost_deals": lost_row[0] if lost_row else 0,
                "win_rate": (won_row[0] / (won_row[0] + lost_row[0]) * 100) if won_row and lost_row and (won_row[0] + lost_row[0]) > 0 else 0
            },
            "generated_at": datetime.utcnow().isoformat()
        }
        
        return pipeline
    
    async def _forecast_revenue(self, data: Dict) -> Dict:
        """Forecast revenue based on pipeline"""
        months = data.get("months", 3)
        
        pipeline = await self._get_pipeline({})
        
        # Simple forecast based on weighted pipeline
        monthly_weighted = pipeline["weighted_value"] / months
        
        forecast = {
            "period_months": months,
            "pipeline_value": pipeline["total_value"],
            "weighted_pipeline": pipeline["weighted_value"],
            "monthly_forecast": monthly_weighted,
            "quarterly_forecast": monthly_weighted * 3,
            "annual_forecast": monthly_weighted * 12,
            "founder_royalty_forecast": monthly_weighted * 12 * 0.40 * 0.30,  # 30% of profit
            "confidence": "medium",
            "generated_at": datetime.utcnow().isoformat()
        }
        
        return forecast
    
    async def run(self):
        """Main agent loop"""
        self.logger.info("Sales AI starting main loop")
        
        while self.status == AgentStatus.RUNNING:
            try:
                # Process pending follow-ups
                await self._process_scheduled_activities()
                
                # Update pipeline metrics
                await self._update_pipeline_snapshot()
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"Error in main loop: {e}")
                self.metrics.errors += 1
                await asyncio.sleep(60)
    
    async def _process_scheduled_activities(self):
        """Process scheduled activities"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get overdue activities
        cursor.execute("""
            SELECT * FROM sales_activities
            WHERE scheduled_at < datetime('now')
            AND completed_at IS NULL
        """)
        
        overdue = cursor.fetchall()
        conn.close()
        
        for activity in overdue:
            self.logger.info(f"Overdue activity: {activity[3]}")  # subject
            # In production, this would trigger actual follow-up actions
    
    async def _update_pipeline_snapshot(self):
        """Save pipeline snapshot for historical tracking"""
        pipeline = await self._get_pipeline({})
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO sales_pipeline (
                total_deals, total_value, weighted_value, by_stage
            ) VALUES (?, ?, ?, ?)
        """, (
            pipeline["total_deals"],
            pipeline["total_value"],
            pipeline["weighted_value"],
            json.dumps(pipeline["by_stage"])
        ))
        
        conn.commit()
        conn.close()


# Singleton instance
_sales_agent: Optional[SalesAgent] = None


def get_sales_agent() -> SalesAgent:
    global _sales_agent
    if _sales_agent is None:
        _sales_agent = SalesAgent()
    return _sales_agent
