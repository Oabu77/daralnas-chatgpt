"""
QuranChain™ Translation AI Agent
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- Customer inquiry handling
- Support ticket management
- FAQ responses
- Escalation routing

Constraints:
- Crypto payment guidance ONLY
- No refunds without approval
- Human escalation for complex issues
"""

import os
import sys
import json
import sqlite3
from datetime import datetime
from typing import Dict, Any, List, Optional

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from organized.ai_agents.ai_workforce.shared.base_agent import (
    BaseAIAgent, AgentType, ActionSeverity, 
    COPYRIGHT, FOUNDER_ROYALTY_RATE
)

# Add CRM to path
crm_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))), "crm")
sys.path.insert(0, crm_path)
from database import CRMDatabase, Lead, LeadSource, LeadStatus

# Initialize CRM
crm = CRMDatabase()


class TranslationAI(BaseAIAgent):
    """
    🚨 PAYMENT POLICY: CRYPTOCURRENCY ONLY
    
    This agent ONLY accepts cryptocurrency payments:
    - USDT (Tether) - Ethereum, Polygon, BSC, Tron
    - USDC (USD Coin) - Ethereum, Polygon, Solana
    - BTC (Bitcoin)
    - ETH (Ethereum)
    - DAI (Decentralized stablecoin)
    
    ❌ NO FIAT - No credit cards, no bank transfers, no PayPal
    ✅ CRYPTO ONLY - Pure decentralized economy
    
    Payment processor: DarPay™ Crypto (port 9011)
    """

    """
    Translation AI Agent for QuranChain ecosystem.
    
    Generates demand through ethical, consent-based marketing.
    """
    
    def __init__(self, agent_id: Optional[str] = None):
        super().__init__(AgentType.MARKETING, agent_id)
        self.content_templates = self._load_templates()
        
    def _load_templates(self) -> Dict[str, Any]:
        """Load marketing content templates"""
        return {
            "email_merchant_outreach": {
                "subject": "Pay with Cryptocurrency — Keep More of Your Revenue",
                "body": """Hi {{name}},

Traditional payment processors charge 2.9% + $0.30 per transaction.

QuranChain Pay automatically routes payments through the cheapest available rail — cryptocurrency (USDT, USDC, BTC, ETH, DAI).

Merchants typically save 30-60% on processing fees.

Would you like to see how much you could save based on your transaction volume?

Best regards,
QuranChain Pay Team

---
© QuranChain™ | Omar Mohammad Abunadi™
You're receiving this because you opted in at quranchain.com
Unsubscribe: {{unsubscribe_link}}"""
            },
            "email_dar_al_nas": {
                "subject": "Islamic Finance Without Riba — Dar Al Nas",
                "body": """Assalamu Alaikum {{name}},

Are you looking for Sharia-compliant financial services?

Dar Al Nas offers:
✓ Halal savings accounts (profit-sharing, not interest)
✓ Murabaha home financing (fixed 3% markup)
✓ Takaful insurance (cooperative, not commercial)
✓ Zakat calculation and distribution

Join thousands who manage their finances the halal way.

Jazak Allah Khair,
Dar Al Nas Team

---
© QuranChain™ | Omar Mohammad Abunadi™
You're receiving this because you opted in at quranchain.com
Unsubscribe: {{unsubscribe_link}}"""
            },
            "landing_quranchain_pay": {
                "headline": "Pay Less. Settle Faster. Own Your Payments.",
                "subheadline": "Automatic payment routing through the cheapest rail",
                "cta": "Get Early Access",
                "benefits": [
                    "Save 95% on payment fees (crypto $2 vs card $30 per $1k)",
                    "Automatic rail selection (crypto, ACH, card)",
                    "Real-time settlement",
                    "Sharia-compliant options available"
                ]
            },
            "landing_dar_al_nas": {
                "headline": "Islamic Finance Without Riba",
                "subheadline": "Sharia-compliant banking, mortgages, and insurance",
                "cta": "Join the Waitlist",
                "benefits": [
                    "No interest — profit-sharing instead",
                    "Halal mortgages with fixed markup",
                    "Takaful cooperative insurance",
                    "Automated zakat calculation"
                ]
            }
        }
    
    def _execute_internal(self, action: str, details: Dict[str, Any]) -> Any:
        """Execute marketing actions"""
        
        if action == "capture_lead":
            return self._capture_lead(details)
        elif action == "create_landing_page":
            return self._create_landing_page(details)
        elif action == "draft_email_campaign":
            return self._draft_email_campaign(details)
        elif action == "analyze_attribution":
            return self._analyze_attribution(details)
        elif action == "generate_content":
            return self._generate_content(details)
        elif action == "calculate_metrics":
            return self._calculate_metrics()
        else:
            raise ValueError(f"Unknown action: {action}")
    
    def _capture_lead(self, details: Dict) -> Dict:
        """
        Capture a new lead from a form submission.
        CRITICAL: Only captures leads who have explicitly opted in.
        """
        # Validate opt-in
        if not details.get("opted_in", False):
            self.logger.warning("Lead capture blocked - no opt-in consent")
            return {
                "success": False,
                "reason": "no_opt_in_consent",
                "message": "Lead must explicitly opt-in for communications"
            }
        
        lead = Lead(
            id=None,
            name=details["name"],
            email=details["email"],
            company=details.get("company"),
            phone=details.get("phone"),
            source=details.get("source", LeadSource.WEBSITE.value),
            status=LeadStatus.NEW.value,
            score=self._calculate_lead_score(details),
            notes=details.get("notes"),
            assigned_to=self.agent_id,
            created_at=datetime.utcnow().isoformat(),
            updated_at=datetime.utcnow().isoformat(),
            opted_in=True,
            opt_in_timestamp=datetime.utcnow().isoformat()
        )
        
        try:
            lead_id = crm.create_lead(lead)
            crm.log_activity("lead", lead_id, "captured", 
                           {"source": lead.source}, self.agent_id)
            
            self.logger.info(f"Lead captured: {lead.email} (ID: {lead_id})")
            
            return {
                "success": True,
                "lead_id": lead_id,
                "score": lead.score
            }
        except sqlite3.IntegrityError:
            self.logger.info(f"Lead already exists: {details['email']}")
            return {
                "success": False,
                "reason": "duplicate",
                "message": "Lead with this email already exists"
            }
    
    def _calculate_lead_score(self, details: Dict) -> int:
        """Calculate lead score based on available information"""
        score = 20  # Base score for opt-in
        
        if details.get("company"):
            score += 20
        if details.get("phone"):
            score += 10
        if details.get("volume"):
            volume = details["volume"]
            if volume > 100000:
                score += 30
            elif volume > 10000:
                score += 20
            elif volume > 1000:
                score += 10
        if details.get("source") == LeadSource.REFERRAL.value:
            score += 15
        if details.get("interested_products"):
            score += len(details["interested_products"]) * 5
            
        return min(score, 100)
    
    def _create_landing_page(self, details: Dict) -> Dict:
        """Generate landing page content"""
        template_key = details.get("template", "landing_quranchain_pay")
        template = self.content_templates.get(template_key, {})
        
        if not template:
            return {"success": False, "reason": "template_not_found"}
        
        # Generate landing page HTML
        landing_content = {
            "template": template_key,
            "headline": template.get("headline", ""),
            "subheadline": template.get("subheadline", ""),
            "cta": template.get("cta", "Get Started"),
            "benefits": template.get("benefits", []),
            "generated_at": datetime.utcnow().isoformat(),
            "generated_by": self.agent_id
        }
        
        self.logger.info(f"Landing page generated: {template_key}")
        
        return {
            "success": True,
            "content": landing_content
        }
    
    def _draft_email_campaign(self, details: Dict) -> Dict:
        """
        Draft an email campaign.
        NOTE: This only creates a draft - sending requires human approval.
        """
        template_key = details.get("template", "email_merchant_outreach")
        template = self.content_templates.get(template_key, {})
        
        if not template:
            return {"success": False, "reason": "template_not_found"}
        
        campaign = {
            "name": details.get("name", f"Campaign_{datetime.utcnow().strftime('%Y%m%d')}"),
            "subject": template["subject"],
            "body": template["body"],
            "status": "draft",  # Always draft - requires approval
            "target_segment": details.get("segment", "all_opted_in"),
            "created_by": self.agent_id,
            "created_at": datetime.utcnow().isoformat(),
            "requires_approval": True,
            "approval_checklist": [
                "Content reviewed for accuracy",
                "Unsubscribe link present",
                "Copyright notice included",
                "Target audience has opted in",
                "Sender identity verified"
            ]
        }
        
        self.logger.info(f"Email campaign drafted: {campaign['name']}")
        
        return {
            "success": True,
            "campaign": campaign,
            "message": "Campaign drafted. Requires human approval before sending."
        }
    
    def _analyze_attribution(self, details: Dict) -> Dict:
        """Analyze lead and revenue attribution"""
        conn = sqlite3.connect(crm.db_path)
        cursor = conn.cursor()
        
        # Attribution by source
        cursor.execute("""
            SELECT source, COUNT(*) as count, 
                   SUM(CASE WHEN status = 'won' THEN 1 ELSE 0 END) as converted
            FROM leads
            GROUP BY source
        """)
        source_attribution = [
            {"source": row[0], "leads": row[1], "converted": row[2]}
            for row in cursor.fetchall()
        ]
        
        # Revenue by source
        cursor.execute("""
            SELECT l.source, SUM(r.amount) as revenue
            FROM revenue_events r
            JOIN merchants m ON r.merchant_id = m.id
            JOIN leads l ON l.email = m.email
            GROUP BY l.source
        """)
        revenue_attribution = {row[0]: row[1] for row in cursor.fetchall()}
        
        conn.close()
        
        return {
            "success": True,
            "source_attribution": source_attribution,
            "revenue_attribution": revenue_attribution,
            "analyzed_at": datetime.utcnow().isoformat()
        }
    
    def _generate_content(self, details: Dict) -> Dict:
        """Generate marketing content"""
        content_type = details.get("type", "blog")
        topic = details.get("topic", "payment processing")
        
        # Content generation templates
        content_ideas = {
            "payment_processing": {
                "title": "5 Ways to Reduce Payment Processing Fees in 2025",
                "outline": [
                    "Introduction: The hidden costs of payment processing",
                    "1. Multi-rail payment routing",
                    "2. Stablecoins for recurring payments",
                    "3. Cryptocurrency for international transactions",
                    "4. Optimizing interchange categories",
                    "5. Negotiating volume discounts",
                    "Conclusion: How QuranChain Pay automates all of this"
                ]
            },
            "islamic_finance": {
                "title": "Understanding Halal Finance: A Beginner's Guide",
                "outline": [
                    "What makes finance halal vs haram",
                    "The prohibition of riba (interest)",
                    "Murabaha: cost-plus financing",
                    "Mudarabah: profit-sharing",
                    "Takaful: cooperative insurance",
                    "How Dar Al Nas implements these principles"
                ]
            }
        }
        
        content = content_ideas.get(topic, content_ideas["payment_processing"])
        
        return {
            "success": True,
            "content_type": content_type,
            "topic": topic,
            "content": content,
            "status": "draft",
            "requires_review": True
        }
    
    def _calculate_metrics(self) -> Dict:
        """Calculate marketing metrics"""
        conn = sqlite3.connect(crm.db_path)
        cursor = conn.cursor()
        
        # Lead metrics
        cursor.execute("SELECT COUNT(*) FROM leads WHERE assigned_to LIKE 'marketing%'")
        leads_generated = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(*) FROM leads 
            WHERE assigned_to LIKE 'marketing%' AND status = 'qualified'
        """)
        leads_qualified = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(*) FROM leads 
            WHERE assigned_to LIKE 'marketing%' AND status = 'won'
        """)
        leads_converted = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "leads_generated": leads_generated,
            "leads_qualified": leads_qualified,
            "leads_converted": leads_converted,
            "qualification_rate": (leads_qualified / leads_generated * 100) if leads_generated > 0 else 0,
            "conversion_rate": (leads_converted / leads_generated * 100) if leads_generated > 0 else 0,
            "calculated_at": datetime.utcnow().isoformat()
        }
    
    def run_cycle(self) -> Dict[str, Any]:
        """Run one marketing cycle"""
        results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions": []
        }
        
        # Calculate and log metrics
        metrics = self.execute_action(
            "calculate_metrics",
            {},
            ActionSeverity.LOW
        )
        results["actions"].append({"action": "calculate_metrics", "result": metrics})
        
        # Check for leads to score
        new_leads = crm.get_leads_by_status(LeadStatus.NEW.value)
        for lead in new_leads[:10]:  # Process up to 10 per cycle
            if lead.assigned_to == self.agent_id:
                # Update score if needed
                pass
        
        results["cycle_end"] = datetime.utcnow().isoformat()
        results["metrics"] = self.get_metrics()
        
        return results
    
    def get_content_library(self) -> Dict[str, Any]:
        """Get all available content templates"""
        return {
            "templates": list(self.content_templates.keys()),
            "email_templates": [k for k in self.content_templates if k.startswith("email_")],
            "landing_templates": [k for k in self.content_templates if k.startswith("landing_")]
        }


# ═══════════════════════════════════════════════════════════════
# MARKETING AI SERVICE
# ═══════════════════════════════════════════════════════════════

from flask import Flask, request, jsonify

def create_translation_api(agent: TranslationAI) -> Flask:
    """Create Flask API for Translation AI"""
    app = Flask(__name__)
    
    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({
            "status": "healthy",
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type.value,
            "copyright": COPYRIGHT
        })
    
    @app.route("/lead/capture", methods=["POST"])
    def capture_lead():
        """Capture a lead from form submission"""
        data = request.json
        
        # Validate required fields
        if not data.get("email") or not data.get("name"):
            return jsonify({"error": "email and name required"}), 400
        
        if not data.get("opted_in"):
            return jsonify({
                "error": "Opt-in consent required",
                "message": "Lead must explicitly opt-in for communications"
            }), 400
        
        result = agent.execute_action(
            "capture_lead",
            data,
            ActionSeverity.LOW,
            revenue_impact=0
        )
        
        return jsonify(result)
    
    @app.route("/content/landing", methods=["POST"])
    def generate_landing():
        """Generate landing page content"""
        data = request.json
        result = agent.execute_action(
            "create_landing_page",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/campaign/draft", methods=["POST"])
    def draft_campaign():
        """Draft an email campaign"""
        data = request.json
        result = agent.execute_action(
            "draft_email_campaign",
            data,
            ActionSeverity.MEDIUM  # Requires logging
        )
        return jsonify(result)
    
    @app.route("/analytics/attribution", methods=["GET"])
    def get_attribution():
        """Get attribution analytics"""
        result = agent.execute_action(
            "analyze_attribution",
            {},
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/metrics", methods=["GET"])
    def get_metrics():
        """Get marketing metrics"""
        return jsonify(agent.get_metrics())
    
    @app.route("/report", methods=["GET"])
    def get_report():
        """Get agent report"""
        return agent.generate_report(), 200, {"Content-Type": "text/plain"}
    
    return app


if __name__ == "__main__":
    print(f"Starting Translation AI Agent")
    print(COPYRIGHT)
    
    agent = TranslationAI()
    app = create_translation_api(agent)
    
    print(f"\nAgent ID: {agent.agent_id}")
    print(f"Commission Rate: {agent.commission_rate * 100}%")
    print(f"\nStarting API on port 9018...")
    
    app.run(host="0.0.0.0", port=9018, debug=False)
