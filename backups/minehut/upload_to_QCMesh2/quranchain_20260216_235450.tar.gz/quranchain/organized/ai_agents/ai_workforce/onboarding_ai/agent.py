"""
QuranChain™ Merchant Onboarding AI Agent
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- Guide merchants through onboarding
- API key provisioning (approval-gated)
- Documentation delivery
- Support ticket triage
- Reduce time-to-onboard

Constraints:
- API keys require human approval
- Verify payout wallet ownership
- Full KYB before activation
"""

import os
import sys
import json
import hashlib
import secrets
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from organized.ai_agents.ai_workforce.shared.base_agent import (
    BaseAIAgent, AgentType, ActionSeverity,
    COPYRIGHT, FOUNDER_ROYALTY_RATE
)

# Add CRM to path
crm_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))), "crm")
sys.path.insert(0, crm_path)
from database import CRMDatabase, Merchant, MerchantStatus

# Initialize CRM
crm = CRMDatabase()

@dataclass
class OnboardingStep:
    """
    🚨 PAYMENT POLICY: CRYPTOCURRENCY ONLY
    
    This agent ONLY accepts cryptocurrency payments:
    - USDT (Tether) - Ethereum, Polygon, BSC, Tron
    - USDC (USD Coin) - Ethereum, Polygon, Solana
    - BTC (Bitcoin)
    - ETH (Ethereum)
    - DAI (Decentralized stablecoin)
    
    ❌ NO FIAT - No credit cards, no bank transfers, no PayPal
    ✅ CRYPTO ONLY - Pure decentralized economy
    
    Payment processor: DarPay™ Crypto (port 9011)
    """

    step_id: str
    name: str
    description: str
    required: bool
    completed: bool
    completed_at: Optional[str]


@dataclass
class OnboardingChecklist:
    """Complete onboarding checklist"""
    merchant_id: int
    product: str
    steps: List[OnboardingStep]
    started_at: str
    completed_at: Optional[str]
    status: str


class OnboardingAI(BaseAIAgent):
    """
    Merchant Onboarding AI Agent.
    
    Guides merchants through onboarding with clear steps,
    documentation, and support triage.
    """
    
    # Onboarding steps by product
    ONBOARDING_STEPS = {
        "quranchain_pay": [
            OnboardingStep("account_created", "Create Account", "Register business account", True, False, None),
            OnboardingStep("email_verified", "Verify Email", "Confirm email address", True, False, None),
            OnboardingStep("business_info", "Business Information", "Company name, address, type", True, False, None),
            OnboardingStep("owner_info", "Owner Information", "Beneficial owner details", True, False, None),
            OnboardingStep("bank_account", "Bank Account", "Connect payout bank account", True, False, None),
            OnboardingStep("kyb_docs", "KYB Documents", "Upload required documents", True, False, None),
            OnboardingStep("kyb_review", "KYB Review", "Compliance team review", True, False, None),
            OnboardingStep("api_key_issued", "API Key", "API credentials issued", True, False, None),
            OnboardingStep("test_transaction", "Test Transaction", "Complete test payment", False, False, None),
            OnboardingStep("go_live", "Go Live", "Production activation", True, False, None),
        ],
        "dar_al_nas": [
            OnboardingStep("account_created", "Create Account", "Register account", True, False, None),
            OnboardingStep("email_verified", "Verify Email", "Confirm email address", True, False, None),
            OnboardingStep("personal_info", "Personal Information", "Name, address, DOB", True, False, None),
            OnboardingStep("kyc_docs", "KYC Documents", "Upload ID documents", True, False, None),
            OnboardingStep("kyc_review", "KYC Review", "Identity verification", True, False, None),
            OnboardingStep("sharia_agreement", "Sharia Agreement", "Accept Sharia compliance terms", True, False, None),
            OnboardingStep("account_active", "Account Activation", "Account ready to use", True, False, None),
        ],
    }
    
    # Documentation links
    DOCUMENTATION = {
        "quranchain_pay": {
            "quickstart": "/docs/quranchain-pay/quickstart",
            "api_reference": "/docs/quranchain-pay/api",
            "webhooks": "/docs/quranchain-pay/webhooks",
            "testing": "/docs/quranchain-pay/testing",
            "rails": "/docs/quranchain-pay/payment-rails",
            "faq": "/docs/quranchain-pay/faq",
        },
        "dar_al_nas": {
            "getting_started": "/docs/dar-al-nas/getting-started",
            "accounts": "/docs/dar-al-nas/accounts",
            "financing": "/docs/dar-al-nas/financing",
            "takaful": "/docs/dar-al-nas/takaful",
            "sharia_compliance": "/docs/dar-al-nas/sharia",
        },
    }
    
    def __init__(self, agent_id: Optional[str] = None):
        super().__init__(AgentType.ONBOARDING, agent_id)
        self.active_onboardings: Dict[int, OnboardingChecklist] = {}
    
    def _execute_internal(self, action: str, details: Dict[str, Any]) -> Any:
        """Execute onboarding actions"""
        
        if action == "start_onboarding":
            return self._start_onboarding(details)
        elif action == "update_step":
            return self._update_step(details)
        elif action == "get_checklist":
            return self._get_checklist(details)
        elif action == "request_api_key":
            return self._request_api_key(details)
        elif action == "verify_payout_wallet":
            return self._verify_payout_wallet(details)
        elif action == "activate_merchant":
            return self._activate_merchant(details)
        elif action == "get_documentation":
            return self._get_documentation(details)
        elif action == "triage_support":
            return self._triage_support(details)
        elif action == "get_onboarding_metrics":
            return self._get_onboarding_metrics()
        else:
            raise ValueError(f"Unknown action: {action}")
    
    def _start_onboarding(self, details: Dict) -> Dict:
        """Start onboarding process for a new merchant"""
        
        # Create merchant record
        merchant = Merchant(
            id=None,
            business_name=details["business_name"],
            contact_name=details["contact_name"],
            email=details["email"],
            phone=details.get("phone"),
            status=MerchantStatus.PENDING.value,
            api_key_issued=False,
            monthly_volume=details.get("expected_volume", 0),
            onboarded_at=None,
            onboarded_by=self.agent_id,
            created_at=datetime.utcnow().isoformat()
        )
        
        merchant_id = crm.create_merchant(merchant)
        
        # Create checklist
        product = details.get("product", "quranchain_pay")
        steps = [
            OnboardingStep(
                step_id=s.step_id,
                name=s.name,
                description=s.description,
                required=s.required,
                completed=False,
                completed_at=None
            )
            for s in self.ONBOARDING_STEPS.get(product, self.ONBOARDING_STEPS["quranchain_pay"])
        ]
        
        # Mark first step complete
        steps[0].completed = True
        steps[0].completed_at = datetime.utcnow().isoformat()
        
        checklist = OnboardingChecklist(
            merchant_id=merchant_id,
            product=product,
            steps=steps,
            started_at=datetime.utcnow().isoformat(),
            completed_at=None,
            status="in_progress"
        )
        
        self.active_onboardings[merchant_id] = checklist
        
        crm.log_activity("merchant", merchant_id, "onboarding_started", {
            "product": product,
            "agent": self.agent_id
        }, self.agent_id)
        
        self.logger.info(f"Onboarding started for merchant {merchant_id}")
        
        # Get next steps
        next_steps = [s for s in steps if not s.completed][:3]
        
        return {
            "success": True,
            "merchant_id": merchant_id,
            "product": product,
            "status": "in_progress",
            "next_steps": [
                {"step": s.step_id, "name": s.name, "description": s.description}
                for s in next_steps
            ],
            "documentation": self.DOCUMENTATION.get(product, {})
        }
    
    def _update_step(self, details: Dict) -> Dict:
        """Update onboarding step completion"""
        merchant_id = details["merchant_id"]
        step_id = details["step_id"]
        completed = details.get("completed", True)
        
        checklist = self.active_onboardings.get(merchant_id)
        if not checklist:
            return {"success": False, "reason": "onboarding_not_found"}
        
        # Find and update step
        for step in checklist.steps:
            if step.step_id == step_id:
                step.completed = completed
                step.completed_at = datetime.utcnow().isoformat() if completed else None
                break
        
        # Update merchant status
        required_steps = [s for s in checklist.steps if s.required]
        completed_required = [s for s in required_steps if s.completed]
        
        if len(completed_required) == len(required_steps):
            checklist.completed_at = datetime.utcnow().isoformat()
            checklist.status = "completed"
            crm.update_merchant_status(merchant_id, MerchantStatus.ONBOARDING.value)
        
        progress = len(completed_required) / len(required_steps) * 100
        
        crm.log_activity("merchant", merchant_id, "step_completed", {
            "step": step_id,
            "progress": progress
        }, self.agent_id)
        
        self.logger.info(f"Merchant {merchant_id} step {step_id}: {progress:.0f}% complete")
        
        # Get next steps
        next_steps = [s for s in checklist.steps if not s.completed][:3]
        
        return {
            "success": True,
            "merchant_id": merchant_id,
            "step_completed": step_id,
            "progress_percent": progress,
            "next_steps": [
                {"step": s.step_id, "name": s.name, "description": s.description}
                for s in next_steps
            ]
        }
    
    def _get_checklist(self, details: Dict) -> Dict:
        """Get current onboarding checklist"""
        merchant_id = details["merchant_id"]
        checklist = self.active_onboardings.get(merchant_id)
        
        if not checklist:
            return {"success": False, "reason": "onboarding_not_found"}
        
        return {
            "success": True,
            "merchant_id": merchant_id,
            "product": checklist.product,
            "status": checklist.status,
            "started_at": checklist.started_at,
            "steps": [
                {
                    "step_id": s.step_id,
                    "name": s.name,
                    "description": s.description,
                    "required": s.required,
                    "completed": s.completed,
                    "completed_at": s.completed_at
                }
                for s in checklist.steps
            ]
        }
    
    def _request_api_key(self, details: Dict) -> Dict:
        """
        Request API key issuance.
        REQUIRES HUMAN APPROVAL.
        """
        merchant_id = details["merchant_id"]
        
        # Check KYB completion
        checklist = self.active_onboardings.get(merchant_id)
        if not checklist:
            return {"success": False, "reason": "onboarding_not_found"}
        
        kyb_step = next((s for s in checklist.steps if s.step_id == "kyb_review"), None)
        if kyb_step and not kyb_step.completed:
            return {
                "success": False,
                "reason": "kyb_incomplete",
                "message": "KYB review must be completed before API key issuance"
            }
        
        # Generate pending API key (not active until approved)
        pending_key = f"qc_test_{secrets.token_hex(16)}"
        key_hash = hashlib.sha256(pending_key.encode()).hexdigest()
        
        # This requires approval
        self.logger.info(f"API key requested for merchant {merchant_id} - REQUIRES APPROVAL")
        
        crm.log_activity("merchant", merchant_id, "api_key_requested", {
            "key_hash": key_hash[:16],
            "requires_approval": True
        }, self.agent_id)
        
        return {
            "success": True,
            "status": "pending_approval",
            "merchant_id": merchant_id,
            "message": "API key request submitted. Requires human approval.",
            "estimated_time": "1-2 business hours",
            "key_preview": f"qc_test_****{pending_key[-8:]}"
        }
    
    def _verify_payout_wallet(self, details: Dict) -> Dict:
        """
        Verify merchant's payout wallet/bank account.
        Uses micro-deposits or blockchain verification.
        """
        merchant_id = details["merchant_id"]
        wallet_type = details.get("type", "bank")  # bank, crypto
        wallet_address = details.get("address")
        
        if wallet_type == "crypto":
            # For crypto, verify ownership via signature
            return {
                "success": True,
                "status": "verification_pending",
                "method": "signature",
                "instructions": [
                    f"Sign the message: 'QuranChain verify {merchant_id}'",
                    "Submit the signature for verification",
                    "Verification typically completes in 5 minutes"
                ]
            }
        else:
            # For bank, use micro-deposits
            return {
                "success": True,
                "status": "verification_pending",
                "method": "micro_deposits",
                "instructions": [
                    "Two small deposits (< $1.00) will be sent to your account",
                    "This typically takes 1-2 business days",
                    "Enter the exact amounts to verify ownership"
                ]
            }
    
    def _activate_merchant(self, details: Dict) -> Dict:
        """
        Activate a merchant for production.
        REQUIRES all onboarding steps complete.
        """
        merchant_id = details["merchant_id"]
        checklist = self.active_onboardings.get(merchant_id)
        
        if not checklist:
            return {"success": False, "reason": "onboarding_not_found"}
        
        # Check all required steps
        required_incomplete = [
            s for s in checklist.steps 
            if s.required and not s.completed
        ]
        
        if required_incomplete:
            return {
                "success": False,
                "reason": "incomplete_steps",
                "missing_steps": [s.step_id for s in required_incomplete]
            }
        
        # Activate
        crm.update_merchant_status(merchant_id, MerchantStatus.ACTIVE.value)
        
        # Update internal tracking
        checklist.status = "activated"
        
        crm.log_activity("merchant", merchant_id, "activated", {
            "activated_by": self.agent_id,
            "onboarding_duration_hours": self._calculate_onboarding_duration(checklist)
        }, self.agent_id)
        
        self.logger.info(f"Merchant {merchant_id} ACTIVATED")
        
        # Attribute revenue (setup fee if applicable)
        setup_fee = details.get("setup_fee", 0)
        if setup_fee > 0:
            self._attribute_revenue(f"merchant_activation_{merchant_id}", setup_fee)
        
        return {
            "success": True,
            "merchant_id": merchant_id,
            "status": "active",
            "message": "Merchant successfully activated for production",
            "next_steps": [
                "Complete first live transaction",
                "Review production best practices",
                "Set up webhook endpoints"
            ]
        }
    
    def _calculate_onboarding_duration(self, checklist: OnboardingChecklist) -> float:
        """Calculate onboarding duration in hours"""
        started = datetime.fromisoformat(checklist.started_at)
        ended = datetime.utcnow()
        duration = (ended - started).total_seconds() / 3600
        return round(duration, 1)
    
    def _get_documentation(self, details: Dict) -> Dict:
        """Get relevant documentation for merchant"""
        product = details.get("product", "quranchain_pay")
        topic = details.get("topic")
        
        docs = self.DOCUMENTATION.get(product, {})
        
        if topic and topic in docs:
            return {
                "success": True,
                "product": product,
                "topic": topic,
                "url": docs[topic]
            }
        
        return {
            "success": True,
            "product": product,
            "documentation": docs
        }
    
    def _triage_support(self, details: Dict) -> Dict:
        """Triage a support request"""
        merchant_id = details.get("merchant_id")
        issue_type = details.get("issue_type", "general")
        description = details.get("description", "")
        
        # Priority assignment
        priority_keywords = {
            "high": ["down", "not working", "urgent", "payment failed", "money", "critical"],
            "medium": ["error", "issue", "problem", "help", "stuck"],
            "low": ["question", "how to", "documentation", "feature"]
        }
        
        priority = "low"
        description_lower = description.lower()
        for p, keywords in priority_keywords.items():
            if any(kw in description_lower for kw in keywords):
                priority = p
                break
        
        # Auto-responses for common issues
        auto_responses = {
            "api_key": "Your API key can be found in your dashboard under Settings > API.",
            "webhook": "Webhook setup guide: /docs/quranchain-pay/webhooks",
            "testing": "Use the test mode toggle in your dashboard to enable test transactions.",
            "integration": "Check our quickstart guide: /docs/quranchain-pay/quickstart"
        }
        
        suggested_response = None
        for keyword, response in auto_responses.items():
            if keyword in description_lower:
                suggested_response = response
                break
        
        ticket = {
            "ticket_id": f"T{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            "merchant_id": merchant_id,
            "issue_type": issue_type,
            "priority": priority,
            "status": "open",
            "suggested_response": suggested_response,
            "requires_human": priority == "high" or not suggested_response,
            "created_at": datetime.utcnow().isoformat()
        }
        
        self.logger.info(f"Support ticket created: {ticket['ticket_id']} (Priority: {priority})")
        
        return {
            "success": True,
            "ticket": ticket
        }
    
    def _get_onboarding_metrics(self) -> Dict:
        """Get onboarding performance metrics"""
        merchant_stats = crm.get_merchant_count_by_status()
        
        # Calculate average onboarding time
        completed = [
            c for c in self.active_onboardings.values()
            if c.status in ["completed", "activated"]
        ]
        
        avg_time = 0
        if completed:
            durations = [self._calculate_onboarding_duration(c) for c in completed]
            avg_time = sum(durations) / len(durations)
        
        return {
            "success": True,
            "merchants_by_status": merchant_stats,
            "active_onboardings": len([c for c in self.active_onboardings.values() if c.status == "in_progress"]),
            "completed_onboardings": len(completed),
            "average_onboarding_hours": avg_time,
            "generated_at": datetime.utcnow().isoformat()
        }
    
    def run_cycle(self) -> Dict[str, Any]:
        """Run one onboarding cycle"""
        results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions": []
        }
        
        # Check for stalled onboardings
        for merchant_id, checklist in self.active_onboardings.items():
            if checklist.status == "in_progress":
                duration = self._calculate_onboarding_duration(checklist)
                if duration > 48:  # More than 48 hours
                    # Log stalled onboarding
                    self.logger.warning(f"Stalled onboarding: Merchant {merchant_id} ({duration:.1f}h)")
                    results["actions"].append({
                        "action": "stalled_alert",
                        "merchant_id": merchant_id,
                        "duration_hours": duration
                    })
        
        # Get metrics
        metrics = self.execute_action("get_onboarding_metrics", {}, ActionSeverity.LOW)
        results["metrics"] = metrics.get("result", {})
        
        results["cycle_end"] = datetime.utcnow().isoformat()
        
        return results


# ═══════════════════════════════════════════════════════════════
# ONBOARDING AI SERVICE
# ═══════════════════════════════════════════════════════════════

from flask import Flask, request, jsonify

def create_onboarding_api(agent: OnboardingAI) -> Flask:
    """Create Flask API for Onboarding AI"""
    app = Flask(__name__)
    
    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({
            "status": "healthy",
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type.value,
            "copyright": COPYRIGHT
        })
    
    @app.route("/onboarding/start", methods=["POST"])
    def start_onboarding():
        """Start onboarding for new merchant"""
        data = request.json
        
        required = ["business_name", "contact_name", "email"]
        for field in required:
            if not data.get(field):
                return jsonify({"error": f"{field} is required"}), 400
        
        result = agent.execute_action(
            "start_onboarding",
            data,
            ActionSeverity.MEDIUM
        )
        return jsonify(result)
    
    @app.route("/onboarding/<int:merchant_id>/step", methods=["POST"])
    def update_step(merchant_id):
        """Update onboarding step"""
        data = request.json
        data["merchant_id"] = merchant_id
        result = agent.execute_action(
            "update_step",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/onboarding/<int:merchant_id>/checklist", methods=["GET"])
    def get_checklist(merchant_id):
        """Get onboarding checklist"""
        result = agent.execute_action(
            "get_checklist",
            {"merchant_id": merchant_id},
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/onboarding/<int:merchant_id>/api-key", methods=["POST"])
    def request_api_key(merchant_id):
        """Request API key (requires approval)"""
        result = agent.execute_action(
            "request_api_key",
            {"merchant_id": merchant_id},
            ActionSeverity.HIGH  # Requires approval
        )
        return jsonify(result)
    
    @app.route("/onboarding/<int:merchant_id>/verify-wallet", methods=["POST"])
    def verify_wallet(merchant_id):
        """Verify payout wallet"""
        data = request.json
        data["merchant_id"] = merchant_id
        result = agent.execute_action(
            "verify_payout_wallet",
            data,
            ActionSeverity.MEDIUM
        )
        return jsonify(result)
    
    @app.route("/onboarding/<int:merchant_id>/activate", methods=["POST"])
    def activate_merchant(merchant_id):
        """Activate merchant for production"""
        data = request.json or {}
        data["merchant_id"] = merchant_id
        result = agent.execute_action(
            "activate_merchant",
            data,
            ActionSeverity.HIGH
        )
        return jsonify(result)
    
    @app.route("/support/triage", methods=["POST"])
    def triage_support():
        """Triage a support request"""
        data = request.json
        result = agent.execute_action(
            "triage_support",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/docs/<product>", methods=["GET"])
    def get_docs(product):
        """Get documentation links"""
        result = agent.execute_action(
            "get_documentation",
            {"product": product},
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/metrics", methods=["GET"])
    def get_metrics():
        """Get onboarding metrics"""
        return jsonify(agent.get_metrics())
    
    return app


if __name__ == "__main__":
    print(f"Starting Onboarding AI Agent")
    print(COPYRIGHT)
    
    agent = OnboardingAI()
    app = create_onboarding_api(agent)
    
    print(f"\nAgent ID: {agent.agent_id}")
    print(f"Commission Rate: {agent.commission_rate * 100}%")
    print(f"\nStarting API on port 9003...")
    
    app.run(host="0.0.0.0", port=9003, debug=False)
