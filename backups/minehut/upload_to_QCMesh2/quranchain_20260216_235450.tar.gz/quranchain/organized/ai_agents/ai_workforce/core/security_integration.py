"""
Agent API Security Integration Utilities
© QuranChain™ | Omar Mohammad Abunadi™

Helper functions and middleware for integrating security into agent Flask applications.
Agents use these utilities to automatically secure their endpoints.
"""

import logging
from functools import wraps
from typing import Optional, Callable, Any
from flask import Flask, request, jsonify, make_response

from .api_security import (
    APIKeyManager, JWTTokenManager, RequestSigner, RateLimiter,
    SecurityLevel, require_auth, require_permission, rate_limit, verify_signature
)
from .security_config import SecurityConfigManager, EndpointSecurityConfig

logger = logging.getLogger(__name__)


class AgentAPISecurityManager:
    """
    Manages all security aspects of an agent's API.
    
    Usage:
        security_mgr = AgentAPISecurityManager(agent_id, "Marketing AI")
        app = create_agent_api(agent)
        security_mgr.apply_security(app)
    """
    
    def __init__(self, agent_id: str, agent_name: str):
        self.agent_id = agent_id
        self.agent_name = agent_name
        
        # Initialize security components
        self.api_key_manager = APIKeyManager(agent_id)
        self.jwt_manager = JWTTokenManager(agent_id)
        self.request_signer = RequestSigner(agent_id)
        self.rate_limiter = RateLimiter(agent_id)
        self.config_manager = SecurityConfigManager()
        self.security_config = self.config_manager.get_or_create_config(agent_id, agent_name)
        
        logger.info(f"Initialized security for {agent_id}")
    
    def apply_security(self, app: Flask) -> None:
        """
        Apply all security measures to a Flask app
        
        This adds:
        - Security headers middleware
        - CORS handling
        - Request logging
        - Authentication on protected endpoints
        - Rate limiting
        """
        
        # Add security headers middleware
        @app.after_request
        def add_security_headers(response):
            for header, value in self.security_config.security_headers.items():
                response.headers[header] = value
            
            # Add CORS headers
            origin = request.headers.get("Origin")
            if origin in self.security_config.cors_allowed_origins:
                response.headers["Access-Control-Allow-Origin"] = origin
                response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
                response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-API-Key, X-Signature, X-Timestamp"
                if self.security_config.cors_allow_credentials:
                    response.headers["Access-Control-Allow-Credentials"] = "true"
            
            return response
        
        # Add request logging middleware
        @app.before_request
        def log_request():
            if self.security_config.log_all_requests:
                log_data = {
                    "method": request.method,
                    "path": request.path,
                    "remote_addr": request.remote_addr,
                    "user_agent": request.headers.get("User-Agent", "unknown")
                }
                
                # Log authentication method used
                if request.headers.get("Authorization"):
                    log_data["auth_method"] = "jwt"
                elif request.headers.get("X-API-Key"):
                    log_data["auth_method"] = "api_key"
                
                if self.security_config.log_request_bodies and request.method in ["POST", "PUT"]:
                    try:
                        log_data["body_size"] = len(request.get_data())
                    except:
                        pass
                
                logger.debug(f"Request: {log_data}")
        
        logger.info(f"Applied security to {self.agent_id} API")
    
    def protect_endpoint(
        self,
        route_func: Callable,
        path: str,
        security_level: Optional[SecurityLevel] = None
    ) -> Callable:
        """
        Protect a Flask route with appropriate security measures
        
        Args:
            route_func: The Flask route function
            path: The endpoint path
            security_level: Override security level
        
        Returns:
            Protected route function
        """
        
        # Get endpoint config
        endpoint_cfg = self.security_config.endpoint_configs.get(path)
        
        if not endpoint_cfg:
            logger.warning(f"No security config for {path}, using defaults")
            endpoint_cfg = EndpointSecurityConfig(path=path)
        
        security_level_str = security_level.value if security_level else endpoint_cfg.security_level
        
        @wraps(route_func)
        def protected_route(*args, **kwargs):
            
            # PUBLIC endpoints - no protection
            if security_level_str == "public":
                return route_func(*args, **kwargs)
            
            # AUTHENTICATED - require API key or JWT
            if security_level_str in ["authenticated", "authorized", "critical"]:
                
                # Check authentication
                auth_header = request.headers.get("Authorization", "")
                api_key = request.headers.get("X-API-Key")
                
                auth_valid = False
                user_data = None
                
                # Try JWT first
                if auth_header.startswith("Bearer "):
                    token = auth_header[7:]
                    if self.security_config.enable_jwt:
                        is_valid, payload = self.jwt_manager.verify_token(token)
                        if is_valid:
                            auth_valid = True
                            user_data = payload
                
                # Try API Key
                if not auth_valid and api_key and self.security_config.enable_api_keys:
                    required_perm = endpoint_cfg.required_permission
                    is_valid, key_data = self.api_key_manager.validate_key(api_key, required_perm)
                    if is_valid:
                        auth_valid = True
                        user_data = {
                            "type": "api_key",
                            "name": key_data.get("name"),
                            "permissions": key_data.get("permissions", [])
                        }
                
                if not auth_valid:
                    if self.security_config.alert_on_failed_auth:
                        logger.warning(f"Auth failed for {path} from {request.remote_addr}")
                    return jsonify({"error": "Authentication required"}), 401
                
                request.user = user_data
            
            # Check rate limiting
            identifier = (
                request.headers.get("X-API-Key") or
                request.remote_addr
            )
            
            is_allowed, rate_info = self.rate_limiter.is_allowed(
                identifier,
                endpoint_cfg.rate_limit or self.security_config.default_rate_limit
            )
            
            if not is_allowed:
                response = jsonify({
                    "error": "Rate limit exceeded",
                    "limit": rate_info["limit"],
                    "remaining": rate_info["remaining"],
                    "reset_at": rate_info["reset_at"]
                })
                response.status_code = 429
                return response
            
            # Verify request signature if required
            if endpoint_cfg.require_signature:
                signature = request.headers.get("X-Signature")
                timestamp = request.headers.get("X-Timestamp")
                
                if not signature or not timestamp:
                    return jsonify({"error": "Missing signature or timestamp"}), 400
                
                try:
                    timestamp = int(timestamp)
                except ValueError:
                    return jsonify({"error": "Invalid timestamp"}), 400
                
                body = request.get_data(as_text=True) if request.data else None
                
                if not self.request_signer.verify_signature(
                    request.method,
                    request.path,
                    signature,
                    timestamp,
                    body
                ):
                    return jsonify({"error": "Invalid signature"}), 401
            
            # Call the actual route
            return route_func(*args, **kwargs)
        
        return protected_route
    
    def generate_api_key(
        self,
        key_name: str,
        expires_in_days: Optional[int] = None,
        permissions: Optional[list] = None
    ) -> str:
        """Generate an API key for external services"""
        expires = expires_in_days or self.security_config.api_key_expiration_days
        return self.api_key_manager.generate_key(key_name, expires, permissions)
    
    def create_jwt_token(self, data: dict, expires_in_hours: int = 24) -> str:
        """Create a JWT token for authentication"""
        return self.jwt_manager.create_token(data, expires_in_hours)
    
    def sign_request(
        self,
        method: str,
        path: str,
        body: Optional[str] = None
    ) -> dict:
        """
        Sign a request for integrity verification
        
        Returns dict with signature and timestamp headers
        """
        import time
        timestamp = int(time.time())
        signature = self.request_signer.sign_request(method, path, body, timestamp)
        
        return {
            "X-Signature": signature,
            "X-Timestamp": str(timestamp)
        }
    
    def get_api_keys(self) -> list:
        """List all API keys for this agent"""
        return self.api_key_manager.list_keys()
    
    def revoke_api_key(self, key_name: str) -> bool:
        """Revoke an API key"""
        return self.api_key_manager.revoke_key(key_name)
    
    def get_security_report(self) -> dict:
        """Get a security report for the agent"""
        return {
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "authentication": {
                "api_keys_enabled": self.security_config.enable_api_keys,
                "jwt_enabled": self.security_config.enable_jwt,
                "request_signing_enabled": self.security_config.enable_request_signing,
                "active_api_keys": len([k for k in self.api_key_manager.list_keys() if k.get("active", True)])
            },
            "rate_limiting": {
                "default_limit": self.security_config.default_rate_limit,
                "window_seconds": self.security_config.rate_limit_window_seconds
            },
            "protected_endpoints": len([
                ep for ep in self.security_config.endpoint_configs.values()
                if ep.security_level != "public"
            ]),
            "cors": {
                "allowed_origins": self.security_config.cors_allowed_origins,
                "allow_credentials": self.security_config.cors_allow_credentials
            }
        }


def create_secured_flask_app(
    agent_id: str,
    agent_name: str,
    app: Flask
) -> tuple[Flask, AgentAPISecurityManager]:
    """
    Factory function to create a Flask app with security pre-configured
    
    Args:
        agent_id: Unique agent identifier
        agent_name: Agent display name
        app: Flask application instance
    
    Returns:
        Tuple of (secured Flask app, security manager)
    """
    
    security_mgr = AgentAPISecurityManager(agent_id, agent_name)
    security_mgr.apply_security(app)
    
    logger.info(f"Created secured Flask app for {agent_id}")
    
    return app, security_mgr


# Middleware for endpoint protection decorator
def secure_endpoint(security_mgr: AgentAPISecurityManager, path: str):
    """
    Decorator to add security to a Flask endpoint
    
    Usage:
        @app.route("/sensitive/endpoint", methods=["POST"])
        @secure_endpoint(security_mgr, "/sensitive/endpoint")
        def my_endpoint():
            return jsonify({"result": "success"})
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            return security_mgr.protect_endpoint(
                lambda: f(*args, **kwargs),
                path
            )()
        return decorated
    return decorator
