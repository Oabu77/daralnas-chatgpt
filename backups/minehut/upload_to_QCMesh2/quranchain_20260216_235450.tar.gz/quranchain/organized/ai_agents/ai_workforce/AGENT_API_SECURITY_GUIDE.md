# Agent API Security - Deployment Guide

© QuranChain™ | Omar Mohammad Abunadi™

## Overview

All 7 AI agents in QuranChain now automatically secure their own APIs with:
- **API Key authentication** - Simple header-based auth for services
- **JWT tokens** - Stateless authentication with expiration
- **Request signing** - HMAC signatures for critical operations
- **Rate limiting** - Per-key/IP limits to prevent abuse
- **Security headers** - CORS, XSS protection, content security
- **Request logging** - Audit trail of all API access
- **Permission-based access** - Fine-grained authorization

## Quick Start

### 1. Enable Security on Your Agent

```python
from ai_workforce.core.security_integration import create_secured_flask_app

# Create your Flask app
app = Flask(__name__)

# Wrap with security - automatic!
app, security_mgr = create_secured_flask_app(
    agent_id=agent.agent_id,
    agent_name="Marketing AI",
    app=app
)

# That's it - all endpoints now have security
```

### 2. Generate API Key for External Services

```python
# Generate an API key for a webhook processor
api_key = security_mgr.generate_api_key(
    key_name="webhook_processor",
    expires_in_days=90,
    permissions=["leads.create", "campaigns.view"]
)

# Key only shown once - store securely
print(f"API Key: {api_key}")
```

### 3. Use API Key in External Services

```python
import requests

# Send request with API key
response = requests.post(
    "http://localhost:7300/lead/capture",
    json={"email": "user@example.com", "name": "John"},
    headers={"X-API-Key": api_key}
)
```

## Security Features by Endpoint Type

### Public Endpoints
No authentication required. Used for health checks and public info.

```
GET /health
GET /status
GET /version
```

**Rate Limit**: 1000 req/hour

### Authenticated Endpoints
Requires API key OR JWT token. Data modification or viewing protected info.

```
POST /lead/capture
GET /analytics
POST /content/generate
```

**Rate Limit**: 50-100 req/hour  
**Authentication**: `X-API-Key` or `Authorization: Bearer <token>`

### Authorized Endpoints
Requires specific permissions. Campaign creation, role-based operations.

```
POST /campaign/create
POST /proposal/generate
POST /deal/update
```

**Rate Limit**: 20-50 req/hour  
**Requires**: API key + specific permission  
**Example Permission**: `campaigns.create`

### Critical Endpoints
Maximum security. Requires API key + request signature + permissions.

```
POST /campaign/deploy
POST /deal/close
POST /api-key/revoke
POST /service/restart
```

**Rate Limit**: 5-10 req/hour  
**Requires**: API key + `X-Signature` + `X-Timestamp`  
**Example**: Deploy campaign or close large deal

## Authentication Methods

### Method 1: API Key (Recommended for Services)

**When to use**: Webhooks, scheduled jobs, internal services  
**Pros**: Simple, easy to rotate, can have permissions  
**Cons**: Must be kept secret

```bash
curl -H "X-API-Key: qc_marketing_ai_abc123..." \
  http://localhost:7300/lead/capture
```

### Method 2: JWT Token (Recommended for Web/Mobile)

**When to use**: Web dashboards, mobile apps, user sessions  
**Pros**: Stateless, includes user context, can expire  
**Cons**: Server must verify signature

```bash
curl -H "Authorization: Bearer eyJhbGc..." \
  http://localhost:7300/analytics
```

**Create token:**
```python
token = security_mgr.create_jwt_token(
    data={"user_id": "user_123", "role": "admin"},
    expires_in_hours=24
)
```

### Method 3: Request Signing (Recommended for Critical Ops)

**When to use**: Deploy campaigns, close deals, system changes  
**Pros**: Verifies both authentication and integrity  
**Cons**: Slightly more complex

```python
# Prepare request
method = "POST"
path = "/campaign/deploy"
body = json.dumps({"campaign_id": "camp_123"})

# Get signature
sig_headers = security_mgr.sign_request(method, path, body)

# Send request
requests.post(
    "http://localhost:7300/campaign/deploy",
    data=body,
    headers={
        "X-API-Key": api_key,
        "X-Signature": sig_headers["X-Signature"],
        "X-Timestamp": sig_headers["X-Timestamp"]
    }
)
```

## Managing API Keys

### Generate Keys

```python
# Basic key
key1 = security_mgr.generate_api_key("my_service")

# With expiration
key2 = security_mgr.generate_api_key(
    "critical_service",
    expires_in_days=30
)

# With specific permissions
key3 = security_mgr.generate_api_key(
    "webhook_processor",
    expires_in_days=90,
    permissions=["leads.create", "campaigns.view"]
)
```

### List Active Keys

```python
keys = security_mgr.get_api_keys()
for key in keys:
    print(f"{key['name']}: {key['created_at']}")
    if key['expires_at']:
        print(f"  Expires: {key['expires_at']}")
```

### Revoke Keys

```python
security_mgr.revoke_api_key("old_service")
```

## Permission System

### Standard Permissions

**Read Permissions:**
- `health.check` - Health check endpoints
- `metrics.view` - View metrics and analytics
- `analytics.view` - View analytics reports
- `leads.view` - View lead data

**Write Permissions:**
- `leads.create` - Create new leads
- `campaigns.create` - Create campaigns
- `campaigns.edit` - Edit campaigns
- `campaigns.deploy` - Deploy campaigns (critical)
- `proposals.create` - Create proposals
- `deals.close` - Close deals (critical)

**Admin Permissions:**
- `api_keys.manage` - Manage API keys
- `security.configure` - Configure security settings
- `services.restart` - Restart services
- `logs.view` - View access logs

### Custom Permissions

Define for your agent:

```python
# When creating API key
custom_permissions = [
    "custom.action1",
    "custom.action2",
    "custom.action3"
]

key = security_mgr.generate_api_key(
    "my_service",
    permissions=custom_permissions
)
```

## Rate Limiting

### How It Works

- **Default**: 100 requests per hour per API key
- **Window**: 1-hour rolling window
- **Per-endpoint**: Different limits for different endpoints
- **Identifier**: API key (if present) or IP address

### Viewing Rate Limits

Response includes rate limit info:

```json
{
  "result": "...",
  "rate_limit": {
    "limit": 100,
    "remaining": 47,
    "reset_at": 1673432400
  }
}
```

### When Rate Limited

```json
{
  "error": "Rate limit exceeded",
  "limit": 100,
  "remaining": 0,
  "reset_at": 1673432400
}
```

Status Code: **429 Too Many Requests**

### Increasing Limits

Contact the agent admin or modify configuration:

```python
# In security config
config_mgr.update_config(
    agent_id="marketing_ai",
    updates={
        "default_rate_limit": 500,  # Increase limit
    }
)
```

## Security Configuration

### View Current Configuration

```python
report = security_mgr.get_security_report()
print(report)

# Output:
# {
#   "agent_id": "marketing_ai",
#   "authentication": {
#     "api_keys_enabled": true,
#     "jwt_enabled": true,
#     "request_signing_enabled": true,
#     "active_api_keys": 5
#   },
#   "protected_endpoints": 8,
#   ...
# }
```

### Modify Configuration

```python
from ai_workforce.core.security_config import SecurityConfigManager

config_mgr = SecurityConfigManager()
config_mgr.update_config(
    agent_id="marketing_ai",
    updates={
        "enable_api_keys": True,
        "enable_jwt": True,
        "default_rate_limit": 200,
        "api_key_expiration_days": 60
    }
)
```

## Security Headers

All responses automatically include:

```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
```

CORS headers added for allowed origins:

```
Access-Control-Allow-Origin: https://quranchain.com
Access-Control-Allow-Credentials: true
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
```

## Logging and Monitoring

### Request Logging

All requests logged with:
- Request method and path
- Remote IP address
- Authentication method used
- Timestamp

### Enable Request Body Logging (Careful!)

```python
config_mgr.update_config(
    agent_id="marketing_ai",
    updates={
        "log_request_bodies": True  # Only for debugging!
    }
)
```

### Monitoring Queries

#### Check recent API key usage
```python
keys = security_mgr.get_api_keys()
for key in keys:
    if key['last_used']:
        print(f"{key['name']}: {key['last_used']}")
```

#### Find expired keys
```python
from datetime import datetime
keys = security_mgr.get_api_keys()
for key in keys:
    if key['expires_at']:
        exp = datetime.fromisoformat(key['expires_at'])
        if exp < datetime.utcnow():
            print(f"EXPIRED: {key['name']}")
```

#### Check active keys
```python
keys = security_mgr.get_api_keys()
active = [k for k in keys if k['active']]
print(f"Active API keys: {len(active)}")
```

## Best Practices

### 1. API Key Rotation
- Rotate keys every 90 days
- Rotate critical keys every 30 days
- Revoke immediately if compromised

### 2. Permissions
- Use least privilege principle
- Grant only needed permissions
- Review permissions quarterly

### 3. Monitoring
- Monitor failed auth attempts
- Alert on unusual patterns
- Check expired keys monthly

### 4. Storage
- Never commit API keys to repo
- Use environment variables or vaults
- Restrict file permissions to 0600

### 5. Sharing
- Never share API keys in chat/email
- Use secure credential manager
- Rotate after any exposure

## Troubleshooting

### "Authentication required"
Check that you're sending API key or JWT:
```python
# Missing header
requests.get("http://localhost:7300/analytics")  # ❌

# With API key
requests.get(
    "http://localhost:7300/analytics",
    headers={"X-API-Key": "qc_marketing_..."}
)  # ✅
```

### "Invalid or expired token"
Token may have expired or key may be revoked:
```python
# Check expiration
if token_exp_time < current_time:
    token = security_mgr.create_jwt_token(data, 24)

# Check if key is active
keys = security_mgr.get_api_keys()
if not any(k['active'] for k in keys if k['name'] == 'my_key'):
    key = security_mgr.generate_api_key('my_key')
```

### "Rate limit exceeded"
You've exceeded the limit. Wait for reset time:
```json
{
  "error": "Rate limit exceeded",
  "reset_at": 1673432400
}
```

Wait until `reset_at` or contact admin to increase limit.

### "Invalid signature"
Check signature generation:
```python
# Wrong order
sig = security_mgr.sign_request("POST", "/api", body)  # ✅

# Missing timestamp
headers={
    "X-Signature": sig["X-Signature"],
    "X-Timestamp": sig["X-Timestamp"]  # ✅ Required
}
```

## Support

For security issues:
1. Contact: security@quranchain.com
2. Create a confidential issue on GitHub
3. Do NOT publish details publicly

For API questions:
1. Check [AGENT_SECURITY_IMPLEMENTATION.py](./AGENT_SECURITY_IMPLEMENTATION.py)
2. Review example code in agent implementations
3. Run `python AGENT_SECURITY_IMPLEMENTATION.py` for examples

---

**Last Updated**: 2024-01-13  
**Version**: 1.0  
**Status**: Production Ready
