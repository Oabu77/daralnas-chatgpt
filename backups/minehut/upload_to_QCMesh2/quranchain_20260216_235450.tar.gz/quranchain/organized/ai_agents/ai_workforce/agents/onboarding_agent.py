"""
Merchant & Partner Onboarding AI Agent
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- QuranChain Pay merchant onboarding
- API key provisioning (via approval)
- Documentation delivery
- Support ticket triage

Deliverables:
- Activated merchants
- Time-to-onboard metrics
- Merchant retention stats
"""

import asyncio
import json
import sqlite3
import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict, field
from enum import Enum
import uuid

import sys
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from organized.ai_agents.ai_workforce.core.base_agent import (
    BaseAgent, AgentAction, ActionType, ApprovalLevel, AgentStatus
)
from organized.ai_agents.ai_workforce.core.message_bus import get_message_bus, Message, MessagePriority


class OnboardingStage(Enum):
    APPLICATION = "application"
    VERIFICATION = "verification"
    KYC_PENDING = "kyc_pending"
    KYC_APPROVED = "kyc_approved"
    INTEGRATION = "integration"
    TESTING = "testing"
    LIVE = "live"
    SUSPENDED = "suspended"


class TicketPriority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    URGENT = 4


class TicketStatus(Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    WAITING_CUSTOMER = "waiting_customer"
    RESOLVED = "resolved"
    CLOSED = "closed"


@dataclass
class Merchant:
    """Merchant record"""
    merchant_id: str
    business_name: str
    business_type: str
    contact_email: str
    contact_name: str
    contact_phone: Optional[str]
    website: Optional[str]
    country: str
    stage: OnboardingStage
    api_key_hash: Optional[str]  # Never store plain API keys
    api_key_prefix: Optional[str]  # For identification (e.g., "qc_live_abc...")
    sandbox_key_hash: Optional[str]
    sandbox_key_prefix: Optional[str]
    monthly_volume_estimate: float
    fee_tier: str
    sharia_certified: bool
    created_at: str
    activated_at: Optional[str]
    kyc_status: str
    kyc_verified_at: Optional[str]
    notes: str


@dataclass
class SupportTicket:
    """Support ticket"""
    ticket_id: str
    merchant_id: Optional[str]
    requester_email: str
    subject: str
    description: str
    category: str
    priority: TicketPriority
    status: TicketStatus
    assigned_to: str  # ai or human agent
    created_at: str
    updated_at: str
    resolved_at: Optional[str]
    resolution: Optional[str]
    satisfaction_score: Optional[int]


@dataclass
class OnboardingTask:
    """Task in onboarding checklist"""
    task_id: str
    merchant_id: str
    task_name: str
    description: str
    required: bool
    completed: bool
    completed_at: Optional[str]
    completed_by: Optional[str]
    order: int


# Fee tiers based on monthly volume
FEE_TIERS = {
    "starter": {
        "min_volume": 0,
        "max_volume": 10000,
        "transaction_fee": 0.029,
        "monthly_fee": 0
    },
    "growth": {
        "min_volume": 10000,
        "max_volume": 50000,
        "transaction_fee": 0.025,
        "monthly_fee": 49
    },
    "scale": {
        "min_volume": 50000,
        "max_volume": 250000,
        "transaction_fee": 0.022,
        "monthly_fee": 199
    },
    "enterprise": {
        "min_volume": 250000,
        "max_volume": float('inf'),
        "transaction_fee": 0.018,
        "monthly_fee": 499
    }
}

# Standard onboarding checklist
ONBOARDING_CHECKLIST = [
    {"name": "Application Submitted", "description": "Complete merchant application form", "required": True, "order": 1},
    {"name": "Email Verified", "description": "Verify business email address", "required": True, "order": 2},
    {"name": "KYC Documents", "description": "Submit KYC documentation", "required": True, "order": 3},
    {"name": "KYC Approved", "description": "KYC verification complete", "required": True, "order": 4},
    {"name": "Sharia Compliance Review", "description": "Business reviewed for Sharia compliance", "required": True, "order": 5},
    {"name": "Sandbox API Key", "description": "Generate sandbox API credentials", "required": True, "order": 6},
    {"name": "Test Transaction", "description": "Complete test transaction in sandbox", "required": True, "order": 7},
    {"name": "Webhook Setup", "description": "Configure webhook endpoints", "required": False, "order": 8},
    {"name": "Live API Key", "description": "Generate production API credentials", "required": True, "order": 9},
    {"name": "First Live Transaction", "description": "Process first live transaction", "required": True, "order": 10}
]


class OnboardingAgent(BaseAgent):
    """
    Merchant & Partner Onboarding AI Agent.
    
    This agent:
    - Guides merchants through onboarding
    - Provisions API keys (with approval)
    - Delivers documentation
    - Triages support tickets
    - Tracks onboarding metrics
    """
    
    def __init__(self):
        super().__init__(
            agent_id="onboarding-ai-001",
            agent_name="Onboarding AI",
            agent_type="merchant_onboarding",
            max_actions_per_minute=60,
            max_revenue_action=1000
        )
        
        self._init_onboarding_db()
        self.message_bus = get_message_bus()
        
        # Subscribe to deal closures
        self.message_bus.subscribe("deal_closed", self._handle_deal_closed)
    
    def _init_onboarding_db(self):
        """Initialize onboarding-specific tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Merchants table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS merchants (
                merchant_id TEXT PRIMARY KEY,
                business_name TEXT NOT NULL,
                business_type TEXT,
                contact_email TEXT NOT NULL UNIQUE,
                contact_name TEXT,
                contact_phone TEXT,
                website TEXT,
                country TEXT,
                stage TEXT DEFAULT 'application',
                api_key_hash TEXT,
                api_key_prefix TEXT,
                sandbox_key_hash TEXT,
                sandbox_key_prefix TEXT,
                monthly_volume_estimate REAL DEFAULT 0,
                fee_tier TEXT DEFAULT 'starter',
                sharia_certified INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                activated_at TEXT,
                kyc_status TEXT DEFAULT 'pending',
                kyc_verified_at TEXT,
                notes TEXT
            )
        """)
        
        # Onboarding tasks table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS onboarding_tasks (
                task_id TEXT PRIMARY KEY,
                merchant_id TEXT NOT NULL,
                task_name TEXT NOT NULL,
                description TEXT,
                required INTEGER DEFAULT 1,
                completed INTEGER DEFAULT 0,
                completed_at TEXT,
                completed_by TEXT,
                task_order INTEGER,
                FOREIGN KEY (merchant_id) REFERENCES merchants(merchant_id)
            )
        """)
        
        # Support tickets table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS support_tickets (
                ticket_id TEXT PRIMARY KEY,
                merchant_id TEXT,
                requester_email TEXT NOT NULL,
                subject TEXT NOT NULL,
                description TEXT,
                category TEXT,
                priority INTEGER DEFAULT 2,
                status TEXT DEFAULT 'open',
                assigned_to TEXT DEFAULT 'ai',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT,
                resolved_at TEXT,
                resolution TEXT,
                satisfaction_score INTEGER,
                FOREIGN KEY (merchant_id) REFERENCES merchants(merchant_id)
            )
        """)
        
        # Ticket messages
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ticket_messages (
                message_id TEXT PRIMARY KEY,
                ticket_id TEXT NOT NULL,
                sender TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES support_tickets(ticket_id)
            )
        """)
        
        # API key audit log
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS api_key_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id TEXT NOT NULL,
                key_type TEXT NOT NULL,
                action TEXT NOT NULL,
                performed_by TEXT,
                performed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT,
                FOREIGN KEY (merchant_id) REFERENCES merchants(merchant_id)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def get_capabilities(self) -> List[str]:
        return [
            "merchant_application",
            "kyc_processing",
            "api_key_provisioning",
            "documentation_delivery",
            "support_ticket_triage",
            "onboarding_tracking",
            "merchant_activation",
            "retention_analysis"
        ]
    
    async def _execute_action_impl(self, action: AgentAction) -> Dict:
        """Execute onboarding-specific actions"""
        action_handlers = {
            "create_merchant": self._create_merchant,
            "update_merchant_stage": self._update_merchant_stage,
            "generate_api_key": self._generate_api_key,
            "complete_task": self._complete_task,
            "create_ticket": self._create_ticket,
            "triage_ticket": self._triage_ticket,
            "respond_to_ticket": self._respond_to_ticket,
            "get_onboarding_status": self._get_onboarding_status,
            "get_merchant_metrics": self._get_merchant_metrics,
        }
        
        handler = action_handlers.get(action.target)
        if handler:
            return await handler(action.data)
        
        return {"error": f"Unknown action: {action.target}"}
    
    async def _handle_deal_closed(self, message: Message):
        """Handle deal closure - start merchant onboarding"""
        deal_data = message.payload
        
        self.logger.info(f"Deal closed, checking for merchant onboarding")
        # In production, this would trigger automatic merchant creation
    
    async def create_merchant(
        self,
        business_name: str,
        contact_email: str,
        contact_name: str,
        business_type: str = "retail",
        country: str = "US",
        monthly_volume_estimate: float = 0,
        website: Optional[str] = None,
        contact_phone: Optional[str] = None
    ) -> Merchant:
        """Create a new merchant application"""
        
        action = AgentAction(
            action_type=ActionType.CREATE,
            description=f"Create merchant: {business_name}",
            target="create_merchant",
            data={
                "business_name": business_name,
                "contact_email": contact_email,
                "contact_name": contact_name,
                "business_type": business_type,
                "country": country,
                "monthly_volume_estimate": monthly_volume_estimate,
                "website": website,
                "contact_phone": contact_phone
            },
            approval_level=ApprovalLevel.NONE
        )
        
        result = await self.execute_action(action)
        return result
    
    async def _create_merchant(self, data: Dict) -> Dict:
        """Internal merchant creation"""
        merchant_id = str(uuid.uuid4())
        
        # Determine fee tier
        volume = data.get("monthly_volume_estimate", 0)
        fee_tier = "starter"
        for tier_name, tier_info in FEE_TIERS.items():
            if tier_info["min_volume"] <= volume < tier_info["max_volume"]:
                fee_tier = tier_name
                break
        
        merchant = Merchant(
            merchant_id=merchant_id,
            business_name=data.get("business_name"),
            business_type=data.get("business_type", "retail"),
            contact_email=data.get("contact_email"),
            contact_name=data.get("contact_name"),
            contact_phone=data.get("contact_phone"),
            website=data.get("website"),
            country=data.get("country", "US"),
            stage=OnboardingStage.APPLICATION,
            api_key_hash=None,
            api_key_prefix=None,
            sandbox_key_hash=None,
            sandbox_key_prefix=None,
            monthly_volume_estimate=volume,
            fee_tier=fee_tier,
            sharia_certified=False,
            created_at=datetime.utcnow().isoformat(),
            activated_at=None,
            kyc_status="pending",
            kyc_verified_at=None,
            notes=""
        )
        
        # Save to database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO merchants (
                    merchant_id, business_name, business_type, contact_email,
                    contact_name, contact_phone, website, country, stage,
                    monthly_volume_estimate, fee_tier, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                merchant.merchant_id,
                merchant.business_name,
                merchant.business_type,
                merchant.contact_email,
                merchant.contact_name,
                merchant.contact_phone,
                merchant.website,
                merchant.country,
                merchant.stage.value,
                merchant.monthly_volume_estimate,
                merchant.fee_tier,
                merchant.created_at
            ))
            
            conn.commit()
            
            # Create onboarding tasks
            await self._create_onboarding_tasks(merchant_id)
            
            # Complete first task (application submitted)
            await self._complete_task({
                "merchant_id": merchant_id,
                "task_name": "Application Submitted"
            })
            
            self.logger.info(f"Merchant created: {merchant.business_name} ({merchant_id})")
            
        except sqlite3.IntegrityError:
            conn.close()
            return {"error": "Email already registered"}
        
        conn.close()
        
        # Send welcome notification
        await self.message_bus.publish(Message(
            topic="merchant_created",
            payload={
                "merchant_id": merchant_id,
                "business_name": merchant.business_name,
                "email": merchant.contact_email
            },
            source_agent=self.agent_id,
            priority=MessagePriority.NORMAL
        ))
        
        return {
            **asdict(merchant),
            "stage": merchant.stage.value,
            "fee_tier_details": FEE_TIERS[fee_tier]
        }
    
    async def _create_onboarding_tasks(self, merchant_id: str):
        """Create onboarding checklist for a merchant"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for task in ONBOARDING_CHECKLIST:
            task_id = str(uuid.uuid4())
            cursor.execute("""
                INSERT INTO onboarding_tasks (
                    task_id, merchant_id, task_name, description, required, task_order
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                task_id,
                merchant_id,
                task["name"],
                task["description"],
                1 if task["required"] else 0,
                task["order"]
            ))
        
        conn.commit()
        conn.close()
    
    async def _complete_task(self, data: Dict) -> Dict:
        """Mark an onboarding task as complete"""
        merchant_id = data.get("merchant_id")
        task_name = data.get("task_name")
        completed_by = data.get("completed_by", "ai")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE onboarding_tasks 
            SET completed = 1, completed_at = ?, completed_by = ?
            WHERE merchant_id = ? AND task_name = ?
        """, (
            datetime.utcnow().isoformat(),
            completed_by,
            merchant_id,
            task_name
        ))
        
        affected = cursor.rowcount
        conn.commit()
        conn.close()
        
        if affected > 0:
            # Check if all required tasks complete
            await self._check_onboarding_completion(merchant_id)
        
        return {
            "task_name": task_name,
            "completed": affected > 0
        }
    
    async def _check_onboarding_completion(self, merchant_id: str):
        """Check if all required onboarding tasks are complete"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT COUNT(*) FROM onboarding_tasks
            WHERE merchant_id = ? AND required = 1 AND completed = 0
        """, (merchant_id,))
        
        incomplete_count = cursor.fetchone()[0]
        conn.close()
        
        if incomplete_count == 0:
            # All required tasks complete - activate merchant
            await self._update_merchant_stage({
                "merchant_id": merchant_id,
                "stage": "live"
            })
    
    async def _update_merchant_stage(self, data: Dict) -> Dict:
        """Update merchant onboarding stage"""
        merchant_id = data.get("merchant_id")
        new_stage = data.get("stage")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        update_fields = ["stage = ?"]
        update_values = [new_stage]
        
        if new_stage == "live":
            update_fields.append("activated_at = ?")
            update_values.append(datetime.utcnow().isoformat())
        
        if new_stage == "kyc_approved":
            update_fields.append("kyc_status = ?")
            update_fields.append("kyc_verified_at = ?")
            update_values.append("approved")
            update_values.append(datetime.utcnow().isoformat())
        
        update_values.append(merchant_id)
        
        cursor.execute(f"""
            UPDATE merchants SET {', '.join(update_fields)} WHERE merchant_id = ?
        """, update_values)
        
        conn.commit()
        conn.close()
        
        self.logger.info(f"Merchant {merchant_id} stage updated to {new_stage}")
        
        return {
            "merchant_id": merchant_id,
            "stage": new_stage,
            "updated_at": datetime.utcnow().isoformat()
        }
    
    async def generate_api_key(
        self,
        merchant_id: str,
        key_type: str = "sandbox",
        approved_by: Optional[str] = None
    ) -> Dict:
        """Generate API key for merchant (requires approval for live keys)"""
        
        approval_level = ApprovalLevel.HIGH if key_type == "live" else ApprovalLevel.LOW
        
        action = AgentAction(
            action_type=ActionType.CREATE,
            description=f"Generate {key_type} API key for merchant {merchant_id}",
            target="generate_api_key",
            data={
                "merchant_id": merchant_id,
                "key_type": key_type,
                "approved_by": approved_by
            },
            approval_level=approval_level
        )
        
        result = await self.execute_action(action)
        return result
    
    async def _generate_api_key(self, data: Dict) -> Dict:
        """Internal API key generation"""
        merchant_id = data.get("merchant_id")
        key_type = data.get("key_type", "sandbox")
        approved_by = data.get("approved_by", "system")
        
        # Generate secure API key
        key_bytes = secrets.token_bytes(32)
        api_key = f"qc_{key_type}_{secrets.token_urlsafe(32)}"
        key_prefix = api_key[:20]
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        # Store only the hash
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if key_type == "live":
            cursor.execute("""
                UPDATE merchants SET api_key_hash = ?, api_key_prefix = ?
                WHERE merchant_id = ?
            """, (key_hash, key_prefix, merchant_id))
        else:
            cursor.execute("""
                UPDATE merchants SET sandbox_key_hash = ?, sandbox_key_prefix = ?
                WHERE merchant_id = ?
            """, (key_hash, key_prefix, merchant_id))
        
        # Log the action
        cursor.execute("""
            INSERT INTO api_key_log (merchant_id, key_type, action, performed_by)
            VALUES (?, ?, ?, ?)
        """, (merchant_id, key_type, "generated", approved_by))
        
        conn.commit()
        conn.close()
        
        # Complete relevant task
        task_name = "Live API Key" if key_type == "live" else "Sandbox API Key"
        await self._complete_task({
            "merchant_id": merchant_id,
            "task_name": task_name
        })
        
        self.logger.info(f"API key generated for merchant {merchant_id} (type: {key_type})")
        
        # IMPORTANT: Return the key only ONCE - merchant must save it
        return {
            "merchant_id": merchant_id,
            "key_type": key_type,
            "api_key": api_key,  # Only shown once!
            "key_prefix": key_prefix,
            "warning": "Save this key now! It will not be shown again.",
            "generated_at": datetime.utcnow().isoformat()
        }
    
    async def create_ticket(
        self,
        requester_email: str,
        subject: str,
        description: str,
        category: str = "general",
        merchant_id: Optional[str] = None
    ) -> SupportTicket:
        """Create a support ticket"""
        
        action = AgentAction(
            action_type=ActionType.CREATE,
            description=f"Create support ticket: {subject}",
            target="create_ticket",
            data={
                "requester_email": requester_email,
                "subject": subject,
                "description": description,
                "category": category,
                "merchant_id": merchant_id
            },
            approval_level=ApprovalLevel.NONE
        )
        
        result = await self.execute_action(action)
        return result
    
    async def _create_ticket(self, data: Dict) -> Dict:
        """Internal ticket creation"""
        ticket_id = f"TKT-{datetime.utcnow().strftime('%Y%m%d')}-{secrets.token_hex(4).upper()}"
        
        ticket = SupportTicket(
            ticket_id=ticket_id,
            merchant_id=data.get("merchant_id"),
            requester_email=data.get("requester_email"),
            subject=data.get("subject"),
            description=data.get("description"),
            category=data.get("category", "general"),
            priority=TicketPriority.MEDIUM,
            status=TicketStatus.OPEN,
            assigned_to="ai",
            created_at=datetime.utcnow().isoformat(),
            updated_at=datetime.utcnow().isoformat(),
            resolved_at=None,
            resolution=None,
            satisfaction_score=None
        )
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO support_tickets (
                ticket_id, merchant_id, requester_email, subject, description,
                category, priority, status, assigned_to, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ticket.ticket_id,
            ticket.merchant_id,
            ticket.requester_email,
            ticket.subject,
            ticket.description,
            ticket.category,
            ticket.priority.value,
            ticket.status.value,
            ticket.assigned_to,
            ticket.created_at,
            ticket.updated_at
        ))
        
        conn.commit()
        conn.close()
        
        # Auto-triage the ticket
        await self._triage_ticket({"ticket_id": ticket_id})
        
        return {
            **asdict(ticket),
            "priority": ticket.priority.name,
            "status": ticket.status.value
        }
    
    async def _triage_ticket(self, data: Dict) -> Dict:
        """Triage a support ticket - determine priority and routing"""
        ticket_id = data.get("ticket_id")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM support_tickets WHERE ticket_id = ?", (ticket_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return {"error": "Ticket not found"}
        
        subject = row[3].lower()
        description = (row[4] or "").lower()
        category = row[5]
        
        # Priority keywords
        urgent_keywords = ["urgent", "critical", "down", "not working", "broken", "emergency"]
        high_keywords = ["payment", "failed", "error", "bug", "money", "transaction"]
        
        # Determine priority
        priority = TicketPriority.MEDIUM
        if any(kw in subject or kw in description for kw in urgent_keywords):
            priority = TicketPriority.URGENT
        elif any(kw in subject or kw in description for kw in high_keywords):
            priority = TicketPriority.HIGH
        
        # Determine routing
        assigned_to = "ai"
        if priority == TicketPriority.URGENT:
            assigned_to = "human"  # Escalate urgent tickets
            self.metrics.escalations += 1
        
        # Category-based routing
        if category in ["refund", "dispute", "legal"]:
            assigned_to = "human"
            self.metrics.escalations += 1
        
        # Update ticket
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE support_tickets SET priority = ?, assigned_to = ?, updated_at = ?
            WHERE ticket_id = ?
        """, (priority.value, assigned_to, datetime.utcnow().isoformat(), ticket_id))
        conn.commit()
        conn.close()
        
        return {
            "ticket_id": ticket_id,
            "priority": priority.name,
            "assigned_to": assigned_to,
            "escalated": assigned_to == "human"
        }
    
    async def _respond_to_ticket(self, data: Dict) -> Dict:
        """Respond to a support ticket"""
        ticket_id = data.get("ticket_id")
        message = data.get("message")
        sender = data.get("sender", "ai")
        resolve = data.get("resolve", False)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Add message
        message_id = str(uuid.uuid4())
        cursor.execute("""
            INSERT INTO ticket_messages (message_id, ticket_id, sender, message)
            VALUES (?, ?, ?, ?)
        """, (message_id, ticket_id, sender, message))
        
        # Update ticket
        updates = ["updated_at = ?"]
        values = [datetime.utcnow().isoformat()]
        
        if resolve:
            updates.extend(["status = ?", "resolved_at = ?", "resolution = ?"])
            values.extend(["resolved", datetime.utcnow().isoformat(), message])
        else:
            updates.append("status = ?")
            values.append("in_progress")
        
        values.append(ticket_id)
        
        cursor.execute(f"""
            UPDATE support_tickets SET {', '.join(updates)} WHERE ticket_id = ?
        """, values)
        
        conn.commit()
        conn.close()
        
        return {
            "ticket_id": ticket_id,
            "message_sent": True,
            "resolved": resolve
        }
    
    async def _get_onboarding_status(self, data: Dict) -> Dict:
        """Get merchant onboarding status"""
        merchant_id = data.get("merchant_id")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get merchant
        cursor.execute("SELECT * FROM merchants WHERE merchant_id = ?", (merchant_id,))
        merchant_row = cursor.fetchone()
        
        if not merchant_row:
            conn.close()
            return {"error": "Merchant not found"}
        
        # Get tasks
        cursor.execute("""
            SELECT task_name, completed, completed_at
            FROM onboarding_tasks
            WHERE merchant_id = ?
            ORDER BY task_order
        """, (merchant_id,))
        
        tasks = []
        completed_count = 0
        for row in cursor.fetchall():
            tasks.append({
                "task": row[0],
                "completed": bool(row[1]),
                "completed_at": row[2]
            })
            if row[1]:
                completed_count += 1
        
        conn.close()
        
        # Calculate time to onboard
        created_at = datetime.fromisoformat(merchant_row[16])
        activated_at = datetime.fromisoformat(merchant_row[17]) if merchant_row[17] else None
        
        time_to_onboard = None
        if activated_at:
            time_to_onboard = (activated_at - created_at).total_seconds() / 3600  # hours
        
        return {
            "merchant_id": merchant_id,
            "business_name": merchant_row[1],
            "stage": merchant_row[8],
            "progress": f"{completed_count}/{len(tasks)}",
            "progress_percent": round(completed_count / len(tasks) * 100),
            "tasks": tasks,
            "kyc_status": merchant_row[18],
            "time_to_onboard_hours": time_to_onboard,
            "activated": merchant_row[17] is not None
        }
    
    async def _get_merchant_metrics(self, data: Dict) -> Dict:
        """Get merchant onboarding metrics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total merchants
        cursor.execute("SELECT COUNT(*) FROM merchants")
        total = cursor.fetchone()[0]
        
        # By stage
        cursor.execute("SELECT stage, COUNT(*) FROM merchants GROUP BY stage")
        by_stage = dict(cursor.fetchall())
        
        # Active merchants (live)
        cursor.execute("SELECT COUNT(*) FROM merchants WHERE stage = 'live'")
        active = cursor.fetchone()[0]
        
        # Average time to onboard (completed merchants only)
        cursor.execute("""
            SELECT AVG(
                (julianday(activated_at) - julianday(created_at)) * 24
            ) FROM merchants WHERE activated_at IS NOT NULL
        """)
        avg_time = cursor.fetchone()[0]
        
        # Retention (merchants active > 30 days)
        cursor.execute("""
            SELECT COUNT(*) FROM merchants
            WHERE activated_at < datetime('now', '-30 days')
            AND stage = 'live'
        """)
        retained = cursor.fetchone()[0]
        
        # Support tickets
        cursor.execute("SELECT COUNT(*) FROM support_tickets WHERE status IN ('open', 'in_progress')")
        open_tickets = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT AVG(
                (julianday(resolved_at) - julianday(created_at)) * 24
            ) FROM support_tickets WHERE resolved_at IS NOT NULL
        """)
        avg_resolution_time = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "total_merchants": total,
            "active_merchants": active,
            "by_stage": by_stage,
            "average_onboarding_hours": round(avg_time, 1) if avg_time else None,
            "retention_30_day": retained,
            "open_support_tickets": open_tickets,
            "average_resolution_hours": round(avg_resolution_time, 1) if avg_resolution_time else None,
            "generated_at": datetime.utcnow().isoformat()
        }
    
    async def run(self):
        """Main agent loop"""
        self.logger.info("Onboarding AI starting main loop")
        
        while self.status == AgentStatus.RUNNING:
            try:
                # Process pending KYC reviews
                await self._process_pending_kyc()
                
                # Check for stalled onboardings
                await self._check_stalled_onboardings()
                
                # Process open tickets
                await self._process_open_tickets()
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"Error in main loop: {e}")
                self.metrics.errors += 1
                await asyncio.sleep(60)
    
    async def _process_pending_kyc(self):
        """Process merchants waiting for KYC"""
        # In production, this would integrate with KYC providers
        pass
    
    async def _check_stalled_onboardings(self):
        """Check for merchants stuck in onboarding"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Find merchants inactive for > 7 days
        cursor.execute("""
            SELECT merchant_id, business_name, contact_email, stage
            FROM merchants
            WHERE stage NOT IN ('live', 'suspended')
            AND created_at < datetime('now', '-7 days')
        """)
        
        stalled = cursor.fetchall()
        conn.close()
        
        for merchant in stalled:
            self.logger.info(f"Stalled onboarding: {merchant[1]} (stage: {merchant[3]})")
            # In production, this would send reminder emails
    
    async def _process_open_tickets(self):
        """Process and auto-respond to simple tickets"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get AI-assigned open tickets
        cursor.execute("""
            SELECT ticket_id, subject, description, category
            FROM support_tickets
            WHERE assigned_to = 'ai' AND status = 'open'
        """)
        
        tickets = cursor.fetchall()
        conn.close()
        
        # Auto-respond to simple tickets
        for ticket in tickets:
            ticket_id, subject, description, category = ticket
            response = self._generate_auto_response(subject, description, category)
            
            if response:
                await self._respond_to_ticket({
                    "ticket_id": ticket_id,
                    "message": response,
                    "sender": "ai"
                })
    
    def _generate_auto_response(self, subject: str, description: str, category: str) -> Optional[str]:
        """Generate automatic response for common queries"""
        subject_lower = subject.lower()
        
        # Common queries and responses
        if "api key" in subject_lower or "credentials" in subject_lower:
            return """Thank you for contacting QuranChain™ Support.

To generate or regenerate your API keys:
1. Log into your merchant dashboard
2. Navigate to Settings > API Keys
3. Click "Generate New Key" for sandbox or live credentials

For security, live API key generation requires admin approval.

If you need further assistance, please reply to this ticket.

Best regards,
QuranChain™ Support
© Omar Mohammad Abunadi™"""
        
        if "integration" in subject_lower or "documentation" in subject_lower:
            return """Thank you for contacting QuranChain™ Support.

Our integration documentation is available at:
- API Reference: https://docs.quranchain.com/api
- Quick Start Guide: https://docs.quranchain.com/quickstart
- Code Examples: https://github.com/quranchain/examples

If you have specific questions, please reply with details and we'll assist you.

Best regards,
QuranChain™ Support
© Omar Mohammad Abunadi™"""
        
        return None


# Singleton instance
_onboarding_agent: Optional[OnboardingAgent] = None


def get_onboarding_agent() -> OnboardingAgent:
    global _onboarding_agent
    if _onboarding_agent is None:
        _onboarding_agent = OnboardingAgent()
    return _onboarding_agent
