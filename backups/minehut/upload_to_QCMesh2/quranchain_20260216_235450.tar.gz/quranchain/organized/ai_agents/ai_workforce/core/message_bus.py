"""
Message Bus for AI Workforce Inter-Agent Communication
© QuranChain™ | Omar Mohammad Abunadi™

Provides:
- Pub/sub messaging
- Task queue
- Event broadcasting
- Priority handling
"""

import asyncio
import json
import sqlite3
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Callable, Any, Optional
from enum import Enum
import uuid
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("MessageBus")


class MessagePriority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    URGENT = 3
    CRITICAL = 4


class MessageType(Enum):
    TASK = "task"
    EVENT = "event"
    COMMAND = "command"
    RESPONSE = "response"
    BROADCAST = "broadcast"


@dataclass
class Message:
    """Message object for inter-agent communication"""
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    message_type: MessageType = MessageType.TASK
    priority: MessagePriority = MessagePriority.NORMAL
    source_agent: str = ""
    target_agent: str = ""  # Empty for broadcasts
    topic: str = ""
    payload: Dict = field(default_factory=dict)
    correlation_id: Optional[str] = None  # For request-response patterns
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    expires_at: Optional[str] = None
    processed: bool = False
    processed_at: Optional[str] = None
    result: Optional[Dict] = None


class MessageBus:
    """
    Central message bus for AI workforce communication.
    
    Features:
    - Topic-based pub/sub
    - Direct agent messaging
    - Priority queue
    - Message persistence
    - Dead letter handling
    """
    
    def __init__(self, db_path: str = "/home/omar/Desktop/QuranChain/ai_workforce/message_bus.db"):
        self.db_path = db_path
        self._subscribers: Dict[str, List[Callable]] = {}
        self._agent_handlers: Dict[str, Callable] = {}
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._running = False
        
        self._init_database()
    
    def _init_database(self):
        """Initialize message persistence database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                message_id TEXT PRIMARY KEY,
                message_type TEXT NOT NULL,
                priority INTEGER DEFAULT 1,
                source_agent TEXT,
                target_agent TEXT,
                topic TEXT,
                payload TEXT,
                correlation_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                expires_at TEXT,
                processed INTEGER DEFAULT 0,
                processed_at TEXT,
                result TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS dead_letters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id TEXT NOT NULL,
                error TEXT,
                retries INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_messages_topic ON messages(topic)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_messages_target ON messages(target_agent)
        """)
        
        conn.commit()
        conn.close()
    
    def subscribe(self, topic: str, handler: Callable):
        """Subscribe to a topic"""
        if topic not in self._subscribers:
            self._subscribers[topic] = []
        self._subscribers[topic].append(handler)
        logger.info(f"Subscribed to topic: {topic}")
    
    def unsubscribe(self, topic: str, handler: Callable):
        """Unsubscribe from a topic"""
        if topic in self._subscribers:
            self._subscribers[topic].remove(handler)
    
    def register_agent(self, agent_id: str, handler: Callable):
        """Register an agent's message handler"""
        self._agent_handlers[agent_id] = handler
        logger.info(f"Registered agent handler: {agent_id}")
    
    def unregister_agent(self, agent_id: str):
        """Unregister an agent"""
        if agent_id in self._agent_handlers:
            del self._agent_handlers[agent_id]
    
    async def publish(self, message: Message) -> str:
        """Publish a message to the bus"""
        # Persist message
        self._persist_message(message)
        
        # Add to priority queue (negative priority for max-heap behavior)
        await self._queue.put((-message.priority.value, message.created_at, message))
        
        logger.debug(f"Published message {message.message_id} to topic {message.topic}")
        return message.message_id
    
    async def send_to_agent(self, target_agent: str, message: Message) -> str:
        """Send a direct message to an agent"""
        message.target_agent = target_agent
        message.message_type = MessageType.COMMAND
        return await self.publish(message)
    
    async def broadcast(self, topic: str, payload: Dict, source_agent: str = "system") -> str:
        """Broadcast a message to all subscribers of a topic"""
        message = Message(
            message_type=MessageType.BROADCAST,
            source_agent=source_agent,
            topic=topic,
            payload=payload
        )
        return await self.publish(message)
    
    async def request(self, target_agent: str, payload: Dict, source_agent: str, timeout: float = 30.0) -> Optional[Dict]:
        """Send a request and wait for response"""
        correlation_id = str(uuid.uuid4())
        
        message = Message(
            message_type=MessageType.COMMAND,
            source_agent=source_agent,
            target_agent=target_agent,
            correlation_id=correlation_id,
            payload=payload
        )
        
        await self.publish(message)
        
        # Wait for response
        start_time = datetime.utcnow()
        while (datetime.utcnow() - start_time).total_seconds() < timeout:
            response = self._get_response(correlation_id)
            if response:
                return response
            await asyncio.sleep(0.1)
        
        return None
    
    def _get_response(self, correlation_id: str) -> Optional[Dict]:
        """Get response by correlation ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT result FROM messages 
            WHERE correlation_id = ? AND message_type = 'response' AND processed = 1
        """, (correlation_id,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result and result[0]:
            return json.loads(result[0])
        return None
    
    async def respond(self, original_message: Message, result: Dict, source_agent: str):
        """Send a response to a request"""
        if not original_message.correlation_id:
            return
        
        response = Message(
            message_type=MessageType.RESPONSE,
            source_agent=source_agent,
            target_agent=original_message.source_agent,
            correlation_id=original_message.correlation_id,
            payload=result
        )
        
        response.processed = True
        response.result = result
        
        await self.publish(response)
    
    def _persist_message(self, message: Message):
        """Persist message to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO messages (
                message_id, message_type, priority, source_agent, target_agent,
                topic, payload, correlation_id, created_at, expires_at,
                processed, processed_at, result
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            message.message_id,
            message.message_type.value,
            message.priority.value,
            message.source_agent,
            message.target_agent,
            message.topic,
            json.dumps(message.payload),
            message.correlation_id,
            message.created_at,
            message.expires_at,
            1 if message.processed else 0,
            message.processed_at,
            json.dumps(message.result) if message.result else None
        ))
        
        conn.commit()
        conn.close()
    
    def _mark_processed(self, message: Message, result: Optional[Dict] = None):
        """Mark message as processed"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE messages SET processed = 1, processed_at = ?, result = ?
            WHERE message_id = ?
        """, (datetime.utcnow().isoformat(), json.dumps(result) if result else None, message.message_id))
        
        conn.commit()
        conn.close()
    
    def _move_to_dead_letter(self, message: Message, error: str):
        """Move failed message to dead letter queue"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO dead_letters (message_id, error) VALUES (?, ?)
        """, (message.message_id, error))
        
        conn.commit()
        conn.close()
        
        logger.warning(f"Message {message.message_id} moved to dead letter queue: {error}")
    
    async def _process_message(self, message: Message):
        """Process a single message"""
        try:
            result = None
            
            # Direct agent message
            if message.target_agent and message.target_agent in self._agent_handlers:
                handler = self._agent_handlers[message.target_agent]
                result = await handler(message)
            
            # Topic subscribers
            if message.topic in self._subscribers:
                for handler in self._subscribers[message.topic]:
                    try:
                        await handler(message)
                    except Exception as e:
                        logger.error(f"Handler error for topic {message.topic}: {e}")
            
            self._mark_processed(message, result)
            
        except Exception as e:
            logger.error(f"Failed to process message {message.message_id}: {e}")
            self._move_to_dead_letter(message, str(e))
    
    async def start(self):
        """Start the message bus processor"""
        self._running = True
        logger.info("Message bus started")
        
        while self._running:
            try:
                # Get message from queue with timeout
                try:
                    _, _, message = await asyncio.wait_for(
                        self._queue.get(), timeout=1.0
                    )
                    await self._process_message(message)
                except asyncio.TimeoutError:
                    continue
                    
            except Exception as e:
                logger.error(f"Message bus error: {e}")
                await asyncio.sleep(1)
    
    async def stop(self):
        """Stop the message bus"""
        self._running = False
        logger.info("Message bus stopped")
    
    def get_pending_messages(self, agent_id: Optional[str] = None) -> List[Dict]:
        """Get pending messages, optionally filtered by agent"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if agent_id:
            cursor.execute("""
                SELECT * FROM messages WHERE target_agent = ? AND processed = 0
                ORDER BY priority DESC, created_at ASC
            """, (agent_id,))
        else:
            cursor.execute("""
                SELECT * FROM messages WHERE processed = 0
                ORDER BY priority DESC, created_at ASC
            """)
        
        columns = [desc[0] for desc in cursor.description]
        results = [dict(zip(columns, row)) for row in cursor.fetchall()]
        conn.close()
        
        return results
    
    def get_statistics(self) -> Dict:
        """Get message bus statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM messages")
        total = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM messages WHERE processed = 1")
        processed = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM dead_letters")
        dead_letters = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT topic, COUNT(*) FROM messages GROUP BY topic ORDER BY COUNT(*) DESC LIMIT 10
        """)
        top_topics = dict(cursor.fetchall())
        
        conn.close()
        
        return {
            "total_messages": total,
            "processed": processed,
            "pending": total - processed,
            "dead_letters": dead_letters,
            "queue_size": self._queue.qsize(),
            "subscribers": len(self._subscribers),
            "registered_agents": len(self._agent_handlers),
            "top_topics": top_topics
        }


# Global message bus instance
_message_bus: Optional[MessageBus] = None


def get_message_bus() -> MessageBus:
    """Get or create the global message bus instance"""
    global _message_bus
    if _message_bus is None:
        _message_bus = MessageBus()
    return _message_bus
