# AI Workforce - Templates Init
from .emails import EMAIL_TEMPLATES, EMAIL_SEQUENCES, get_template, render_template, get_sequence
