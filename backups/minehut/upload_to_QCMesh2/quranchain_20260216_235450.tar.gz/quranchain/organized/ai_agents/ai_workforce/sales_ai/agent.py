"""
QuranChain™ Sales AI Agent
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- CRM pipeline management
- Lead qualification (BANT)
- Proposal drafting
- Deal closing (low-ticket autonomous)
- High-ticket escalation to humans

Constraints:
- No misrepresentation
- No contract signing authority
- No price deviation without approval
- Escalate deals above threshold
"""

import os
import sys
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from organized.ai_agents.ai_workforce.shared.base_agent import (
    BaseAIAgent, AgentType, ActionSeverity,
    COPYRIGHT, FOUNDER_ROYALTY_RATE
)

# Add CRM to path
crm_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))), "crm")
sys.path.insert(0, crm_path)
from database import CRMDatabase, Lead, Deal, DealStage

# Initialize CRM
crm = CRMDatabase()


# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════

# Deal thresholds
LOW_TICKET_MAX = 500        # Auto-close up to $500
MID_TICKET_MAX = 2500       # Can negotiate up to $2500
HIGH_TICKET_THRESHOLD = 5000  # Requires human for $5000+

# Product pricing
PRICING = {
    "quranchain_pay_starter": {"monthly": 99, "annual": 999},
    "quranchain_pay_growth": {"monthly": 299, "annual": 2999},
    "quranchain_pay_enterprise": {"monthly": 999, "annual": 9999},
    "dar_al_nas_personal": {"monthly": 0, "annual": 0},
    "dar_al_nas_business": {"monthly": 49, "annual": 490},
    "takaful_basic": {"monthly": 29, "annual": 290},
    "takaful_family": {"monthly": 99, "annual": 990},
}


@dataclass
class BANTScore:
    """
    🚨 PAYMENT POLICY: CRYPTOCURRENCY ONLY
    
    This agent ONLY accepts cryptocurrency payments:
    - USDT (Tether) - Ethereum, Polygon, BSC, Tron
    - USDC (USD Coin) - Ethereum, Polygon, Solana
    - BTC (Bitcoin)
    - ETH (Ethereum)
    - DAI (Decentralized stablecoin)
    
    ❌ NO FIAT - No credit cards, no bank transfers, no PayPal
    ✅ CRYPTO ONLY - Pure decentralized economy
    
    Payment processor: DarPay™ Crypto (port 9011)
    """

    """BANT qualification score"""
    budget: int      # 0-25
    authority: int   # 0-25
    need: int        # 0-25
    timeline: int    # 0-25
    total: int       # 0-100
    qualified: bool  # total >= 60


class SalesAI(BaseAIAgent):
    """
    Sales AI Agent for QuranChain ecosystem.
    
    Converts qualified leads into paying customers through
    ethical, transparent sales processes.
    """
    
    def __init__(self, agent_id: Optional[str] = None):
        super().__init__(AgentType.SALES, agent_id)
        self.proposal_templates = self._load_proposal_templates()
        
        # Track deals being worked
        self.active_deals: Dict[int, Dict] = {}
    
    def _load_proposal_templates(self) -> Dict[str, str]:
        """Load proposal templates"""
        return {
            "quranchain_pay": """
PROPOSAL: QuranChain Pay Integration
=====================================
© QuranChain™ | Omar Mohammad Abunadi™

Prepared for: {{company_name}}
Date: {{date}}
Valid for: 30 days

EXECUTIVE SUMMARY
-----------------
QuranChain Pay offers automatic payment routing to reduce your
processing costs by 30-60% compared to traditional processors.

RECOMMENDED PLAN: {{plan_name}}
Monthly: ${{monthly_price}}
Annual: ${{annual_price}} (save {{annual_savings}}%)

INCLUDED FEATURES
-----------------
✓ Cryptocurrency payment processing (USDT, USDC, BTC, ETH, DAI)
✓ Real-time settlement options
✓ Merchant dashboard
✓ API access
✓ Sharia-compliant options
✓ 24/7 support

ESTIMATED SAVINGS
-----------------
Based on {{monthly_volume}} monthly volume:
- Current fees (est. 2.9%): ${{current_fees}}
- QuranChain Pay fees (est. 1.2%): ${{our_fees}}
- Monthly savings: ${{monthly_savings}}
- Annual savings: ${{annual_savings_amount}}

NEXT STEPS
----------
1. Sign up at quranchain.com/pay
2. Complete KYB verification
3. Integrate API (average: 2 hours)
4. Start processing payments

This proposal is informational only and not a binding contract.
Final terms subject to agreement execution.
""",
            "dar_al_nas": """
PROPOSAL: Dar Al Nas Business Account
=====================================
© QuranChain™ | Omar Mohammad Abunadi™

Prepared for: {{company_name}}
Date: {{date}}

SHARIA-COMPLIANT BUSINESS BANKING
---------------------------------
Dar Al Nas provides fully halal financial services with
no riba (interest) - only ethical profit-sharing.

BUSINESS ACCOUNT FEATURES
-------------------------
✓ Checking account (no interest)
✓ Profit-sharing savings (est. 3-5% annual return)
✓ Business financing (Murabaha)
✓ Takaful insurance options
✓ Zakat calculation tools

PRICING
-------
Monthly: ${{monthly_price}}
Annual: ${{annual_price}}

All services comply with AAOIFI Sharia standards.

NEXT STEPS
----------
1. Complete business application
2. Submit required documents
3. Sharia board review (1-2 days)
4. Account activation

This proposal is informational only.
"""
        }
    
    def _execute_internal(self, action: str, details: Dict[str, Any]) -> Any:
        """Execute sales actions"""
        
        if action == "qualify_lead":
            return self._qualify_lead(details)
        elif action == "create_deal":
            return self._create_deal(details)
        elif action == "update_deal_stage":
            return self._update_deal_stage(details)
        elif action == "generate_proposal":
            return self._generate_proposal(details)
        elif action == "close_deal":
            return self._close_deal(details)
        elif action == "get_pipeline":
            return self._get_pipeline()
        elif action == "forecast_revenue":
            return self._forecast_revenue()
        elif action == "schedule_followup":
            return self._schedule_followup(details)
        else:
            raise ValueError(f"Unknown action: {action}")
    
    def _qualify_lead(self, details: Dict) -> Dict:
        """
        Qualify a lead using BANT methodology.
        Budget, Authority, Need, Timeline
        """
        lead_id = details.get("lead_id")
        lead = crm.get_lead(lead_id) if lead_id else None
        
        if not lead:
            return {"success": False, "reason": "lead_not_found"}
        
        # BANT scoring
        budget_score = self._score_budget(details.get("budget_info", {}))
        authority_score = self._score_authority(details.get("authority_info", {}))
        need_score = self._score_need(details.get("need_info", {}))
        timeline_score = self._score_timeline(details.get("timeline_info", {}))
        
        total_score = budget_score + authority_score + need_score + timeline_score
        qualified = total_score >= 60
        
        bant = BANTScore(
            budget=budget_score,
            authority=authority_score,
            need=need_score,
            timeline=timeline_score,
            total=total_score,
            qualified=qualified
        )
        
        # Update lead status
        new_status = LeadStatus.QUALIFIED.value if qualified else LeadStatus.CONTACTED.value
        crm.update_lead_status(lead_id, new_status, f"BANT Score: {total_score}")
        
        crm.log_activity("lead", lead_id, "qualified", {
            "bant_score": total_score,
            "qualified": qualified,
            "breakdown": {
                "budget": budget_score,
                "authority": authority_score,
                "need": need_score,
                "timeline": timeline_score
            }
        }, self.agent_id)
        
        self.logger.info(f"Lead {lead_id} qualified: {qualified} (score: {total_score})")
        
        return {
            "success": True,
            "lead_id": lead_id,
            "bant": {
                "budget": budget_score,
                "authority": authority_score,
                "need": need_score,
                "timeline": timeline_score,
                "total": total_score,
                "qualified": qualified
            },
            "next_action": "create_deal" if qualified else "nurture"
        }
    
    def _score_budget(self, info: Dict) -> int:
        """Score budget qualification"""
        if info.get("confirmed_budget"):
            if info.get("budget_amount", 0) >= 1000:
                return 25
            elif info.get("budget_amount", 0) >= 100:
                return 20
            else:
                return 15
        elif info.get("budget_discussion"):
            return 10
        return 5
    
    def _score_authority(self, info: Dict) -> int:
        """Score decision-making authority"""
        role = info.get("role", "").lower()
        if any(t in role for t in ["ceo", "cfo", "cto", "owner", "founder", "director"]):
            return 25
        elif any(t in role for t in ["manager", "head", "lead", "vp"]):
            return 20
        elif info.get("can_decide"):
            return 15
        return 5
    
    def _score_need(self, info: Dict) -> int:
        """Score need/pain point"""
        if info.get("explicit_pain"):
            return 25
        elif info.get("current_solution_issues"):
            return 20
        elif info.get("exploring_options"):
            return 15
        elif info.get("general_interest"):
            return 10
        return 5
    
    def _score_timeline(self, info: Dict) -> int:
        """Score purchase timeline"""
        timeline = info.get("timeline", "unknown").lower()
        if "immediate" in timeline or "now" in timeline or "asap" in timeline:
            return 25
        elif "month" in timeline or "30 day" in timeline:
            return 20
        elif "quarter" in timeline or "90 day" in timeline:
            return 15
        elif "year" in timeline:
            return 10
        return 5
    
    def _create_deal(self, details: Dict) -> Dict:
        """Create a new deal from qualified lead"""
        lead_id = details.get("lead_id")
        lead = crm.get_lead(lead_id) if lead_id else None
        
        if not lead:
            return {"success": False, "reason": "lead_not_found"}
        
        # Determine product and value
        product = details.get("product", "quranchain_pay_starter")
        pricing = PRICING.get(product, PRICING["quranchain_pay_starter"])
        deal_value = details.get("deal_value", pricing["annual"])
        
        deal = Deal(
            id=None,
            lead_id=lead_id,
            name=f"{lead.company or lead.name} - {product}",
            stage=DealStage.DISCOVERY.value,
            deal_value=deal_value,
            currency="USD",
            probability=20,
            expected_close_date=(datetime.utcnow() + timedelta(days=30)).isoformat(),
            product=product,
            assigned_to=self.agent_id,
            notes=details.get("notes"),
            created_at=datetime.utcnow().isoformat(),
            updated_at=datetime.utcnow().isoformat()
        )
        
        deal_id = crm.create_deal(deal)
        
        crm.log_activity("deal", deal_id, "created", {
            "product": product,
            "value": deal_value
        }, self.agent_id)
        
        self.logger.info(f"Deal created: {deal_id} - ${deal_value}")
        
        return {
            "success": True,
            "deal_id": deal_id,
            "deal_value": deal_value,
            "product": product
        }
    
    def _update_deal_stage(self, details: Dict) -> Dict:
        """Update deal stage"""
        deal_id = details.get("deal_id")
        new_stage = details.get("stage")
        
        # Stage probability mapping
        stage_probability = {
            DealStage.DISCOVERY.value: 20,
            DealStage.QUALIFICATION.value: 40,
            DealStage.PROPOSAL.value: 60,
            DealStage.NEGOTIATION.value: 80,
        }
        
        probability = stage_probability.get(new_stage, 50)
        
        crm.update_deal_stage(deal_id, new_stage, probability)
        
        crm.log_activity("deal", deal_id, "stage_updated", {
            "new_stage": new_stage,
            "probability": probability
        }, self.agent_id)
        
        self.logger.info(f"Deal {deal_id} moved to {new_stage}")
        
        return {
            "success": True,
            "deal_id": deal_id,
            "stage": new_stage,
            "probability": probability
        }
    
    def _generate_proposal(self, details: Dict) -> Dict:
        """Generate a proposal for a deal"""
        deal_id = details.get("deal_id")
        template_name = details.get("template", "quranchain_pay")
        
        template = self.proposal_templates.get(template_name, "")
        if not template:
            return {"success": False, "reason": "template_not_found"}
        
        # Get deal and lead info
        conn = sqlite3.connect(crm.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT d.*, l.name, l.company, l.email
            FROM deals d
            JOIN leads l ON d.lead_id = l.id
            WHERE d.id = ?
        """, (deal_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return {"success": False, "reason": "deal_not_found"}
        
        # Fill template
        product = row[8]
        pricing = PRICING.get(product, PRICING["quranchain_pay_starter"])
        monthly_volume = details.get("monthly_volume", 10000)
        
        proposal = template.replace("{{company_name}}", row[14] or row[13])
        proposal = proposal.replace("{{date}}", datetime.utcnow().strftime("%Y-%m-%d"))
        proposal = proposal.replace("{{plan_name}}", product.replace("_", " ").title())
        proposal = proposal.replace("{{monthly_price}}", str(pricing["monthly"]))
        proposal = proposal.replace("{{annual_price}}", str(pricing["annual"]))
        proposal = proposal.replace("{{annual_savings}}", "17")
        proposal = proposal.replace("{{monthly_volume}}", f"${monthly_volume:,}")
        
        current_fees = monthly_volume * 0.029
        our_fees = monthly_volume * 0.012
        monthly_savings = current_fees - our_fees
        
        proposal = proposal.replace("{{current_fees}}", f"{current_fees:,.2f}")
        proposal = proposal.replace("{{our_fees}}", f"{our_fees:,.2f}")
        proposal = proposal.replace("{{monthly_savings}}", f"{monthly_savings:,.2f}")
        proposal = proposal.replace("{{annual_savings_amount}}", f"{monthly_savings * 12:,.2f}")
        
        # Move deal to proposal stage
        crm.update_deal_stage(deal_id, DealStage.PROPOSAL.value, 60)
        
        crm.log_activity("deal", deal_id, "proposal_generated", {
            "template": template_name
        }, self.agent_id)
        
        return {
            "success": True,
            "deal_id": deal_id,
            "proposal": proposal,
            "stage": "proposal",
            "message": "Proposal generated. Review before sending to prospect."
        }
    
    def _close_deal(self, details: Dict) -> Dict:
        """
        Close a deal as won or lost.
        
        CONSTRAINTS:
        - Can auto-close deals up to LOW_TICKET_MAX
        - MID_TICKET requires logging
        - HIGH_TICKET requires human approval
        """
        deal_id = details.get("deal_id")
        won = details.get("won", True)
        final_value = details.get("final_value")
        
        # Get deal
        conn = sqlite3.connect(crm.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT deal_value FROM deals WHERE id = ?", (deal_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return {"success": False, "reason": "deal_not_found"}
        
        deal_value = final_value or row[0]
        
        # Check thresholds
        if deal_value > HIGH_TICKET_THRESHOLD:
            self.logger.warning(f"Deal {deal_id} (${deal_value}) requires human approval")
            return {
                "success": False,
                "reason": "requires_human_approval",
                "message": f"Deals over ${HIGH_TICKET_THRESHOLD} require human closer",
                "deal_id": deal_id,
                "deal_value": deal_value,
                "escalation_required": True
            }
        
        # Close the deal
        crm.close_deal(deal_id, won, deal_value)
        
        # Update lead status
        conn = sqlite3.connect(crm.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT lead_id FROM deals WHERE id = ?", (deal_id,))
        lead_id = cursor.fetchone()[0]
        conn.close()
        
        crm.update_lead_status(
            lead_id, 
            LeadStatus.WON.value if won else LeadStatus.LOST.value
        )
        
        crm.log_activity("deal", deal_id, "closed", {
            "won": won,
            "final_value": deal_value
        }, self.agent_id)
        
        # Attribute revenue if won
        if won:
            self._attribute_revenue(f"deal_{deal_id}", deal_value)
        
        self.logger.info(f"Deal {deal_id} closed: {'WON' if won else 'LOST'} - ${deal_value}")
        
        return {
            "success": True,
            "deal_id": deal_id,
            "won": won,
            "final_value": deal_value,
            "revenue_attributed": deal_value if won else 0
        }
    
    def _get_pipeline(self) -> Dict:
        """Get current sales pipeline"""
        pipeline = crm.get_pipeline()
        pipeline_value = crm.get_pipeline_value()
        
        total_deals = sum(len(deals) for deals in pipeline.values())
        total_value = sum(pv["total_value"] for pv in pipeline_value.values())
        weighted_value = sum(pv["weighted_value"] for pv in pipeline_value.values())
        
        return {
            "success": True,
            "pipeline": pipeline,
            "summary": {
                "total_deals": total_deals,
                "total_value": total_value,
                "weighted_value": weighted_value
            },
            "by_stage": pipeline_value
        }
    
    def _forecast_revenue(self) -> Dict:
        """Forecast revenue based on pipeline"""
        pipeline_value = crm.get_pipeline_value()
        
        # 30-day forecast
        forecast_30 = sum(
            pv["weighted_value"] 
            for stage, pv in pipeline_value.items()
            if stage in [DealStage.NEGOTIATION.value, DealStage.PROPOSAL.value]
        )
        
        # 90-day forecast  
        forecast_90 = sum(pv["weighted_value"] for pv in pipeline_value.values())
        
        return {
            "success": True,
            "forecast_30_day": forecast_30,
            "forecast_90_day": forecast_90,
            "confidence": "medium",
            "assumptions": [
                "Based on current pipeline probabilities",
                "Assumes consistent close rates",
                "Does not account for new leads"
            ]
        }
    
    def _schedule_followup(self, details: Dict) -> Dict:
        """Schedule a follow-up action"""
        deal_id = details.get("deal_id")
        followup_type = details.get("type", "email")
        days = details.get("days", 3)
        
        followup_date = datetime.utcnow() + timedelta(days=days)
        
        crm.log_activity("deal", deal_id, "followup_scheduled", {
            "type": followup_type,
            "scheduled_for": followup_date.isoformat()
        }, self.agent_id)
        
        return {
            "success": True,
            "deal_id": deal_id,
            "followup_type": followup_type,
            "scheduled_for": followup_date.isoformat()
        }
    
    def run_cycle(self) -> Dict[str, Any]:
        """Run one sales cycle"""
        results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions": []
        }
        
        # Check for qualified leads to convert
        qualified_leads = crm.get_leads_by_status(LeadStatus.QUALIFIED.value)
        for lead in qualified_leads[:5]:  # Process up to 5 per cycle
            # Check if deal already exists
            conn = sqlite3.connect(crm.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM deals WHERE lead_id = ?", (lead.id,))
            existing = cursor.fetchone()
            conn.close()
            
            if not existing:
                result = self.execute_action(
                    "create_deal",
                    {"lead_id": lead.id, "product": "quranchain_pay_starter"},
                    ActionSeverity.LOW
                )
                results["actions"].append({"action": "create_deal", "result": result})
        
        # Get pipeline metrics
        pipeline = self.execute_action("get_pipeline", {}, ActionSeverity.LOW)
        results["pipeline"] = pipeline.get("result", {})
        
        results["cycle_end"] = datetime.utcnow().isoformat()
        results["metrics"] = self.get_metrics()
        
        return results


# ═══════════════════════════════════════════════════════════════
# SALES AI SERVICE
# ═══════════════════════════════════════════════════════════════

from flask import Flask, request, jsonify

def create_sales_api(agent: SalesAI) -> Flask:
    """Create Flask API for Sales AI"""
    app = Flask(__name__)
    
    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({
            "status": "healthy",
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type.value,
            "copyright": COPYRIGHT
        })
    
    @app.route("/lead/qualify", methods=["POST"])
    def qualify_lead():
        """Qualify a lead using BANT"""
        data = request.json
        result = agent.execute_action(
            "qualify_lead",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/deal/create", methods=["POST"])
    def create_deal():
        """Create a new deal"""
        data = request.json
        result = agent.execute_action(
            "create_deal",
            data,
            ActionSeverity.MEDIUM
        )
        return jsonify(result)
    
    @app.route("/deal/<int:deal_id>/stage", methods=["PUT"])
    def update_stage(deal_id):
        """Update deal stage"""
        data = request.json
        data["deal_id"] = deal_id
        result = agent.execute_action(
            "update_deal_stage",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/deal/<int:deal_id>/proposal", methods=["POST"])
    def generate_proposal(deal_id):
        """Generate proposal for a deal"""
        data = request.json or {}
        data["deal_id"] = deal_id
        result = agent.execute_action(
            "generate_proposal",
            data,
            ActionSeverity.MEDIUM
        )
        return jsonify(result)
    
    @app.route("/deal/<int:deal_id>/close", methods=["POST"])
    def close_deal(deal_id):
        """Close a deal"""
        data = request.json
        data["deal_id"] = deal_id
        
        # Determine severity based on deal value
        severity = ActionSeverity.HIGH if data.get("final_value", 0) > MID_TICKET_MAX else ActionSeverity.MEDIUM
        
        result = agent.execute_action(
            "close_deal",
            data,
            severity,
            revenue_impact=data.get("final_value", 0) if data.get("won", True) else 0
        )
        return jsonify(result)
    
    @app.route("/pipeline", methods=["GET"])
    def get_pipeline():
        """Get sales pipeline"""
        result = agent.execute_action("get_pipeline", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/forecast", methods=["GET"])
    def get_forecast():
        """Get revenue forecast"""
        result = agent.execute_action("forecast_revenue", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/metrics", methods=["GET"])
    def get_metrics():
        """Get sales metrics"""
        return jsonify(agent.get_metrics())
    
    @app.route("/report", methods=["GET"])
    def get_report():
        """Get agent report"""
        return agent.generate_report(), 200, {"Content-Type": "text/plain"}
    
    return app


if __name__ == "__main__":
    print(f"Starting Sales AI Agent")
    print(COPYRIGHT)
    
    agent = SalesAI()
    app = create_sales_api(agent)
    
    print(f"\nAgent ID: {agent.agent_id}")
    print(f"Commission Rate: {agent.commission_rate * 100}%")
    print(f"\nDeal Thresholds:")
    print(f"  Auto-close: up to ${LOW_TICKET_MAX}")
    print(f"  Can negotiate: up to ${MID_TICKET_MAX}")
    print(f"  Requires human: above ${HIGH_TICKET_THRESHOLD}")
    print(f"\nStarting API on port 7301...")
    
    app.run(host="0.0.0.0", port=7301, debug=False)
