#!/usr/bin/env python3
"""
Crypto Invoice Helper for AI Agents
===================================
Helper functions for AI agents to create DarPay™ crypto invoices.

© 2026 QuranChain™
"""

import requests
import logging

logger = logging.getLogger(__name__)

DARPAY_CRYPTO_URL = "http://localhost:9011"


def create_crypto_invoice(agent_name: str, amount_usd: float, 
                          customer_email: str = None,
                          customer_name: str = None,
                          description: str = None) -> dict:
    """
    Create crypto payment invoice via DarPay™
    
    Args:
        agent_name: Name of AI agent creating invoice
        amount_usd: Amount in USD
        customer_email: Customer's email
        customer_name: Customer's name
        description: Payment description
    
    Returns:
        Invoice details with payment URL and QR codes
    """
    try:
        response = requests.post(
            f"{DARPAY_CRYPTO_URL}/crypto/invoice/create",
            json={
                'agent_name': agent_name,
                'amount_usd': amount_usd,
                'customer_email': customer_email,
                'customer_name': customer_name,
                'description': description,
                'accepted_coins': ['USDT', 'USDC', 'BTC', 'ETH', 'DAI']
            },
            timeout=10
        )
        
        if response.status_code == 201:
            invoice = response.json()
            logger.info(f"✅ Created crypto invoice {invoice['invoice_id']} for ${amount_usd}")
            return invoice
        else:
            logger.error(f"❌ Invoice creation failed: {response.text}")
            return {'success': False, 'error': response.text}
            
    except Exception as e:
        logger.error(f"❌ Invoice creation error: {e}")
        return {'success': False, 'error': str(e)}


def get_crypto_payment_email(invoice: dict) -> str:
    """
    Generate email content for crypto payment request
    
    Args:
        invoice: Invoice details from create_crypto_invoice()
    
    Returns:
        Email body with payment instructions
    """
    payment_url = invoice.get('payment_url', '')
    invoice_id = invoice.get('invoice_id', '')
    amount = invoice.get('amount_usd', 0)
    
    email = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 CRYPTO PAYMENT INVOICE #{invoice_id}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Amount: ${amount:.2f} USD

Thank you for choosing QuranChain! Your invoice is ready for payment.

🔗 PAY NOW: {payment_url}

We accept the following cryptocurrencies:
✅ USDT (Tether) - RECOMMENDED
✅ USDC (USD Coin)
✅ BTC (Bitcoin)
✅ ETH (Ethereum)
✅ DAI

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW TO PAY:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Click the payment link above
2. Choose your preferred cryptocurrency
3. Scan the QR code with your crypto wallet
   (or copy/paste the address)
4. Send EXACTLY the amount shown
5. Payment confirmed within 30 seconds - 5 minutes

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHY CRYPTO ONLY?
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡ INSTANT: Settlements in minutes, not days
💰 LOW FEES: ~$2 per transaction vs $30 with cards
🌍 GLOBAL: Works anywhere, no bank restrictions
🔒 SECURE: Blockchain-verified, immutable transactions
🚀 PERMISSIONLESS: No intermediaries, no gatekeepers

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Need help? Reply to this email.

Powered by DarPay™ Crypto
QuranChain© 2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    
    return email


def get_crypto_signature() -> str:
    """Get email signature with crypto payment info"""
    return """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
QuranChain™ | Powered by DarPay™ Crypto

💎 We accept: USDT • USDC • BTC • ETH • DAI
⚡ Instant settlement • Global access • Low fees

🌐 https://quranchain.com
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
