#!/usr/bin/env python3
"""
Service Guardian AI Agent
-------------------------
Monitors a target service and its dependencies; performs health checks,
triggers restarts when needed, and exposes /health, /metrics, /protect endpoints.

Args (CLI):
  --name <service_name>
  --target-port <port>
  --health-path <path> (e.g., /health, /status, /api/health)
  --script-path <python_file_relative_to_repo_root>
  --check-interval <seconds> (default: 10)

Logs: logs/ai_workforce/service_guardians/<name>.log
"""

import argparse
import os
import sys
import time
import subprocess
from datetime import datetime
from typing import Dict, Any

try:
    from fastapi import FastAPI
except Exception:
    class FastAPI:  # minimal stub
        def __init__(self, *args, **kwargs):
            self._routes = []
        def get(self, path: str, **kwargs):
            def deco(f):
                self._routes.append(("GET", path))
                return f
            return deco
        def post(self, path: str, **kwargs):
            def deco(f):
                self._routes.append(("POST", path))
                return f
            return deco

import requests

REPO_ROOT = "/home/omar/Desktop/QuranChain"
LOG_DIR = os.path.join(REPO_ROOT, "logs", "ai_workforce", "service_guardians")
os.makedirs(LOG_DIR, exist_ok=True)

app: FastAPI
# Initialize app before using decorators
app = FastAPI(title="Service Guardian", version="1.0.0", description="Personal AI agent for service protection")
STATE: Dict[str, Any] = {
    "service": None,
    "target_port": None,
    "health_path": None,
    "script_path": None,
    "last_check": None,
    "status": "unknown",
    "restarts": 0,
    "alerts": 0,
}


def log(name: str, message: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    path = os.path.join(LOG_DIR, f"{name}.log")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"[{ts}] {message}\n")


def check_target(name: str) -> bool:
    url = f"http://127.0.0.1:{STATE['target_port']}{STATE['health_path']}"
    try:
        r = requests.get(url, timeout=2)
        return r.status_code == 200
    except Exception:
        return False


def restart_target(name: str) -> bool:
    # Kill existing process for the script and start anew similar to watchdog behavior
    script_rel = STATE["script_path"]
    script_abs = os.path.join(REPO_ROOT, script_rel)
    if not os.path.exists(script_abs):
        log(name, f"❌ restart_target: script not found {script_abs}")
        STATE["alerts"] += 1
        return False
    try:
        subprocess.run(["pkill", "-9", "-f", script_rel], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
    time.sleep(1)
    try:
        with open(os.path.join(LOG_DIR, f"{name}_target.log"), "a") as lf:
            proc = subprocess.Popen(["nohup", "python3", script_abs], stdout=lf, stderr=lf, cwd=REPO_ROOT)
        STATE["restarts"] += 1
        log(name, f"🔄 restart_target: started PID {proc.pid} for {script_rel}")
        time.sleep(3)
        return check_target(name)
    except Exception as e:
        log(name, f"❌ restart_target: failed to start {script_rel}: {e}")
        STATE["alerts"] += 1
        return False


@app.get("/health")
def health():
    return {
        "status": STATE.get("status"),
        "service": STATE.get("service"),
        "target_port": STATE.get("target_port"),
        "health_path": STATE.get("health_path"),
        "script_path": STATE.get("script_path"),
        "last_check": STATE.get("last_check"),
        "restarts": STATE.get("restarts"),
        "alerts": STATE.get("alerts"),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


@app.get("/metrics")
def metrics():
    return {
        "service": STATE.get("service"),
        "status": STATE.get("status"),
        "restarts": STATE.get("restarts"),
        "alerts": STATE.get("alerts"),
    }


@app.post("/protect")
def protect():
    name = STATE["service"]
    ok = check_target(name)
    STATE["last_check"] = datetime.utcnow().isoformat() + "Z"
    if ok:
        STATE["status"] = "healthy"
        log(name, "✅ protect: target healthy")
        return {"protected": True, "action": "none"}
    log(name, "⚠️ protect: target unhealthy, attempting restart")
    ok2 = restart_target(name)
    STATE["status"] = "healthy" if ok2 else "down"
    return {"protected": ok2, "action": "restart" if ok2 else "failed"}


def run_guardian(name: str, port: int, health_path: str, script_path: str, interval: int, listen_port: int):
    global app
    STATE.update({
        "service": name,
        "target_port": port,
        "health_path": health_path if health_path.startswith('/') else f"/{health_path}",
        "script_path": script_path,
    })
    app = FastAPI(title=f"Service Guardian: {name}", version="1.0.0", description="Personal AI agent for service protection")
    # Re-register routes (ensure routes exist on the new app instance)
    app.get("/health")(health)
    app.get("/metrics")(metrics)
    app.post("/protect")(protect)

    # Background loop
    def loop():
        while True:
            STATE["last_check"] = datetime.utcnow().isoformat() + "Z"
            ok = check_target(name)
            STATE["status"] = "healthy" if ok else "down"
            if not ok:
                log(name, "⚠️ loop: unhealthy detected, restarting")
                restart_target(name)
            time.sleep(interval)
    import threading
    threading.Thread(target=loop, daemon=True).start()

    # Start server
    try:
        import importlib
        try:
            uvicorn = importlib.import_module("uvicorn")
        except Exception:
            hypercorn_asyncio = importlib.import_module("hypercorn.asyncio")
            hypercorn_config = importlib.import_module("hypercorn.config")
            import asyncio
            def _hypercorn_run(app_obj, host="0.0.0.0", port=listen_port, reload=False):
                cfg = hypercorn_config.Config()
                cfg.bind = [f"{host}:{port}"]
                asyncio.run(hypercorn_asyncio.serve(app_obj, cfg))
            class _UvicornShim:
                run = staticmethod(_hypercorn_run)
            uvicorn = _UvicornShim()
    except Exception:
        print("uvicorn/hypercorn not available; cannot start guardian server.")
        sys.exit(1)

    print(f"🚀 Guardian {name} listening on 0.0.0.0:{listen_port} for target {port}{STATE['health_path']}")
    uvicorn.run(app, host="0.0.0.0", port=listen_port, reload=False)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True)
    p.add_argument("--target-port", type=int, required=True)
    p.add_argument("--health-path", required=True)
    p.add_argument("--script-path", required=True)
    p.add_argument("--check-interval", type=int, default=10)
    p.add_argument("--listen-port", type=int, required=True)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_guardian(
        name=args.name,
        port=args.target_port,
        health_path=args.health_path,
        script_path=args.script_path,
        interval=args.check_interval,
        listen_port=args.listen_port,
    )
