"""
QuranChain™ Cybersecurity AI Agent
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- Abuse and intrusion detection
- Authentication failure monitoring
- Rate limit enforcement
- Ledger integrity auditing
- Threat escalation

Constraints:
- DEFENSIVE ONLY - No offensive actions
- Cannot modify security rules without approval
- Must escalate critical threats immediately
- Cannot access raw PII without approval
"""

import os
import sys
import json
import sqlite3
import hashlib
import re
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from collections import defaultdict
import ipaddress

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from organized.ai_agents.ai_workforce.shared.base_agent import (
    BaseAIAgent, AgentType, ActionSeverity,
    COPYRIGHT, FOUNDER_ROYALTY_RATE
)


# ═══════════════════════════════════════════════════════════════
# THREAT DEFINITIONS
# ═══════════════════════════════════════════════════════════════

class ThreatLevel:
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class SecurityEvent:
    """A security-relevant event"""
    id: str
    timestamp: str
    event_type: str
    source_ip: Optional[str]
    user_id: Optional[str]
    details: Dict[str, Any]
    threat_level: str
    action_taken: Optional[str]


@dataclass
class ThreatAlert:
    """A detected threat"""
    id: str
    threat_type: str
    threat_level: str
    description: str
    indicators: List[str]
    detected_at: str
    escalated: bool
    mitigated: bool
    mitigation_action: Optional[str]


# Detection rules
DETECTION_RULES = {
    "brute_force": {
        "threshold": 5,
        "window_seconds": 60,
        "threat_level": ThreatLevel.HIGH,
        "description": "Multiple failed login attempts"
    },
    "rate_limit_abuse": {
        "threshold": 100,
        "window_seconds": 60,
        "threat_level": ThreatLevel.MEDIUM,
        "description": "Excessive API requests"
    },
    "sql_injection": {
        "patterns": [r"'.*OR.*'", r"UNION\s+SELECT", r"DROP\s+TABLE", r"--\s*$"],
        "threat_level": ThreatLevel.CRITICAL,
        "description": "SQL injection attempt detected"
    },
    "xss_attempt": {
        "patterns": [r"<script", r"javascript:", r"onerror=", r"onload="],
        "threat_level": ThreatLevel.HIGH,
        "description": "Cross-site scripting attempt"
    },
    "suspicious_withdrawal": {
        "threshold_usd": 10000,
        "threat_level": ThreatLevel.HIGH,
        "description": "Large withdrawal request"
    }
}


class SecurityAI(BaseAIAgent):
    """
    Cybersecurity AI Agent.
    
    Monitors for threats, enforces security policies,
    and escalates incidents. DEFENSIVE ONLY.
    """
    
    def __init__(self, agent_id: Optional[str] = None):
        super().__init__(AgentType.SECURITY, agent_id)
        
        # Event tracking
        self.events: List[SecurityEvent] = []
        self.alerts: List[ThreatAlert] = []
        
        # Rate limiting tracking
        self.request_counts: Dict[str, List[datetime]] = defaultdict(list)
        self.failed_logins: Dict[str, List[datetime]] = defaultdict(list)
        
        # Blocked IPs (in-memory, would be Redis in production)
        self.blocked_ips: Dict[str, datetime] = {}
        
        self._init_security_db()
    
    def _init_security_db(self):
        """Initialize security database"""
        db_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "shared", "security.db"
        )
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS security_events (
                id TEXT PRIMARY KEY,
                timestamp TEXT,
                event_type TEXT,
                source_ip TEXT,
                user_id TEXT,
                details TEXT,
                threat_level TEXT,
                action_taken TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS threat_alerts (
                id TEXT PRIMARY KEY,
                threat_type TEXT,
                threat_level TEXT,
                description TEXT,
                indicators TEXT,
                detected_at TEXT,
                escalated INTEGER,
                mitigated INTEGER,
                mitigation_action TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS blocked_ips (
                ip TEXT PRIMARY KEY,
                reason TEXT,
                blocked_at TEXT,
                expires_at TEXT
            )
        """)
        
        conn.commit()
        conn.close()
        
        self.db_path = db_path
    
    def _execute_internal(self, action: str, details: Dict[str, Any]) -> Any:
        """Execute security actions"""
        
        if action == "analyze_request":
            return self._analyze_request(details)
        elif action == "check_auth_attempt":
            return self._check_auth_attempt(details)
        elif action == "check_rate_limit":
            return self._check_rate_limit(details)
        elif action == "scan_for_injection":
            return self._scan_for_injection(details)
        elif action == "audit_ledger":
            return self._audit_ledger(details)
        elif action == "block_ip":
            return self._block_ip(details)
        elif action == "get_threat_summary":
            return self._get_threat_summary()
        elif action == "analyze_transaction":
            return self._analyze_transaction(details)
        elif action == "generate_security_report":
            return self._generate_security_report()
        else:
            raise ValueError(f"Unknown action: {action}")
    
    def _analyze_request(self, details: Dict) -> Dict:
        """Analyze an incoming request for threats"""
        source_ip = details.get("source_ip", "unknown")
        path = details.get("path", "")
        method = details.get("method", "GET")
        body = details.get("body", "")
        headers = details.get("headers", {})
        
        threats_detected = []
        
        # Check if IP is blocked
        if source_ip in self.blocked_ips:
            if datetime.utcnow() < self.blocked_ips[source_ip]:
                return {
                    "allowed": False,
                    "reason": "ip_blocked",
                    "source_ip": source_ip
                }
        
        # Check rate limit
        rate_check = self._check_rate_limit({"source_ip": source_ip})
        if not rate_check.get("allowed"):
            threats_detected.append("rate_limit_exceeded")
        
        # Scan for injection
        injection_check = self._scan_for_injection({
            "content": f"{path} {body}",
            "source_ip": source_ip
        })
        if injection_check.get("threats"):
            threats_detected.extend(injection_check["threats"])
        
        # Log event
        event = SecurityEvent(
            id=f"EVT{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}",
            timestamp=datetime.utcnow().isoformat(),
            event_type="request_analysis",
            source_ip=source_ip,
            user_id=details.get("user_id"),
            details={"path": path, "method": method},
            threat_level=ThreatLevel.HIGH if threats_detected else ThreatLevel.INFO,
            action_taken="blocked" if threats_detected else "allowed"
        )
        self._record_event(event)
        
        return {
            "allowed": len(threats_detected) == 0,
            "threats": threats_detected,
            "source_ip": source_ip,
            "event_id": event.id
        }
    
    def _check_auth_attempt(self, details: Dict) -> Dict:
        """Check authentication attempt for brute force"""
        source_ip = details.get("source_ip", "unknown")
        user_id = details.get("user_id")
        success = details.get("success", False)
        
        if not success:
            # Track failed login
            now = datetime.utcnow()
            self.failed_logins[source_ip].append(now)
            
            # Clean old entries
            window = timedelta(seconds=DETECTION_RULES["brute_force"]["window_seconds"])
            self.failed_logins[source_ip] = [
                t for t in self.failed_logins[source_ip]
                if now - t < window
            ]
            
            # Check threshold
            if len(self.failed_logins[source_ip]) >= DETECTION_RULES["brute_force"]["threshold"]:
                # Brute force detected
                alert = ThreatAlert(
                    id=f"ALT{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                    threat_type="brute_force",
                    threat_level=ThreatLevel.HIGH,
                    description=f"Brute force attack from {source_ip}",
                    indicators=[f"IP: {source_ip}", f"Failed attempts: {len(self.failed_logins[source_ip])}"],
                    detected_at=datetime.utcnow().isoformat(),
                    escalated=True,
                    mitigated=False,
                    mitigation_action=None
                )
                self._record_alert(alert)
                
                # Block IP
                self._block_ip({
                    "ip": source_ip,
                    "reason": "brute_force",
                    "duration_minutes": 30
                })
                
                self.logger.warning(f"BRUTE FORCE DETECTED from {source_ip}")
                
                return {
                    "allowed": False,
                    "threat": "brute_force",
                    "alert_id": alert.id,
                    "action": "ip_blocked"
                }
        else:
            # Successful login clears failed attempts
            self.failed_logins[source_ip] = []
        
        # Log event
        event = SecurityEvent(
            id=f"EVT{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}",
            timestamp=datetime.utcnow().isoformat(),
            event_type="auth_attempt",
            source_ip=source_ip,
            user_id=user_id,
            details={"success": success},
            threat_level=ThreatLevel.INFO if success else ThreatLevel.LOW,
            action_taken=None
        )
        self._record_event(event)
        
        return {
            "allowed": True,
            "success": success,
            "event_id": event.id
        }
    
    def _check_rate_limit(self, details: Dict) -> Dict:
        """Check if request exceeds rate limit"""
        source_ip = details.get("source_ip", "unknown")
        limit = details.get("limit", DETECTION_RULES["rate_limit_abuse"]["threshold"])
        window = details.get("window_seconds", DETECTION_RULES["rate_limit_abuse"]["window_seconds"])
        
        now = datetime.utcnow()
        window_delta = timedelta(seconds=window)
        
        # Add current request
        self.request_counts[source_ip].append(now)
        
        # Clean old entries
        self.request_counts[source_ip] = [
            t for t in self.request_counts[source_ip]
            if now - t < window_delta
        ]
        
        count = len(self.request_counts[source_ip])
        allowed = count <= limit
        
        if not allowed:
            self.logger.warning(f"Rate limit exceeded for {source_ip}: {count}/{limit}")
            
            event = SecurityEvent(
                id=f"EVT{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}",
                timestamp=now.isoformat(),
                event_type="rate_limit_exceeded",
                source_ip=source_ip,
                user_id=None,
                details={"count": count, "limit": limit},
                threat_level=ThreatLevel.MEDIUM,
                action_taken="request_blocked"
            )
            self._record_event(event)
        
        return {
            "allowed": allowed,
            "count": count,
            "limit": limit,
            "remaining": max(0, limit - count)
        }
    
    def _scan_for_injection(self, details: Dict) -> Dict:
        """Scan content for injection attacks"""
        content = details.get("content", "")
        source_ip = details.get("source_ip")
        
        threats = []
        
        # Check SQL injection patterns
        for pattern in DETECTION_RULES["sql_injection"]["patterns"]:
            if re.search(pattern, content, re.IGNORECASE):
                threats.append({
                    "type": "sql_injection",
                    "pattern": pattern,
                    "threat_level": ThreatLevel.CRITICAL
                })
        
        # Check XSS patterns
        for pattern in DETECTION_RULES["xss_attempt"]["patterns"]:
            if re.search(pattern, content, re.IGNORECASE):
                threats.append({
                    "type": "xss",
                    "pattern": pattern,
                    "threat_level": ThreatLevel.HIGH
                })
        
        if threats:
            # Create alert
            alert = ThreatAlert(
                id=f"ALT{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                threat_type=threats[0]["type"],
                threat_level=threats[0]["threat_level"],
                description=f"Injection attack attempt from {source_ip}",
                indicators=[t["pattern"] for t in threats],
                detected_at=datetime.utcnow().isoformat(),
                escalated=True,
                mitigated=True,
                mitigation_action="request_blocked"
            )
            self._record_alert(alert)
            
            self.logger.error(f"INJECTION ATTACK from {source_ip}: {[t['type'] for t in threats]}")
        
        return {
            "clean": len(threats) == 0,
            "threats": [t["type"] for t in threats],
            "threat_level": max([t["threat_level"] for t in threats], default=ThreatLevel.INFO)
        }
    
    def _audit_ledger(self, details: Dict) -> Dict:
        """Audit ledger for integrity issues"""
        days = details.get("days", 7)
        
        # This would connect to actual ledger in production
        # For now, simulate audit checks
        
        audit_checks = {
            "royalty_enforcement": True,
            "balance_consistency": True,
            "transaction_signatures": True,
            "no_unauthorized_modifications": True,
            "audit_trail_complete": True
        }
        
        # Check founder royalty
        # In production: verify all transactions have correct royalty
        
        issues = []
        for check, passed in audit_checks.items():
            if not passed:
                issues.append({
                    "check": check,
                    "status": "failed",
                    "severity": ThreatLevel.CRITICAL
                })
        
        return {
            "success": True,
            "period_days": days,
            "checks": audit_checks,
            "issues": issues,
            "integrity_verified": len(issues) == 0,
            "audited_at": datetime.utcnow().isoformat()
        }
    
    def _block_ip(self, details: Dict) -> Dict:
        """Block an IP address"""
        ip = details.get("ip")
        reason = details.get("reason", "security_threat")
        duration = details.get("duration_minutes", 60)
        
        if not ip:
            return {"success": False, "reason": "ip_required"}
        
        # Validate IP
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            return {"success": False, "reason": "invalid_ip"}
        
        expires = datetime.utcnow() + timedelta(minutes=duration)
        self.blocked_ips[ip] = expires
        
        # Store in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO blocked_ips (ip, reason, blocked_at, expires_at)
            VALUES (?, ?, ?, ?)
        """, (ip, reason, datetime.utcnow().isoformat(), expires.isoformat()))
        conn.commit()
        conn.close()
        
        self.logger.info(f"Blocked IP: {ip} for {duration} minutes ({reason})")
        
        return {
            "success": True,
            "ip": ip,
            "reason": reason,
            "expires_at": expires.isoformat()
        }
    
    def _analyze_transaction(self, details: Dict) -> Dict:
        """Analyze a transaction for suspicious activity"""
        amount = details.get("amount", 0)
        currency = details.get("currency", "USD")
        user_id = details.get("user_id")
        transaction_type = details.get("type", "withdrawal")
        
        risk_score = 0
        risk_factors = []
        
        # Check amount threshold
        if amount > DETECTION_RULES["suspicious_withdrawal"]["threshold_usd"]:
            risk_score += 40
            risk_factors.append(f"Large amount: ${amount:,.2f}")
        
        # Would check: velocity, geolocation, device fingerprint, etc.
        
        # Determine risk level
        if risk_score >= 70:
            risk_level = ThreatLevel.CRITICAL
            requires_review = True
        elif risk_score >= 40:
            risk_level = ThreatLevel.HIGH
            requires_review = True
        elif risk_score >= 20:
            risk_level = ThreatLevel.MEDIUM
            requires_review = False
        else:
            risk_level = ThreatLevel.LOW
            requires_review = False
        
        if requires_review:
            event = SecurityEvent(
                id=f"EVT{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}",
                timestamp=datetime.utcnow().isoformat(),
                event_type="suspicious_transaction",
                source_ip=None,
                user_id=user_id,
                details={"amount": amount, "type": transaction_type},
                threat_level=risk_level,
                action_taken="flagged_for_review"
            )
            self._record_event(event)
        
        return {
            "allowed": risk_score < 70,
            "risk_score": risk_score,
            "risk_level": risk_level,
            "risk_factors": risk_factors,
            "requires_review": requires_review
        }
    
    def _get_threat_summary(self) -> Dict:
        """Get summary of current threats"""
        now = datetime.utcnow()
        day_ago = now - timedelta(days=1)
        
        # Count events by level
        event_counts = defaultdict(int)
        for event in self.events:
            if datetime.fromisoformat(event.timestamp) > day_ago:
                event_counts[event.threat_level] += 1
        
        # Count open alerts
        open_alerts = [a for a in self.alerts if not a.mitigated]
        
        return {
            "success": True,
            "period": "24h",
            "events_by_level": dict(event_counts),
            "total_events": sum(event_counts.values()),
            "open_alerts": len(open_alerts),
            "blocked_ips": len(self.blocked_ips),
            "critical_alerts": len([a for a in open_alerts if a.threat_level == ThreatLevel.CRITICAL]),
            "generated_at": datetime.utcnow().isoformat()
        }
    
    def _generate_security_report(self) -> Dict:
        """Generate comprehensive security report"""
        summary = self._get_threat_summary()
        ledger_audit = self._audit_ledger({"days": 7})
        
        report = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    SECURITY STATUS REPORT                                     ║
║                    {COPYRIGHT}                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║ Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}                                        ║
╠══════════════════════════════════════════════════════════════════════════════╣

THREAT SUMMARY (24h)
────────────────────────────────────────────────────────────────────────────────
Total Events: {summary['total_events']}
  - Critical: {summary['events_by_level'].get(ThreatLevel.CRITICAL, 0)}
  - High: {summary['events_by_level'].get(ThreatLevel.HIGH, 0)}
  - Medium: {summary['events_by_level'].get(ThreatLevel.MEDIUM, 0)}
  - Low: {summary['events_by_level'].get(ThreatLevel.LOW, 0)}

Open Alerts: {summary['open_alerts']}
Blocked IPs: {summary['blocked_ips']}

LEDGER INTEGRITY AUDIT
────────────────────────────────────────────────────────────────────────────────
Royalty Enforcement: {'✅ Verified' if ledger_audit['result']['checks']['royalty_enforcement'] else '❌ ISSUE'}
Balance Consistency: {'✅ Verified' if ledger_audit['result']['checks']['balance_consistency'] else '❌ ISSUE'}
Transaction Signatures: {'✅ Verified' if ledger_audit['result']['checks']['transaction_signatures'] else '❌ ISSUE'}
Audit Trail: {'✅ Complete' if ledger_audit['result']['checks']['audit_trail_complete'] else '❌ INCOMPLETE'}

Overall Integrity: {'✅ VERIFIED' if ledger_audit['result']['integrity_verified'] else '❌ ISSUES DETECTED'}

RECENT ALERTS
────────────────────────────────────────────────────────────────────────────────
"""
        for alert in self.alerts[-10:]:
            status = "✅ Mitigated" if alert.mitigated else "🔴 Open"
            report += f"  [{alert.threat_level.upper()}] {alert.threat_type}: {alert.description} - {status}\n"
        
        if not self.alerts:
            report += "  No recent alerts\n"
        
        report += f"""
DEFENSIVE STATUS
────────────────────────────────────────────────────────────────────────────────
Mode: DEFENSIVE ONLY (no offensive capabilities)
Rate Limiting: ✅ Active
Injection Scanning: ✅ Active
Brute Force Protection: ✅ Active
Transaction Monitoring: ✅ Active

════════════════════════════════════════════════════════════════════════════════
"""
        return {
            "success": True,
            "report": report,
            "summary": summary,
            "ledger_audit": ledger_audit
        }
    
    def _record_event(self, event: SecurityEvent):
        """Record security event"""
        self.events.append(event)
        # Keep only last 1000 events in memory
        self.events = self.events[-1000:]
        
        # Store in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO security_events 
            (id, timestamp, event_type, source_ip, user_id, details, threat_level, action_taken)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event.id, event.timestamp, event.event_type, event.source_ip,
            event.user_id, json.dumps(event.details), event.threat_level, event.action_taken
        ))
        conn.commit()
        conn.close()
    
    def _record_alert(self, alert: ThreatAlert):
        """Record threat alert"""
        self.alerts.append(alert)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO threat_alerts
            (id, threat_type, threat_level, description, indicators, detected_at,
             escalated, mitigated, mitigation_action)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alert.id, alert.threat_type, alert.threat_level, alert.description,
            json.dumps(alert.indicators), alert.detected_at,
            1 if alert.escalated else 0, 1 if alert.mitigated else 0,
            alert.mitigation_action
        ))
        conn.commit()
        conn.close()
    
    def run_cycle(self) -> Dict[str, Any]:
        """Run one security cycle"""
        results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions": []
        }
        
        # Get threat summary
        summary = self.execute_action("get_threat_summary", {}, ActionSeverity.LOW)
        results["actions"].append({"action": "threat_summary", "result": summary})
        
        # Audit ledger
        audit = self.execute_action("audit_ledger", {"days": 1}, ActionSeverity.HIGH)
        results["actions"].append({"action": "audit_ledger", "result": audit})
        
        # Clean expired blocked IPs
        now = datetime.utcnow()
        expired = [ip for ip, exp in self.blocked_ips.items() if exp < now]
        for ip in expired:
            del self.blocked_ips[ip]
            self.logger.info(f"Unblocked IP (expired): {ip}")
        
        results["expired_blocks_cleared"] = len(expired)
        results["cycle_end"] = datetime.utcnow().isoformat()
        results["metrics"] = self.get_metrics()
        
        return results


# ═══════════════════════════════════════════════════════════════
# SECURITY AI SERVICE
# ═══════════════════════════════════════════════════════════════

from flask import Flask, request, jsonify

def create_security_api(agent: SecurityAI) -> Flask:
    """Create Flask API for Security AI"""
    app = Flask(__name__)
    
    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({
            "status": "healthy",
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type.value,
            "mode": "DEFENSIVE_ONLY",
            "copyright": COPYRIGHT
        })
    
    @app.route("/analyze/request", methods=["POST"])
    def analyze_request():
        """Analyze incoming request"""
        data = request.json
        result = agent.execute_action(
            "analyze_request",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/auth/check", methods=["POST"])
    def check_auth():
        """Check authentication attempt"""
        data = request.json
        result = agent.execute_action(
            "check_auth_attempt",
            data,
            ActionSeverity.MEDIUM
        )
        return jsonify(result)
    
    @app.route("/rate-limit/check", methods=["POST"])
    def check_rate_limit():
        """Check rate limit"""
        data = request.json
        result = agent.execute_action(
            "check_rate_limit",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/scan/injection", methods=["POST"])
    def scan_injection():
        """Scan for injection attacks"""
        data = request.json
        result = agent.execute_action(
            "scan_for_injection",
            data,
            ActionSeverity.LOW
        )
        return jsonify(result)
    
    @app.route("/audit/ledger", methods=["GET"])
    def audit_ledger():
        """Audit ledger integrity"""
        days = request.args.get("days", 7, type=int)
        result = agent.execute_action(
            "audit_ledger",
            {"days": days},
            ActionSeverity.HIGH
        )
        return jsonify(result)
    
    @app.route("/transaction/analyze", methods=["POST"])
    def analyze_transaction():
        """Analyze transaction risk"""
        data = request.json
        result = agent.execute_action(
            "analyze_transaction",
            data,
            ActionSeverity.MEDIUM
        )
        return jsonify(result)
    
    @app.route("/ip/block", methods=["POST"])
    def block_ip():
        """Block an IP address"""
        data = request.json
        result = agent.execute_action(
            "block_ip",
            data,
            ActionSeverity.HIGH
        )
        return jsonify(result)
    
    @app.route("/threats", methods=["GET"])
    def get_threats():
        """Get threat summary"""
        result = agent.execute_action("get_threat_summary", {}, ActionSeverity.LOW)
        return jsonify(result)
    
    @app.route("/report", methods=["GET"])
    def get_report():
        """Get security report"""
        result = agent.execute_action("generate_security_report", {}, ActionSeverity.LOW)
        if result.get("success"):
            return result["result"]["report"], 200, {"Content-Type": "text/plain"}
        return jsonify(result)
    
    @app.route("/metrics", methods=["GET"])
    def get_metrics():
        """Get agent metrics"""
        return jsonify(agent.get_metrics())
    
    return app


if __name__ == "__main__":
    print(f"Starting Cybersecurity AI Agent")
    print(COPYRIGHT)
    print("\n⚠️  MODE: DEFENSIVE ONLY - No offensive capabilities")
    
    agent = SecurityAI()
    app = create_security_api(agent)
    
    print(f"\nAgent ID: {agent.agent_id}")
    print(f"\nStarting API on port 9006...")
    
    app.run(host="0.0.0.0", port=9006, debug=False)
