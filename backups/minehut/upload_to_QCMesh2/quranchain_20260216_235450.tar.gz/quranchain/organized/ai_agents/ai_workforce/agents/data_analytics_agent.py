"""
Data Analytics AI Agent - System Performance & Insights
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- System performance monitoring and optimization
- Data analysis and trend identification
- Predictive analytics and forecasting
- Revenue analytics and optimization
- User behavior analysis
- Technical metrics tracking

Constraints:
- Data privacy and security compliance
- Real-time performance monitoring
- Automated alerting for anomalies
- Islamic compliance in data analysis
"""

import asyncio
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import uuid
import statistics
import numpy as np

import sys
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from organized.ai_agents.ai_workforce.core.base_agent import (
    BaseAgent, AgentAction, ActionType, ApprovalLevel, AgentStatus
)
from organized.ai_agents.ai_workforce.core.message_bus import get_message_bus, Message, MessagePriority


@dataclass
class SystemMetric:
    """System performance metric"""
    metric_id: str
    name: str
    category: str  # performance, usage, revenue, error
    value: float
    timestamp: str
    metadata: Dict[str, Any]


@dataclass
class AnalyticsInsight:
    """Data analytics insight"""
    insight_id: str
    title: str
    description: str
    insight_type: str  # trend, anomaly, prediction, recommendation
    confidence: float  # 0-1
    impact: str  # high, medium, low
    data_points: List[Dict[str, Any]]
    recommendations: List[str]
    created_at: str


@dataclass
class PredictiveModel:
    """Predictive analytics model"""
    model_id: str
    name: str
    target_metric: str
    model_type: str  # linear_regression, time_series, classification
    accuracy: float
    last_trained: str
    predictions: List[Dict[str, Any]]


class DataAnalyticsAgent(BaseAgent):
    """
    Data Analytics AI Agent for system performance and insights.

    This agent:
    - Monitors system performance metrics
    - Analyzes data trends and patterns
    - Generates predictive insights
    - Optimizes system performance
    - Provides revenue analytics
    """

    def __init__(self, agent_id: str):
        super().__init__(agent_id, "Data Analytics AI")
        self.system_metrics: List[SystemMetric] = []
        self.analytics_insights: Dict[str, AnalyticsInsight] = {}
        self.predictive_models: Dict[str, PredictiveModel] = {}
        self.db_path = f"/home/omar/Desktop/QuranChain/prod_databases/data_analytics_{agent_id}.db"
        self.metric_history_days = 30
        self._init_database()

    def _init_database(self):
        """Initialize data analytics database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            # System metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_metrics (
                    metric_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    category TEXT,
                    value REAL,
                    timestamp TEXT,
                    metadata TEXT
                )
            ''')

            # Analytics insights table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS analytics_insights (
                    insight_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    description TEXT,
                    insight_type TEXT,
                    confidence REAL,
                    impact TEXT,
                    data_points TEXT,
                    recommendations TEXT,
                    created_at TEXT
                )
            ''')

            # Predictive models table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS predictive_models (
                    model_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    target_metric TEXT,
                    model_type TEXT,
                    accuracy REAL,
                    last_trained TEXT,
                    predictions TEXT
                )
            ''')

            conn.commit()

    async def run_cycle(self) -> Dict[str, Any]:
        """Run data analytics operations cycle"""
        if not self.is_active:
            return {"status": "inactive"}

        cycle_results = {
            "agent_id": self.agent_id,
            "cycle_start": datetime.utcnow().isoformat(),
            "actions_taken": [],
            "metrics": self.get_metrics()
        }

        try:
            # Collect system metrics
            metrics_collection = await self._collect_system_metrics()
            cycle_results["metrics_collection"] = metrics_collection

            # Analyze trends and patterns
            trend_analysis = await self._analyze_trends()
            cycle_results["trend_analysis"] = trend_analysis

            # Generate predictive insights
            predictive_insights = await self._generate_predictive_insights()
            cycle_results["predictive_insights"] = predictive_insights

            # Optimize performance
            performance_optimization = await self._optimize_performance()
            cycle_results["performance_optimization"] = performance_optimization

            # Generate revenue analytics
            revenue_analytics = await self._analyze_revenue()
            cycle_results["revenue_analytics"] = revenue_analytics

            cycle_results["status"] = "completed"

        except Exception as e:
            cycle_results["status"] = "error"
            cycle_results["error"] = str(e)

        cycle_results["cycle_end"] = datetime.utcnow().isoformat()
        return cycle_results

    async def _collect_system_metrics(self) -> Dict[str, Any]:
        """Collect system performance metrics"""
        metrics_collected = []

        # Mock metric collection - in production would collect real metrics
        metric_types = [
            ("cpu_usage", "performance", lambda: 45.2 + np.random.normal(0, 5)),
            ("memory_usage", "performance", lambda: 67.8 + np.random.normal(0, 3)),
            ("response_time", "performance", lambda: 245 + np.random.normal(0, 20)),
            ("active_users", "usage", lambda: 1250 + np.random.normal(0, 50)),
            ("transactions_per_minute", "usage", lambda: 45.6 + np.random.normal(0, 5)),
            ("error_rate", "error", lambda: 0.02 + np.random.normal(0, 0.005)),
            ("revenue_per_minute", "revenue", lambda: 1250.50 + np.random.normal(0, 100))
        ]

        for name, category, value_func in metric_types:
            metric = SystemMetric(
                metric_id=str(uuid.uuid4()),
                name=name,
                category=category,
                value=max(0, value_func()),  # Ensure non-negative
                timestamp=datetime.utcnow().isoformat(),
                metadata={"source": "system_monitor", "unit": self._get_metric_unit(name)}
            )

            self.system_metrics.append(metric)
            metrics_collected.append({
                "name": name,
                "category": category,
                "value": metric.value,
                "unit": metric.metadata["unit"]
            })

            # Keep only recent metrics
            cutoff_date = datetime.utcnow() - timedelta(days=self.metric_history_days)
            self.system_metrics = [
                m for m in self.system_metrics
                if datetime.fromisoformat(m.timestamp) > cutoff_date
            ]

        return {"metrics_collected": len(metrics_collected), "details": metrics_collected}

    def _get_metric_unit(self, metric_name: str) -> str:
        """Get the unit for a metric"""
        units = {
            "cpu_usage": "%",
            "memory_usage": "%",
            "response_time": "ms",
            "active_users": "count",
            "transactions_per_minute": "tx/min",
            "error_rate": "%",
            "revenue_per_minute": "USD/min"
        }
        return units.get(metric_name, "unit")

    async def _analyze_trends(self) -> Dict[str, Any]:
        """Analyze trends and patterns in system metrics"""
        analysis_results = {
            "trends_identified": [],
            "anomalies_detected": [],
            "correlations_found": []
        }

        # Group metrics by name
        metric_groups = {}
        for metric in self.system_metrics:
            if metric.name not in metric_groups:
                metric_groups[metric.name] = []
            metric_groups[metric.name].append(metric)

        # Analyze each metric group
        for metric_name, metrics in metric_groups.items():
            if len(metrics) < 10:  # Need minimum data points
                continue

            values = [m.value for m in sorted(metrics, key=lambda m: m.timestamp)]

            # Calculate trend
            if len(values) >= 2:
                trend = self._calculate_trend(values)
                if abs(trend) > 0.1:  # Significant trend
                    analysis_results["trends_identified"].append({
                        "metric": metric_name,
                        "trend": "increasing" if trend > 0 else "decreasing",
                        "magnitude": abs(trend),
                        "confidence": min(0.95, len(values) / 50)  # Higher confidence with more data
                    })

            # Detect anomalies
            if len(values) >= 20:
                anomalies = self._detect_anomalies(values)
                if anomalies:
                    analysis_results["anomalies_detected"].append({
                        "metric": metric_name,
                        "anomalies_count": len(anomalies),
                        "severity": "high" if len(anomalies) > 3 else "medium"
                    })

        # Find correlations
        correlation_pairs = [
            ("cpu_usage", "response_time"),
            ("active_users", "transactions_per_minute"),
            ("memory_usage", "error_rate")
        ]

        for metric1, metric2 in correlation_pairs:
            if metric1 in metric_groups and metric2 in metric_groups:
                values1 = [m.value for m in metric_groups[metric1][-20:]]  # Last 20 points
                values2 = [m.value for m in metric_groups[metric2][-20:]]

                if len(values1) == len(values2) and len(values1) >= 10:
                    try:
                        correlation = abs(np.corrcoef(values1, values2)[0, 1])
                        if correlation > 0.7:  # Strong correlation
                            analysis_results["correlations_found"].append({
                                "metric1": metric1,
                                "metric2": metric2,
                                "correlation_strength": correlation,
                                "relationship": "positive" if np.corrcoef(values1, values2)[0, 1] > 0 else "negative"
                            })
                    except:
                        pass  # Skip if correlation calculation fails

        return analysis_results

    def _calculate_trend(self, values: List[float]) -> float:
        """Calculate trend slope using linear regression"""
        if len(values) < 2:
            return 0.0

        x = np.arange(len(values))
        y = np.array(values)

        # Simple linear regression
        slope = np.polyfit(x, y, 1)[0]
        return slope

    def _detect_anomalies(self, values: List[float]) -> List[int]:
        """Detect anomalies using statistical methods"""
        if len(values) < 20:
            return []

        # Calculate rolling mean and std
        window_size = min(10, len(values) // 2)
        anomalies = []

        for i in range(window_size, len(values)):
            window = values[i-window_size:i]
            mean = statistics.mean(window)
            stdev = statistics.stdev(window) if len(window) > 1 else 0

            if stdev > 0:
                z_score = abs(values[i] - mean) / stdev
                if z_score > 3:  # 3 standard deviations
                    anomalies.append(i)

        return anomalies

    async def _generate_predictive_insights(self) -> Dict[str, Any]:
        """Generate predictive analytics insights"""
        insights_generated = []

        # Revenue prediction
        revenue_metrics = [m for m in self.system_metrics if m.name == "revenue_per_minute"]
        if len(revenue_metrics) >= 14:  # At least 2 weeks of data
            prediction = self._predict_revenue_trend(revenue_metrics)
            if prediction["confidence"] > 0.7:
                insights_generated.append({
                    "type": "revenue_prediction",
                    "title": "Revenue Trend Prediction",
                    "description": f"Revenue projected to {prediction['direction']} by {prediction['percentage']:.1f}% in next 7 days",
                    "confidence": prediction["confidence"],
                    "impact": "high"
                })

        # Performance degradation prediction
        response_time_metrics = [m for m in self.system_metrics if m.name == "response_time"]
        if len(response_time_metrics) >= 7:
            degradation_risk = self._predict_performance_degradation(response_time_metrics)
            if degradation_risk > 0.8:
                insights_generated.append({
                    "type": "performance_alert",
                    "title": "Performance Degradation Risk",
                    "description": f"High risk of performance degradation detected. Response time may increase by {degradation_risk:.1f}%",
                    "confidence": degradation_risk,
                    "impact": "high"
                })

        # User growth prediction
        user_metrics = [m for m in self.system_metrics if m.name == "active_users"]
        if len(user_metrics) >= 14:
            growth_prediction = self._predict_user_growth(user_metrics)
            if growth_prediction["growth_rate"] > 0.05:  # 5% growth
                insights_generated.append({
                    "type": "user_growth",
                    "title": "User Growth Opportunity",
                    "description": f"User base projected to grow by {growth_prediction['growth_rate']:.1f}% weekly",
                    "confidence": growth_prediction["confidence"],
                    "impact": "medium"
                })

        return {"insights_generated": len(insights_generated), "details": insights_generated}

    def _predict_revenue_trend(self, metrics: List[SystemMetric]) -> Dict[str, Any]:
        """Predict revenue trend for next 7 days"""
        values = [m.value for m in sorted(metrics, key=lambda m: m.timestamp)]

        if len(values) < 7:
            return {"direction": "stable", "percentage": 0, "confidence": 0}

        # Simple trend extrapolation
        recent_trend = self._calculate_trend(values[-7:])  # Last 7 days
        current_avg = statistics.mean(values[-7:])

        if abs(recent_trend) < 0.01:  # Minimal change
            return {"direction": "stable", "percentage": 0, "confidence": 0.8}

        projected_change = recent_trend * 7  # 7-day projection
        percentage_change = (projected_change / current_avg) * 100

        return {
            "direction": "increase" if percentage_change > 0 else "decrease",
            "percentage": abs(percentage_change),
            "confidence": min(0.9, len(values) / 30)  # Higher confidence with more data
        }

    def _predict_performance_degradation(self, metrics: List[SystemMetric]) -> float:
        """Predict risk of performance degradation"""
        values = [m.value for m in sorted(metrics, key=lambda m: m.timestamp)]

        if len(values) < 7:
            return 0.0

        # Check if response time is trending upward
        recent_trend = self._calculate_trend(values[-7:])
        avg_response_time = statistics.mean(values[-7:])

        if recent_trend > 0:  # Increasing response time
            degradation_percentage = (recent_trend * 7 / avg_response_time) * 100
            risk_score = min(1.0, degradation_percentage / 50)  # Scale to 0-1
            return risk_score

        return 0.0

    def _predict_user_growth(self, metrics: List[SystemMetric]) -> Dict[str, Any]:
        """Predict user growth rate"""
        values = [m.value for m in sorted(metrics, key=lambda m: m.timestamp)]

        if len(values) < 14:
            return {"growth_rate": 0, "confidence": 0}

        # Calculate weekly growth rates
        weekly_growth_rates = []
        for i in range(7, len(values)):
            prev_week = statistics.mean(values[i-7:i])
            curr_week = statistics.mean(values[i-7:i+7]) if i+7 <= len(values) else statistics.mean(values[i-7:])
            if prev_week > 0:
                growth_rate = (curr_week - prev_week) / prev_week
                weekly_growth_rates.append(growth_rate)

        if weekly_growth_rates:
            avg_growth_rate = statistics.mean(weekly_growth_rates)
            confidence = min(0.9, len(weekly_growth_rates) / 10)

            return {
                "growth_rate": avg_growth_rate,
                "confidence": confidence
            }

        return {"growth_rate": 0, "confidence": 0}

    async def _optimize_performance(self) -> Dict[str, Any]:
        """Optimize system performance based on analytics"""
        optimization_actions = []

        # Check for performance bottlenecks
        cpu_metrics = [m for m in self.system_metrics if m.name == "cpu_usage"]
        memory_metrics = [m for m in self.system_metrics if m.name == "memory_usage"]

        if cpu_metrics:
            avg_cpu = statistics.mean([m.value for m in cpu_metrics[-10:]])  # Last 10 readings
            if avg_cpu > 80:
                optimization_actions.append({
                    "type": "cpu_optimization",
                    "description": "High CPU usage detected",
                    "recommendations": [
                        "Scale up compute resources",
                        "Optimize CPU-intensive operations",
                        "Implement caching strategies"
                    ],
                    "priority": "high"
                })

        if memory_metrics:
            avg_memory = statistics.mean([m.value for m in memory_metrics[-10:]])
            if avg_memory > 85:
                optimization_actions.append({
                    "type": "memory_optimization",
                    "description": "High memory usage detected",
                    "recommendations": [
                        "Implement memory-efficient algorithms",
                        "Add memory monitoring and alerts",
                        "Consider memory optimization techniques"
                    ],
                    "priority": "high"
                })

        # Check error rates
        error_metrics = [m for m in self.system_metrics if m.name == "error_rate"]
        if error_metrics:
            avg_error_rate = statistics.mean([m.value for m in error_metrics[-10:]])
            if avg_error_rate > 0.05:  # 5% error rate
                optimization_actions.append({
                    "type": "error_reduction",
                    "description": f"Error rate at {avg_error_rate:.2f}%",
                    "recommendations": [
                        "Implement comprehensive error handling",
                        "Add error monitoring and alerting",
                        "Conduct root cause analysis"
                    ],
                    "priority": "medium"
                })

        return {"optimization_actions": len(optimization_actions), "details": optimization_actions}

    async def _analyze_revenue(self) -> Dict[str, Any]:
        """Analyze revenue patterns and optimization opportunities"""
        revenue_analysis = {
            "total_revenue_tracked": 0,
            "average_daily_revenue": 0,
            "revenue_trends": [],
            "optimization_opportunities": []
        }

        # Calculate revenue metrics
        revenue_metrics = [m for m in self.system_metrics if m.name == "revenue_per_minute"]
        if revenue_metrics:
            revenue_values = [m.value for m in revenue_metrics]
            revenue_analysis["total_revenue_tracked"] = sum(revenue_values) * 60  # Convert to total revenue

            # Daily average (assuming 24/7 operation)
            daily_revenue = sum(revenue_values) * 60 * 24 / len(revenue_values)
            revenue_analysis["average_daily_revenue"] = daily_revenue

            # Revenue trends
            if len(revenue_values) >= 7:
                trend = self._calculate_trend(revenue_values[-7:])
                if trend > 0:
                    revenue_analysis["revenue_trends"].append("Revenue increasing")
                elif trend < 0:
                    revenue_analysis["revenue_trends"].append("Revenue declining")

        # Identify optimization opportunities
        if revenue_analysis["average_daily_revenue"] > 0:
            # Mock optimization analysis
            revenue_analysis["optimization_opportunities"] = [
                "Implement upselling strategies for high-value users",
                "Optimize conversion funnel for better revenue per user",
                "Introduce premium features with subscription model"
            ]

        return revenue_analysis

    def get_metrics(self) -> Dict[str, Any]:
        """Get data analytics metrics"""
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "total_metrics_collected": len(self.system_metrics),
            "metrics_categories": len(set(m.category for m in self.system_metrics)),
            "insights_generated": len(self.analytics_insights),
            "predictive_models": len(self.predictive_models),
            "anomalies_detected": sum(1 for insight in self.analytics_insights.values() if insight.insight_type == "anomaly"),
            "revenue_analyzed": sum(m.value for m in self.system_metrics if m.name == "revenue_per_minute") * 60,
            "performance_optimized": 0,  # Would track actual optimizations
            "commission_earned": 0.0,   # Would be calculated from insights impact
            "tasks_executed": 0,        # Would be tracked
            "last_updated": datetime.utcnow().isoformat()
        }