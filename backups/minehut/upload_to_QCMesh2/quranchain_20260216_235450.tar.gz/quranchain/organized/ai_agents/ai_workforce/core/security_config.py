"""
Agent Security Configuration
© QuranChain™ | Omar Mohammad Abunadi™

Centralized configuration for agent API security settings and credential management.
Each agent automatically loads and uses its security configuration.
"""

import os
import json
from typing import Dict, Any, Optional
from dataclasses import dataclass, field, asdict
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class AuthenticationMethod(Enum):
    """Supported authentication methods"""
    API_KEY = "api_key"           # Simple API key in headers
    JWT = "jwt"                   # JSON Web Tokens
    HMAC = "hmac"                 # Request signing with HMAC
    MULTI_AUTH = "multi_auth"     # Multiple methods supported
    NONE = "none"                 # Public endpoint (no auth)


@dataclass
class EndpointSecurityConfig:
    """Security configuration for a single endpoint"""
    path: str
    methods: list = field(default_factory=lambda: ["GET"])
    security_level: str = "authenticated"  # public, authenticated, authorized, critical
    auth_method: AuthenticationMethod = AuthenticationMethod.API_KEY
    required_permission: Optional[str] = None
    rate_limit: Optional[int] = None  # Requests per hour
    require_signature: bool = False
    description: str = ""


@dataclass
class AgentSecurityConfig:
    """Complete security configuration for an agent"""
    agent_id: str
    agent_name: str
    
    # Authentication
    enable_api_keys: bool = True
    enable_jwt: bool = True
    enable_request_signing: bool = True
    
    # JWT Configuration
    jwt_expiration_hours: int = 24
    jwt_refresh_token_expiration_days: int = 30
    jwt_algorithm: str = "HS256"
    
    # Rate Limiting
    default_rate_limit: int = 100  # Per hour
    rate_limit_window_seconds: int = 3600
    
    # API Key Settings
    api_key_expiration_days: Optional[int] = 90
    require_api_key_rotation: bool = True
    
    # Security Headers
    cors_allowed_origins: list = field(default_factory=lambda: ["https://quranchain.com"])
    cors_allow_credentials: bool = True
    security_headers: Dict[str, str] = field(default_factory=lambda: {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains"
    })
    
    # Endpoint-specific configurations
    endpoint_configs: Dict[str, EndpointSecurityConfig] = field(default_factory=dict)
    
    # Logging and Monitoring
    log_all_requests: bool = True
    log_request_bodies: bool = False  # Sensitive data
    alert_on_failed_auth: bool = True
    track_api_key_usage: bool = True


class SecurityConfigManager:
    """Manages agent security configurations"""
    
    # Default security configurations for different agent types
    DEFAULT_CONFIGS = {
        "marketing_ai": {
            "enable_api_keys": True,
            "enable_jwt": True,
            "default_rate_limit": 100,
            "endpoint_configs": {
                "/health": {
                    "methods": ["GET"],
                    "security_level": "public",
                    "rate_limit": 1000
                },
                "/lead/capture": {
                    "methods": ["POST"],
                    "security_level": "authenticated",
                    "rate_limit": 50
                },
                "/content/landing": {
                    "methods": ["POST"],
                    "security_level": "authenticated",
                    "rate_limit": 20
                },
                "/campaign/draft": {
                    "methods": ["POST"],
                    "security_level": "authorized",
                    "required_permission": "campaigns.create",
                    "rate_limit": 10
                },
                "/analytics/attribution": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                },
                "/metrics": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                }
            }
        },
        "sales_ai": {
            "enable_api_keys": True,
            "enable_jwt": True,
            "default_rate_limit": 100,
            "endpoint_configs": {
                "/health": {
                    "methods": ["GET"],
                    "security_level": "public",
                    "rate_limit": 1000
                },
                "/opportunities": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                },
                "/proposal/create": {
                    "methods": ["POST"],
                    "security_level": "authorized",
                    "required_permission": "proposals.create",
                    "rate_limit": 20
                },
                "/deal/close": {
                    "methods": ["POST"],
                    "security_level": "critical",
                    "required_permission": "deals.close",
                    "require_signature": True,
                    "rate_limit": 10
                }
            }
        },
        "onboarding_ai": {
            "enable_api_keys": True,
            "enable_jwt": True,
            "default_rate_limit": 80,
            "endpoint_configs": {
                "/health": {
                    "methods": ["GET"],
                    "security_level": "public",
                    "rate_limit": 1000
                },
                "/merchant/create": {
                    "methods": ["POST"],
                    "security_level": "authorized",
                    "required_permission": "merchants.create",
                    "rate_limit": 30
                },
                "/api-key/generate": {
                    "methods": ["POST"],
                    "security_level": "critical",
                    "required_permission": "apikeys.create",
                    "require_signature": True,
                    "rate_limit": 5
                }
            }
        },
        "optimization_ai": {
            "enable_api_keys": True,
            "enable_jwt": True,
            "default_rate_limit": 150,
            "endpoint_configs": {
                "/health": {
                    "methods": ["GET"],
                    "security_level": "public",
                    "rate_limit": 1000
                },
                "/analysis": {
                    "methods": ["POST"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                },
                "/recommendations": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                }
            }
        },
        "it_ops_ai": {
            "enable_api_keys": True,
            "enable_jwt": True,
            "enable_request_signing": True,
            "default_rate_limit": 50,
            "endpoint_configs": {
                "/health": {
                    "methods": ["GET"],
                    "security_level": "public",
                    "rate_limit": 1000
                },
                "/services": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                },
                "/service/<name>/restart": {
                    "methods": ["POST"],
                    "security_level": "critical",
                    "required_permission": "services.restart",
                    "require_signature": True,
                    "rate_limit": 10
                },
                "/system/metrics": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                }
            }
        },
        "security_ai": {
            "enable_api_keys": True,
            "enable_jwt": True,
            "enable_request_signing": True,
            "default_rate_limit": 50,
            "endpoint_configs": {
                "/health": {
                    "methods": ["GET"],
                    "security_level": "public",
                    "rate_limit": 1000
                },
                "/threats": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 100
                },
                "/threat/block": {
                    "methods": ["POST"],
                    "security_level": "critical",
                    "required_permission": "threats.block",
                    "require_signature": True,
                    "rate_limit": 20
                }
            }
        },
        "orchestrator": {
            "enable_api_keys": True,
            "enable_jwt": True,
            "enable_request_signing": True,
            "default_rate_limit": 200,
            "endpoint_configs": {
                "/health": {
                    "methods": ["GET"],
                    "security_level": "public",
                    "rate_limit": 1000
                },
                "/task/submit": {
                    "methods": ["POST"],
                    "security_level": "authenticated",
                    "rate_limit": 150
                },
                "/task/<id>/execute": {
                    "methods": ["POST"],
                    "security_level": "authorized",
                    "required_permission": "tasks.execute",
                    "rate_limit": 100
                },
                "/agent/status": {
                    "methods": ["GET"],
                    "security_level": "authenticated",
                    "rate_limit": 200
                }
            }
        }
    }
    
    def __init__(self, config_dir: str = ".agent_security_configs"):
        self.config_dir = config_dir
        os.makedirs(config_dir, exist_ok=True)
        self.configs: Dict[str, AgentSecurityConfig] = {}
    
    def get_or_create_config(self, agent_id: str, agent_name: str) -> AgentSecurityConfig:
        """
        Get existing config or create new one for an agent
        
        Args:
            agent_id: Unique agent identifier
            agent_name: Agent display name
        
        Returns:
            AgentSecurityConfig instance
        """
        # Load from disk if exists
        config_file = os.path.join(self.config_dir, f"{agent_id}_security.json")
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    config_data = json.load(f)
                logger.info(f"Loaded security config for {agent_id}")
                # Reconstruct endpoint configs
                endpoint_configs = {}
                for path, cfg in config_data.get("endpoint_configs", {}).items():
                    endpoint_configs[path] = EndpointSecurityConfig(**cfg)
                config_data["endpoint_configs"] = endpoint_configs
                return AgentSecurityConfig(**config_data)
            except Exception as e:
                logger.error(f"Failed to load config: {e}")
        
        # Create new config from defaults
        default_data = self.DEFAULT_CONFIGS.get(
            agent_name.lower().replace(" ", "_"),
            self.DEFAULT_CONFIGS.get("marketing_ai")  # Fallback
        )
        
        # Convert endpoint configs
        endpoint_configs = {}
        for path, cfg in default_data.get("endpoint_configs", {}).items():
            if isinstance(cfg, dict):
                endpoint_configs[path] = EndpointSecurityConfig(path=path, **cfg)
            else:
                endpoint_configs[path] = cfg
        
        default_data["endpoint_configs"] = endpoint_configs
        
        config = AgentSecurityConfig(
            agent_id=agent_id,
            agent_name=agent_name,
            **{k: v for k, v in default_data.items() if k != "endpoint_configs"}
        )
        config.endpoint_configs = endpoint_configs
        
        logger.info(f"Created default security config for {agent_id}")
        self._save_config(config)
        
        return config
    
    def _save_config(self, config: AgentSecurityConfig) -> None:
        """Save configuration to disk"""
        try:
            config_file = os.path.join(self.config_dir, f"{config.agent_id}_security.json")
            config_data = asdict(config)
            
            # Convert dataclass objects to dicts
            endpoint_configs = {}
            for path, cfg in config.endpoint_configs.items():
                if hasattr(cfg, '__dataclass_fields__'):
                    cfg_dict = asdict(cfg)
                    cfg_dict["auth_method"] = cfg.auth_method.value
                    endpoint_configs[path] = cfg_dict
                else:
                    endpoint_configs[path] = cfg
            
            config_data["endpoint_configs"] = endpoint_configs
            
            with open(config_file, 'w') as f:
                json.dump(config_data, f, indent=2, default=str)
            
            os.chmod(config_file, 0o600)
            logger.info(f"Saved security config for {config.agent_id}")
        except Exception as e:
            logger.error(f"Failed to save config: {e}")
    
    def update_config(self, agent_id: str, updates: Dict[str, Any]) -> AgentSecurityConfig:
        """Update an agent's security configuration"""
        config_file = os.path.join(self.config_dir, f"{agent_id}_security.json")
        
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config_data = json.load(f)
        else:
            raise ValueError(f"Config not found for {agent_id}")
        
        # Update configuration
        config_data.update(updates)
        
        # Save back
        with open(config_file, 'w') as f:
            json.dump(config_data, f, indent=2, default=str)
        
        logger.info(f"Updated security config for {agent_id}")
        
        # Reload
        return self.get_or_create_config(agent_id, config_data.get("agent_name", agent_id))
    
    def get_endpoint_config(self, agent_id: str, path: str) -> Optional[EndpointSecurityConfig]:
        """Get security configuration for a specific endpoint"""
        config_file = os.path.join(self.config_dir, f"{agent_id}_security.json")
        
        if not os.path.exists(config_file):
            return None
        
        with open(config_file, 'r') as f:
            config_data = json.load(f)
        
        endpoint_cfg = config_data.get("endpoint_configs", {}).get(path)
        if endpoint_cfg:
            endpoint_cfg["path"] = path
            return EndpointSecurityConfig(**endpoint_cfg)
        
        return None
