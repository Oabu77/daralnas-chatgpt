"""
Marketing AI Agent - Demand Generation
© QuranChain™ | Omar Mohammad Abunadi™

Responsibilities:
- Content creation (landing pages, emails, blogs)
- SEO optimization
- Ad copy generation (human-approved only)
- Funnel analysis and optimization
- Campaign performance tracking

Constraints:
- Consent-based outreach ONLY
- Human approval required before campaigns go live
- No auto-spend without approval
"""

import asyncio
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import uuid
import re
import hashlib

import sys
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from organized.ai_agents.ai_workforce.core.base_agent import (
    BaseAgent, AgentAction, ActionType, ApprovalLevel, AgentStatus
)
from organized.ai_agents.ai_workforce.core.message_bus import get_message_bus, Message, MessagePriority


@dataclass
class ContentPiece:
    """Represents a content piece created by the agent"""
    content_id: str
    content_type: str  # landing_page, email, blog, ad_copy, social
    title: str
    content: str
    meta_description: str
    keywords: List[str]
    target_audience: str
    status: str  # draft, pending_approval, approved, published
    created_at: str
    approved_by: Optional[str] = None
    published_at: Optional[str] = None


@dataclass
class Campaign:
    """Marketing campaign definition"""
    campaign_id: str
    name: str
    objective: str  # awareness, leads, conversions
    target_audience: str
    channels: List[str]
    budget: float
    budget_approved: bool
    start_date: str
    end_date: str
    content_ids: List[str]
    status: str  # draft, pending_approval, approved, active, paused, completed
    metrics: Dict


@dataclass
class Lead:
    """Lead generated from marketing efforts"""
    lead_id: str
    source: str
    campaign_id: Optional[str]
    email: str
    name: Optional[str]
    company: Optional[str]
    phone: Optional[str]
    consent_given: bool
    consent_timestamp: str
    score: int  # 0-100
    status: str  # new, qualified, contacted, converted, lost
    created_at: str
    metadata: Dict


class MarketingAgent(BaseAgent):
    """
    Marketing AI Agent for demand generation.
    
    This agent:
    - Creates content (with human approval)
    - Analyzes SEO opportunities
    - Tracks campaign performance
    - Generates qualified leads
    - Attributes revenue to campaigns
    """
    
    def __init__(self):
        super().__init__(
            agent_id="marketing-ai-001",
            agent_name="Marketing AI",
            agent_type="demand_generation",
            max_actions_per_minute=30,
            max_revenue_action=500
        )
        
        self._init_marketing_db()
        self.message_bus = get_message_bus()
        
        # Content templates
        self.templates = {
            "landing_page": self._landing_page_template,
            "email": self._email_template,
            "blog": self._blog_template,
        }
    
    def _init_marketing_db(self):
        """Initialize marketing-specific tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Content table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS marketing_content (
                content_id TEXT PRIMARY KEY,
                content_type TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                meta_description TEXT,
                keywords TEXT,
                target_audience TEXT,
                status TEXT DEFAULT 'draft',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                approved_by TEXT,
                published_at TEXT
            )
        """)
        
        # Campaigns table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS marketing_campaigns (
                campaign_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                objective TEXT,
                target_audience TEXT,
                channels TEXT,
                budget REAL DEFAULT 0,
                budget_approved INTEGER DEFAULT 0,
                start_date TEXT,
                end_date TEXT,
                content_ids TEXT,
                status TEXT DEFAULT 'draft',
                metrics TEXT
            )
        """)
        
        # Leads table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS marketing_leads (
                lead_id TEXT PRIMARY KEY,
                source TEXT,
                campaign_id TEXT,
                email TEXT NOT NULL,
                name TEXT,
                company TEXT,
                phone TEXT,
                consent_given INTEGER DEFAULT 0,
                consent_timestamp TEXT,
                score INTEGER DEFAULT 0,
                status TEXT DEFAULT 'new',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                metadata TEXT,
                FOREIGN KEY (campaign_id) REFERENCES marketing_campaigns(campaign_id)
            )
        """)
        
        # SEO tracking
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS seo_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                keyword TEXT NOT NULL,
                position INTEGER,
                impressions INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                tracked_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
    
    def get_capabilities(self) -> List[str]:
        return [
            "content_creation",
            "seo_analysis",
            "campaign_management",
            "lead_generation",
            "funnel_optimization",
            "performance_tracking",
            "email_marketing",
            "landing_page_creation"
        ]
    
    async def _execute_action_impl(self, action: AgentAction) -> Dict:
        """Execute marketing-specific actions"""
        action_handlers = {
            "create_content": self._create_content,
            "analyze_seo": self._analyze_seo,
            "create_campaign": self._create_campaign,
            "track_lead": self._track_lead,
            "qualify_lead": self._qualify_lead,
            "get_campaign_metrics": self._get_campaign_metrics,
            "generate_report": self._generate_report,
        }
        
        handler = action_handlers.get(action.target)
        if handler:
            return await handler(action.data)
        
        return {"error": f"Unknown action: {action.target}"}
    
    async def create_content(
        self,
        content_type: str,
        title: str,
        target_audience: str,
        keywords: List[str],
        additional_context: Dict = None
    ) -> ContentPiece:
        """Create a new content piece (requires approval before publishing)"""
        
        action = AgentAction(
            action_type=ActionType.CREATE,
            description=f"Create {content_type}: {title}",
            target="create_content",
            data={
                "content_type": content_type,
                "title": title,
                "target_audience": target_audience,
                "keywords": keywords,
                "additional_context": additional_context or {}
            },
            approval_level=ApprovalLevel.MEDIUM  # Content needs approval
        )
        
        result = await self.execute_action(action)
        return result
    
    async def _create_content(self, data: Dict) -> Dict:
        """Internal content creation logic"""
        content_type = data.get("content_type")
        title = data.get("title")
        target_audience = data.get("target_audience")
        keywords = data.get("keywords", [])
        
        # Generate content based on type
        template_func = self.templates.get(content_type)
        if not template_func:
            return {"error": f"Unknown content type: {content_type}"}
        
        content, meta_description = template_func(title, target_audience, keywords)
        
        content_piece = ContentPiece(
            content_id=str(uuid.uuid4()),
            content_type=content_type,
            title=title,
            content=content,
            meta_description=meta_description,
            keywords=keywords,
            target_audience=target_audience,
            status="pending_approval",
            created_at=datetime.utcnow().isoformat()
        )
        
        # Save to database
        self._save_content(content_piece)
        
        # Update metrics
        self.metrics.tasks_executed += 1
        
        return asdict(content_piece)
    
    def _landing_page_template(self, title: str, audience: str, keywords: List[str]) -> tuple:
        """Generate landing page content"""
        keyword_str = ", ".join(keywords[:3]) if keywords else "Islamic finance"
        
        content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | QuranChain™</title>
    <meta name="description" content="{title} - Sharia-compliant financial services by QuranChain™">
    <meta name="keywords" content="{keyword_str}">
</head>
<body>
    <header>
        <h1>{title}</h1>
        <p>Sharia-Compliant Solutions for {audience}</p>
    </header>
    
    <section class="hero">
        <h2>Transform Your Financial Future</h2>
        <p>Join thousands who trust QuranChain™ for ethical, interest-free banking.</p>
        <a href="#signup" class="cta-button">Get Started Today</a>
    </section>
    
    <section class="benefits">
        <h3>Why Choose QuranChain™?</h3>
        <ul>
            <li>✅ 100% Sharia-Compliant</li>
            <li>✅ No Interest (Riba-Free)</li>
            <li>✅ Transparent Pricing</li>
            <li>✅ 24/7 Support</li>
        </ul>
    </section>
    
    <section id="signup" class="signup-form">
        <h3>Request Information</h3>
        <form action="/api/leads" method="POST">
            <input type="email" name="email" placeholder="Your Email" required>
            <input type="text" name="name" placeholder="Your Name">
            <label>
                <input type="checkbox" name="consent" required>
                I agree to receive communications from QuranChain™
            </label>
            <button type="submit">Learn More</button>
        </form>
    </section>
    
    <footer>
        <p>© 2025 QuranChain™ | Omar Mohammad Abunadi™</p>
    </footer>
</body>
</html>
"""
        
        meta = f"{title} - Sharia-compliant {keyword_str} for {audience}. Join QuranChain™ today."
        return content.strip(), meta
    
    def _email_template(self, title: str, audience: str, keywords: List[str]) -> tuple:
        """Generate email content"""
        content = f"""
Subject: {title}

Assalamu Alaikum,

We noticed you're interested in Sharia-compliant financial services.

At QuranChain™, we provide:

• Interest-Free Banking - No riba, ever
• Halal Investments - Carefully screened for compliance
• Islamic Insurance (Takaful) - Based on mutual cooperation
• Halal Mortgages - Own your home the ethical way

As a valued member of our community, we'd like to offer you:

🎁 FREE Financial Health Assessment
🎁 Personalized Sharia Compliance Report
🎁 Priority Access to New Services

Ready to take the next step?

[Schedule Your Free Consultation]

Best regards,
The QuranChain™ Team

---
© 2025 QuranChain™ | Omar Mohammad Abunadi™
You're receiving this because you requested information.
[Unsubscribe] | [Privacy Policy]
"""
        
        meta = f"Email campaign: {title} for {audience}"
        return content.strip(), meta
    
    def _blog_template(self, title: str, audience: str, keywords: List[str]) -> tuple:
        """Generate blog post outline"""
        keyword_str = ", ".join(keywords) if keywords else "Islamic finance"
        
        content = f"""
# {title}

*Published by QuranChain™ | For {audience}*

## Introduction

In today's financial landscape, finding truly Sharia-compliant solutions 
can be challenging. This guide will help you understand {keyword_str} 
and how to make ethical financial decisions.

## What Makes Finance "Halal"?

Islamic finance is built on several core principles:

1. **No Riba (Interest)** - Money cannot earn money without genuine economic activity
2. **No Gharar (Uncertainty)** - Contracts must be clear and transparent
3. **No Haram Activities** - No investment in alcohol, gambling, or other prohibited sectors
4. **Risk Sharing** - Both parties share in profits AND losses

## How QuranChain™ Helps

At QuranChain™, we've built technology that:

- Automatically screens investments for compliance
- Calculates profit-sharing instead of interest
- Provides transparent fee structures
- Connects you with certified Islamic scholars

## Getting Started

Ready to make the switch to ethical finance?

1. [Open a Dar Al Nas Account](#) - Interest-free banking
2. [Explore Halal Investments](#) - Screened and certified
3. [Get Takaful Insurance](#) - Mutual protection

## Conclusion

Making the transition to Sharia-compliant finance has never been easier. 
QuranChain™ is here to guide you every step of the way.

---
*© 2025 QuranChain™ | Omar Mohammad Abunadi™*
*Keywords: {keyword_str}*
"""
        
        meta = f"{title} - A comprehensive guide to {keyword_str} for {audience}"
        return content.strip(), meta
    
    def _save_content(self, content: ContentPiece):
        """Save content to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO marketing_content (
                content_id, content_type, title, content, meta_description,
                keywords, target_audience, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            content.content_id,
            content.content_type,
            content.title,
            content.content,
            content.meta_description,
            json.dumps(content.keywords),
            content.target_audience,
            content.status,
            content.created_at
        ))
        
        conn.commit()
        conn.close()
    
    async def _analyze_seo(self, data: Dict) -> Dict:
        """Analyze SEO opportunities"""
        url = data.get("url", "")
        target_keywords = data.get("keywords", [])
        
        # SEO analysis (simulated - would integrate with real SEO tools)
        analysis = {
            "url": url,
            "score": 75,
            "recommendations": [
                "Add more internal links",
                "Optimize meta description length",
                "Include target keywords in H1",
                "Add alt text to images",
                "Improve page load speed"
            ],
            "keyword_opportunities": [
                {"keyword": "halal banking", "volume": 12000, "difficulty": 45},
                {"keyword": "islamic finance", "volume": 8500, "difficulty": 52},
                {"keyword": "sharia compliant", "volume": 6200, "difficulty": 38},
            ],
            "analyzed_at": datetime.utcnow().isoformat()
        }
        
        return analysis
    
    async def _create_campaign(self, data: Dict) -> Dict:
        """Create a marketing campaign (requires approval)"""
        campaign = Campaign(
            campaign_id=str(uuid.uuid4()),
            name=data.get("name", ""),
            objective=data.get("objective", "leads"),
            target_audience=data.get("target_audience", ""),
            channels=data.get("channels", []),
            budget=data.get("budget", 0),
            budget_approved=False,  # Always requires approval
            start_date=data.get("start_date", ""),
            end_date=data.get("end_date", ""),
            content_ids=data.get("content_ids", []),
            status="pending_approval",
            metrics={"impressions": 0, "clicks": 0, "leads": 0, "conversions": 0}
        )
        
        # Save campaign
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO marketing_campaigns (
                campaign_id, name, objective, target_audience, channels,
                budget, budget_approved, start_date, end_date, content_ids, status, metrics
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            campaign.campaign_id,
            campaign.name,
            campaign.objective,
            campaign.target_audience,
            json.dumps(campaign.channels),
            campaign.budget,
            0,
            campaign.start_date,
            campaign.end_date,
            json.dumps(campaign.content_ids),
            campaign.status,
            json.dumps(campaign.metrics)
        ))
        
        conn.commit()
        conn.close()
        
        self.logger.info(f"Campaign created: {campaign.name} (pending approval)")
        
        return asdict(campaign)
    
    async def track_lead(
        self,
        email: str,
        source: str,
        consent_given: bool,
        campaign_id: Optional[str] = None,
        name: Optional[str] = None,
        company: Optional[str] = None,
        metadata: Dict = None
    ) -> Lead:
        """Track a new lead (consent MUST be given)"""
        
        if not consent_given:
            self.logger.warning(f"Lead rejected - no consent: {email}")
            return None
        
        action = AgentAction(
            action_type=ActionType.CREATE,
            description=f"Track lead: {email}",
            target="track_lead",
            data={
                "email": email,
                "source": source,
                "consent_given": consent_given,
                "campaign_id": campaign_id,
                "name": name,
                "company": company,
                "metadata": metadata or {}
            },
            approval_level=ApprovalLevel.NONE  # Leads auto-tracked if consent given
        )
        
        result = await self.execute_action(action)
        return result
    
    async def _track_lead(self, data: Dict) -> Dict:
        """Internal lead tracking"""
        if not data.get("consent_given"):
            return {"error": "Consent not given - lead not tracked"}
        
        lead = Lead(
            lead_id=str(uuid.uuid4()),
            source=data.get("source", "unknown"),
            campaign_id=data.get("campaign_id"),
            email=data.get("email"),
            name=data.get("name"),
            company=data.get("company"),
            phone=data.get("phone"),
            consent_given=True,
            consent_timestamp=datetime.utcnow().isoformat(),
            score=self._calculate_lead_score(data),
            status="new",
            created_at=datetime.utcnow().isoformat(),
            metadata=data.get("metadata", {})
        )
        
        # Save to database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO marketing_leads (
                lead_id, source, campaign_id, email, name, company, phone,
                consent_given, consent_timestamp, score, status, created_at, metadata
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            lead.lead_id,
            lead.source,
            lead.campaign_id,
            lead.email,
            lead.name,
            lead.company,
            lead.phone,
            1,
            lead.consent_timestamp,
            lead.score,
            lead.status,
            lead.created_at,
            json.dumps(lead.metadata)
        ))
        
        conn.commit()
        conn.close()
        
        # Update metrics
        self.metrics.leads_generated += 1
        
        # Notify Sales AI
        await self.message_bus.publish(Message(
            topic="new_lead",
            payload=asdict(lead),
            source_agent=self.agent_id,
            priority=MessagePriority.HIGH
        ))
        
        return asdict(lead)
    
    def _calculate_lead_score(self, data: Dict) -> int:
        """Calculate lead quality score (0-100)"""
        score = 30  # Base score for providing email with consent
        
        if data.get("name"):
            score += 10
        if data.get("company"):
            score += 20
        if data.get("phone"):
            score += 15
        
        # Source quality
        source_scores = {
            "organic": 25,
            "referral": 30,
            "paid_search": 20,
            "social": 15,
            "email": 20,
            "direct": 15
        }
        score += source_scores.get(data.get("source", ""), 10)
        
        return min(score, 100)
    
    async def _qualify_lead(self, data: Dict) -> Dict:
        """Qualify a lead using BANT criteria"""
        lead_id = data.get("lead_id")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM marketing_leads WHERE lead_id = ?", (lead_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return {"error": "Lead not found"}
        
        # BANT scoring (Budget, Authority, Need, Timeline)
        qualification = {
            "lead_id": lead_id,
            "bant_score": {
                "budget": data.get("budget_score", 0),
                "authority": data.get("authority_score", 0),
                "need": data.get("need_score", 0),
                "timeline": data.get("timeline_score", 0)
            },
            "total_score": 0,
            "qualified": False,
            "recommended_action": ""
        }
        
        total = sum(qualification["bant_score"].values())
        qualification["total_score"] = total
        qualification["qualified"] = total >= 60
        
        if total >= 80:
            qualification["recommended_action"] = "Schedule demo immediately"
        elif total >= 60:
            qualification["recommended_action"] = "Nurture with content, schedule call"
        elif total >= 40:
            qualification["recommended_action"] = "Add to drip campaign"
        else:
            qualification["recommended_action"] = "Low priority - passive nurture"
        
        # Update lead status
        new_status = "qualified" if qualification["qualified"] else "nurturing"
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE marketing_leads SET status = ?, score = ? WHERE lead_id = ?",
            (new_status, total, lead_id)
        )
        conn.commit()
        conn.close()
        
        return qualification
    
    async def _get_campaign_metrics(self, data: Dict) -> Dict:
        """Get metrics for a campaign"""
        campaign_id = data.get("campaign_id")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM marketing_campaigns WHERE campaign_id = ?",
            (campaign_id,)
        )
        campaign_row = cursor.fetchone()
        
        if not campaign_row:
            conn.close()
            return {"error": "Campaign not found"}
        
        # Get lead count for campaign
        cursor.execute(
            "SELECT COUNT(*) FROM marketing_leads WHERE campaign_id = ?",
            (campaign_id,)
        )
        lead_count = cursor.fetchone()[0]
        
        # Get conversion count
        cursor.execute(
            "SELECT COUNT(*) FROM marketing_leads WHERE campaign_id = ? AND status = 'converted'",
            (campaign_id,)
        )
        conversion_count = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "campaign_id": campaign_id,
            "leads": lead_count,
            "conversions": conversion_count,
            "conversion_rate": conversion_count / lead_count * 100 if lead_count > 0 else 0,
            "cost_per_lead": campaign_row[5] / lead_count if lead_count > 0 else 0,
            "roi": "Pending revenue attribution"
        }
    
    async def _generate_report(self, data: Dict) -> Dict:
        """Generate marketing performance report"""
        period = data.get("period", "daily")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get totals
        cursor.execute("SELECT COUNT(*) FROM marketing_content")
        content_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM marketing_campaigns")
        campaign_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM marketing_leads")
        total_leads = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM marketing_leads WHERE status = 'qualified'")
        qualified_leads = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM marketing_leads WHERE status = 'converted'")
        converted_leads = cursor.fetchone()[0]
        
        conn.close()
        
        report = {
            "period": period,
            "generated_at": datetime.utcnow().isoformat(),
            "summary": {
                "content_pieces": content_count,
                "active_campaigns": campaign_count,
                "total_leads": total_leads,
                "qualified_leads": qualified_leads,
                "converted_leads": converted_leads,
                "conversion_rate": converted_leads / total_leads * 100 if total_leads > 0 else 0
            },
            "agent_metrics": self.get_metrics(),
            "recommendations": [
                "Focus on high-converting content types",
                "Increase investment in organic search",
                "Test new landing page variants"
            ]
        }
        
        return report
    
    async def run(self):
        """Main agent loop"""
        self.logger.info("Marketing AI starting main loop")
        
        # Subscribe to relevant topics
        self.message_bus.subscribe("content_request", self._handle_content_request)
        self.message_bus.subscribe("campaign_update", self._handle_campaign_update)
        
        while self.status == AgentStatus.RUNNING:
            try:
                # Check for pending tasks
                await self._process_pending_tasks()
                
                # Generate periodic reports
                await self._check_scheduled_tasks()
                
                await asyncio.sleep(5)  # Check every 5 seconds
                
            except Exception as e:
                self.logger.error(f"Error in main loop: {e}")
                self.metrics.errors += 1
                await asyncio.sleep(10)
    
    async def _handle_content_request(self, message: Message):
        """Handle content creation requests"""
        data = message.payload
        await self.create_content(
            content_type=data.get("content_type", "landing_page"),
            title=data.get("title", ""),
            target_audience=data.get("target_audience", ""),
            keywords=data.get("keywords", [])
        )
    
    async def _handle_campaign_update(self, message: Message):
        """Handle campaign status updates"""
        data = message.payload
        campaign_id = data.get("campaign_id")
        new_status = data.get("status")
        
        if campaign_id and new_status:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE marketing_campaigns SET status = ? WHERE campaign_id = ?",
                (new_status, campaign_id)
            )
            conn.commit()
            conn.close()
    
    async def _process_pending_tasks(self):
        """Process any pending tasks"""
        # Check for pending content approvals
        pass
    
    async def _check_scheduled_tasks(self):
        """Check for scheduled tasks like daily reports"""
        pass


# Create singleton instance
_marketing_agent: Optional[MarketingAgent] = None


def get_marketing_agent() -> MarketingAgent:
    global _marketing_agent
    if _marketing_agent is None:
        _marketing_agent = MarketingAgent()
    return _marketing_agent
