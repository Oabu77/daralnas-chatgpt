"""
QuranChain™ AI Workforce - Base Agent Framework
© QuranChain™ | Omar Mohammad Abunadi™

All AI agents inherit from this base class which enforces:
- Governance compliance
- Kill-switch obedience
- Audit logging
- Human approval gates
- Revenue attribution
"""

import os
import json
import sqlite3
import hashlib
import logging
from blockchain_logging_handler import setup_blockchain_logging
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from enum import Enum
import threading
import time

# ═══════════════════════════════════════════════════════════════
# CONSTANTS & CONFIGURATION
# ═══════════════════════════════════════════════════════════════

FOUNDER = "Omar Mohammad Abunadi"
FOUNDER_ROYALTY_RATE = 0.30  # 30% IMMUTABLE
COPYRIGHT = "© QuranChain™ | Omar Mohammad Abunadi™"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_DIR = os.path.join(BASE_DIR, "logs")
DB_PATH = os.path.join(BASE_DIR, "shared", "ai_workforce.db")

os.makedirs(LOG_DIR, exist_ok=True)

# ═══════════════════════════════════════════════════════════════
# ENUMS & DATA CLASSES
# ═══════════════════════════════════════════════════════════════

class AgentType(Enum):
    MARKETING = "marketing_ai"
    SALES = "sales_ai"
    ONBOARDING = "onboarding_ai"
    OPTIMIZATION = "optimization_ai"
    IT_OPS = "it_ops_ai"
    SECURITY = "security_ai"
    CUSTOMER_SUPPORT = "customer_support_ai"
    DATA_ANALYST = "data_analyst_ai"
    CONTENT_WRITER = "content_writer_ai"
    SOCIAL_MEDIA = "social_media_ai"
    TECHNICAL_WRITER = "technical_writer_ai"
    RESEARCH = "research_ai"
    TRANSLATION = "translation_ai"
    QUALITY_ASSURANCE = "quality_assurance_ai"
    PROJECT_MANAGER = "project_manager_ai"
    COMPLIANCE = "compliance_ai"

class ActionSeverity(Enum):
    LOW = "low"           # Auto-execute
    MEDIUM = "medium"     # Log and execute
    HIGH = "high"         # Requires approval
    CRITICAL = "critical" # Human-only

class ApprovalStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    EXPIRED = "expired"

@dataclass
class ActionLog:
    agent_id: str
    agent_type: str
    action: str
    severity: str
    details: Dict[str, Any]
    revenue_impact: float
    timestamp: str
    approval_required: bool
    approval_status: str
    execution_status: str
    error_message: Optional[str] = None

@dataclass
class RevenueAttribution:
    agent_id: str
    agent_type: str
    source: str
    amount: float
    currency: str
    commission_rate: float
    commission_amount: float
    founder_royalty: float
    timestamp: str

# ═══════════════════════════════════════════════════════════════
# GOVERNANCE CHECKER
# ═══════════════════════════════════════════════════════════════

class GovernanceChecker:
    """Enforces governance rules across all AI agents"""
    
    FORBIDDEN_ACTIONS = [
        "spam", "scam", "fraud", "impersonate", "fake_review",
        "fake_account", "unauthorized_spend", "bypass_approval",
        "disable_logging", "modify_royalty", "unsupervised_transfer"
    ]
    
    APPROVAL_REQUIRED_ACTIONS = [
        "send_email_campaign", "create_api_key", "process_payout",
        "modify_pricing", "deploy_production", "access_pii",
        "large_transaction", "contract_generation"
    ]
    
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self.kill_switch_active = False
        self._init_db()
    
    def _init_db(self):
        """Initialize governance database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS kill_switch (
                id INTEGER PRIMARY KEY,
                active INTEGER DEFAULT 0,
                activated_by TEXT,
                activated_at TEXT,
                reason TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS approval_requests (
                id TEXT PRIMARY KEY,
                agent_id TEXT,
                action TEXT,
                details TEXT,
                status TEXT DEFAULT 'pending',
                requested_at TEXT,
                reviewed_at TEXT,
                reviewed_by TEXT,
                expires_at TEXT
            )
        """)
        
        # Initialize kill switch if not exists
        cursor.execute("SELECT COUNT(*) FROM kill_switch")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO kill_switch (active) VALUES (0)")
        
        conn.commit()
        conn.close()
    
    def check_kill_switch(self) -> bool:
        """Check if kill switch is active"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT active FROM kill_switch ORDER BY id DESC LIMIT 1")
        result = cursor.fetchone()
        conn.close()
        return bool(result[0]) if result else False
    
    def activate_kill_switch(self, activated_by: str, reason: str):
        """Activate emergency kill switch"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO kill_switch (active, activated_by, activated_at, reason)
            VALUES (1, ?, ?, ?)
        """, (activated_by, datetime.utcnow().isoformat(), reason))
        conn.commit()
        conn.close()
        self.kill_switch_active = True
    
    def is_action_forbidden(self, action: str) -> bool:
        """Check if action is forbidden"""
        action_lower = action.lower()
        return any(forbidden in action_lower for forbidden in self.FORBIDDEN_ACTIONS)
    
    def requires_approval(self, action: str) -> bool:
        """Check if action requires human approval"""
        action_lower = action.lower()
        return any(req in action_lower for req in self.APPROVAL_REQUIRED_ACTIONS)
    
    def request_approval(self, agent_id: str, action: str, details: Dict) -> str:
        """Submit approval request"""
        request_id = hashlib.sha256(
            f"{agent_id}{action}{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:16]
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO approval_requests 
            (id, agent_id, action, details, status, requested_at, expires_at)
            VALUES (?, ?, ?, ?, 'pending', ?, ?)
        """, (
            request_id, agent_id, action, json.dumps(details),
            datetime.utcnow().isoformat(),
            (datetime.utcnow() + timedelta(hours=24)).isoformat()
        ))
        conn.commit()
        conn.close()
        return request_id
    
    def check_approval(self, request_id: str) -> ApprovalStatus:
        """Check approval status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT status, expires_at FROM approval_requests WHERE id = ?
        """, (request_id,))
        result = cursor.fetchone()
        conn.close()
        
        if not result:
            return ApprovalStatus.DENIED
        
        status, expires_at = result
        if datetime.fromisoformat(expires_at) < datetime.utcnow():
            return ApprovalStatus.EXPIRED
        
        return ApprovalStatus[status.upper()]

# ═══════════════════════════════════════════════════════════════
# BASE AI AGENT
# ═══════════════════════════════════════════════════════════════

class BaseAIAgent(ABC):
    """
    Base class for all AI agents in the QuranChain workforce.
    Enforces governance, logging, and revenue attribution.
    """
    
    # Commission rates by agent type
    COMMISSION_RATES = {
        AgentType.MARKETING: 0.05,    # 5%
        AgentType.SALES: 0.10,        # 10%
        AgentType.ONBOARDING: 0.03,   # 3%
        AgentType.OPTIMIZATION: 0.02, # 2%
        AgentType.IT_OPS: 0.01,       # 1%
        AgentType.SECURITY: 0.01,     # 1%
        AgentType.CUSTOMER_SUPPORT: 0.04,  # 4%
        AgentType.DATA_ANALYST: 0.03,      # 3%
        AgentType.CONTENT_WRITER: 0.05,    # 5%
        AgentType.SOCIAL_MEDIA: 0.04,      # 4%
        AgentType.TECHNICAL_WRITER: 0.04,  # 4%
        AgentType.RESEARCH: 0.03,          # 3%
        AgentType.TRANSLATION: 0.03,       # 3%
        AgentType.QUALITY_ASSURANCE: 0.02, # 2%
        AgentType.PROJECT_MANAGER: 0.06,   # 6%
        AgentType.COMPLIANCE: 0.02,        # 2%
    }
    
    def __init__(self, agent_type: AgentType, agent_id: Optional[str] = None):
        self.agent_type = agent_type
        self.agent_id = agent_id or f"{agent_type.value}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        self.governance = GovernanceChecker()
        self.commission_rate = self.COMMISSION_RATES.get(agent_type, 0.01)
        
        # Setup logging
        self.logger = logging.getLogger(self.agent_id)
        self.logger.setLevel(logging.INFO)
        
        log_file = os.path.join(LOG_DIR, f"{self.agent_id}.log")
        handler = logging.FileHandler(log_file)
        handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        self.logger.addHandler(handler)
        
        # Metrics
        self.metrics = {
            "tasks_executed": 0,
            "tasks_blocked": 0,
            "revenue_attributed": 0.0,
            "commission_earned": 0.0,
            "errors": 0,
            "approvals_requested": 0,
            "approvals_granted": 0,
        }
        
        self._init_agent_db()
        self.logger.info(f"Agent {self.agent_id} initialized | {COPYRIGHT}")
    
    def _init_agent_db(self):
        """Initialize agent-specific database tables"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS action_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT,
                agent_type TEXT,
                action TEXT,
                severity TEXT,
                details TEXT,
                revenue_impact REAL,
                timestamp TEXT,
                approval_required INTEGER,
                approval_status TEXT,
                execution_status TEXT,
                error_message TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS revenue_attributions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT,
                agent_type TEXT,
                source TEXT,
                amount REAL,
                currency TEXT,
                commission_rate REAL,
                commission_amount REAL,
                founder_royalty REAL,
                timestamp TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT,
                metric_name TEXT,
                metric_value REAL,
                recorded_at TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def execute_action(
        self, 
        action: str, 
        details: Dict[str, Any],
        severity: ActionSeverity = ActionSeverity.LOW,
        revenue_impact: float = 0.0
    ) -> Dict[str, Any]:
        """
        Execute an action with full governance checking.
        
        Returns:
            Dict with execution result
        """
        # Step 1: Check kill switch
        if self.governance.check_kill_switch():
            self.logger.warning(f"KILL SWITCH ACTIVE - Action blocked: {action}")
            self.metrics["tasks_blocked"] += 1
            return {
                "success": False,
                "reason": "kill_switch_active",
                "action": action
            }
        
        # Step 2: Check if action is forbidden
        if self.governance.is_action_forbidden(action):
            self.logger.error(f"FORBIDDEN ACTION BLOCKED: {action}")
            self.metrics["tasks_blocked"] += 1
            self._log_action(action, severity, details, revenue_impact, 
                           False, "blocked", "Action is forbidden by governance")
            return {
                "success": False,
                "reason": "forbidden_action",
                "action": action
            }
        
        # Step 3: Check if approval required
        approval_status = "not_required"
        if severity in [ActionSeverity.HIGH, ActionSeverity.CRITICAL] or \
           self.governance.requires_approval(action):
            
            if severity == ActionSeverity.CRITICAL:
                self.logger.warning(f"CRITICAL ACTION - Human only: {action}")
                self.metrics["tasks_blocked"] += 1
                return {
                    "success": False,
                    "reason": "requires_human_execution",
                    "action": action
                }
            
            # Request approval
            request_id = self.governance.request_approval(
                self.agent_id, action, details
            )
            self.metrics["approvals_requested"] += 1
            self.logger.info(f"Approval requested: {request_id} for {action}")
            
            # For now, we'll simulate checking - in production this would wait
            approval = self.governance.check_approval(request_id)
            approval_status = approval.value
            
            if approval != ApprovalStatus.APPROVED:
                self.logger.warning(f"Action pending approval: {action}")
                self._log_action(action, severity, details, revenue_impact,
                               True, approval_status, None)
                return {
                    "success": False,
                    "reason": "pending_approval",
                    "request_id": request_id,
                    "action": action
                }
            
            self.metrics["approvals_granted"] += 1
        
        # Step 4: Execute the action
        try:
            result = self._execute_internal(action, details)
            self.metrics["tasks_executed"] += 1
            
            # Step 5: Attribute revenue if applicable
            if revenue_impact > 0:
                self._attribute_revenue(action, revenue_impact)
            
            # Step 6: Log success
            self._log_action(action, severity, details, revenue_impact,
                           self.governance.requires_approval(action),
                           approval_status, "success")
            
            self.logger.info(f"Action executed: {action}")
            return {
                "success": True,
                "action": action,
                "result": result
            }
            
        except Exception as e:
            self.metrics["errors"] += 1
            self.logger.error(f"Action failed: {action} - {str(e)}")
            self._log_action(action, severity, details, revenue_impact,
                           False, approval_status, "failed", str(e))
            return {
                "success": False,
                "reason": "execution_error",
                "error": str(e),
                "action": action
            }
    
    @abstractmethod
    def _execute_internal(self, action: str, details: Dict[str, Any]) -> Any:
        """
        Internal execution method - implemented by each agent type.
        """
        pass
    
    @abstractmethod
    def run_cycle(self) -> Dict[str, Any]:
        """
        Run one operational cycle of the agent.
        Returns metrics and status.
        """
        pass
    
    def _log_action(
        self, 
        action: str, 
        severity: ActionSeverity,
        details: Dict,
        revenue_impact: float,
        approval_required: bool,
        approval_status: str,
        execution_status: str,
        error_message: Optional[str] = None
    ):
        """Log action to database"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO action_logs 
            (agent_id, agent_type, action, severity, details, revenue_impact,
             timestamp, approval_required, approval_status, execution_status, error_message)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            self.agent_id, self.agent_type.value, action, severity.value,
            json.dumps(details), revenue_impact, datetime.utcnow().isoformat(),
            1 if approval_required else 0, approval_status, execution_status, error_message
        ))
        conn.commit()
        conn.close()
    
    def _attribute_revenue(self, source: str, amount: float, currency: str = "USD"):
        """Attribute revenue and calculate commissions"""
        founder_royalty = amount * FOUNDER_ROYALTY_RATE
        remaining = amount - founder_royalty
        commission = remaining * self.commission_rate
        
        attribution = RevenueAttribution(
            agent_id=self.agent_id,
            agent_type=self.agent_type.value,
            source=source,
            amount=amount,
            currency=currency,
            commission_rate=self.commission_rate,
            commission_amount=commission,
            founder_royalty=founder_royalty,
            timestamp=datetime.utcnow().isoformat()
        )
        
        # Store attribution
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO revenue_attributions
            (agent_id, agent_type, source, amount, currency, commission_rate,
             commission_amount, founder_royalty, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            attribution.agent_id, attribution.agent_type, attribution.source,
            attribution.amount, attribution.currency, attribution.commission_rate,
            attribution.commission_amount, attribution.founder_royalty,
            attribution.timestamp
        ))
        conn.commit()
        conn.close()
        
        self.metrics["revenue_attributed"] += amount
        self.metrics["commission_earned"] += commission
        
        self.logger.info(
            f"Revenue attributed: ${amount:.2f} | "
            f"Founder royalty: ${founder_royalty:.2f} | "
            f"Commission: ${commission:.2f}"
        )
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current agent metrics"""
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type.value,
            "metrics": self.metrics,
            "commission_rate": self.commission_rate,
            "timestamp": datetime.utcnow().isoformat(),
            "copyright": COPYRIGHT
        }
    
    def generate_report(self) -> str:
        """Generate agent status report"""
        metrics = self.get_metrics()
        report = f"""
═══════════════════════════════════════════════════════════════
AI AGENT STATUS REPORT
{COPYRIGHT}
═══════════════════════════════════════════════════════════════
Agent ID: {metrics['agent_id']}
Agent Type: {metrics['agent_type']}
Commission Rate: {metrics['commission_rate']*100:.1f}%

OPERATIONAL METRICS:
- Tasks Executed: {metrics['metrics']['tasks_executed']}
- Tasks Blocked: {metrics['metrics']['tasks_blocked']}
- Errors: {metrics['metrics']['errors']}
- Approvals Requested: {metrics['metrics']['approvals_requested']}
- Approvals Granted: {metrics['metrics']['approvals_granted']}

REVENUE METRICS:
- Revenue Attributed: ${metrics['metrics']['revenue_attributed']:,.2f}
- Commission Earned: ${metrics['metrics']['commission_earned']:,.2f}
- Founder Royalty Generated: ${metrics['metrics']['revenue_attributed'] * FOUNDER_ROYALTY_RATE:,.2f}

Report Generated: {metrics['timestamp']}
═══════════════════════════════════════════════════════════════
"""
        return report


# ═══════════════════════════════════════════════════════════════
# AGENT ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════

class AgentOrchestrator:
    """
    Central orchestrator for all AI agents.
    Manages lifecycle, coordination, and reporting.
    """
    
    def __init__(self):
        self.agents: Dict[str, BaseAIAgent] = {}
        self.governance = GovernanceChecker()
        self.running = False
        self.logger = logging.getLogger("orchestrator")
        
    def register_agent(self, agent: BaseAIAgent):
        """Register an agent with the orchestrator"""
        self.agents[agent.agent_id] = agent
        self.logger.info(f"Registered agent: {agent.agent_id}")
    
    def unregister_agent(self, agent_id: str):
        """Unregister an agent"""
        if agent_id in self.agents:
            del self.agents[agent_id]
            self.logger.info(f"Unregistered agent: {agent_id}")
    
    def run_all_cycles(self) -> Dict[str, Any]:
        """Run one cycle for all agents"""
        if self.governance.check_kill_switch():
            self.logger.warning("KILL SWITCH ACTIVE - All agents halted")
            return {"status": "halted", "reason": "kill_switch"}
        
        results = {}
        for agent_id, agent in self.agents.items():
            try:
                results[agent_id] = agent.run_cycle()
            except Exception as e:
                self.logger.error(f"Agent {agent_id} cycle failed: {e}")
                results[agent_id] = {"error": str(e)}
        
        return results
    
    def get_fleet_metrics(self) -> Dict[str, Any]:
        """Get aggregated metrics across all agents"""
        total_revenue = 0.0
        total_commission = 0.0
        total_tasks = 0
        total_errors = 0
        
        agent_metrics = {}
        for agent_id, agent in self.agents.items():
            metrics = agent.get_metrics()
            agent_metrics[agent_id] = metrics
            total_revenue += metrics['metrics']['revenue_attributed']
            total_commission += metrics['metrics']['commission_earned']
            total_tasks += metrics['metrics']['tasks_executed']
            total_errors += metrics['metrics']['errors']
        
        return {
            "fleet_size": len(self.agents),
            "total_revenue": total_revenue,
            "total_commission": total_commission,
            "founder_royalty": total_revenue * FOUNDER_ROYALTY_RATE,
            "total_tasks": total_tasks,
            "total_errors": total_errors,
            "agents": agent_metrics,
            "kill_switch_active": self.governance.check_kill_switch(),
            "timestamp": datetime.utcnow().isoformat(),
            "copyright": COPYRIGHT
        }
    
    def generate_daily_report(self) -> str:
        """Generate comprehensive daily report"""
        metrics = self.get_fleet_metrics()
        
        report = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    AI WORKFORCE DAILY OPERATIONS REPORT                       ║
║                        {COPYRIGHT}                          ║
╠══════════════════════════════════════════════════════════════════════════════╣
║ Report Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}                                       ║
╠══════════════════════════════════════════════════════════════════════════════╣

FLEET STATUS
────────────────────────────────────────────────────────────────────────────────
Active Agents: {metrics['fleet_size']}
Kill Switch: {'🔴 ACTIVE' if metrics['kill_switch_active'] else '🟢 INACTIVE'}

REVENUE SUMMARY
────────────────────────────────────────────────────────────────────────────────
Total Revenue Attributed:    ${metrics['total_revenue']:>12,.2f}
Founder Royalty (30%):       ${metrics['founder_royalty']:>12,.2f}
AI Commission Pool:          ${metrics['total_commission']:>12,.2f}

OPERATIONAL METRICS
────────────────────────────────────────────────────────────────────────────────
Total Tasks Executed:        {metrics['total_tasks']:>12,}
Total Errors:                {metrics['total_errors']:>12,}
Success Rate:                {(metrics['total_tasks']/(metrics['total_tasks']+metrics['total_errors'])*100) if metrics['total_tasks'] > 0 else 0:>11.1f}%

AGENT BREAKDOWN
────────────────────────────────────────────────────────────────────────────────
"""
        for agent_id, agent_data in metrics['agents'].items():
            m = agent_data['metrics']
            report += f"""
  {agent_data['agent_type'].upper()}
  ├─ Tasks: {m['tasks_executed']} | Blocked: {m['tasks_blocked']} | Errors: {m['errors']}
  ├─ Revenue: ${m['revenue_attributed']:,.2f}
  └─ Commission: ${m['commission_earned']:,.2f}
"""
        
        report += f"""
════════════════════════════════════════════════════════════════════════════════
GOVERNANCE STATUS: {'✅ COMPLIANT' if not metrics['kill_switch_active'] else '⚠️ HALTED'}
════════════════════════════════════════════════════════════════════════════════
"""
        return report


if __name__ == "__main__":
    print(f"QuranChain AI Workforce Base Framework")
    print(COPYRIGHT)
    print("This module provides the base classes for all AI agents.")
