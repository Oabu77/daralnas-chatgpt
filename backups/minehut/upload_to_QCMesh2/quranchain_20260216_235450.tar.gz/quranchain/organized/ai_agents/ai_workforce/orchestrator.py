"""
QuranChain™ AI Workforce Orchestrator
© QuranChain™ | Omar Mohammad Abunadi™

Central orchestrator that coordinates all AI agents,
enforces governance, and generates reports.
"""

import os
import sys
import json
import threading
import time
from datetime import datetime
from typing import Dict, Any, List
from flask import Flask, request, jsonify, render_template_string

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from shared.base_agent import (
    AgentOrchestrator, GovernanceChecker, 
    COPYRIGHT, FOUNDER_ROYALTY_RATE
)

# Import all agents
from marketing_ai.agent import MarketingAI
from sales_ai.agent import SalesAI
from onboarding_ai.agent import OnboardingAI
from optimization_ai.agent import OptimizationAI
from it_ops_ai.agent import ITOpsAI
from security_ai.agent import SecurityAI


# ═══════════════════════════════════════════════════════════════
# ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════

class AIWorkforceOrchestrator:
    """
    Central coordinator for the AI workforce.
    
    Manages agent lifecycle, coordinates operations,
    enforces governance, and generates reports.
    """
    
    def __init__(self):
        self.governance = GovernanceChecker()
        self.agents: Dict[str, Any] = {}
        self.running = False
        self.cycle_interval = 60  # seconds
        
        # Initialize all agents
        self._initialize_agents()
    
    def _initialize_agents(self):
        """Initialize all AI agents"""
        print("Initializing AI Workforce...")
        
        self.agents = {
            "marketing": MarketingAI("marketing_ai_001"),
            "sales": SalesAI("sales_ai_001"),
            "onboarding": OnboardingAI("onboarding_ai_001"),
            "optimization": OptimizationAI("optimization_ai_001"),
            "it_ops": ITOpsAI("it_ops_ai_001"),
            "security": SecurityAI("security_ai_001"),
        }
        
        for name, agent in self.agents.items():
            print(f"  ✓ {name.upper()} AI initialized: {agent.agent_id}")
    
    def get_fleet_status(self) -> Dict[str, Any]:
        """Get status of all agents"""
        status = {
            "timestamp": datetime.utcnow().isoformat(),
            "running": self.running,
            "kill_switch_active": self.governance.check_kill_switch(),
            "agents": {}
        }
        
        total_revenue = 0
        total_commission = 0
        total_tasks = 0
        
        for name, agent in self.agents.items():
            metrics = agent.get_metrics()
            status["agents"][name] = {
                "agent_id": metrics["agent_id"],
                "agent_type": metrics["agent_type"],
                "metrics": metrics["metrics"]
            }
            total_revenue += metrics["metrics"]["revenue_attributed"]
            total_commission += metrics["metrics"]["commission_earned"]
            total_tasks += metrics["metrics"]["tasks_executed"]
        
        status["totals"] = {
            "total_revenue": total_revenue,
            "founder_royalty": total_revenue * FOUNDER_ROYALTY_RATE,
            "total_commission": total_commission,
            "total_tasks": total_tasks
        }
        
        return status
    
    def run_cycle(self) -> Dict[str, Any]:
        """Run one operational cycle for all agents"""
        if self.governance.check_kill_switch():
            return {
                "status": "halted",
                "reason": "kill_switch_active",
                "timestamp": datetime.utcnow().isoformat()
            }
        
        results = {
            "cycle_start": datetime.utcnow().isoformat(),
            "agents": {}
        }
        
        for name, agent in self.agents.items():
            try:
                cycle_result = agent.run_cycle()
                results["agents"][name] = {
                    "status": "completed",
                    "result": cycle_result
                }
            except Exception as e:
                results["agents"][name] = {
                    "status": "error",
                    "error": str(e)
                }
        
        results["cycle_end"] = datetime.utcnow().isoformat()
        return results
    
    def generate_daily_report(self) -> str:
        """Generate comprehensive daily report"""
        status = self.get_fleet_status()
        
        report = f"""
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                        AI WORKFORCE DAILY OPERATIONS REPORT                           ║
║                        {COPYRIGHT}                             ║
╠══════════════════════════════════════════════════════════════════════════════════════╣
║ Report Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}                                              ║
╠══════════════════════════════════════════════════════════════════════════════════════╣

EXECUTIVE SUMMARY
────────────────────────────────────────────────────────────────────────────────────────
Fleet Status: {'🟢 RUNNING' if status['running'] else '🔴 STOPPED'}
Kill Switch: {'🔴 ACTIVE' if status['kill_switch_active'] else '🟢 INACTIVE'}
Active Agents: {len(status['agents'])}

REVENUE SUMMARY
────────────────────────────────────────────────────────────────────────────────────────
Total Revenue Attributed:      ${status['totals']['total_revenue']:>15,.2f}
Founder Royalty (30%):         ${status['totals']['founder_royalty']:>15,.2f}
AI Commission Pool:            ${status['totals']['total_commission']:>15,.2f}

OPERATIONAL METRICS
────────────────────────────────────────────────────────────────────────────────────────
Total Tasks Executed:          {status['totals']['total_tasks']:>15,}

AGENT BREAKDOWN
────────────────────────────────────────────────────────────────────────────────────────
"""
        for name, data in status['agents'].items():
            m = data['metrics']
            report += f"""
┌─ {name.upper()} AI ({data['agent_id']})
│  Tasks: {m['tasks_executed']} executed | {m['tasks_blocked']} blocked | {m['errors']} errors
│  Approvals: {m['approvals_requested']} requested | {m['approvals_granted']} granted
│  Revenue: ${m['revenue_attributed']:,.2f} | Commission: ${m['commission_earned']:,.2f}
└──────────────────────────────────────────────────────────────────
"""

        report += f"""
AI COMMISSION STRUCTURE
────────────────────────────────────────────────────────────────────────────────────────
Marketing AI:     5% of attributed revenue
Sales AI:        10% of attributed revenue
Onboarding AI:    3% of attributed revenue
Optimization AI:  2% of attributed revenue
IT Ops AI:        1% of attributed revenue
Security AI:      1% of attributed revenue

Note: Commissions are tracked for prioritization only. No actual payouts.

GOVERNANCE STATUS
────────────────────────────────────────────────────────────────────────────────────────
✓ All agents operating within governance rules
✓ Founder royalty rate enforced: {FOUNDER_ROYALTY_RATE * 100}%
✓ Kill-switch operational
✓ Approval gates functional
✓ Audit logging active

════════════════════════════════════════════════════════════════════════════════════════
                              END OF REPORT
════════════════════════════════════════════════════════════════════════════════════════
"""
        return report
    
    def start_continuous_operation(self):
        """Start continuous operation loop"""
        self.running = True
        
        def operation_loop():
            while self.running:
                if not self.governance.check_kill_switch():
                    self.run_cycle()
                time.sleep(self.cycle_interval)
        
        thread = threading.Thread(target=operation_loop, daemon=True)
        thread.start()
        print("Continuous operation started")
    
    def stop_continuous_operation(self):
        """Stop continuous operation"""
        self.running = False
        print("Continuous operation stopped")


# ═══════════════════════════════════════════════════════════════
# WEB DASHBOARD
# ═══════════════════════════════════════════════════════════════

DASHBOARD_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>AI Workforce Dashboard - QuranChain™</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', system-ui, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        header {
            text-align: center;
            padding: 30px;
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            margin-bottom: 30px;
        }
        h1 { color: #00d9ff; margin-bottom: 10px; }
        .status-bar {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }
        .status-item {
            background: rgba(255,255,255,0.1);
            padding: 15px 25px;
            border-radius: 10px;
            text-align: center;
        }
        .status-value { font-size: 1.5em; color: #00d9ff; font-weight: bold; }
        .status-label { opacity: 0.7; font-size: 0.9em; }
        .agents-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .agent-card {
            background: rgba(255,255,255,0.08);
            border-radius: 15px;
            padding: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .agent-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .agent-name { font-size: 1.1em; color: #00d9ff; }
        .agent-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: bold;
        }
        .status-active { background: #4caf50; }
        .status-warning { background: #ff9800; }
        .status-error { background: #f44336; }
        .metrics-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .metric-label { opacity: 0.7; }
        .metric-value { font-weight: bold; }
        .controls {
            text-align: center;
            padding: 20px;
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            cursor: pointer;
            margin: 5px;
            transition: transform 0.2s;
        }
        .btn:hover { transform: scale(1.05); }
        .btn-primary { background: linear-gradient(135deg, #00d9ff, #4caf50); color: #fff; }
        .btn-danger { background: #f44336; color: #fff; }
        .btn-secondary { background: rgba(255,255,255,0.2); color: #fff; }
        footer {
            text-align: center;
            padding: 20px;
            opacity: 0.7;
            font-size: 0.9em;
        }
        .revenue-box {
            background: linear-gradient(135deg, #00d9ff22, #4caf5022);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            margin-bottom: 30px;
        }
        .revenue-value { font-size: 2.5em; color: #4caf50; font-weight: bold; }
        .royalty-value { font-size: 1.5em; color: #ffd700; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🤖 AI Workforce Dashboard</h1>
            <p>QuranChain™ Autonomous Revenue Operations</p>
            <p style="color: #ffd700; margin-top: 10px;">© Omar Mohammad Abunadi™</p>
        </header>
        
        <div class="revenue-box">
            <div class="revenue-value" id="total-revenue">$0.00</div>
            <div>Total Revenue Attributed</div>
            <div class="royalty-value" id="founder-royalty" style="margin-top: 10px;">$0.00</div>
            <div>Founder Royalty (30%)</div>
        </div>
        
        <div class="status-bar">
            <div class="status-item">
                <div class="status-value" id="fleet-status">⏳</div>
                <div class="status-label">Fleet Status</div>
            </div>
            <div class="status-item">
                <div class="status-value" id="active-agents">0</div>
                <div class="status-label">Active Agents</div>
            </div>
            <div class="status-item">
                <div class="status-value" id="total-tasks">0</div>
                <div class="status-label">Tasks Executed</div>
            </div>
            <div class="status-item">
                <div class="status-value" id="kill-switch">🟢</div>
                <div class="status-label">Kill Switch</div>
            </div>
        </div>
        
        <div class="controls">
            <button class="btn btn-primary" onclick="runCycle()">▶️ Run Cycle</button>
            <button class="btn btn-secondary" onclick="refreshStatus()">🔄 Refresh</button>
            <button class="btn btn-danger" onclick="activateKillSwitch()">🛑 Kill Switch</button>
        </div>
        
        <div class="agents-grid" id="agents-grid">
            <!-- Agents populated by JS -->
        </div>
        
        <footer>
            © 2025 QuranChain™ | Omar Mohammad Abunadi™<br>
            All agents operate under human governance and approval
        </footer>
    </div>
    
    <script>
        async function fetchStatus() {
            const res = await fetch('/api/status');
            return await res.json();
        }
        
        async function refreshStatus() {
            const status = await fetchStatus();
            
            document.getElementById('fleet-status').textContent = status.running ? '🟢' : '🔴';
            document.getElementById('active-agents').textContent = Object.keys(status.agents).length;
            document.getElementById('total-tasks').textContent = status.totals.total_tasks.toLocaleString();
            document.getElementById('kill-switch').textContent = status.kill_switch_active ? '🔴' : '🟢';
            document.getElementById('total-revenue').textContent = '$' + status.totals.total_revenue.toLocaleString(undefined, {minimumFractionDigits: 2});
            document.getElementById('founder-royalty').textContent = '$' + status.totals.founder_royalty.toLocaleString(undefined, {minimumFractionDigits: 2});
            
            const grid = document.getElementById('agents-grid');
            grid.innerHTML = '';
            
            for (const [name, data] of Object.entries(status.agents)) {
                const m = data.metrics;
                const card = document.createElement('div');
                card.className = 'agent-card';
                card.innerHTML = `
                    <div class="agent-header">
                        <span class="agent-name">${name.toUpperCase()} AI</span>
                        <span class="agent-status status-active">ACTIVE</span>
                    </div>
                    <div class="metrics-row">
                        <span class="metric-label">Tasks Executed</span>
                        <span class="metric-value">${m.tasks_executed}</span>
                    </div>
                    <div class="metrics-row">
                        <span class="metric-label">Tasks Blocked</span>
                        <span class="metric-value">${m.tasks_blocked}</span>
                    </div>
                    <div class="metrics-row">
                        <span class="metric-label">Errors</span>
                        <span class="metric-value">${m.errors}</span>
                    </div>
                    <div class="metrics-row">
                        <span class="metric-label">Approvals Requested</span>
                        <span class="metric-value">${m.approvals_requested}</span>
                    </div>
                    <div class="metrics-row">
                        <span class="metric-label">Revenue Attributed</span>
                        <span class="metric-value">$${m.revenue_attributed.toFixed(2)}</span>
                    </div>
                    <div class="metrics-row">
                        <span class="metric-label">Commission Earned</span>
                        <span class="metric-value">$${m.commission_earned.toFixed(2)}</span>
                    </div>
                `;
                grid.appendChild(card);
            }
        }
        
        async function runCycle() {
            const res = await fetch('/api/cycle', { method: 'POST' });
            const result = await res.json();
            alert('Cycle completed');
            refreshStatus();
        }
        
        async function activateKillSwitch() {
            if (confirm('Are you sure you want to activate the KILL SWITCH? This will halt all AI operations.')) {
                const res = await fetch('/api/kill-switch', { method: 'POST' });
                const result = await res.json();
                alert('Kill switch activated');
                refreshStatus();
            }
        }
        
        // Initial load
        refreshStatus();
        
        // Auto-refresh every 30 seconds
        setInterval(refreshStatus, 30000);
    </script>
</body>
</html>
"""

def create_orchestrator_api(orchestrator: AIWorkforceOrchestrator) -> Flask:
    """Create Flask API for AI Workforce Orchestrator"""
    app = Flask(__name__)
    
    @app.route("/")
    def dashboard():
        return DASHBOARD_HTML
    
    @app.route("/health")
    def health():
        return jsonify({
            "status": "healthy",
            "component": "ai_workforce_orchestrator",
            "agents": len(orchestrator.agents),
            "copyright": COPYRIGHT
        })
    
    @app.route("/api/status")
    def get_status():
        return jsonify(orchestrator.get_fleet_status())
    
    @app.route("/api/cycle", methods=["POST"])
    def run_cycle():
        result = orchestrator.run_cycle()
        return jsonify(result)
    
    @app.route("/api/start", methods=["POST"])
    def start_operations():
        orchestrator.start_continuous_operation()
        return jsonify({"status": "started"})
    
    @app.route("/api/stop", methods=["POST"])
    def stop_operations():
        orchestrator.stop_continuous_operation()
        return jsonify({"status": "stopped"})
    
    @app.route("/api/kill-switch", methods=["POST"])
    def kill_switch():
        orchestrator.governance.activate_kill_switch(
            "human_operator",
            "Manual activation via dashboard"
        )
        orchestrator.stop_continuous_operation()
        return jsonify({"status": "kill_switch_activated"})
    
    @app.route("/api/report")
    def get_report():
        report = orchestrator.generate_daily_report()
        return report, 200, {"Content-Type": "text/plain"}
    
    @app.route("/api/agent/<agent_name>/metrics")
    def get_agent_metrics(agent_name):
        agent = orchestrator.agents.get(agent_name)
        if not agent:
            return jsonify({"error": "Agent not found"}), 404
        return jsonify(agent.get_metrics())
    
    @app.route("/api/agent/<agent_name>/report")
    def get_agent_report(agent_name):
        agent = orchestrator.agents.get(agent_name)
        if not agent:
            return jsonify({"error": "Agent not found"}), 404
        return agent.generate_report(), 200, {"Content-Type": "text/plain"}
    
    return app


# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 70)
    print("QuranChain™ AI Workforce Orchestrator")
    print(COPYRIGHT)
    print("=" * 70)
    
    orchestrator = AIWorkforceOrchestrator()
    app = create_orchestrator_api(orchestrator)
    
    print(f"\n✓ Orchestrator initialized with {len(orchestrator.agents)} agents")
    print(f"✓ Dashboard available at http://localhost:9091")
    print(f"\nStarting server...")
    
    app.run(host="0.0.0.0", port=9091, debug=False)
