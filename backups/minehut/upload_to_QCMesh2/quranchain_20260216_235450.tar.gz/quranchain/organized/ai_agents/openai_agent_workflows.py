#!/usr/bin/env python3
"""
QuranChain AI Agent Workflows — OpenAI Agents SDK
Built for Agent Builder + ChatKit deployment

Workflows:
1. QuranChain Main Agent — Blockchain ecosystem expert
2. DarCloud Support Agent — Customer support triage + resolution
3. Revenue Agent — Billing, payments, revenue optimization
4. Developer Agent — Code assistance, debugging, architecture

Founder: Omar Mohammad Abunadi™
FOUNDER_ROYALTY_RATE = 0.30 (IMMUTABLE)
"""

import os
import json
import asyncio
import logging
from typing import Any
from dataclasses import dataclass
from datetime import datetime

from agents import (
    Agent,
    Runner,
    function_tool,
    handoff,
    RunContextWrapper,
    GuardrailFunctionOutput,
    InputGuardrail,
    OutputGuardrail,
    trace,
)

# ═══════════════════════════════════════════════════════════
# Configuration
# ═══════════════════════════════════════════════════════════

# Prefer service key (QuranChain project) over project key
SERVICE_KEY = os.getenv("OPENAI_SERVICE_KEY") or os.getenv("OPENAI_API_KEY", "")
ADMIN_KEY = os.getenv("OPENAI_ADMIN_KEY", "")
FOUNDER = "Omar Mohammad Abunadi™"
FOUNDER_ROYALTY_RATE = 0.30  # IMMUTABLE

# Force the Agents SDK to use our preferred key
if SERVICE_KEY:
    os.environ["OPENAI_API_KEY"] = SERVICE_KEY

# Assistant IDs (created via admin API)
ASSISTANT_IDS = {
    "quranchain": os.getenv("OPENAI_ASSISTANT_QURANCHAIN", "asst_vB2RhsqH6ALCsTFrNSi3bLDu"),
    "darcloud": os.getenv("OPENAI_ASSISTANT_DARCLOUD", "asst_BN56P3aqtjo5FfGEvWyhnEcP"),
    "revenue": os.getenv("OPENAI_ASSISTANT_REVENUE", "asst_WAvHaB1BywdnnY4gRbgR6Etx"),
    "developer": os.getenv("OPENAI_ASSISTANT_DEVELOPER", "asst_wghkwDKlQexJrSiptEqgLSXy"),
}

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("quranchain-agents")


# ═══════════════════════════════════════════════════════════
# Shared Context
# ═══════════════════════════════════════════════════════════

@dataclass
class QuranChainContext:
    """Shared context across all agent workflows"""
    user_id: str = ""
    session_id: str = ""
    language: str = "en"  # en or ar
    is_enterprise: bool = False
    blockchain_height: int = 0
    mesh_peers: int = 0
    gas_toll_collected: float = 0.0
    founder_royalty_total: float = 0.0


# ═══════════════════════════════════════════════════════════
# TOOLS — Shared functions agents can call
# ═══════════════════════════════════════════════════════════

@function_tool
def get_blockchain_status() -> str:
    """Get current QuranChain blockchain status including height, peers, and gas toll."""
    import requests
    try:
        r = requests.get("http://localhost:3001/health", timeout=5)
        data = r.json()
        return json.dumps({
            "status": data.get("status"),
            "chain_height": data.get("blockchain", {}).get("height"),
            "mesh_peers": data.get("mesh", {}).get("peers"),
            "bridge_active": data.get("crossProject", {}).get("active"),
            "gas_toll_collected": data.get("gasTollHighway", {}).get("totalCollected"),
            "founder_royalty": data.get("gasTollHighway", {}).get("founderRoyalty"),
            "agent_fleet": data.get("liveAgentFleet", {}).get("totalAgents"),
            "validator": data.get("validator", {}).get("running"),
        })
    except Exception as e:
        return json.dumps({"error": str(e), "hint": "Blockchain server may be down on port 3001"})


@function_tool
def get_darcloud_services() -> str:
    """Get status of all DarCloud services (storage, CDN, hosting, domains, etc.)."""
    import requests
    services = {
        "web_hosting": 8080,
        "domain_manager": 8081,
        "cdn_distribution": 8083,
        "mesh_deployer": 8084,
        "cloud_storage": 8086,
        "blockchain_storage": 8087,
        "ssl_certificates": 8089,
        "personal_cloud": 8091,
    }
    results = {}
    for name, port in services.items():
        try:
            r = requests.get(f"http://localhost:{port}/health", timeout=2)
            results[name] = {"port": port, "status": r.status_code, "healthy": r.status_code == 200}
        except:
            results[name] = {"port": port, "status": "unreachable", "healthy": False}
    return json.dumps(results)


@function_tool
def get_revenue_status() -> str:
    """Get current revenue metrics across all streams."""
    import requests
    try:
        r = requests.get("http://localhost:3001/health", timeout=5)
        data = r.json()
        gas = data.get("gasTollHighway", {})
        billing = data.get("enterpriseBilling", {})
        invoice = billing.get("invoiceGenerator", {})
        return json.dumps({
            "gas_toll": {
                "total_collected": gas.get("totalCollected", 0),
                "total_tolls": gas.get("totalTolls", 0),
                "founder_royalty": gas.get("founderRoyalty", 0),
            },
            "enterprise_billing": {
                "invoices_generated": invoice.get("totalGenerated", 0),
                "total_amount": invoice.get("totalAmount", 0),
                "clients": billing.get("pricing", {}).get("clients", 0),
            },
            "live_invoice_engine": {
                "invoices_created": data.get("liveInvoiceEngine", {}).get("invoicesCreated", 0),
                "total_collected": data.get("liveInvoiceEngine", {}).get("totalCollected", 0),
            },
            "revenue_distribution": {
                "founder_30pct": FOUNDER_ROYALTY_RATE,
                "ai_validators_40pct": 0.40,
                "hardware_hosts_10pct": 0.10,
                "ecosystem_18pct": 0.18,
                "zakat_2pct": 0.02,
            },
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


@function_tool
def create_stripe_checkout(price_id: str, mode: str = "payment") -> str:
    """Create a Stripe checkout session for a customer. Returns the checkout URL.
    
    Args:
        price_id: The Stripe price ID (e.g., price_1T0WErAqs2ifkfkqWLpqkGKz)
        mode: Either 'payment' for one-time or 'subscription' for recurring
    """
    import requests
    try:
        r = requests.post(
            "http://localhost:3000/api/checkout/public-session",
            json={"priceId": price_id, "mode": mode},
            headers={"Content-Type": "application/json"},
            timeout=10,
        )
        data = r.json()
        if "url" in data:
            return json.dumps({"success": True, "checkout_url": data["url"]})
        return json.dumps({"success": False, "error": data})
    except Exception as e:
        return json.dumps({"success": False, "error": str(e)})


@function_tool
def get_data_ocean_status() -> str:
    """Get Data Ocean status — capacity, shards, quantum encryption state."""
    import requests
    try:
        r = requests.get("http://localhost:3001/api/ocean/status", timeout=5)
        data = r.json()
        ocean = data.get("ocean", {})
        cap = data.get("capacity", {})
        return json.dumps({
            "running": data.get("running"),
            "tide_phase": ocean.get("tidePhase"),
            "total_objects": ocean.get("totalObjects"),
            "total_shards": ocean.get("totalShards"),
            "total_size_gb": ocean.get("totalSizeGB"),
            "encrypted_gb": ocean.get("totalEncryptedGB"),
            "this_node_hot_gb": cap.get("thisNode", {}).get("hot", {}).get("total"),
            "this_node_warm_gb": cap.get("thisNode", {}).get("warm", {}).get("total"),
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


@function_tool
def get_stripe_products() -> str:
    """Get available Stripe product catalog for payment links."""
    import requests
    try:
        r = requests.get("http://localhost:3000/api/products", timeout=5)
        return json.dumps(r.json())
    except:
        # Fallback to known products
        return json.dumps({
            "products": [
                {"name": "QuranChain Gas Toll", "price_id": "price_1T0WErAqs2ifkfkqWLpqkGKz", "amount": 9.99},
                {"name": "DarCloud Storage 100GB", "price_id": "price_storage_100gb", "amount": 4.99},
                {"name": "DarCloud Pro Hosting", "price_id": "price_hosting_pro", "amount": 19.99},
                {"name": "Enterprise Node License", "price_id": "price_enterprise_node", "amount": 99.99},
            ]
        })


@function_tool
def check_service_port(port: int) -> str:
    """Check if a service is running on a specific port.
    
    Args:
        port: The port number to check
    """
    import requests
    try:
        r = requests.get(f"http://localhost:{port}/health", timeout=3)
        return json.dumps({"port": port, "status": r.status_code, "healthy": True, "response": r.text[:200]})
    except Exception as e:
        return json.dumps({"port": port, "healthy": False, "error": str(e)})


@function_tool
def get_fungi_mesh_status() -> str:
    """Get FungiMesh P2P network status — peers, devices, connections."""
    import requests
    try:
        r = requests.get("http://localhost:3001/health", timeout=5)
        data = r.json()
        mesh = data.get("mesh", {})
        expander = data.get("meshExpander", {}).get("stats", {})
        bridge = data.get("bridge", {})
        return json.dumps({
            "mesh_running": mesh.get("running"),
            "mesh_peers": mesh.get("peers"),
            "devices_found": expander.get("totalDevices"),
            "mesh_connected": expander.get("meshConnected"),
            "compute_pool": bridge.get("computePool"),
            "edge_nodes": bridge.get("edgeNodes"),
            "enrolled_devices": bridge.get("enrolledDevices"),
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


# ═══════════════════════════════════════════════════════════
# GUARDRAILS — Safety checks
# ═══════════════════════════════════════════════════════════

async def founder_royalty_guardrail(
    ctx: RunContextWrapper[QuranChainContext], agent: Agent, output: str
) -> GuardrailFunctionOutput:
    """Ensure no output suggests modifying the 30% founder royalty."""
    lower = output.lower()
    flagged = any(phrase in lower for phrase in [
        "reduce founder", "lower royalty", "change 30%", "modify royalty",
        "remove founder", "decrease royalty", "0% founder",
    ])
    return GuardrailFunctionOutput(
        output_info={"flagged": flagged},
        tripwire_triggered=flagged,
    )


# ═══════════════════════════════════════════════════════════
# AGENT DEFINITIONS — Multi-step workflow nodes
# ═══════════════════════════════════════════════════════════

# --- Specialized Sub-Agents ---

blockchain_expert = Agent[QuranChainContext](
    name="Blockchain Expert",
    model="gpt-4o",
    instructions="""You are a blockchain expert specializing in QuranChain.
You know about the Nomad Mainnet consensus, 47+ monitored chains, gas toll collection,
block mining, P2P networking, and cross-chain bridges.
Use the blockchain status tool to get live data.
Always mention the 30% founder royalty is immutable.""",
    tools=[get_blockchain_status, get_fungi_mesh_status],
)

darcloud_specialist = Agent[QuranChainContext](
    name="DarCloud Specialist",
    model="gpt-4o-mini",
    instructions="""You are a DarCloud infrastructure specialist.
You handle questions about cloud storage, CDN, web hosting, domain management,
SSL certificates, mesh deployment, and personal cloud services.
Use tools to check service health and provide real status.
All services run on ports 8080-8091.""",
    tools=[get_darcloud_services, check_service_port, get_data_ocean_status],
)

billing_specialist = Agent[QuranChainContext](
    name="Billing Specialist",
    model="gpt-4o-mini",
    instructions="""You are the QuranChain billing specialist.
You handle payment processing, Stripe checkout creation, invoice inquiries,
and subscription management. You can create live checkout sessions.
Revenue distribution: 30% Founder (IMMUTABLE), 40% AI Validators, 
10% Hardware Hosts, 18% Ecosystem, 2% Zakat.""",
    tools=[get_revenue_status, create_stripe_checkout, get_stripe_products],
)

code_specialist = Agent[QuranChainContext](
    name="Code Specialist",
    model="gpt-4o",
    instructions="""You are a senior developer for the QuranChain ecosystem.
    
Architecture:
- QuranChain (Python): organized/services/, organized/revenue/, organized/ai_agents/
- QuranChain-OS (Node.js): src/blockchain-server.js, src/services/, src/routes/
- Revenue engines use singleton pattern — never instantiate directly
- FastAPI/uvicorn for Python, Express for Node.js
- 30% FOUNDER_ROYALTY_RATE in ALL payment flows — NEVER modify

You can check service status to debug issues.""",
    tools=[get_blockchain_status, get_darcloud_services, check_service_port],
)


# --- Main Triage/Router Agent ---

quranchain_main_agent = Agent[QuranChainContext](
    name="QuranChain AI™",
    model="gpt-4o",
    instructions=f"""You are QuranChain AI™, the official AI assistant for the QuranChain blockchain ecosystem.
Founder: {FOUNDER}

## Your Role
You are the front-door triage agent. Analyze the user's question and either:
1. Answer directly if it's a general question about QuranChain
2. Hand off to a specialist agent for domain-specific questions

## Handoff Rules
- Blockchain, mining, consensus, chains → Blockchain Expert
- Cloud storage, hosting, CDN, domains, SSL → DarCloud Specialist  
- Payments, billing, invoices, Stripe, revenue → Billing Specialist
- Code, debugging, architecture, API → Code Specialist

## Key Facts
- 150+ blocks mined on Nomad Mainnet
- 47+ blockchain networks monitored
- 550 AI agents in workforce
- 146+ FungiMesh peers
- DarCloud: 8 production services (ports 8080-8091)
- Revenue: 30% Founder (IMMUTABLE), 40% AI Validators, 10% Hardware, 18% Ecosystem, 2% Zakat
- Stripe LIVE integration with 200+ products

## Style
- Professional, knowledgeable, helpful
- Support English and Arabic
- Always reinforce the 30% founder royalty is immutable
- Reference Islamic finance principles when relevant""",
    tools=[get_blockchain_status, get_darcloud_services, get_revenue_status],
    handoffs=[
        handoff(blockchain_expert, tool_name_override="transfer_to_blockchain_expert",
                tool_description_override="Transfer to blockchain expert for chain, mining, consensus questions"),
        handoff(darcloud_specialist, tool_name_override="transfer_to_darcloud_specialist",
                tool_description_override="Transfer to DarCloud specialist for cloud, hosting, CDN, domain questions"),
        handoff(billing_specialist, tool_name_override="transfer_to_billing_specialist",
                tool_description_override="Transfer to billing specialist for payments, invoices, Stripe questions"),
        handoff(code_specialist, tool_name_override="transfer_to_code_specialist",
                tool_description_override="Transfer to code specialist for development, debugging, API questions"),
    ],
    output_guardrails=[
        OutputGuardrail(guardrail_function=founder_royalty_guardrail),
    ],
)


# ═══════════════════════════════════════════════════════════
# WORKFLOW RUNNER
# ═══════════════════════════════════════════════════════════

async def run_workflow(user_message: str, context: QuranChainContext = None) -> str:
    """Run the QuranChain agent workflow with a user message."""
    ctx = context or QuranChainContext()
    
    with trace("QuranChain Agent Workflow"):
        result = await Runner.run(
            starting_agent=quranchain_main_agent,
            input=user_message,
            context=ctx,
        )
    
    return result.final_output


async def run_conversation(messages: list, context: QuranChainContext = None) -> str:
    """Run a multi-turn conversation through the workflow."""
    ctx = context or QuranChainContext()
    
    with trace("QuranChain Conversation"):
        result = await Runner.run(
            starting_agent=quranchain_main_agent,
            input=messages,
            context=ctx,
        )
    
    return result.final_output


# ═══════════════════════════════════════════════════════════
# HTTP SERVER — Expose workflow as API
# ═══════════════════════════════════════════════════════════

def create_api_server():
    """Create FastAPI server to expose agent workflows."""
    from fastapi import FastAPI, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    
    app = FastAPI(
        title="QuranChain AI Agent Workflows",
        version="1.0.0",
        description="Multi-agent workflow system powered by OpenAI Agents SDK",
    )
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    @app.get("/health")
    async def health():
        return {
            "status": "OK",
            "service": "QuranChain AI Agent Workflows",
            "founder": FOUNDER,
            "agents": list(ASSISTANT_IDS.keys()),
            "timestamp": datetime.utcnow().isoformat(),
        }
    
    @app.post("/api/agents/chat")
    async def agent_chat(request: Request):
        """Send a message to the QuranChain agent workflow."""
        body = await request.json()
        message = body.get("message", "")
        user_id = body.get("user_id", "anonymous")
        language = body.get("language", "en")
        
        if not message:
            return JSONResponse({"error": "message required"}, status_code=400)
        
        ctx = QuranChainContext(user_id=user_id, language=language)
        
        try:
            response = await run_workflow(message, ctx)
            return {
                "success": True,
                "response": response,
                "agent": "QuranChain AI™",
                "context": {
                    "user_id": user_id,
                    "language": language,
                },
            }
        except Exception as e:
            logger.error(f"Agent workflow error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)
    
    @app.post("/api/agents/conversation")
    async def agent_conversation(request: Request):
        """Multi-turn conversation with the agent workflow."""
        body = await request.json()
        messages = body.get("messages", [])
        user_id = body.get("user_id", "anonymous")
        
        if not messages:
            return JSONResponse({"error": "messages array required"}, status_code=400)
        
        # Convert to OpenAI message format
        formatted = []
        for msg in messages:
            formatted.append({
                "role": msg.get("role", "user"),
                "content": msg.get("content", ""),
            })
        
        ctx = QuranChainContext(user_id=user_id)
        
        try:
            response = await run_conversation(formatted, ctx)
            return {"success": True, "response": response}
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)
    
    @app.get("/api/agents/list")
    async def list_agents():
        """List all available agents and their capabilities."""
        return {
            "agents": [
                {
                    "name": "QuranChain AI™",
                    "model": "gpt-4o",
                    "role": "Main triage and routing agent",
                    "assistant_id": ASSISTANT_IDS["quranchain"],
                    "capabilities": ["blockchain", "ecosystem", "routing", "general"],
                },
                {
                    "name": "Blockchain Expert",
                    "model": "gpt-4o",
                    "role": "Blockchain, mining, consensus specialist",
                    "capabilities": ["blockchain", "mining", "p2p", "gas_toll"],
                },
                {
                    "name": "DarCloud Specialist",
                    "model": "gpt-4o-mini",
                    "role": "Cloud infrastructure support",
                    "assistant_id": ASSISTANT_IDS["darcloud"],
                    "capabilities": ["storage", "hosting", "cdn", "domains", "ssl"],
                },
                {
                    "name": "Billing Specialist",
                    "model": "gpt-4o-mini",
                    "role": "Revenue and payment management",
                    "assistant_id": ASSISTANT_IDS["revenue"],
                    "capabilities": ["stripe", "invoices", "subscriptions", "revenue"],
                },
                {
                    "name": "Code Specialist",
                    "model": "gpt-4o",
                    "role": "Developer assistance and debugging",
                    "assistant_id": ASSISTANT_IDS["developer"],
                    "capabilities": ["python", "nodejs", "architecture", "debugging"],
                },
            ],
            "workflow": {
                "type": "triage_with_handoffs",
                "entry_point": "QuranChain AI™",
                "model": "gpt-4o",
                "guardrails": ["founder_royalty_protection"],
            },
        }
    
    @app.get("/api/agents/status")
    async def agent_status():
        """Get live status of all backend services the agents connect to."""
        import requests
        
        checks = {}
        ports = {"blockchain": 3001, "revenue": 3000, "webhook": 9100}
        for name, port in ports.items():
            try:
                r = requests.get(f"http://localhost:{port}/health", timeout=2)
                checks[name] = {"port": port, "status": "UP", "code": r.status_code}
            except:
                checks[name] = {"port": port, "status": "DOWN"}
        
        darcloud_ports = {
            "web_hosting": 8080, "domain_manager": 8081, "cdn": 8083,
            "mesh_deployer": 8084, "cloud_storage": 8086, "ssl": 8089,
        }
        for name, port in darcloud_ports.items():
            try:
                r = requests.get(f"http://localhost:{port}/health", timeout=2)
                checks[f"darcloud_{name}"] = {"port": port, "status": "UP"}
            except:
                checks[f"darcloud_{name}"] = {"port": port, "status": "DOWN"}
        
        return {"services": checks, "timestamp": datetime.utcnow().isoformat()}

    @app.post("/api/agents/stream")
    async def agent_stream(request: Request):
        """Stream agent response using Server-Sent Events for ChatKit integration."""
        from fastapi.responses import StreamingResponse
        from agents import Runner

        body = await request.json()
        message = body.get("message", "")
        user_id = body.get("user_id", "anonymous")

        if not message:
            return JSONResponse({"error": "message required"}, status_code=400)

        ctx = QuranChainContext(user_id=user_id)

        async def event_generator():
            try:
                result = Runner.run_streamed(
                    starting_agent=quranchain_main_agent,
                    input=message,
                    context=ctx,
                )
                async for event in result.stream_events():
                    if hasattr(event, "data"):
                        chunk = json.dumps({"type": "text", "content": str(event.data)})
                        yield f"data: {chunk}\n\n"
                final = await result.final_output
                done = json.dumps({"type": "done", "agent": "QuranChain AI™", "full_response": str(final)})
                yield f"data: {done}\n\n"
            except Exception as e:
                error = json.dumps({"type": "error", "error": str(e)})
                yield f"data: {error}\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    @app.get("/chatkit/embed.js")
    async def chatkit_embed_js():
        """Serve the ChatKit embeddable widget JavaScript."""
        from fastapi.responses import Response
        js = """
(function() {
    const STYLE = `
        #qc-chat-widget { position:fixed; bottom:20px; right:20px; z-index:99999; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }
        #qc-chat-toggle { width:60px; height:60px; border-radius:50%; background:linear-gradient(135deg,#059669,#4ade80); border:none; cursor:pointer; box-shadow:0 4px 20px rgba(74,222,128,0.4); display:flex; align-items:center; justify-content:center; font-size:28px; transition:transform 0.2s; }
        #qc-chat-toggle:hover { transform:scale(1.1); }
        #qc-chat-window { display:none; width:400px; height:600px; background:#0a0a1a; border-radius:16px; border:1px solid rgba(74,222,128,0.3); box-shadow:0 10px 40px rgba(0,0,0,0.5); flex-direction:column; overflow:hidden; position:absolute; bottom:70px; right:0; }
        #qc-chat-window.open { display:flex; }
        #qc-chat-header { padding:14px 18px; background:rgba(10,10,26,0.95); border-bottom:1px solid rgba(74,222,128,0.2); display:flex; align-items:center; gap:10px; }
        #qc-chat-header h3 { color:#4ade80; font-size:0.95rem; flex:1; margin:0; }
        #qc-chat-close { background:none; border:none; color:#888; cursor:pointer; font-size:18px; }
        #qc-chat-messages { flex:1; overflow-y:auto; padding:16px; display:flex; flex-direction:column; gap:12px; }
        .qc-msg { max-width:85%; padding:10px 14px; border-radius:12px; font-size:0.88rem; line-height:1.5; color:#e0e0e0; word-wrap:break-word; }
        .qc-msg.user { align-self:flex-end; background:linear-gradient(135deg,#1e40af,#7c3aed); color:white; border-bottom-right-radius:4px; }
        .qc-msg.bot { align-self:flex-start; background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.1); border-bottom-left-radius:4px; }
        .qc-msg.bot .qc-agent { font-size:0.7rem; color:#4ade80; margin-bottom:4px; }
        #qc-chat-input-area { padding:12px; background:rgba(10,10,26,0.95); border-top:1px solid rgba(255,255,255,0.1); display:flex; gap:8px; }
        #qc-chat-input { flex:1; background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.15); border-radius:10px; padding:10px 14px; color:white; font-size:0.88rem; outline:none; }
        #qc-chat-input:focus { border-color:#4ade80; }
        #qc-chat-send { background:linear-gradient(135deg,#059669,#4ade80); color:#0a0a1a; border:none; border-radius:10px; padding:10px 16px; font-weight:700; cursor:pointer; font-size:0.88rem; }
        #qc-chat-send:disabled { opacity:0.4; }
    `;

    const API = window.QURANCHAIN_API || 'http://localhost:9200';
    let open = false;

    function init() {
        const style = document.createElement('style');
        style.textContent = STYLE;
        document.head.appendChild(style);

        const widget = document.createElement('div');
        widget.id = 'qc-chat-widget';
        widget.innerHTML = `
            <div id="qc-chat-window">
                <div id="qc-chat-header">
                    <span style="font-size:20px">\\U0001f54c</span>
                    <h3>QuranChain AI\\u2122</h3>
                    <button id="qc-chat-close">\\u2715</button>
                </div>
                <div id="qc-chat-messages"></div>
                <div id="qc-chat-input-area">
                    <input id="qc-chat-input" placeholder="Ask QuranChain AI..." />
                    <button id="qc-chat-send">Send</button>
                </div>
            </div>
            <button id="qc-chat-toggle">\\U0001f54c</button>
        `;
        document.body.appendChild(widget);

        document.getElementById('qc-chat-toggle').onclick = toggle;
        document.getElementById('qc-chat-close').onclick = toggle;
        document.getElementById('qc-chat-send').onclick = send;
        document.getElementById('qc-chat-input').onkeydown = e => { if(e.key==='Enter') send(); };

        addMsg('bot', 'Welcome to QuranChain AI\\u2122! How can I help you today?', 'QuranChain AI\\u2122');
    }

    function toggle() {
        open = !open;
        document.getElementById('qc-chat-window').classList.toggle('open', open);
    }

    function addMsg(role, text, agent) {
        const msgs = document.getElementById('qc-chat-messages');
        const div = document.createElement('div');
        div.className = 'qc-msg ' + (role === 'user' ? 'user' : 'bot');
        if (role !== 'user' && agent) {
            div.innerHTML = '<div class="qc-agent">\\U0001f916 ' + agent + '</div>' + text;
        } else {
            div.textContent = text;
        }
        msgs.appendChild(div);
        msgs.scrollTop = msgs.scrollHeight;
    }

    async function send() {
        const input = document.getElementById('qc-chat-input');
        const btn = document.getElementById('qc-chat-send');
        const msg = input.value.trim();
        if (!msg) return;
        input.value = '';
        btn.disabled = true;
        addMsg('user', msg);
        try {
            const res = await fetch(API + '/api/agents/chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({message: msg, user_id: 'chatkit_user'})
            });
            const data = await res.json();
            if (data.success) {
                addMsg('bot', data.response, data.agent || 'QuranChain AI\\u2122');
            } else {
                addMsg('bot', 'Error: ' + (data.error || 'Unknown error'));
            }
        } catch(e) {
            addMsg('bot', 'Connection error. Is the agent server running?');
        }
        btn.disabled = false;
        input.focus();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
"""
        return Response(content=js, media_type="application/javascript")

    return app


# ═══════════════════════════════════════════════════════════
# MAIN — Run as server or CLI
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "serve":
        # Run as HTTP server
        import uvicorn
        port = int(sys.argv[2]) if len(sys.argv) > 2 else 9200
        app = create_api_server()
        logger.info(f"🤖 QuranChain Agent Workflows starting on port {port}")
        uvicorn.run(app, host="0.0.0.0", port=port)
    
    elif len(sys.argv) > 1 and sys.argv[1] == "chat":
        # Interactive CLI chat
        print(f"\n🤖 QuranChain AI™ Agent Workflow")
        print(f"   Founder: {FOUNDER}")
        print(f"   Agents: Main → Blockchain | DarCloud | Billing | Code")
        print(f"   Type 'quit' to exit\n")
        
        async def cli_loop():
            while True:
                msg = input("You: ").strip()
                if msg.lower() in ("quit", "exit", "q"):
                    break
                response = await run_workflow(msg)
                print(f"\nQuranChain AI: {response}\n")
        
        asyncio.run(cli_loop())
    
    else:
        # Quick test
        async def test():
            print("Testing QuranChain Agent Workflow...")
            response = await run_workflow("What is QuranChain and how does the revenue system work?")
            print(f"Response: {response}")
        
        asyncio.run(test())
