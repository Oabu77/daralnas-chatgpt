#!/usr/bin/env python3
"""
DarPharma
Halal pharmaceutical supply and verification
© QuranChain™ | Dar Al-Nas™ | Omar Mohammad Abunadi™ 2026

FEATURES:
  - Halal medication verification
  - Online pharmacy
  - Prescription delivery
  - Drug interaction checking
  - Medication adherence
  - Blockchain tracking

REVENUE MODEL:
  - 30% Founder Royalty (IMMUTABLE)
  - 40% AI Validators
  - 18% Ecosystem Fund
  - 10% Hardware Hosts
  - 2% Zakat Distribution
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, jsonify, request, render_template_string
import json
import time
import logging
import sqlite3
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime
from pathlib import Path
import hashlib

# Configure logging
log_dir = Path("/home/omar/Desktop/QuranChain/monitoring_logs")
log_dir.mkdir(parents=True, exist_ok=True)

setup_blockchain_logging()
logger = logging.getLogger(__name__)

app = Flask(__name__)
PORT = 8501

# Constants
FOUNDER_ROYALTY_RATE = 0.30
AI_VALIDATOR_RATE = 0.40
ECOSYSTEM_RATE = 0.18
HARDWARE_HOST_RATE = 0.10
ZAKAT_RATE = 0.02

class DarPharmaEngine:
    """Main Healthcare Service Engine"""
    
    def __init__(self):
        self.db_path = Path("/home/omar/Desktop/QuranChain/organized/databases/darpharma.db")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.total_revenue = 0.0
        self.transactions = []
        self.active_users = 0
        self.services_provided = 0
        
        self.setup_database()
        logger.info(f"✅ DarPharma initialized on port {PORT}")
    
    def setup_database(self):
        """Initialize database schema"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id TEXT UNIQUE,
                amount REAL,
                currency TEXT,
                service_type TEXT,
                user_id TEXT,
                timestamp TEXT,
                founder_royalty REAL,
                status TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT UNIQUE,
                name TEXT,
                email TEXT,
                joined_date TEXT,
                total_spent REAL,
                status TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS revenue_distribution (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id TEXT,
                founder_share REAL,
                ai_validator_share REAL,
                ecosystem_share REAL,
                hardware_host_share REAL,
                zakat_share REAL,
                timestamp TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def process_transaction(self, amount, service_type, user_id):
        """Process transaction with revenue distribution"""
        transaction_id = f"TXN-{int(time.time())}-{hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]}"
        
        # Calculate distribution
        founder_share = amount * FOUNDER_ROYALTY_RATE
        ai_validator_share = amount * AI_VALIDATOR_RATE
        ecosystem_share = amount * ECOSYSTEM_RATE
        hardware_host_share = amount * HARDWARE_HOST_RATE
        zakat_share = amount * ZAKAT_RATE
        
        # Store transaction
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO transactions 
            (transaction_id, amount, currency, service_type, user_id, timestamp, founder_royalty, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (transaction_id, amount, 'USD', service_type, user_id, 
              datetime.now().isoformat(), founder_share, 'completed'))
        
        cursor.execute("""
            INSERT INTO revenue_distribution
            (transaction_id, founder_share, ai_validator_share, ecosystem_share, hardware_host_share, zakat_share, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (transaction_id, founder_share, ai_validator_share, ecosystem_share, 
              hardware_host_share, zakat_share, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        self.total_revenue += amount
        self.transactions.append({
            'id': transaction_id,
            'amount': amount,
            'founder_share': founder_share,
            'timestamp': datetime.now().isoformat()
        })
        
        logger.info(f"💰 Transaction {transaction_id}: ${amount:.2f} (Founder: ${founder_share:.2f})")
        
        return {
            'transaction_id': transaction_id,
            'amount': amount,
            'distribution': {
                'founder': founder_share,
                'ai_validators': ai_validator_share,
                'ecosystem': ecosystem_share,
                'hardware_hosts': hardware_host_share,
                'zakat': zakat_share
            },
            'status': 'completed'
        }
    
    def get_stats(self):
        """Get service statistics"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM transactions")
        total_transactions = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(amount) FROM transactions WHERE status='completed'")
        result = cursor.fetchone()
        total_revenue = result[0] if result[0] else 0.0
        
        cursor.execute("SELECT COUNT(DISTINCT user_id) FROM transactions")
        unique_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(founder_share) FROM revenue_distribution")
        result = cursor.fetchone()
        total_founder_royalty = result[0] if result[0] else 0.0
        
        conn.close()
        
        return {
            'total_transactions': total_transactions,
            'total_revenue': total_revenue,
            'unique_users': unique_users,
            'founder_royalty_collected': total_founder_royalty,
            'active': True,
            'uptime_hours': int((time.time()) / 3600)
        }

# Create service instance
service = DarPharmaEngine()

@app.route('/')
def index():
    """Dashboard"""
    stats = service.get_stats()
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>DarPharma</title>
        <style>
            body { font-family: Arial; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                   color: white; margin: 0; padding: 20px; }
            .container { max-width: 1200px; margin: 0 auto; }
            .header { text-align: center; padding: 40px 0; }
            .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                     gap: 20px; margin: 30px 0; }
            .stat-card { background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); 
                         padding: 25px; border-radius: 15px; border: 1px solid rgba(255,255,255,0.2); }
            .stat-value { font-size: 2.5em; font-weight: bold; margin: 10px 0; }
            .stat-label { opacity: 0.9; text-transform: uppercase; font-size: 0.9em; }
            .features { background: rgba(255,255,255,0.1); padding: 30px; border-radius: 15px; margin: 20px 0; }
            .feature-list { list-style: none; padding: 0; }
            .feature-list li { padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.1); }
            .royalty-badge { background: gold; color: #333; padding: 10px 20px; border-radius: 25px;
                             display: inline-block; font-weight: bold; margin: 20px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>💊 DarPharma</h1>
                <p>Halal pharmaceutical supply and verification</p>
                <div class="royalty-badge">👑 30% Founder Royalty Active</div>
            </div>
            
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-label">Total Revenue</div>
                    <div class="stat-value">${stats['total_revenue']:.2f}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Transactions</div>
                    <div class="stat-value">{stats['total_transactions']}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Unique Users</div>
                    <div class="stat-value">{stats['unique_users']}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Founder Royalty</div>
                    <div class="stat-value">${stats['founder_royalty_collected']:.2f}</div>
                </div>
            </div>
            
            <div class="features">
                <h2>Key Features</h2>
                <ul class="feature-list">
                    <li>Halal medication verification</li>
                    <li>Online pharmacy</li>
                    <li>Prescription delivery</li>
                    <li>Drug interaction checking</li>
                    <li>Medication adherence</li>
                    <li>Blockchain tracking</li>
                </ul>
            </div>
        </div>
    </body>
    </html>
    """
    return html

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'online',
        'service': 'DarPharma',
        'port': PORT,
        'timestamp': datetime.now().isoformat()
    })

@app.route('/stats')
def stats():
    """Statistics endpoint"""
    return jsonify(service.get_stats())

@app.route('/process', methods=['POST'])
def process():
    """Process transaction"""
    data = request.get_json()
    result = service.process_transaction(
        amount=data.get('amount', 0),
        service_type=data.get('service_type', 'healthcare'),
        user_id=data.get('user_id', 'anonymous')
    )
    return jsonify(result)

if __name__ == '__main__':
    logger.info(f"🚀 Starting DarPharma on port {PORT}")
    logger.info(f"👑 Founder royalty rate: {FOUNDER_ROYALTY_RATE*100}%")
    app.run(host='0.0.0.0', port=PORT, debug=False)
