#!/usr/bin/env python3
"""
🌐 DARCLOUD DOMAIN MANAGER
Islamic domain registration and management (.quran, .islam, .halal, .dar, .mesh)
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import json
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
import uvicorn

# Add project root to path
sys.path.insert(0, "/home/omar/Desktop/QuranChain")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] 🌐 DOMAIN - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="DarCloud Domain Manager", version="1.0.0")

# Domain storage
DOMAINS_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_domains")
DOMAINS_DIR.mkdir(exist_ok=True)

class DomainManager:
    """Manages Islamic domain registration and DNS"""

    ISLAMIC_TLDS = [".quran", ".islam", ".halal", ".dar", ".mesh", ".ummat", ".iman", ".taqwa"]

    def __init__(self):
        self.registered_domains = {}
        self.dns_records = {}
        self.load_domain_registry()
        logger.info("🌐 Domain Manager initialized")

    def load_domain_registry(self):
        """Load registered domains from registry"""
        registry_file = DOMAINS_DIR / "domains.json"
        if registry_file.exists():
            try:
                with open(registry_file, 'r') as f:
                    data = json.load(f)
                    self.registered_domains = data.get('domains', {})
                    self.dns_records = data.get('dns_records', {})
                logger.info(f"📋 Loaded {len(self.registered_domains)} domains from registry")
            except Exception as e:
                logger.error(f"Failed to load domain registry: {e}")

    def save_domain_registry(self):
        """Save registered domains to registry"""
        registry_file = DOMAINS_DIR / "domains.json"
        try:
            data = {
                'domains': self.registered_domains,
                'dns_records': self.dns_records,
                'last_updated': datetime.utcnow().isoformat() + "Z"
            }
            with open(registry_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info("💾 Domain registry saved")
        except Exception as e:
            logger.error(f"Failed to save domain registry: {e}")

    def register_domain(self, domain: str, owner: str, registration_years: int = 1) -> Dict:
        """Register Islamic domain"""

        # Validate domain
        if not self.is_valid_islamic_domain(domain):
            raise ValueError(f"Invalid Islamic domain: {domain}")

        # Check if already registered
        if domain in self.registered_domains:
            raise ValueError(f"Domain {domain} is already registered")

        # Calculate expiry
        registered_at = datetime.utcnow()
        expiry_date = registered_at + timedelta(days=365 * registration_years)

        # Register domain
        domain_info = {
            "domain": domain,
            "owner": owner,
            "registered_at": registered_at.isoformat() + "Z",
            "expiry_date": expiry_date.isoformat() + "Z",
            "registration_years": registration_years,
            "auto_renew": True,
            "status": "active",
            "nameservers": self.get_mesh_nameservers(),
            "dnssec_enabled": True,
            "whois_privacy": True
        }

        self.registered_domains[domain] = domain_info

        # Create default DNS records
        self.create_default_dns_records(domain)

        self.save_domain_registry()

        logger.info(f"✅ Islamic domain {domain} registered for {owner}")
        return domain_info

    def is_valid_islamic_domain(self, domain: str) -> bool:
        """Check if domain is valid Islamic TLD"""
        for tld in self.ISLAMIC_TLDS:
            if domain.endswith(tld):
                return True
        return False

    def get_mesh_nameservers(self) -> List[str]:
        """Get mesh network nameservers"""
        return [
            "ns1.mesh.quran",
            "ns2.fungi.quran",
            "ns3.meshtalk.quran",
            "ns4.quranchain.islam"
        ]

    def create_default_dns_records(self, domain: str):
        """Create default DNS records for domain"""
        self.dns_records[domain] = {
            "A": [
                {"name": "@", "value": "127.0.0.1", "ttl": 300},  # Points to local DarCloud
                {"name": "www", "value": "127.0.0.1", "ttl": 300}
            ],
            "AAAA": [
                {"name": "@", "value": "::1", "ttl": 300},
                {"name": "www", "value": "::1", "ttl": 300}
            ],
            "CNAME": [],
            "MX": [
                {"name": "@", "value": "mail.quranchain.islam", "priority": 10, "ttl": 3600}
            ],
            "TXT": [
                {"name": "@", "value": f"\"v=spf1 include:quranchain.islam ~all\"", "ttl": 3600},
                {"name": "_dmarc", "value": f"\"v=DMARC1; p=quarantine; rua=mailto:dmarc@{domain}\"", "ttl": 3600}
            ]
        }

        logger.info(f"📋 Created default DNS records for {domain}")

    def update_dns_record(self, domain: str, record_type: str, name: str, value: str, ttl: int = 300):
        """Update DNS record"""
        if domain not in self.dns_records:
            raise ValueError(f"Domain {domain} not found")

        if record_type not in self.dns_records[domain]:
            self.dns_records[domain][record_type] = []

        # Remove existing record with same name
        self.dns_records[domain][record_type] = [
            record for record in self.dns_records[domain][record_type]
            if record.get('name') != name
        ]

        # Add new record
        record = {"name": name, "value": value, "ttl": ttl}
        if record_type == "MX":
            record["priority"] = 10

        self.dns_records[domain][record_type].append(record)
        self.save_domain_registry()

        logger.info(f"📋 Updated {record_type} record for {domain}: {name} -> {value}")

    def get_domain_info(self, domain: str) -> Optional[Dict]:
        """Get domain information"""
        return self.registered_domains.get(domain)

    def get_dns_records(self, domain: str) -> Optional[Dict]:
        """Get DNS records for domain"""
        return self.dns_records.get(domain)

    def list_domains(self) -> List[Dict]:
        """List all registered domains"""
        return list(self.registered_domains.values())

    def renew_domain(self, domain: str, years: int = 1) -> bool:
        """Renew domain registration"""
        if domain not in self.registered_domains:
            return False

        current_expiry = datetime.fromisoformat(self.registered_domains[domain]['expiry_date'][:-1])
        new_expiry = current_expiry + timedelta(days=365 * years)

        self.registered_domains[domain]['expiry_date'] = new_expiry.isoformat() + "Z"
        self.registered_domains[domain]['registration_years'] += years

        self.save_domain_registry()

        logger.info(f"🔄 Domain {domain} renewed for {years} years")
        return True

    def delete_domain(self, domain: str) -> bool:
        """Delete domain registration"""
        if domain in self.registered_domains:
            del self.registered_domains[domain]
            if domain in self.dns_records:
                del self.dns_records[domain]
            self.save_domain_registry()

            logger.info(f"🗑️ Domain {domain} deleted")
            return True

        return False

# Global domain manager
domain_manager = DomainManager()

# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.get("/")
def root():
    """DarCloud Domain Manager Dashboard"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>🌐 DarCloud Domain Manager</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .header {{ background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
            .stat-card {{ background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }}
            .stat-number {{ font-size: 2em; font-weight: bold; color: #4CAF50; }}
            .domains {{ margin-top: 30px; }}
            .domain-card {{ background: white; margin: 10px 0; padding: 15px; border-radius: 8px; box-shadow: 0 1px 5px rgba(0,0,0,0.1); }}
            .tlds {{ background: #e8f5e8; padding: 15px; border-radius: 8px; margin: 20px 0; }}
            .tld-tag {{ display: inline-block; background: #4CAF50; color: white; padding: 5px 10px; margin: 2px; border-radius: 15px; font-size: 0.9em; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🌐 DarCloud Domain Manager</h1>
            <p>Islamic Domain Registration & Management</p>
            <p><strong>Owner:</strong> Omar Mohammad Abunadi™</p>
        </div>

        <div class="tlds">
            <h3>🕌 Supported Islamic TLDs</h3>
            {"".join(f'<span class="tld-tag">{tld}</span>' for tld in domain_manager.ISLAMIC_TLDS)}
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">{len(domain_manager.registered_domains)}</div>
                <div>Registered Domains</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{len(domain_manager.ISLAMIC_TLDS)}</div>
                <div>Islamic TLDs</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">∞</div>
                <div>Free Registration</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">100%</div>
                <div>Privacy Protected</div>
            </div>
        </div>

        <div class="domains">
            <h2>📋 Registered Domains</h2>
    """

    for domain in domain_manager.list_domains():
        html_content += f"""
            <div class="domain-card">
                <h3>{domain['domain']}</h3>
                <p><strong>Owner:</strong> {domain['owner']}</p>
                <p><strong>Registered:</strong> {domain['registered_at'][:19]}</p>
                <p><strong>Expires:</strong> {domain['expiry_date'][:19]}</p>
                <p><strong>Status:</strong> <span style="color: green;">{domain['status'].upper()}</span></p>
                <p><strong>Nameservers:</strong> {', '.join(domain['nameservers'][:2])}</p>
            </div>
        """

    html_content += """
        </div>
    </body>
    </html>
    """

    return HTMLResponse(content=html_content)

@app.post("/register")
def register_domain(domain: str, owner: str = "Omar Mohammad Abunadi™", years: int = 1):
    """Register Islamic domain"""
    try:
        result = domain_manager.register_domain(domain, owner, years)
        return JSONResponse({
            "status": "success",
            "message": f"Domain {domain} registered successfully",
            "data": result
        })
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Registration failed: {e}")
        raise HTTPException(status_code=500, detail=f"Registration failed: {str(e)}")

@app.get("/api/domains")
def list_domains():
    """List all registered domains"""
    return JSONResponse({
        "domains": domain_manager.list_domains(),
        "total": len(domain_manager.registered_domains)
    })

@app.get("/api/domain/{domain}")
def get_domain_info(domain: str):
    """Get domain information"""
    domain_info = domain_manager.get_domain_info(domain)
    if not domain_info:
        raise HTTPException(status_code=404, detail="Domain not found")

    return JSONResponse(domain_info)

@app.get("/api/dns/{domain}")
def get_dns_records(domain: str):
    """Get DNS records for domain"""
    dns_records = domain_manager.get_dns_records(domain)
    if not dns_records:
        raise HTTPException(status_code=404, detail="Domain not found")

    return JSONResponse(dns_records)

@app.put("/api/dns/{domain}")
def update_dns_record(domain: str, record_type: str, name: str, value: str, ttl: int = 300):
    """Update DNS record"""
    try:
        domain_manager.update_dns_record(domain, record_type, name, value, ttl)
        return JSONResponse({"status": "success", "message": "DNS record updated"})
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"DNS update failed: {e}")
        raise HTTPException(status_code=500, detail=f"DNS update failed: {str(e)}")

@app.post("/api/renew/{domain}")
def renew_domain(domain: str, years: int = 1):
    """Renew domain registration"""
    if domain_manager.renew_domain(domain, years):
        return JSONResponse({"status": "success", "message": f"Domain {domain} renewed for {years} years"})
    else:
        raise HTTPException(status_code=404, detail="Domain not found")

@app.delete("/api/domain/{domain}")
def delete_domain(domain: str):
    """Delete domain registration"""
    if domain_manager.delete_domain(domain):
        return JSONResponse({"status": "success", "message": f"Domain {domain} deleted"})
    else:
        raise HTTPException(status_code=404, detail="Domain not found")

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "DarCloud Domain Manager",
        "domains_registered": len(domain_manager.registered_domains),
        "islamic_tlds": len(domain_manager.ISLAMIC_TLDS),
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

def main():
    """Start DarCloud Domain Manager"""
    logger.info("🌐 Starting DarCloud Domain Manager on port 8081")
    uvicorn.run(app, host="0.0.0.0", port=8081)

if __name__ == "__main__":
    main()