"""
⚖️🤖 DAR LAW - ISLAMIC LEGAL & IP PROTECTION PLATFORM
AI-powered legal services with automatic patent filing, validation, and enforcement
Deployed on DarCloud with 30% Founder Royalty

Features:
  - Automated patent filing & registration
  - Patent validation & enforceability checks
  - Software patent infringement detection
  - Trademark & copyright management
  - Islamic legal compliance verification
  - International IP protection coordination
  - AI-powered contract review & generation
  - 30% Founder royalty on legal services

Author: Omar Mohammad Abunadi
© QuranChain™ 2026
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import sqlite3
import hashlib
import json
import os
import logging
import re

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(
    title="Dar Law Legal Platform",
    description="AI-powered Islamic legal services with IP protection - 30% Founder Royalty",
    version="1.0.0"
)

# Configuration
FOUNDER_WALLET = "0xFounderQuranChainWallet"
FOUNDER_ROYALTY_RATE = 0.30
DAR_LAW_PORT = 8120
DB_PATH = "prod_databases/dar_law.db"

class PatentStatus(Enum):
    PENDING = "pending"
    FILED = "filed"
    APPROVED = "approved"
    REJECTED = "rejected"
    ENFORCED = "enforced"

class LegalJurisdiction(Enum):
    US = "united_states"
    EU = "european_union"
    INTERNATIONAL = "international"
    ISLAMIC = "islamic_countries"
    GLOBAL = "global"

class InfringementStatus(Enum):
    CLEAR = "clear"
    SUSPICIOUS = "suspicious"
    INFRINGEMENT = "infringement"
    LEGAL_ACTION = "legal_action"

@dataclass
class Patent:
    patent_id: str
    title: str
    owner: str
    description: str
    claims: List[str]
    status: PatentStatus
    jurisdiction: LegalJurisdiction
    blockchain_hash: str
    filed_date: datetime
    approval_date: Optional[datetime] = None
    enforceable: bool = True

@dataclass
class PatentAIAgent:
    agent_id: str
    agent_type: str  # filer, validator, enforcer, scanner
    status: str
    tasks_completed: int = 0
    patents_processed: int = 0

class DarLawEngine:
    """Dar Law legal and IP protection platform engine"""
    
    def __init__(self):
        self.founder_wallet = FOUNDER_WALLET
        self.founder_royalty_rate = FOUNDER_ROYALTY_RATE
        self.db_path = DB_PATH
        self._init_database()
        self._init_ai_agents()
        logger.info("⚖️ Dar Law Legal Platform initialized")
    
    def _init_database(self):
        """Initialize SQLite database"""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Patents table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS patents (
                patent_id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                owner TEXT NOT NULL,
                description TEXT,
                claims TEXT,
                status TEXT NOT NULL,
                jurisdiction TEXT NOT NULL,
                blockchain_hash TEXT UNIQUE,
                filed_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                approval_date TIMESTAMP,
                enforceable BOOLEAN DEFAULT 1
            )
        """)
        
        # AI Agents table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ai_agents (
                agent_id TEXT PRIMARY KEY,
                agent_type TEXT NOT NULL,
                status TEXT NOT NULL,
                tasks_completed INTEGER DEFAULT 0,
                patents_processed INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Infringement cases table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS infringement_cases (
                case_id TEXT PRIMARY KEY,
                patent_id TEXT NOT NULL,
                infringing_software TEXT NOT NULL,
                severity TEXT NOT NULL,
                status TEXT NOT NULL,
                detected_by TEXT,
                blockchain_hash TEXT UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (patent_id) REFERENCES patents (patent_id)
            )
        """)
        
        # Legal actions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS legal_actions (
                action_id TEXT PRIMARY KEY,
                case_id TEXT NOT NULL,
                action_type TEXT NOT NULL,
                jurisdiction TEXT NOT NULL,
                status TEXT NOT NULL,
                amount_claimed REAL,
                blockchain_hash TEXT UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (case_id) REFERENCES infringement_cases (case_id)
            )
        """)
        
        # Revenue tracking
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS revenue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_type TEXT NOT NULL,
                amount REAL NOT NULL,
                founder_royalty REAL NOT NULL,
                client TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
    
    def _init_ai_agents(self):
        """Initialize AI legal agents"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        agents = [
            ("agent_patent_filer", "filer", "active"),
            ("agent_patent_validator", "validator", "active"),
            ("agent_patent_enforcer", "enforcer", "active"),
            ("agent_infringement_scanner", "scanner", "active")
        ]
        
        for agent_id, agent_type, status in agents:
            cursor.execute("""
                INSERT OR IGNORE INTO ai_agents (agent_id, agent_type, status)
                VALUES (?, ?, ?)
            """, (agent_id, agent_type, status))
        
        conn.commit()
        conn.close()
        
        logger.info("✅ 4 AI Legal Agents initialized")
    
    def _calculate_blockchain_hash(self, data: Dict) -> str:
        """Calculate blockchain hash"""
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()
    
    def file_patent(self, title: str, owner: str, description: str, 
                    claims: List[str], jurisdiction: str = "global") -> Dict:
        """AI agent files patent automatically"""
        patent_id = f"patent_{hashlib.md5(f'{title}_{owner}_{datetime.utcnow()}'.encode()).hexdigest()[:16]}"
        
        # Calculate blockchain hash
        blockchain_data = {
            "patent_id": patent_id,
            "title": title,
            "owner": owner,
            "claims": claims,
            "timestamp": datetime.utcnow().isoformat()
        }
        blockchain_hash = self._calculate_blockchain_hash(blockchain_data)
        
        # Store in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO patents (patent_id, title, owner, description, claims, 
                               status, jurisdiction, blockchain_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (patent_id, title, owner, description, json.dumps(claims), 
              "filed", jurisdiction, blockchain_hash))
        
        # Update AI filer agent stats
        cursor.execute("""
            UPDATE ai_agents 
            SET tasks_completed = tasks_completed + 1,
                patents_processed = patents_processed + 1
            WHERE agent_id = 'agent_patent_filer'
        """)
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Patent filed: {title} ({patent_id})")
        
        return {
            "success": True,
            "patent_id": patent_id,
            "title": title,
            "owner": owner,
            "status": "filed",
            "jurisdiction": jurisdiction,
            "blockchain_hash": blockchain_hash,
            "filed_by": "AI Patent Filer Agent",
            "filed_date": datetime.utcnow().isoformat()
        }
    
    def validate_patent(self, patent_id: str) -> Dict:
        """AI agent validates patent enforceability"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM patents WHERE patent_id = ?", (patent_id,))
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return {"success": False, "error": "Patent not found"}
        
        # AI validation logic
        title = row[1]
        claims = json.loads(row[4])
        
        # Check enforceability criteria
        enforceable = True
        validation_issues = []
        
        # Check claim count
        if len(claims) < 1:
            enforceable = False
            validation_issues.append("Insufficient patent claims")
        
        # Check title length
        if len(title) < 10:
            validation_issues.append("Title too short")
        
        # Update patent status
        new_status = "approved" if enforceable else "rejected"
        
        cursor.execute("""
            UPDATE patents 
            SET status = ?,
                enforceable = ?,
                approval_date = ?
            WHERE patent_id = ?
        """, (new_status, enforceable, datetime.utcnow(), patent_id))
        
        # Update AI validator agent stats
        cursor.execute("""
            UPDATE ai_agents 
            SET tasks_completed = tasks_completed + 1,
                patents_processed = patents_processed + 1
            WHERE agent_id = 'agent_patent_validator'
        """)
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Patent validated: {patent_id} - {new_status}")
        
        return {
            "success": True,
            "patent_id": patent_id,
            "status": new_status,
            "enforceable": enforceable,
            "validation_issues": validation_issues,
            "validated_by": "AI Patent Validator Agent",
            "validation_date": datetime.utcnow().isoformat()
        }
    
    def scan_for_infringement(self, software_name: str, software_description: str) -> Dict:
        """AI agent scans software for patent infringement"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all approved patents
        cursor.execute("""
            SELECT patent_id, title, claims 
            FROM patents 
            WHERE status = 'approved' AND enforceable = 1
        """)
        
        patents = cursor.fetchall()
        
        # AI scanning logic
        infringements = []
        
        for patent_id, title, claims_json in patents:
            claims = json.loads(claims_json)
            
            # Simple keyword matching (real AI would use NLP)
            for claim in claims:
                claim_lower = claim.lower()
                desc_lower = software_description.lower()
                
                # Check for keyword overlap
                claim_words = set(re.findall(r'\w+', claim_lower))
                desc_words = set(re.findall(r'\w+', desc_lower))
                
                overlap = claim_words.intersection(desc_words)
                
                if len(overlap) > 3:  # Threshold for potential infringement
                    severity = "suspicious" if len(overlap) < 6 else "infringement"
                    
                    # Create infringement case
                    case_id = f"case_{hashlib.md5(f'{patent_id}_{software_name}_{datetime.utcnow()}'.encode()).hexdigest()[:12]}"
                    
                    blockchain_data = {
                        "case_id": case_id,
                        "patent_id": patent_id,
                        "software": software_name,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                    blockchain_hash = self._calculate_blockchain_hash(blockchain_data)
                    
                    cursor.execute("""
                        INSERT INTO infringement_cases 
                        (case_id, patent_id, infringing_software, severity, status, 
                         detected_by, blockchain_hash)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (case_id, patent_id, software_name, severity, "pending",
                          "AI Infringement Scanner", blockchain_hash))
                    
                    infringements.append({
                        "case_id": case_id,
                        "patent_id": patent_id,
                        "patent_title": title,
                        "severity": severity,
                        "matched_keywords": len(overlap)
                    })
                    
                    break  # One case per patent
        
        # Update AI scanner agent stats
        cursor.execute("""
            UPDATE ai_agents 
            SET tasks_completed = tasks_completed + 1
            WHERE agent_id = 'agent_infringement_scanner'
        """)
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Infringement scan completed: {len(infringements)} potential cases")
        
        return {
            "success": True,
            "software_name": software_name,
            "infringements_found": len(infringements),
            "cases": infringements,
            "scanned_by": "AI Infringement Scanner Agent",
            "scan_date": datetime.utcnow().isoformat()
        }
    
    def enforce_patent(self, case_id: str, action_type: str = "cease_and_desist") -> Dict:
        """AI agent enforces patent rights"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT c.*, p.title, p.owner 
            FROM infringement_cases c
            JOIN patents p ON c.patent_id = p.patent_id
            WHERE c.case_id = ?
        """, (case_id,))
        
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return {"success": False, "error": "Case not found"}
        
        action_id = f"action_{hashlib.md5(f'{case_id}_{datetime.utcnow()}'.encode()).hexdigest()[:12]}"
        
        # Determine claim amount based on severity
        severity = row[3]
        amount_claimed = 100000.0 if severity == "infringement" else 50000.0
        
        blockchain_data = {
            "action_id": action_id,
            "case_id": case_id,
            "action_type": action_type,
            "amount": amount_claimed,
            "timestamp": datetime.utcnow().isoformat()
        }
        blockchain_hash = self._calculate_blockchain_hash(blockchain_data)
        
        cursor.execute("""
            INSERT INTO legal_actions 
            (action_id, case_id, action_type, jurisdiction, status, 
             amount_claimed, blockchain_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (action_id, case_id, action_type, "international", "filed",
              amount_claimed, blockchain_hash))
        
        # Update case status
        cursor.execute("""
            UPDATE infringement_cases 
            SET status = 'legal_action'
            WHERE case_id = ?
        """, (case_id,))
        
        # Update AI enforcer agent stats
        cursor.execute("""
            UPDATE ai_agents 
            SET tasks_completed = tasks_completed + 1
            WHERE agent_id = 'agent_patent_enforcer'
        """)
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Patent enforcement initiated: {case_id}")
        
        return {
            "success": True,
            "action_id": action_id,
            "case_id": case_id,
            "action_type": action_type,
            "amount_claimed": amount_claimed,
            "status": "filed",
            "blockchain_hash": blockchain_hash,
            "enforced_by": "AI Patent Enforcer Agent",
            "action_date": datetime.utcnow().isoformat()
        }
    
    def get_ai_agents_status(self) -> List[Dict]:
        """Get status of all AI legal agents"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM ai_agents ORDER BY agent_type")
        rows = cursor.fetchall()
        conn.close()
        
        agents = []
        for row in rows:
            agents.append({
                "agent_id": row[0],
                "agent_type": row[1],
                "status": row[2],
                "tasks_completed": row[3],
                "patents_processed": row[4],
                "created_at": row[5]
            })
        
        return agents
    
    def get_patent_stats(self) -> Dict:
        """Get patent statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                COUNT(*) as total_patents,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN enforceable = 1 THEN 1 ELSE 0 END) as enforceable
            FROM patents
        """)
        
        patent_stats = cursor.fetchone()
        
        cursor.execute("SELECT COUNT(*) FROM infringement_cases")
        infringement_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM legal_actions")
        legal_actions_count = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "total_patents": patent_stats[0] or 0,
            "approved_patents": patent_stats[1] or 0,
            "pending_patents": patent_stats[2] or 0,
            "enforceable_patents": patent_stats[3] or 0,
            "infringement_cases": infringement_count,
            "legal_actions": legal_actions_count
        }

# Global engine instance
dar_law_engine = DarLawEngine()

# API Endpoints
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Dar Law Legal Platform",
        "version": "1.0.0",
        "port": DAR_LAW_PORT,
        "ai_agents": 4,
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE * 100}%"
    }

@app.post("/patents/file")
async def file_patent(request: Request):
    """AI agent files patent automatically"""
    data = await request.json()
    
    title = data.get("title")
    owner = data.get("owner")
    description = data.get("description", "")
    claims = data.get("claims", [])
    jurisdiction = data.get("jurisdiction", "global")
    
    if not title or not owner:
        raise HTTPException(status_code=400, detail="Missing required fields: title, owner")
    
    result = dar_law_engine.file_patent(title, owner, description, claims, jurisdiction)
    return result

@app.post("/patents/{patent_id}/validate")
async def validate_patent(patent_id: str):
    """AI agent validates patent enforceability"""
    result = dar_law_engine.validate_patent(patent_id)
    
    if not result.get("success"):
        raise HTTPException(status_code=404, detail=result.get("error"))
    
    return result

@app.post("/scan/infringement")
async def scan_infringement(request: Request):
    """AI agent scans software for patent infringement"""
    data = await request.json()
    
    software_name = data.get("software_name")
    software_description = data.get("description", "")
    
    if not software_name:
        raise HTTPException(status_code=400, detail="Missing required field: software_name")
    
    result = dar_law_engine.scan_for_infringement(software_name, software_description)
    return result

@app.post("/enforce/{case_id}")
async def enforce_patent(case_id: str, request: Request):
    """AI agent enforces patent rights"""
    data = await request.json()
    action_type = data.get("action_type", "cease_and_desist")
    
    result = dar_law_engine.enforce_patent(case_id, action_type)
    
    if not result.get("success"):
        raise HTTPException(status_code=404, detail=result.get("error"))
    
    return result

@app.get("/agents/status")
async def get_agents_status():
    """Get AI agents status"""
    agents = dar_law_engine.get_ai_agents_status()
    return {
        "count": len(agents),
        "agents": agents
    }

@app.get("/stats")
async def get_stats():
    """Get patent and legal stats"""
    stats = dar_law_engine.get_patent_stats()
    return stats

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Dar Law Legal & IP Protection Platform",
        "description": "AI-powered Islamic legal services with automatic patent protection",
        "version": "1.0.0",
        "ai_agents": [
            "Patent Filer Agent",
            "Patent Validator Agent",
            "Patent Enforcer Agent",
            "Infringement Scanner Agent"
        ],
        "features": [
            "Automated patent filing",
            "Patent validation & enforceability checks",
            "Software infringement detection",
            "Patent enforcement & legal action",
            "Blockchain-verified legal records",
            "30% Founder royalty"
        ],
        "endpoints": {
            "file_patent": "/patents/file",
            "validate_patent": "/patents/{patent_id}/validate",
            "scan_infringement": "/scan/infringement",
            "enforce_patent": "/enforce/{case_id}",
            "agents_status": "/agents/status",
            "stats": "/stats"
        }
    }

if __name__ == "__main__":
    import uvicorn
    
    print("=" * 60)
    print("⚖️🤖 DAR LAW LEGAL & IP PROTECTION PLATFORM")
    print("=" * 60)
    print(f"Port: {DAR_LAW_PORT}")
    print(f"AI Agents: 4 (Filer, Validator, Enforcer, Scanner)")
    print(f"Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    print("=" * 60)
    
    uvicorn.run(app, host="0.0.0.0", port=DAR_LAW_PORT)
