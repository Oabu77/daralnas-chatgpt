#!/usr/bin/env python3
"""
🔐 QURANCHAIN PRODUCTION CONFIG - Add Your Wallet & Payment Details Here
This file stores your LIVE production configuration
Keep this file SECURE and never commit to git
"""

# ============================================================================
# YOUR CRYPTO WALLET ADDRESSES (For live blockchain gas toll collection)
# ============================================================================
# Add your actual wallet addresses here:

CRYPTO_ADDRESSES = {
    # Bitcoin address for BTC/Lightning payments
    "bitcoin": "3NaWi32bU27P6Dbo6FQTauyBWghmEnApix",  # ✅ CONFIGURED
    
    # Ethereum address for ETH, Polygon, Arbitrum, etc.
    "ethereum": "0x4e90944C093f7727ff89a30AF96A556deB95cCB8",  # ✅ CONFIGURED
    
    # Polygon MATIC address
    "polygon": "0x4e90944C093f7727ff89a30AF96A556deB95cCB8",  # ✅ CONFIGURED (same as ETH)
    
    # USDC/USDT stablecoin address
    "usdc": "0x4e90944C093f7727ff89a30AF96A556deB95cCB8",  # ✅ CONFIGURED (same as ETH)
}


# ============================================================================
# STRIPE PAYMENT PROCESSOR (DISABLED - Using ACH + PayPal instead)
# ============================================================================

STRIPE_CONFIG = {
    # Stripe disabled - using ACH and PayPal instead
    "enabled": False,
    
    "api_key": "DISABLED",
    "webhook_secret": "DISABLED",
    "merchant_account": "DISABLED",
    "live_mode": False,
}


# ============================================================================
# PAYPAL (DISABLED - Using ACH only)
# ============================================================================

PAYPAL_CONFIG = {
    # Disabled - ACH only mode
    "enabled": False,
    
    "client_id": "DISABLED",
    "client_secret": "DISABLED",
    "account_email": "DISABLED",
    "live_mode": False,
}


# ============================================================================
# ACH BANK ACCOUNT (For direct bank transfers)
# ============================================================================

ACH_CONFIG = {
    # Your business bank account number
    "bank_account": "260108845256",  # ✅ CONFIGURED
    
    # Your bank routing number
    "routing_number": "091017138",  # ✅ CONFIGURED
    
    # Account holder name (your company name)
    "account_holder": "Omar Mohammad Abunadi",  # ✅ CONFIGURED
    
    # Account type: "checking" or "savings"
    "account_type": "checking",
}


# ============================================================================
# YOUR BUSINESS INFORMATION
# ============================================================================

BUSINESS_INFO = {
    # Your legal business name
    "legal_name": "QuranChain LLC",
    
    # Your business tax ID / EIN
    "tax_id": "00-0000000",
    
    # Your business website
    "website": "https://quranchain.com",
    
    # Support email for customers
    "support_email": "support@quranchain.com",
    
    # Business phone number
    "phone": "+1-000-000-0000",
}


# ============================================================================
# QUICKSTART - ACH ONLY MODE
# ============================================================================

"""
✅ YOUR SYSTEM IS CONFIGURED FOR ACH-ONLY MODE

Payment Method: Direct Bank Transfers (ACH)
  • Bank Account: 260108845256
  • Routing Number: 091017138
  • Account Holder: Omar Mohammad Abunadi
  • Status: ✅ CONFIGURED AND READY

All merchants will submit payments via ACH:
  1. Customer signs up at merchants.quranchain.com
  2. Provides their bank details
  3. Submits payment amount
  4. System processes ACH transfer
  5. 70% to merchant, 30% to you (founder)
  6. Deposits directly to your bank account

NO ADDITIONAL SETUP REQUIRED - YOU'RE READY TO DEPLOY!
"""


# ============================================================================
# AUTOMATIC PAYOUT SETTINGS
# ============================================================================

PAYOUT_CONFIG = {
    # How often to automatically payout to your wallets (in hours)
    "payout_frequency_hours": 4,
    
    # Minimum balance before triggering payout
    "minimum_payout_threshold_usd": 500,
    
    # Priority order for payout (try these methods in order)
    "payout_priority_order": [
        "cryptocurrency",  # Try to payout to crypto first
        "stripe",          # Then try Stripe
        "paypal",          # Then try PayPal
        "ach",            # Finally ACH to bank
    ],
    
    # Which cryptocurrencies to prioritize for auto-payout
    "crypto_priority": [
        "ethereum",
        "polygon",
        "usdc",
        "bitcoin",
    ],
}


# ============================================================================
# FOUNDER IMMUTABLE SETTINGS (DO NOT CHANGE)
# ============================================================================

FOUNDER_SETTINGS = {
    "founder_name": "Omar Mohammad Abunadi™",
    "founder_royalty_rate": 0.30,  # 30% - IMMUTABLE
    "business_name": "QuranChain",
    "immutable_note": "Founder royalty of 30% is IMMUTABLE and enforced in smart contracts"
}


# ============================================================================
# VALIDATION FUNCTION
# ============================================================================

def validate_config() -> dict:
    """Validate that all required fields are filled in"""
    
    issues = []
    
    # Check crypto addresses
    for network, address in CRYPTO_ADDRESSES.items():
        if not address or address.startswith("YOUR_") or address.startswith("1A1z7"):
            issues.append(f"❌ Missing or placeholder: CRYPTO_ADDRESSES['{network}']")
    
    # Check Stripe
    if STRIPE_CONFIG["api_key"].startswith("sk_live_YOUR"):
        issues.append("❌ Missing: STRIPE_CONFIG['api_key']")
    
    # Check PayPal
    if PAYPAL_CONFIG["client_id"].startswith("YOUR"):
        issues.append("❌ Missing: PAYPAL_CONFIG['client_id']")
    
    # Check business info
    if not BUSINESS_INFO["legal_name"] or BUSINESS_INFO["legal_name"].startswith("Your"):
        issues.append("❌ Missing: BUSINESS_INFO['legal_name']")
    
    if issues:
        return {
            "status": "invalid",
            "issues": issues,
            "action": "Fill in all missing values above with your actual details"
        }
    else:
        return {
            "status": "valid",
            "message": "✅ All production settings configured correctly",
            "action": "Ready to deploy live revenue collection"
        }


if __name__ == "__main__":
    print("\n" + "=" * 100)
    print("🔐 QURANCHAIN PRODUCTION CONFIGURATION")
    print("=" * 100 + "\n")
    
    result = validate_config()
    
    if result["status"] == "invalid":
        print("⚠️ CONFIGURATION INCOMPLETE:")
        print()
        for issue in result["issues"]:
            print(f"   {issue}")
        print()
        print("ACTION REQUIRED:")
        print("   1. Edit this file (production_config.py)")
        print("   2. Replace each placeholder with your actual values")
        print("   3. Save the file")
        print("   4. Run: python3 activate_live_collection.py")
        print()
    else:
        print(result["message"])
        print()
        print("Your configuration is ready for live deployment!")
        print("Run: python3 activate_live_collection.py")
        print()
