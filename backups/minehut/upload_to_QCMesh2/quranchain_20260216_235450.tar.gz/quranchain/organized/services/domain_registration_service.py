#!/usr/bin/env python3

"""
DARCLOUD DOMAIN REGISTRATION SERVICE
Complete domain registration, management, and DNS configuration
"""

import asyncio
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from enum import Enum

# ============================================================================
# ENUMS & CONSTANTS
# ============================================================================

class RegistrarProvider(Enum):
    CLOUDFLARE = "cloudflare"
    NAMECHEAP = "namecheap"
    GODADDY = "godaddy"

class DomainExtension(Enum):
    COM = ".com"
    NET = ".net"
    ORG = ".org"
    IO = ".io"
    CO = ".co"
    XYZ = ".xyz"
    HOST = ".host"
    ONLINE = ".online"

DOMAIN_PRICING = {
    ".com": {"registration": 8.99, "renewal": 8.99, "markup": 1.50},
    ".net": {"registration": 9.99, "renewal": 9.99, "markup": 1.50},
    ".org": {"registration": 9.99, "renewal": 9.99, "markup": 1.50},
    ".io": {"registration": 34.99, "renewal": 34.99, "markup": 5.00},
    ".co": {"registration": 19.99, "renewal": 19.99, "markup": 2.00},
    ".xyz": {"registration": 10.99, "renewal": 10.99, "markup": 1.50},
    ".host": {"registration": 34.99, "renewal": 34.99, "markup": 5.00},
    ".online": {"registration": 24.99, "renewal": 24.99, "markup": 3.00}
}

FOUNDER_ROYALTY_RATE = 0.30

# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class Domain:
    name: str
    tld: str
    customer_id: str
    registrar: str
    status: str
    registration_date: str
    expiry_date: str
    auto_renew: bool
    dns_provider: str
    nameservers: List[str]
    dns_records: Dict = None

@dataclass
class DomainSearchResult:
    domain: str
    available: bool
    price_registration: float
    price_renewal: float
    price_markup: float
    premium: bool
    registrar: str = "cloudflare"

# ============================================================================
# DOMAIN REGISTRATION DATABASE
# ============================================================================

class DomainRegistrationDB:
    def __init__(self, db_path: str = "/home/omar/Desktop/QuranChain/crm/domain_registry.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize domain registry database"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        # Domains table
        c.execute('''
            CREATE TABLE IF NOT EXISTS domains (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain_name TEXT UNIQUE NOT NULL,
                customer_id TEXT NOT NULL,
                registrar TEXT DEFAULT 'cloudflare',
                status TEXT DEFAULT 'active',
                registration_date TEXT NOT NULL,
                expiry_date TEXT NOT NULL,
                auto_renew BOOLEAN DEFAULT 1,
                dns_provider TEXT DEFAULT 'cloudflare',
                nameservers TEXT,
                dns_records TEXT,
                price_paid REAL,
                created_at TEXT,
                updated_at TEXT
            )
        ''')
        
        # Domain search cache
        c.execute('''
            CREATE TABLE IF NOT EXISTS domain_search_cache (
                domain_name TEXT PRIMARY KEY,
                available BOOLEAN,
                last_checked TEXT,
                price_registration REAL,
                price_renewal REAL,
                registrar TEXT
            )
        ''')
        
        # Domain renewal schedule
        c.execute('''
            CREATE TABLE IF NOT EXISTS domain_renewals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain_name TEXT NOT NULL,
                customer_id TEXT NOT NULL,
                renewal_date TEXT NOT NULL,
                auto_renew BOOLEAN DEFAULT 1,
                status TEXT DEFAULT 'scheduled',
                created_at TEXT,
                FOREIGN KEY(domain_name) REFERENCES domains(domain_name)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def execute_query(self, query: str, params: tuple = ()) -> List:
        """Execute SELECT query"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute(query, params)
        result = c.fetchall()
        conn.close()
        return result
    
    def execute_update(self, query: str, params: tuple = ()) -> int:
        """Execute INSERT/UPDATE/DELETE query"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute(query, params)
        conn.commit()
        affected = c.rowcount
        conn.close()
        return affected

# ============================================================================
# DOMAIN REGISTRATION SERVICE
# ============================================================================

class DomainRegistrationService:
    """Complete domain registration and management system"""
    
    def __init__(self):
        self.db = DomainRegistrationDB()
        self.registrar = RegistrarProvider.CLOUDFLARE.value
    
    async def search_domains(self, base_name: str) -> List[DomainSearchResult]:
        """Search domain availability across TLDs"""
        results = []
        
        for tld_enum in DomainExtension:
            tld = tld_enum.value
            full_domain = f"{base_name}{tld}"
            
            # Check cache first
            cached = self.db.execute_query(
                'SELECT * FROM domain_search_cache WHERE domain_name = ?',
                (full_domain,)
            )
            
            if cached:
                row = cached[0]
                results.append(DomainSearchResult(
                    domain=full_domain,
                    available=bool(row[1]),
                    price_registration=row[3],
                    price_renewal=row[4],
                    price_markup=DOMAIN_PRICING[tld]["markup"],
                    premium=False,
                    registrar=row[5]
                ))
            else:
                # In production: call registrar API
                result = await self._check_availability(full_domain)
                
                search_result = DomainSearchResult(
                    domain=full_domain,
                    available=result["available"],
                    price_registration=DOMAIN_PRICING[tld]["registration"],
                    price_renewal=DOMAIN_PRICING[tld]["renewal"],
                    price_markup=DOMAIN_PRICING[tld]["markup"],
                    premium=result.get("premium", False),
                    registrar=self.registrar
                )
                
                # Cache result
                self._cache_search_result(search_result)
                results.append(search_result)
        
        return results
    
    async def _check_availability(self, domain: str) -> Dict:
        """Check domain availability (mock implementation)"""
        # Reserved domains
        reserved = ["darcloud", "quranchain", "test", "admin", "root", "demo"]
        base = domain.split('.')[0].lower()
        
        # Mock premium domains
        premium_domains = ["ai.com", "blockchain.com", "crypto.com"]
        
        return {
            "available": base not in reserved,
            "premium": domain in premium_domains
        }
    
    def _cache_search_result(self, result: DomainSearchResult):
        """Cache domain search result"""
        query = '''
            INSERT OR REPLACE INTO domain_search_cache
            (domain_name, available, last_checked, price_registration, price_renewal, registrar)
            VALUES (?, ?, ?, ?, ?, ?)
        '''
        self.db.execute_update(query, (
            result.domain,
            result.available,
            datetime.now().isoformat(),
            result.price_registration,
            result.price_renewal,
            result.registrar
        ))
    
    async def register_domain(self,
                             domain: str,
                             customer_id: str,
                             years: int = 1,
                             auto_renew: bool = True,
                             dns_provider: str = "cloudflare") -> Dict:
        """Register domain for customer"""
        try:
            # Verify availability
            base_name = domain.split('.')[0]
            search_results = await self.search_domains(base_name)
            
            domain_result = None
            for result in search_results:
                if result.domain == domain:
                    domain_result = result
                    break
            
            if not domain_result or not domain_result.available:
                return {"status": "error", "error": f"Domain {domain} is not available"}
            
            # Calculate pricing
            price_per_year = domain_result.price_registration
            total_price = price_per_year * years
            founder_share = total_price * FOUNDER_ROYALTY_RATE
            platform_share = total_price * (1 - FOUNDER_ROYALTY_RATE)
            
            # Set expiry date
            expiry_date = (datetime.now() + timedelta(days=365*years)).isoformat()
            
            # Store domain registration
            query = '''
                INSERT INTO domains
                (domain_name, customer_id, registrar, status, registration_date, expiry_date, 
                 auto_renew, dns_provider, nameservers, price_paid, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            '''
            
            cloudflare_nameservers = [
                "shubhi.ns.cloudflare.com",
                "trevor.ns.cloudflare.com"
            ]
            
            now = datetime.now().isoformat()
            self.db.execute_update(query, (
                domain,
                customer_id,
                self.registrar,
                "active",
                now,
                expiry_date,
                auto_renew,
                dns_provider,
                json.dumps(cloudflare_nameservers),
                total_price,
                now,
                now
            ))
            
            # Schedule renewal if auto-renew enabled
            if auto_renew:
                renewal_query = '''
                    INSERT INTO domain_renewals
                    (domain_name, customer_id, renewal_date, auto_renew, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                '''
                renewal_date = (datetime.now() + timedelta(days=330)).isoformat()
                self.db.execute_update(renewal_query, (
                    domain,
                    customer_id,
                    renewal_date,
                    auto_renew,
                    "scheduled",
                    now
                ))
            
            return {
                "status": "success",
                "domain": domain,
                "customer_id": customer_id,
                "registrar": self.registrar,
                "registration_date": now,
                "expiry_date": expiry_date,
                "auto_renew": auto_renew,
                "years": years,
                "pricing": {
                    "yearly_cost": price_per_year,
                    "total_cost": total_price,
                    "founder_royalty": founder_share,
                    "platform_revenue": platform_share
                },
                "nameservers": cloudflare_nameservers,
                "dns_provider": dns_provider,
                "message": f"Domain {domain} registered successfully"
            }
        
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    async def renew_domain(self, domain: str, customer_id: str, years: int = 1) -> Dict:
        """Renew domain registration"""
        try:
            # Get current domain
            query = 'SELECT * FROM domains WHERE domain_name = ? AND customer_id = ?'
            result = self.db.execute_query(query, (domain, customer_id))
            
            if not result:
                return {"status": "error", "error": "Domain not found"}
            
            row = result[0]
            current_expiry = datetime.fromisoformat(row[8])
            new_expiry = (current_expiry + timedelta(days=365*years)).isoformat()
            
            # Calculate renewal cost
            tld = domain[domain.rfind('.'):]
            renewal_cost = DOMAIN_PRICING[tld]["renewal"] * years
            
            # Update domain
            update_query = '''
                UPDATE domains
                SET expiry_date = ?, updated_at = ?
                WHERE domain_name = ?
            '''
            self.db.execute_update(update_query, (
                new_expiry,
                datetime.now().isoformat(),
                domain
            ))
            
            return {
                "status": "success",
                "domain": domain,
                "old_expiry": row[8],
                "new_expiry": new_expiry,
                "renewal_cost": renewal_cost,
                "founder_royalty": renewal_cost * FOUNDER_ROYALTY_RATE,
                "message": f"Domain {domain} renewed successfully"
            }
        
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    async def get_customer_domains(self, customer_id: str) -> Dict:
        """Get all domains for customer"""
        try:
            query = '''
                SELECT domain_name, status, registration_date, expiry_date, auto_renew, dns_provider
                FROM domains
                WHERE customer_id = ?
                ORDER BY registration_date DESC
            '''
            results = self.db.execute_query(query, (customer_id,))
            
            domains = []
            for row in results:
                expiry = datetime.fromisoformat(row[3])
                days_until_expiry = (expiry - datetime.now()).days
                
                domains.append({
                    "domain": row[0],
                    "status": row[1],
                    "registration_date": row[2],
                    "expiry_date": row[3],
                    "days_until_expiry": days_until_expiry,
                    "auto_renew": bool(row[4]),
                    "dns_provider": row[5],
                    "renewal_required": days_until_expiry < 30
                })
            
            return {
                "status": "success",
                "customer_id": customer_id,
                "domains": domains,
                "total_domains": len(domains)
            }
        
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    async def configure_dns(self, domain: str, customer_id: str, dns_records: Dict) -> Dict:
        """Configure DNS records for domain"""
        try:
            query = '''
                UPDATE domains
                SET dns_records = ?, updated_at = ?
                WHERE domain_name = ? AND customer_id = ?
            '''
            
            self.db.execute_update(query, (
                json.dumps(dns_records),
                datetime.now().isoformat(),
                domain,
                customer_id
            ))
            
            return {
                "status": "success",
                "domain": domain,
                "dns_records": dns_records,
                "message": "DNS records configured successfully"
            }
        
        except Exception as e:
            return {"status": "error", "error": str(e)}

# ============================================================================
# INITIALIZATION
# ============================================================================

import json

async def main():
    """Test domain registration service"""
    service = DomainRegistrationService()
    print("✅ Domain Registration Service Initialized")
    print(f"📊 Database: {service.db.db_path}")
    print("✨ Ready for production deployment")

if __name__ == "__main__":
    asyncio.run(main())
