#!/usr/bin/env python3

"""
DARCLOUD WEBSITE HOSTING - PRODUCTION API SERVER
Live production server for customer acquisition and website management
"""

import sys
import asyncio
from datetime import datetime

sys.path.insert(0, '/home/omar/Desktop/QuranChain/organized/services')

from flask import Flask, jsonify, request
from flask_cors import CORS

from darcloud_platform_integration import DarcloudCompletePlatform

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Initialize DarCloud platform
platform = DarcloudCompletePlatform()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "DarCloud Website Hosting API",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "platform": "production"
    })


@app.route('/api/v1/platform/status', methods=['GET'])
def platform_status():
    """Get platform operational status"""
    return jsonify({
        "status": "operational",
        "services": {
            "website_hosting": "online",
            "customer_management": "online",
            "domain_registration": "online",
            "website_builder": "online",
            "revenue_engine": "live",
            "loyalty_program": "active"
        },
        "databases": {
            "websites": "connected",
            "customers": "connected",
            "domains": "connected",
            "builder": "connected"
        },
        "timestamp": datetime.now().isoformat()
    })


@app.route('/api/v1/customers/register', methods=['POST'])
def register_customer():
    """Register new customer"""
    data = request.get_json()
    
    email = data.get('email')
    company_name = data.get('company_name')
    phone = data.get('phone')
    country = data.get('country')
    password = data.get('password')
    
    if not all([email, company_name, phone, country, password]):
        return jsonify({"error": "Missing required fields"}), 400
    
    async def async_register():
        return await platform.onboard_customer(
            email=email,
            company_name=company_name,
            phone=phone,
            country=country,
            password=password
        )
    
    try:
        result = asyncio.run(async_register())
        if result["status"] == "success":
            return jsonify({
                "status": "success",
                "customer_id": result["customer_id"],
                "message": "Customer registered successfully"
            }), 201
        else:
            return jsonify({
                "error": result.get("error", "Registration failed")
            }), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/v1/domains/search', methods=['POST'])
def search_domains():
    """Search available domains"""
    data = request.get_json()
    domain_name = data.get('domain_name')
    
    if not domain_name:
        return jsonify({"error": "domain_name required"}), 400
    
    async def async_search():
        return await platform.hosting_api.domain_service.search_domains(domain_name)
    
    try:
        domains = asyncio.run(async_search())
        return jsonify({
            "status": "success",
            "query": domain_name,
            "results": len(domains),
            "domains": [
                {
                    "domain": d.domain,
                    "available": d.available,
                    "price_registration": d.price_registration,
                    "price_renewal": d.price_renewal
                } for d in domains
            ]
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/v1/website/create', methods=['POST'])
def create_website():
    """Create website for customer"""
    data = request.get_json()
    
    customer_id = data.get('customer_id')
    domain = data.get('domain')
    plan_tier = data.get('plan_tier', 'starter')
    design_style = data.get('design_style', 'minimal')
    
    if not customer_id or not domain:
        return jsonify({"error": "customer_id and domain required"}), 400
    
    async def async_create():
        return await platform.create_customer_website(
            customer_id=customer_id,
            domain=domain,
            plan_tier=plan_tier,
            design_style=design_style
        )
    
    try:
        result = asyncio.run(async_create())
        if result.get("status") == "success":
            return jsonify(result), 201
        else:
            return jsonify(result), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/docs', methods=['GET'])
def docs():
    """API Documentation"""
    return jsonify({
        "api": "DarCloud Website Hosting API",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "platform_status": "/api/v1/platform/status",
            "register_customer": "POST /api/v1/customers/register",
            "search_domains": "POST /api/v1/domains/search",
            "create_website": "POST /api/v1/website/create"
        },
        "documentation": "https://darcloud.host/api/docs"
    })


@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found", "hint": "See /docs"}), 404


@app.errorhandler(500)
def server_error(error):
    return jsonify({"error": "Internal server error"}), 500


if __name__ == '__main__':
    print("="*70)
    print("🚀 DARCLOUD WEBSITE HOSTING PLATFORM - PRODUCTION SERVER")
    print("="*70)
    print(f"\n⏰ Server start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\n📍 API Server: http://localhost:5000")
    print(f"   Health Check: http://localhost:5000/health")
    print(f"   API Docs: http://localhost:5000/docs")
    print(f"   Status: http://localhost:5000/api/v1/platform/status")
    print(f"\n✅ Platform Status: ONLINE")
    print(f"   - Website Hosting: READY")
    print(f"   - Customer Management: READY")
    print(f"   - Domain Registration: READY")
    print(f"   - Revenue System: LIVE")
    print("\n" + "="*70)
    print("Press CTRL+C to stop the server")
    print("="*70 + "\n")
    
    app.run(host='0.0.0.0', port=5000, debug=False)
