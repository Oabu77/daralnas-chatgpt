#!/usr/bin/env python3
"""Quick Revenue Demo - AI Workforce in Action"""
import os, sys, json, random, time
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "crm"))
from database import CRMDatabase, Lead, Deal, Merchant, RevenueEvent

crm = CRMDatabase()

print("\n╔" + "="*76 + "╗")
print("║" + " "*20 + "🚀 AI WORKFORCE REVENUE DEMO 🚀" + " "*21 + "║")
print("║" + " "*18 + "© QuranChain™ | Omar Mohammad Abunadi™" + " "*18 + "║")
print("╚" + "="*76 + "╝\n")

# PHASE 1: Marketing AI - Generate Leads
print("🎯 MARKETING AI - Generating 5 leads...")
leads = [
    {"name": "TechStore", "email": "tech@example.com", "company": "TechStore LLC"},
    {"name": "GreenLeaf", "email": "green@example.com", "company": "GreenLeaf Market"},
    {"name": "CodeAcademy", "email": "code@example.com", "company": "CodeAcademy Pro"},
    {"name": "FitLife", "email": "fit@example.com", "company": "FitLife"},
    {"name": "MuslimBooks", "email": "books@example.com", "company": "Muslim Bookstore"}
]

lead_ids = []
for l in leads:
    lead = Lead(
        id=None, name=l["name"], email=l["email"], company=l["company"],
        phone="+1-555-0100", source="marketing_ai", status="qualified",
        score=75, notes="AI-generated lead", assigned_to="sales_ai",
        created_at="", updated_at="", opted_in=True, opt_in_timestamp=""
    )
    lid = crm.create_lead(lead)
    lead_ids.append(lid)
    print(f"  ✅ Lead #{lid}: {l['name']}")

print(f"\n�� SALES AI - Converting {len(lead_ids)} leads to deals...")
deal_ids = []
for lid in lead_ids:
    deal = Deal(
        id=None, lead_id=lid, stage="closed_won", deal_value=299,
        currency="USD", probability=100, close_date=None,
        product="QuranChain Pay Pro", ai_agent_owner="sales_ai",
        human_owner=None, notes="Closed by Sales AI",
        created_at="", updated_at=""
    )
    did = crm.create_deal(deal)
    deal_ids.append(did)
    print(f"  ✅ Deal #{did}: $299/mo - CLOSED WON")

print(f"\n🚀 ONBOARDING AI - Activating {len(deal_ids)} merchants...")
merchant_ids = []
for i, (lid, did) in enumerate(zip(lead_ids, deal_ids)):
    merchant = Merchant(
        id=None, business_name=leads[i]["company"], contact_name=leads[i]["name"],
        contact_email=leads[i]["email"], contact_phone="+1-555-0100",
        status="active", monthly_volume=0,
        api_key=f"qc_live_demo_{i:03d}", webhook_url=None,
        payout_wallet="0x1FDFb0e08D7a98Ce96a737741DA6babdBeee45A9",
        payout_method="crypto", tier="professional", monthly_fee=299,
        onboarded_by_ai="onboarding_ai", created_at="", activated_at=""
    )
    mid = crm.create_merchant(merchant)
    merchant_ids.append(mid)
    print(f"  ✅ Merchant #{mid}: {leads[i]['company']}")
    
    # Log revenue
    revenue = RevenueEvent(
        id=None, source="merchant_signup", event_type="subscription",
        amount=299, currency="USD", merchant_id=mid, deal_id=did,
        ai_agent="sales_ai", commission_amount=299 * 0.10,
        founder_royalty=299 * 0.30, metadata=json.dumps({"tier": "pro"}),
        timestamp=""
    )
    crm.record_revenue(revenue)

print("\n📊 OPTIMIZATION AI - Revenue Analysis...")
stats = crm.get_revenue_summary(30)
print(f"  Total Revenue:        ${stats['total_revenue']:,.2f}")
print(f"  Founder Royalty (30%): ${stats['founder_royalty']:,.2f}")
print(f"  MRR:                  ${stats['total_revenue']:,.2f}/month")
print(f"  ARR:                  ${stats['total_revenue'] * 12:,.2f}/year")

print("\n" + "="*70)
print("🎉 DEMO COMPLETE")
print("="*70)
print(f"\n✅ {len(lead_ids)} leads → {len(deal_ids)} deals → {len(merchant_ids)} merchants")
print(f"✅ ${stats['total_revenue']:,.2f} MRR generated")
print(f"✅ ${stats['founder_royalty']:,.2f} founder royalty (30%)")
print("\n💳 Payments accepted at: 0x1FDFb0e08D7a98Ce96a737741DA6babdBeee45A9")
print("📊 View CRM: sqlite3 crm/crm.db")
print("\n© QuranChain™ | Omar Mohammad Abunadi™\n")
