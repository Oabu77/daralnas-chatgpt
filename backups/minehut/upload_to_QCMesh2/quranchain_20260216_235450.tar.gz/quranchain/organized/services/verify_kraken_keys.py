#!/usr/bin/env python3
"""Verify Kraken API Key Format"""

print("\n" + "="*70)
print("🔍 KRAKEN API KEY VERIFICATION")
print("="*70 + "\n")

key1 = "mbkv6oAd4dxiUyNvgz+3IWxZF1O7K7o8BwQvkJCwQ5t4oOHxYYO/SlqYASnnCeKMj1R8oS/aPvJK8f5pKQbfqA=="
key2 = "/9+jSXPjsHGXJF+mTH7MgQM207WKaw2TkcGQzGQrjF6ZWJiAhkgA8GWq"

print("Key 1:")
print(f"  Value: {key1[:20]}...{key1[-20:]}")
print(f"  Length: {len(key1)} chars")
print(f"  Base64: {'✅' if set(key1).issubset(set('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=')) else '❌'}")

print("\nKey 2:")
print(f"  Value: {key2[:20]}...{key2[-20:]}")
print(f"  Length: {len(key2)} chars")
print(f"  Base64: {'✅' if set(key2).issubset(set('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=')) else '❌'}")

print("\n" + "="*70)
print("📋 EXPECTED FORMAT (from Kraken docs):")
print("="*70)
print("""
API Key Example:    abc123DEF456xyz789
Private Key Example: 1234567890abcdef... (base64, ~88 chars)

Your keys look like Private Keys (both base64 encoded).

TO FIX:
1. Login to Kraken.com
2. Settings → API
3. Look for TWO separate values:
   - API Key (short, alphanumeric)
   - Private Key (long, base64)
4. The API Key is NOT base64 encoded
""")

print("\n© QuranChain™ | Omar Mohammad Abunadi™\n")
