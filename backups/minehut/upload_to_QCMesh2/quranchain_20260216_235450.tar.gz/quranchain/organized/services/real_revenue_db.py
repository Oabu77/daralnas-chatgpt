#!/usr/bin/env python3
"""
Real Revenue Database Layer
Tracks actual on-chain transactions and payment processor events
© QuranChain™ | Omar Mohammad Abunadi™
"""

import sqlite3
import json
import os
from datetime import datetime
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict
from contextlib import contextmanager


DB_PATH = os.getenv("REVENUE_DB_PATH", "/home/omar/Desktop/QuranChain/revenue_production.db")


@dataclass
class TransactionEvent:
    """Real blockchain transaction or payment processor event"""
    id: Optional[int]
    source: str  # "bitcoin", "ethereum", "coinbase_commerce", etc.
    chain: str  # "btc", "eth", "polygon", "arbitrum"
    asset: str  # "BTC", "ETH", "USDC", "USDT"
    amount: float  # Raw amount in asset
    amount_usd: float  # USD value at time of tx
    from_addr: Optional[str]
    to_addr: str  # Our receiving address
    txid: str  # Blockchain tx hash or processor charge ID
    block_block-size: Optional[int]
    confirmations: int
    status: str  # "pending", "confirmed", "failed"
    seen_at: str  # ISO timestamp when first detected
    confirmed_at: Optional[str]  # ISO timestamp when confirmed
    price_source: str  # "coingecko", "kraken", "stable_peg"
    metadata: str  # JSON for additional data


@dataclass
class RevenueRollup:
    """Hourly/daily revenue aggregation"""
    ts_hour: str  # YYYY-MM-DD HH:00:00
    ts_day: str  # YYYY-MM-DD
    gross_usd: float
    founder_usd: float  # After founder share %
    by_chain_json: str  # JSON breakdown per chain
    by_service_json: str  # JSON breakdown per service


class RealRevenueDB:
    """Database for real revenue tracking"""
    
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._init_schema()
    
    @contextmanager
    def get_connection(self):
        """Get database connection context"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def _init_schema(self):
        """Initialize database schema"""
        with self.get_connection() as conn:
            # Transaction events table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tx_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT NOT NULL,
                    chain TEXT NOT NULL,
                    asset TEXT NOT NULL,
                    amount REAL NOT NULL,
                    amount_usd REAL NOT NULL,
                    from_addr TEXT,
                    to_addr TEXT NOT NULL,
                    txid TEXT NOT NULL,
                    block_height INTEGER,
                    confirmations INTEGER DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'pending',
                    seen_at TEXT NOT NULL,
                    confirmed_at TEXT,
                    price_source TEXT NOT NULL,
                    metadata TEXT DEFAULT '{}',
                    UNIQUE(source, txid)
                )
            """)
            
            # Revenue rollups table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS revenue_rollups (
                    ts_hour TEXT NOT NULL,
                    ts_day TEXT NOT NULL,
                    gross_usd REAL NOT NULL,
                    founder_usd REAL NOT NULL,
                    by_chain_json TEXT DEFAULT '{}',
                    by_service_json TEXT DEFAULT '{}',
                    PRIMARY KEY (ts_hour)
                )
            """)
            
            # Indices for performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tx_status ON tx_events(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tx_chain ON tx_events(chain)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tx_seen_at ON tx_events(seen_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_rollup_day ON revenue_rollups(ts_day)")
    
    def record_transaction(self, tx: TransactionEvent) -> int:
        """
        Record a real transaction event (idempotent on source+txid)
        Returns: transaction ID
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT OR IGNORE INTO tx_events 
                (source, chain, asset, amount, amount_usd, from_addr, to_addr, txid,
                 block_height, confirmations, status, seen_at, confirmed_at, price_source, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                tx.source, tx.chain, tx.asset, tx.amount, tx.amount_usd,
                tx.from_addr, tx.to_addr, tx.txid, tx.block_height,
                tx.confirmations, tx.status, tx.seen_at, tx.confirmed_at,
                tx.price_source, tx.metadata
            ))
            
            if cursor.rowcount == 0:
                # Already exists, update confirmations/status
                conn.execute("""
                    UPDATE tx_events 
                    SET confirmations = ?, status = ?, confirmed_at = ?
                    WHERE source = ? AND txid = ?
                """, (tx.confirmations, tx.status, tx.confirmed_at, tx.source, tx.txid))
                
                # Get existing ID
                row = conn.execute(
                    "SELECT id FROM tx_events WHERE source = ? AND txid = ?",
                    (tx.source, tx.txid)
                ).fetchone()
                return row['id'] if row else 0
            
            return cursor.lastrowid
    
    def get_pending_transactions(self) -> List[Dict[str, Any]]:
        """Get all pending transactions needing confirmation updates"""
        with self.get_connection() as conn:
            rows = conn.execute("""
                SELECT * FROM tx_events 
                WHERE status = 'pending'
                ORDER BY seen_at DESC
            """).fetchall()
            return [dict(row) for row in rows]
    
    def get_confirmed_revenue(self, since: Optional[str] = None) -> Dict[str, Any]:
        """
        Get confirmed revenue totals
        since: ISO timestamp to filter from (optional)
        Returns: {total_usd, founder_usd, by_chain, by_asset, count}
        """
        with self.get_connection() as conn:
            query = """
                SELECT 
                    COUNT(*) as tx_count,
                    SUM(amount_usd) as gross_usd,
                    chain,
                    asset
                FROM tx_events 
                WHERE status = 'confirmed'
            """
            params = []
            
            if since:
                query += " AND confirmed_at >= ?"
                params.append(since)
            
            query += " GROUP BY chain, asset"
            
            rows = conn.execute(query, params).fetchall()
            
            by_chain = {}
            by_asset = {}
            total_usd = 0.0
            total_count = 0
            
            for row in rows:
                chain = row['chain']
                asset = row['asset']
                gross = row['gross_usd'] or 0.0
                count = row['tx_count'] or 0
                
                by_chain[chain] = by_chain.get(chain, 0.0) + gross
                by_asset[asset] = by_asset.get(asset, 0.0) + gross
                total_usd += gross
                total_count += count
            
            # Calculate founder share (30% default from env)
            founder_share = float(os.getenv("FOUNDER_SHARE", "0.30"))
            founder_usd = total_usd * founder_share
            
            return {
                "total_usd": total_usd,
                "founder_usd": founder_usd,
                "by_chain": by_chain,
                "by_asset": by_asset,
                "count": total_count
            }
    
    def update_rollup(self, ts_hour: str, ts_day: str, gross_usd: float, 
                     founder_usd: float, by_chain: Dict, by_service: Dict):
        """Update hourly revenue rollup"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO revenue_rollups
                (ts_hour, ts_day, gross_usd, founder_usd, by_chain_json, by_service_json)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                ts_hour, ts_day, gross_usd, founder_usd,
                json.dumps(by_chain), json.dumps(by_service)
            ))
    
    def get_daily_revenue(self, date: str) -> float:
        """Get total confirmed revenue for a specific day (YYYY-MM-DD)"""
        with self.get_connection() as conn:
            row = conn.execute("""
                SELECT SUM(gross_usd) as total
                FROM revenue_rollups
                WHERE ts_day = ?
            """, (date,)).fetchone()
            return row['total'] if row and row['total'] else 0.0


# Global instance
real_revenue_db = RealRevenueDB()


if __name__ == "__main__":
    # Test schema creation
    print(f"✅ Real Revenue DB initialized: {DB_PATH}")
    print(f"   Tables: tx_events, revenue_rollups")
    print(f"   Mode: PRODUCTION - REAL DATA ONLY")
    
    # Show current stats
    stats = real_revenue_db.get_confirmed_revenue()
    print(f"\n📊 Current Revenue (Confirmed Only):")
    print(f"   Total: ${stats['total_usd']:.2f}")
    print(f"   Founder (30%): ${stats['founder_usd']:.2f}")
    print(f"   Transactions: {stats['count']}")
    print(f"   By Chain: {stats['by_chain']}")
    print(f"   By Asset: {stats['by_asset']}")
