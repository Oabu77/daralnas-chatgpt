#!/usr/bin/env python3
"""
💾 EXTERNAL DISK MANAGER FOR AI AGENTS
Automatic memory overflow management with external storage
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import json
import shutil
import psutil
import subprocess
from datetime import datetime
from pathlib import Path

class ExternalDiskManager:
    """Manages external disk for AI agent memory overflow"""
    
    def __init__(self):
        self.config_file = "/home/omar/Desktop/QuranChain/external_disk_config.json"
        self.load_config()
        self.ensure_directories()
        
    def load_config(self):
        """Load external disk configuration"""
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                self.config = json.load(f)
        else:
            # Default configuration
            self.config = {
                "external_disk_path": "/tmp/quranchain_external",
                "ai_memory_overflow_dir": "/tmp/quranchain_external/ai_agent_memory",
                "temp_expansion_quota_gb": 100,
                "ram_threshold_percent": 80,
                "disk_threshold_percent": 90,
                "auto_compress_enabled": True,
                "cloud_archive_enabled": False
            }
            self.save_config()
            
    def save_config(self):
        """Save configuration"""
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=2)
            
    def ensure_directories(self):
        """Ensure all required directories exist"""
        paths = [
            self.config["external_disk_path"],
            self.config["ai_memory_overflow_dir"],
            f"{self.config['external_disk_path']}/overflow_cache",
            f"{self.config['external_disk_path']}/transaction_archive",
            f"{self.config['external_disk_path']}/compressed_logs"
        ]
        
        for path in paths:
            os.makedirs(path, exist_ok=True)
            
    def check_ram_usage(self) -> float:
        """Check current RAM usage percentage"""
        mem = psutil.virtual_memory()
        return mem.percent
        
    def check_disk_usage(self, path="/") -> float:
        """Check disk usage percentage"""
        disk = psutil.disk_usage(path)
        return disk.percent
        
    def get_overflow_path(self, ai_agent_name: str) -> str:
        """Get overflow directory for specific AI agent"""
        overflow_dir = f"{self.config['ai_memory_overflow_dir']}/{ai_agent_name}"
        os.makedirs(overflow_dir, exist_ok=True)
        return overflow_dir
        
    def offload_to_external_disk(self, source_dir: str, ai_agent_name: str):
        """Offload data to external disk when RAM > threshold"""
        ram_usage = self.check_ram_usage()
        
        if ram_usage > self.config['ram_threshold_percent']:
            print(f"⚠️  RAM usage {ram_usage:.1f}% exceeds threshold {self.config['ram_threshold_percent']}%")
            print(f"📦 Offloading {ai_agent_name} data to external disk...")
            
            overflow_path = self.get_overflow_path(ai_agent_name)
            
            # Move large files to external disk
            for root, dirs, files in os.walk(source_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    file_size = os.path.getsize(file_path) / (1024 * 1024)  # MB
                    
                    if file_size > 10:  # Files larger than 10MB
                        relative_path = os.path.relpath(file_path, source_dir)
                        target_path = os.path.join(overflow_path, relative_path)
                        
                        os.makedirs(os.path.dirname(target_path), exist_ok=True)
                        shutil.move(file_path, target_path)
                        
                        # Create symlink
                        os.symlink(target_path, file_path)
                        
            print(f"✅ Offload complete - Data moved to {overflow_path}")
            return True
        
        return False
        
    def compress_old_data(self):
        """Compress old data when disk usage > threshold"""
        disk_usage = self.check_disk_usage()
        
        if disk_usage > self.config['disk_threshold_percent'] and self.config['auto_compress_enabled']:
            print(f"⚠️  Disk usage {disk_usage:.1f}% exceeds threshold {self.config['disk_threshold_percent']}%")
            print("🗜️  Compressing old data...")
            
            # Compress logs older than 7 days
            log_dirs = [
                "/home/omar/Desktop/QuranChain/monitoring_logs",
                "/home/omar/Desktop/QuranChain/logs"
            ]
            
            for log_dir in log_dirs:
                if os.path.exists(log_dir):
                    subprocess.run([
                        "find", log_dir,
                        "-name", "*.log",
                        "-mtime", "+7",
                        "-exec", "gzip", "{}", ";"
                    ], capture_output=True)
                    
            print("✅ Compression complete")
            
    def cleanup_overflow(self, days_old=30):
        """Clean up overflow data older than specified days"""
        print(f"🧹 Cleaning overflow data older than {days_old} days...")
        
        overflow_base = self.config['ai_memory_overflow_dir']
        
        subprocess.run([
            "find", overflow_base,
            "-type", "f",
            "-mtime", f"+{days_old}",
            "-delete"
        ], capture_output=True)
        
        print("✅ Cleanup complete")
        
    def get_external_disk_stats(self) -> dict:
        """Get statistics about external disk usage"""
        external_path = self.config['external_disk_path']
        
        if not os.path.exists(external_path):
            return {"error": "External disk path not found"}
            
        disk = psutil.disk_usage(external_path)
        
        # Count files
        total_files = 0
        total_size = 0
        
        for root, dirs, files in os.walk(external_path):
            total_files += len(files)
            for file in files:
                try:
                    total_size += os.path.getsize(os.path.join(root, file))
                except:
                    pass
                    
        return {
            "path": external_path,
            "total_gb": disk.total / (1024**3),
            "used_gb": disk.used / (1024**3),
            "free_gb": disk.free / (1024**3),
            "percent_used": disk.percent,
            "total_files": total_files,
            "total_size_gb": total_size / (1024**3)
        }
        
    def auto_manage(self):
        """Automatic management loop"""
        print("🔄 Running automatic external disk management...")
        
        # Check RAM and offload if needed
        ram_usage = self.check_ram_usage()
        if ram_usage > self.config['ram_threshold_percent']:
            print(f"⚠️  High RAM usage: {ram_usage:.1f}%")
            
        # Check disk and compress if needed
        disk_usage = self.check_disk_usage()
        if disk_usage > self.config['disk_threshold_percent']:
            self.compress_old_data()
            
        # Get stats
        stats = self.get_external_disk_stats()
        print(f"\n💾 External Disk Stats:")
        print(f"   Path: {stats.get('path')}")
        print(f"   Used: {stats.get('used_gb', 0):.2f} GB / {stats.get('total_gb', 0):.2f} GB ({stats.get('percent_used', 0):.1f}%)")
        print(f"   Files: {stats.get('total_files', 0):,}")
        
        return stats


def main():
    """Main entry point"""
    print("╔" + "="*78 + "╗")
    print("║" + " "*20 + "💾 EXTERNAL DISK MANAGER FOR AI AGENTS" + " "*20 + "║")
    print("╚" + "="*78 + "╝\n")
    
    manager = ExternalDiskManager()
    stats = manager.auto_manage()
    
    print("\n✅ External disk management complete")
    
    # Save stats
    stats_file = "/home/omar/Desktop/QuranChain/external_disk_stats.json"
    with open(stats_file, 'w') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "stats": stats,
            "config": manager.config
        }, f, indent=2)
        
    print(f"📊 Stats saved: {stats_file}\n")


if __name__ == "__main__":
    main()
