#!/usr/bin/env python3
"""
📦 PRODUCT DOWNLOAD & FUNGI MESH EXPANSION SYSTEM
Every QuranChain product purchase includes downloadable files that install
Fungi Mesh network nodes on customer hardware — expanding the mesh globally.

Every download package includes:
  🍄 Fungi Mesh Node Agent (connects to global mesh)
  📡 MeshTalk OS Lite (peer-to-peer communication)
  🔗 QuranChain Blockchain Light Client
  📊 Revenue Attribution Tracker
  🔒 Product-specific software & configuration

Founder: Omar Mohammad Abunadi™
© 2026 QuranChain™ — All Rights Reserved
❌ NEVER modify 30% founder royalty (FOUNDER_ROYALTY_RATE = 0.30)
"""

import os
import sys
import json
import hashlib
import logging
import zipfile
import io
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

sys.path.insert(0, "/home/omar/Desktop/QuranChain")

logger = logging.getLogger('ProductDownloads')

# ============================================================================
# CONSTANTS
# ============================================================================

FOUNDER_ROYALTY_RATE = 0.30  # IMMUTABLE
DOWNLOADS_BASE_URL = "https://darcloud.host/downloads"
FUNGI_MESH_VERSION = "2.4.0"
MESHTALK_LITE_VERSION = "1.8.0"
QURANCHAIN_LIGHT_VERSION = "5.2.0"
HUB_ENDPOINT = "http://localhost:9999"
FUNGI_MESH_ENDPOINT = "http://localhost:5006"

# Base directory for generated download packages
DOWNLOADS_DIR = Path("/home/omar/Desktop/QuranChain/product_downloads")
DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================================
# HARDWARE PLATFORM TARGETS
# ============================================================================

class HardwarePlatform(Enum):
    """Supported hardware platforms for Fungi Mesh expansion"""
    LINUX_X86_64 = "linux-x86_64"
    LINUX_ARM64 = "linux-arm64"
    LINUX_ARMV7 = "linux-armv7"
    MACOS_X86_64 = "macos-x86_64"
    MACOS_ARM64 = "macos-arm64"
    WINDOWS_X86_64 = "windows-x86_64"
    RASPBERRY_PI = "raspberry-pi"
    ANDROID_ARM64 = "android-arm64"
    OPENWRT_MIPS = "openwrt-mips"
    DOCKER = "docker"


class DownloadType(Enum):
    """Types of download packages"""
    FULL_INSTALLER = "full_installer"
    LITE_INSTALLER = "lite_installer"
    CONFIG_ONLY = "config_only"
    SDK = "sdk"
    DOCKER_IMAGE = "docker_image"
    FIRMWARE = "firmware"
    CLI_TOOL = "cli_tool"
    API_CLIENT = "api_client"
    MOBILE_APP = "mobile_app"
    DESKTOP_APP = "desktop_app"


# ============================================================================
# DOWNLOAD FILE DEFINITION
# ============================================================================

@dataclass
class DownloadFile:
    """A downloadable file for a product"""
    filename: str
    description: str
    download_type: DownloadType
    platforms: List[HardwarePlatform]
    version: str
    size_mb: float = 0.0
    sha256: str = ""
    includes_fungi_mesh: bool = True
    includes_meshtalk: bool = True
    includes_light_client: bool = True
    install_command: str = ""
    min_hardware: Dict[str, Any] = field(default_factory=dict)

    @property
    def download_url(self) -> str:
        return f"{DOWNLOADS_BASE_URL}/{self.filename}"

    def to_dict(self) -> Dict:
        return {
            'filename': self.filename,
            'description': self.description,
            'download_type': self.download_type.value,
            'platforms': [p.value for p in self.platforms],
            'version': self.version,
            'size_mb': self.size_mb,
            'sha256': self.sha256,
            'download_url': self.download_url,
            'includes_fungi_mesh': self.includes_fungi_mesh,
            'includes_meshtalk': self.includes_meshtalk,
            'includes_light_client': self.includes_light_client,
            'install_command': self.install_command,
        }


# ============================================================================
# PRODUCT DOWNLOAD MAP — EVERY PRODUCT HAS DOWNLOADS
# ============================================================================

PRODUCT_DOWNLOADS: Dict[str, List[DownloadFile]] = {}

# ---------------------------------------------------------------------------
# SHARED CORE COMPONENTS (bundled in every product)
# ---------------------------------------------------------------------------
FUNGI_MESH_CORE = DownloadFile(
    filename="fungi-mesh-node-{platform}-v{ver}.tar.gz",
    description="🍄 Fungi Mesh Network Node — connects your hardware to the global mesh",
    download_type=DownloadType.FULL_INSTALLER,
    platforms=list(HardwarePlatform),
    version=FUNGI_MESH_VERSION,
    size_mb=45.0,
    includes_fungi_mesh=True,
    includes_meshtalk=True,
    includes_light_client=True,
    install_command="curl -sSL https://darcloud.host/install.sh | bash",
    min_hardware={"ram_mb": 512, "disk_mb": 200, "cpu_cores": 1},
)

MESHTALK_LITE_CORE = DownloadFile(
    filename="meshtalk-lite-{platform}-v{ver}.tar.gz",
    description="📡 MeshTalk OS Lite — peer-to-peer communication layer",
    download_type=DownloadType.LITE_INSTALLER,
    platforms=list(HardwarePlatform),
    version=MESHTALK_LITE_VERSION,
    size_mb=22.0,
    includes_fungi_mesh=True,
    includes_meshtalk=True,
    includes_light_client=False,
    install_command="curl -sSL https://darcloud.host/meshtalk-install.sh | bash",
    min_hardware={"ram_mb": 256, "disk_mb": 100, "cpu_cores": 1},
)

QURANCHAIN_LIGHT_CLIENT = DownloadFile(
    filename="quranchain-light-{platform}-v{ver}.tar.gz",
    description="🔗 QuranChain Blockchain Light Client — verify transactions locally",
    download_type=DownloadType.LITE_INSTALLER,
    platforms=list(HardwarePlatform),
    version=QURANCHAIN_LIGHT_VERSION,
    size_mb=18.0,
    includes_fungi_mesh=True,
    includes_meshtalk=False,
    includes_light_client=True,
    install_command="curl -sSL https://darcloud.host/qchain-install.sh | bash",
    min_hardware={"ram_mb": 256, "disk_mb": 150, "cpu_cores": 1},
)


def _core_downloads() -> List[DownloadFile]:
    """Core downloads bundled with every product"""
    return [FUNGI_MESH_CORE, MESHTALK_LITE_CORE, QURANCHAIN_LIGHT_CLIENT]


# ---------------------------------------------------------------------------
# GAS TOLL PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['gas_toll_standard'] = _core_downloads() + [
    DownloadFile(
        filename="gas-toll-agent-standard-v{ver}.tar.gz",
        description="Gas Toll Standard Agent — process standard blockchain transactions",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=12.0,
        install_command="./install-gas-toll.sh --tier standard",
    ),
]
PRODUCT_DOWNLOADS['gas_toll_priority'] = _core_downloads() + [
    DownloadFile(
        filename="gas-toll-agent-priority-v{ver}.tar.gz",
        description="Gas Toll Priority Agent — priority transaction processing node",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=14.0,
        install_command="./install-gas-toll.sh --tier priority",
    ),
]
PRODUCT_DOWNLOADS['gas_toll_critical'] = _core_downloads() + [
    DownloadFile(
        filename="gas-toll-agent-critical-v{ver}.tar.gz",
        description="Gas Toll Critical Agent — instant processing for mission-critical txns",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=16.0,
        install_command="./install-gas-toll.sh --tier critical",
    ),
]
PRODUCT_DOWNLOADS['gas_toll_unlimited'] = _core_downloads() + [
    DownloadFile(
        filename="gas-toll-unlimited-node-v{ver}.tar.gz",
        description="Gas Toll Unlimited Node — dedicated full node for unlimited transactions",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=85.0,
        install_command="./install-gas-toll.sh --tier unlimited --full-node",
        min_hardware={"ram_mb": 4096, "disk_mb": 50000, "cpu_cores": 4},
    ),
]

# ---------------------------------------------------------------------------
# VALIDATOR PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['validator_l1_license'] = _core_downloads() + [
    DownloadFile(
        filename="quranchaind-validator-l1-v{ver}.tar.gz",
        description="QuranChain L1 Validator Node — full consensus validator with staking",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="5.2.0", size_mb=220.0,
        install_command="./deploy-validator.sh --tier l1 --auto-stake",
        min_hardware={"ram_mb": 16384, "disk_mb": 500000, "cpu_cores": 8},
    ),
    DownloadFile(
        filename="validator-monitoring-dashboard-v{ver}.tar.gz",
        description="Validator Monitoring Dashboard — real-time health & revenue tracking",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.2.0", size_mb=35.0,
        install_command="./install-dashboard.sh",
    ),
]
PRODUCT_DOWNLOADS['validator_standard'] = _core_downloads() + [
    DownloadFile(
        filename="quranchaind-validator-standard-v{ver}.tar.gz",
        description="QuranChain Standard Validator — consensus participation node",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="5.2.0", size_mb=180.0,
        install_command="./deploy-validator.sh --tier standard",
        min_hardware={"ram_mb": 8192, "disk_mb": 250000, "cpu_cores": 4},
    ),
]
PRODUCT_DOWNLOADS['validator_enterprise'] = _core_downloads() + [
    DownloadFile(
        filename="quranchaind-validator-enterprise-v{ver}.tar.gz",
        description="Enterprise Validator Suite — HA cluster with auto-failover",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="5.2.0", size_mb=350.0,
        install_command="./deploy-validator.sh --tier enterprise --cluster",
        min_hardware={"ram_mb": 32768, "disk_mb": 1000000, "cpu_cores": 16},
    ),
    DownloadFile(
        filename="validator-ha-orchestrator-v{ver}.tar.gz",
        description="HA Orchestrator — manages validator cluster failover & load balancing",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=25.0,
        install_command="./install-ha-orchestrator.sh",
    ),
]
PRODUCT_DOWNLOADS['validator_hosting'] = _core_downloads() + [
    DownloadFile(
        filename="validator-hosting-agent-v{ver}.tar.gz",
        description="Managed Validator Hosting Agent — auto-managed node with DarCloud",
        download_type=DownloadType.LITE_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=15.0,
        install_command="./install-hosted-validator.sh",
    ),
]

# ---------------------------------------------------------------------------
# VALIDATOR DEPLOYMENT PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['validator_deploy_single'] = _core_downloads() + [
    DownloadFile(
        filename="validator-deploy-single-v{ver}.tar.gz",
        description="Single Validator Deployment Kit — automated deployment to one node",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=200.0,
        install_command="./deploy-single-validator.sh --auto",
        min_hardware={"ram_mb": 8192, "disk_mb": 250000, "cpu_cores": 4},
    ),
]
PRODUCT_DOWNLOADS['validator_deploy_regional'] = _core_downloads() + [
    DownloadFile(
        filename="validator-deploy-regional-v{ver}.tar.gz",
        description="Regional Validator Fleet — deploy across a region with auto-discovery",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="1.0.0", size_mb=280.0,
        install_command="./deploy-regional-validators.sh --region auto",
        min_hardware={"ram_mb": 16384, "disk_mb": 500000, "cpu_cores": 8},
    ),
]
PRODUCT_DOWNLOADS['validator_deploy_global'] = _core_downloads() + [
    DownloadFile(
        filename="validator-deploy-global-v{ver}.tar.gz",
        description="Global Validator Infrastructure — full planet-scale deployment toolkit",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="1.0.0", size_mb=500.0,
        install_command="./deploy-global-validators.sh --all-regions",
        min_hardware={"ram_mb": 32768, "disk_mb": 1000000, "cpu_cores": 16},
    ),
    DownloadFile(
        filename="validator-fleet-manager-v{ver}.tar.gz",
        description="Fleet Manager — centralized control plane for global validator network",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=60.0,
        install_command="./install-fleet-manager.sh",
    ),
]

# ---------------------------------------------------------------------------
# RPC API PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['rpc_developer'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-rpc-sdk-dev-v{ver}.tar.gz",
        description="QuranChain RPC SDK — developer tools, CLI, and API client libraries",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="5.2.0", size_mb=28.0,
        install_command="pip install quranchain-sdk && npm install @quranchain/rpc-client",
    ),
]
PRODUCT_DOWNLOADS['rpc_enterprise'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-rpc-enterprise-node-v{ver}.tar.gz",
        description="RPC Enterprise Node — dedicated high-performance RPC endpoint",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="5.2.0", size_mb=180.0,
        install_command="./install-rpc-node.sh --tier enterprise",
        min_hardware={"ram_mb": 16384, "disk_mb": 500000, "cpu_cores": 8},
    ),
    DownloadFile(
        filename="quranchain-rpc-sdk-enterprise-v{ver}.tar.gz",
        description="Enterprise RPC SDK — full SDK with priority support libraries",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="5.2.0", size_mb=35.0,
        install_command="pip install quranchain-sdk[enterprise]",
    ),
]

# ---------------------------------------------------------------------------
# STAKING PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['staking_basic'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-staking-client-v{ver}.tar.gz",
        description="Staking Client — stake QURAN tokens and earn rewards",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=32.0,
        install_command="./install-staking-client.sh",
    ),
]
PRODUCT_DOWNLOADS['staking_delegator'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-delegator-agent-v{ver}.tar.gz",
        description="Delegator Agent — auto-compounding delegation with smart routing",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=18.0,
        install_command="./install-delegator.sh --auto-compound",
    ),
]
PRODUCT_DOWNLOADS['staking_institutional'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-staking-institutional-v{ver}.tar.gz",
        description="Institutional Staking Platform — dedicated infrastructure with custody",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="1.0.0", size_mb=150.0,
        install_command="./install-institutional-staking.sh",
        min_hardware={"ram_mb": 16384, "disk_mb": 250000, "cpu_cores": 8},
    ),
]

# ---------------------------------------------------------------------------
# BRIDGE PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['bridge_standard'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-bridge-client-v{ver}.tar.gz",
        description="Cross-Chain Bridge Client — transfer assets between blockchains",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=28.0,
        install_command="./install-bridge-client.sh",
    ),
]
PRODUCT_DOWNLOADS['bridge_enterprise'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-bridge-relay-node-v{ver}.tar.gz",
        description="Bridge Relay Node — operate a cross-chain relay for enterprise traffic",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=120.0,
        install_command="./install-bridge-relay.sh --enterprise",
        min_hardware={"ram_mb": 8192, "disk_mb": 100000, "cpu_cores": 4},
    ),
]
PRODUCT_DOWNLOADS['bridge_transaction_fee'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-bridge-cli-v{ver}.tar.gz",
        description="Bridge CLI — command-line tool for cross-chain transfers",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=8.0,
        install_command="pip install quranchain-bridge-cli",
    ),
]

# ---------------------------------------------------------------------------
# SMART CONTRACT PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['smart_contract_deploy'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-contract-deployer-v{ver}.tar.gz",
        description="Smart Contract Deployer — deploy contracts to QuranChain networks",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=15.0,
        install_command="npm install -g @quranchain/contract-deployer",
    ),
]
PRODUCT_DOWNLOADS['smart_contract_audit'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-audit-toolkit-v{ver}.tar.gz",
        description="Smart Contract Audit Toolkit — static analysis & security scanner",
        download_type=DownloadType.SDK,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.MACOS_X86_64],
        version="1.0.0", size_mb=42.0,
        install_command="./install-audit-toolkit.sh",
    ),
]
PRODUCT_DOWNLOADS['smart_contract_sdk'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-cosmwasm-sdk-v{ver}.tar.gz",
        description="CosmWasm SDK — full smart contract development environment",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=55.0,
        install_command="npm install @quranchain/cosmwasm-sdk && pip install quranchain-wasm",
    ),
]

# ---------------------------------------------------------------------------
# GOVERNANCE PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['governance_participation'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-governance-client-v{ver}.tar.gz",
        description="Governance Client — vote on proposals, delegate, and participate",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=24.0,
        install_command="./install-governance-client.sh",
    ),
]
PRODUCT_DOWNLOADS['governance_council'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-council-suite-v{ver}.tar.gz",
        description="Governance Council Suite — full council member toolkit with proposal creation",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=55.0,
        install_command="./install-council-suite.sh",
    ),
]

# ---------------------------------------------------------------------------
# QEX EXCHANGE PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['qex_basic'] = _core_downloads() + [
    DownloadFile(
        filename="qex-trading-client-basic-v{ver}.tar.gz",
        description="QEX Trading Client — desktop trading app with charts & order book",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=48.0,
        install_command="./install-qex-client.sh --tier basic",
    ),
]
PRODUCT_DOWNLOADS['qex_pro'] = _core_downloads() + [
    DownloadFile(
        filename="qex-trading-pro-v{ver}.tar.gz",
        description="QEX Pro Trading Suite — advanced charts, algorithmic trading, API access",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=65.0,
        install_command="./install-qex-client.sh --tier pro",
    ),
    DownloadFile(
        filename="qex-api-sdk-v{ver}.tar.gz",
        description="QEX Exchange API SDK — Python/Node.js trading libraries",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=12.0,
        install_command="pip install qex-sdk && npm install @qex/trading-sdk",
    ),
]
PRODUCT_DOWNLOADS['qex_institutional'] = _core_downloads() + [
    DownloadFile(
        filename="qex-institutional-gateway-v{ver}.tar.gz",
        description="QEX Institutional Gateway — FIX protocol, co-location, low-latency",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=120.0,
        install_command="./install-qex-institutional.sh",
        min_hardware={"ram_mb": 16384, "disk_mb": 100000, "cpu_cores": 8},
    ),
]
PRODUCT_DOWNLOADS['qex_trade_fee'] = _core_downloads() + [
    DownloadFile(
        filename="qex-cli-v{ver}.tar.gz",
        description="QEX CLI — command-line trading tool",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=6.0,
        install_command="pip install qex-cli",
    ),
]
PRODUCT_DOWNLOADS['qex_market_maker'] = _core_downloads() + [
    DownloadFile(
        filename="qex-market-maker-bot-v{ver}.tar.gz",
        description="QEX Market Maker Bot — automated market making with spread optimization",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=22.0,
        install_command="./install-market-maker.sh",
    ),
]
PRODUCT_DOWNLOADS['qex_token_listing'] = _core_downloads() + [
    DownloadFile(
        filename="qex-token-listing-toolkit-v{ver}.tar.gz",
        description="Token Listing Toolkit — compliance docs, smart contract templates, listing tools",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=18.0,
        install_command="npm install @qex/listing-toolkit",
    ),
]

# ---------------------------------------------------------------------------
# NFT MARKETPLACE PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['nft_creator'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-nft-studio-v{ver}.tar.gz",
        description="NFT Creator Studio — design, mint, and list NFTs on QuranChain",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=55.0,
        install_command="./install-nft-studio.sh",
    ),
]
PRODUCT_DOWNLOADS['nft_collector'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-nft-gallery-v{ver}.tar.gz",
        description="NFT Collector Gallery — browse, collect, and showcase NFTs",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=40.0,
        install_command="./install-nft-gallery.sh",
    ),
]
PRODUCT_DOWNLOADS['nft_minting_fee'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-nft-mint-cli-v{ver}.tar.gz",
        description="NFT Minting CLI — command-line minting tool",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=8.0,
        install_command="pip install quranchain-nft-cli",
    ),
]
PRODUCT_DOWNLOADS['nft_trading_fee'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-nft-trader-v{ver}.tar.gz",
        description="NFT Trading Tool — buy, sell, and auction NFTs from the CLI",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=7.0,
        install_command="pip install quranchain-nft-trader",
    ),
]

# ---------------------------------------------------------------------------
# DEFI PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['defi_liquidity'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-defi-liquidity-agent-v{ver}.tar.gz",
        description="DeFi Liquidity Agent — automated LP position management",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=20.0,
        install_command="./install-defi-agent.sh --liquidity",
    ),
]
PRODUCT_DOWNLOADS['defi_yield_optimizer'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-yield-optimizer-v{ver}.tar.gz",
        description="AI Yield Optimizer — ML-powered yield farming across DeFi protocols",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=65.0,
        install_command="./install-yield-optimizer.sh",
        min_hardware={"ram_mb": 4096, "disk_mb": 10000, "cpu_cores": 2},
    ),
]

# ---------------------------------------------------------------------------
# BLOCKCHAIN ENTERPRISE SERVICES
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['blockchain_enterprise_license'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-enterprise-platform-v{ver}.tar.gz",
        description="Enterprise Blockchain Platform — full QuranChain enterprise suite",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.DOCKER],
        version="5.2.0", size_mb=800.0,
        install_command="./install-enterprise.sh --license YOUR_KEY",
        min_hardware={"ram_mb": 65536, "disk_mb": 2000000, "cpu_cores": 32},
    ),
]
PRODUCT_DOWNLOADS['cosmwasm_development'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-cosmwasm-devenv-v{ver}.tar.gz",
        description="CosmWasm Development Environment — IDE plugins, testnet, compiler",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=75.0,
        install_command="./install-cosmwasm-dev.sh",
    ),
]
PRODUCT_DOWNLOADS['ibc_relay'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-ibc-relay-node-v{ver}.tar.gz",
        description="IBC Relay Node — Inter-Blockchain Communication relay operator",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=95.0,
        install_command="./install-ibc-relay.sh",
        min_hardware={"ram_mb": 4096, "disk_mb": 50000, "cpu_cores": 2},
    ),
]
PRODUCT_DOWNLOADS['multi_sig_wallet'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-multisig-wallet-v{ver}.tar.gz",
        description="Multi-Sig Wallet — secure multi-signature wallet application",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=38.0,
        install_command="./install-multisig-wallet.sh",
    ),
]
PRODUCT_DOWNLOADS['fraud_detection'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-fraud-detection-agent-v{ver}.tar.gz",
        description="Fraud Detection AI Agent — ML-powered transaction fraud detection",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=110.0,
        install_command="./install-fraud-detection.sh",
        min_hardware={"ram_mb": 8192, "disk_mb": 50000, "cpu_cores": 4},
    ),
]
PRODUCT_DOWNLOADS['aml_kyc'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-aml-kyc-suite-v{ver}.tar.gz",
        description="AML/KYC Compliance Suite — identity verification & compliance engine",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=85.0,
        install_command="./install-aml-kyc.sh",
        min_hardware={"ram_mb": 4096, "disk_mb": 20000, "cpu_cores": 2},
    ),
]
PRODUCT_DOWNLOADS['blockchain_consulting'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-consulting-toolkit-v{ver}.tar.gz",
        description="Consulting Toolkit — architecture templates, assessment tools, reports",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=12.0,
        install_command="pip install quranchain-consulting-toolkit",
    ),
]
PRODUCT_DOWNLOADS['private_chain'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-private-chain-deployer-v{ver}.tar.gz",
        description="Private Chain Deployer — deploy your own QuranChain private instance",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="5.2.0", size_mb=450.0,
        install_command="./deploy-private-chain.sh --genesis custom",
        min_hardware={"ram_mb": 32768, "disk_mb": 1000000, "cpu_cores": 16},
    ),
]
PRODUCT_DOWNLOADS['chain_upgrade'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-chain-upgrader-v{ver}.tar.gz",
        description="Chain Upgrade Tool — zero-downtime chain upgrade orchestrator",
        download_type=DownloadType.CLI_TOOL,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="1.0.0", size_mb=25.0,
        install_command="./install-chain-upgrader.sh",
    ),
]

# ---------------------------------------------------------------------------
# TOKEN PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['token_quran'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-wallet-v{ver}.tar.gz",
        description="QuranChain Wallet — manage QURAN tokens, stake, and transact",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="2.0.0", size_mb=42.0,
        install_command="./install-quranchain-wallet.sh",
    ),
]
PRODUCT_DOWNLOADS['token_qcoin'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-wallet-v{ver}.tar.gz",
        description="QuranChain Wallet — manage QCOIN tokens and transact",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="2.0.0", size_mb=42.0,
        install_command="./install-quranchain-wallet.sh",
    ),
]
PRODUCT_DOWNLOADS['token_qlearn'] = _core_downloads() + [
    DownloadFile(
        filename="qlearn-student-app-v{ver}.tar.gz",
        description="QLEARN Student App — AI training modules and token management",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=35.0,
        install_command="./install-qlearn-app.sh",
    ),
]
PRODUCT_DOWNLOADS['token_swap_fee'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-swap-cli-v{ver}.tar.gz",
        description="Token Swap CLI — command-line token swap tool",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=5.0,
        install_command="pip install quranchain-swap",
    ),
]
PRODUCT_DOWNLOADS['token_enterprise_pack'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-enterprise-wallet-v{ver}.tar.gz",
        description="Enterprise Wallet — institutional-grade wallet with custody features",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="2.0.0", size_mb=80.0,
        install_command="./install-enterprise-wallet.sh",
    ),
]
PRODUCT_DOWNLOADS['token_starter_pack'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-starter-wallet-v{ver}.tar.gz",
        description="Starter Wallet — lightweight wallet for new users",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="2.0.0", size_mb=30.0,
        install_command="./install-starter-wallet.sh",
    ),
]

# ---------------------------------------------------------------------------
# AI AGENT SCHOOL PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['ai_school_student'] = _core_downloads() + [
    DownloadFile(
        filename="ai-agent-school-student-v{ver}.tar.gz",
        description="AI Agent School Student Kit — training modules, sandbox, and practice labs",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=120.0,
        install_command="./install-ai-school.sh --tier student",
        min_hardware={"ram_mb": 4096, "disk_mb": 20000, "cpu_cores": 2},
    ),
]
PRODUCT_DOWNLOADS['ai_school_enterprise'] = _core_downloads() + [
    DownloadFile(
        filename="ai-agent-school-enterprise-v{ver}.tar.gz",
        description="AI Agent School Enterprise Fleet — bulk agent training & deployment",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=350.0,
        install_command="./install-ai-school.sh --tier enterprise --fleet",
        min_hardware={"ram_mb": 32768, "disk_mb": 100000, "cpu_cores": 16},
    ),
]
PRODUCT_DOWNLOADS['ai_school_hiring'] = _core_downloads() + [
    DownloadFile(
        filename="ai-agent-deployment-kit-v{ver}.tar.gz",
        description="AI Agent Deployment Kit — deploy hired AI agents to your infrastructure",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=85.0,
        install_command="./deploy-ai-agent.sh --agent-id YOUR_AGENT",
        min_hardware={"ram_mb": 8192, "disk_mb": 50000, "cpu_cores": 4},
    ),
]
PRODUCT_DOWNLOADS['ai_school_training_module'] = _core_downloads() + [
    DownloadFile(
        filename="ai-training-module-v{ver}.tar.gz",
        description="AI Training Module — individual AI skill training package",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=25.0,
        install_command="pip install quranchain-ai-training",
    ),
]
PRODUCT_DOWNLOADS['ai_school_nft_cert'] = _core_downloads() + [
    DownloadFile(
        filename="ai-nft-certification-verifier-v{ver}.tar.gz",
        description="AI NFT Certification Verifier — verify and display AI certifications",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=8.0,
        install_command="pip install quranchain-cert-verify",
    ),
]

# ---------------------------------------------------------------------------
# DARPAY CRYPTO PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['darpay_merchant_basic'] = _core_downloads() + [
    DownloadFile(
        filename="darpay-merchant-sdk-basic-v{ver}.tar.gz",
        description="DarPay Merchant SDK — accept crypto payments on your website/app",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=15.0,
        install_command="npm install @darpay/merchant-sdk && pip install darpay-sdk",
    ),
]
PRODUCT_DOWNLOADS['darpay_merchant_enterprise'] = _core_downloads() + [
    DownloadFile(
        filename="darpay-enterprise-gateway-v{ver}.tar.gz",
        description="DarPay Enterprise Gateway — dedicated payment processing node",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=95.0,
        install_command="./install-darpay-gateway.sh --enterprise",
        min_hardware={"ram_mb": 8192, "disk_mb": 50000, "cpu_cores": 4},
    ),
]
PRODUCT_DOWNLOADS['darpay_invoice_fee'] = _core_downloads() + [
    DownloadFile(
        filename="darpay-invoice-cli-v{ver}.tar.gz",
        description="DarPay Invoice CLI — generate and send crypto invoices",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=6.0,
        install_command="pip install darpay-invoice",
    ),
]
PRODUCT_DOWNLOADS['darpay_crypto_fiat_bridge'] = _core_downloads() + [
    DownloadFile(
        filename="darpay-crypto-fiat-bridge-v{ver}.tar.gz",
        description="DarPay Crypto-Fiat Bridge — convert between crypto and fiat currencies",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=70.0,
        install_command="./install-darpay-bridge.sh",
        min_hardware={"ram_mb": 4096, "disk_mb": 20000, "cpu_cores": 2},
    ),
]

# ---------------------------------------------------------------------------
# REVENUE TRACKING PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['revenue_api'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-revenue-api-client-v{ver}.tar.gz",
        description="Revenue Tracking API Client — integrate revenue analytics into your apps",
        download_type=DownloadType.API_CLIENT,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=8.0,
        install_command="pip install quranchain-revenue-api && npm install @quranchain/revenue-client",
    ),
]
PRODUCT_DOWNLOADS['analytics_dashboard'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-analytics-dashboard-v{ver}.tar.gz",
        description="Analytics Dashboard Pro — full analytics dashboard with real-time data",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=55.0,
        install_command="./install-analytics-dashboard.sh",
    ),
]
PRODUCT_DOWNLOADS['block_explorer_pro'] = _core_downloads() + [
    DownloadFile(
        filename="quranchain-block-explorer-pro-v{ver}.tar.gz",
        description="Block Explorer Pro — advanced block explorer with search and analytics",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=40.0,
        install_command="./install-block-explorer.sh",
    ),
]

# ---------------------------------------------------------------------------
# FULL NODE
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['full_node_hosting'] = _core_downloads() + [
    DownloadFile(
        filename="quranchaind-full-node-v{ver}.tar.gz",
        description="QuranChain Full Node — complete blockchain node with all history",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.LINUX_ARM64],
        version="5.2.0", size_mb=250.0,
        install_command="./install-full-node.sh --sync fast",
        min_hardware={"ram_mb": 16384, "disk_mb": 1000000, "cpu_cores": 8},
    ),
]

# ---------------------------------------------------------------------------
# MUSLIM WALLET PRODUCTS
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['muslim_wallet_basic'] = _core_downloads() + [
    DownloadFile(
        filename="muslim-wallet-basic-v{ver}.tar.gz",
        description="Muslim Wallet Basic — halal-compliant digital wallet",
        download_type=DownloadType.MOBILE_APP,
        platforms=[HardwarePlatform.ANDROID_ARM64, HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=28.0,
        install_command="./install-muslim-wallet.sh --tier basic",
    ),
]
PRODUCT_DOWNLOADS['muslim_wallet_pro'] = _core_downloads() + [
    DownloadFile(
        filename="muslim-wallet-pro-v{ver}.tar.gz",
        description="Muslim Wallet Pro — DeFi, investment, and advanced wallet features",
        download_type=DownloadType.MOBILE_APP,
        platforms=[HardwarePlatform.ANDROID_ARM64, HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=42.0,
        install_command="./install-muslim-wallet.sh --tier pro",
    ),
]
PRODUCT_DOWNLOADS['muslim_wallet_enterprise'] = _core_downloads() + [
    DownloadFile(
        filename="muslim-wallet-enterprise-v{ver}.tar.gz",
        description="Muslim Wallet Enterprise — institutional custody and management",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.DOCKER],
        version="1.0.0", size_mb=80.0,
        install_command="./install-muslim-wallet.sh --tier enterprise",
        min_hardware={"ram_mb": 4096, "disk_mb": 20000, "cpu_cores": 2},
    ),
]
PRODUCT_DOWNLOADS['muslim_wallet_tx_fee'] = _core_downloads() + [
    DownloadFile(
        filename="muslim-wallet-cli-v{ver}.tar.gz",
        description="Muslim Wallet CLI — command-line wallet operations",
        download_type=DownloadType.CLI_TOOL,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=5.0,
        install_command="pip install muslim-wallet-cli",
    ),
]

# ---------------------------------------------------------------------------
# DAR AL-NAS BANKING / FINTECH
# ---------------------------------------------------------------------------
_dar_banking_core = _core_downloads() + [
    DownloadFile(
        filename="daralnas-banking-app-v{ver}.tar.gz",
        description="Dar Al-Nas Banking App — Sharia-compliant mobile/desktop banking",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64, HardwarePlatform.ANDROID_ARM64],
        version="1.0.0", size_mb=55.0,
        install_command="./install-daralnas-banking.sh",
    ),
]
PRODUCT_DOWNLOADS['debit_card_standard'] = _dar_banking_core
PRODUCT_DOWNLOADS['debit_card_premium'] = _dar_banking_core
PRODUCT_DOWNLOADS['virtual_card'] = _dar_banking_core
PRODUCT_DOWNLOADS['gold_savings'] = _dar_banking_core + [
    DownloadFile(
        filename="daralnas-gold-tracker-v{ver}.tar.gz",
        description="Gold Savings Tracker — real-time gold price tracking & portfolio management",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=20.0,
        install_command="./install-gold-tracker.sh",
    ),
]
PRODUCT_DOWNLOADS['halal_etf'] = _dar_banking_core + [
    DownloadFile(
        filename="daralnas-halal-etf-screener-v{ver}.tar.gz",
        description="Halal ETF Screener — Sharia-compliance verification for investments",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=18.0,
        install_command="./install-halal-screener.sh",
    ),
]
PRODUCT_DOWNLOADS['sukuk_bond'] = _dar_banking_core

# ---------------------------------------------------------------------------
# HEALTHCARE / TAKAFUL
# ---------------------------------------------------------------------------
_healthcare_core = _core_downloads() + [
    DownloadFile(
        filename="daralnas-health-app-v{ver}.tar.gz",
        description="Dar Al-Nas Health App — Islamic healthcare management portal",
        download_type=DownloadType.MOBILE_APP,
        platforms=[HardwarePlatform.ANDROID_ARM64, HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=45.0,
        install_command="./install-daralnas-health.sh",
    ),
]
PRODUCT_DOWNLOADS['healthcare_basic'] = _healthcare_core
PRODUCT_DOWNLOADS['healthcare_premium'] = _healthcare_core
PRODUCT_DOWNLOADS['healthcare_family'] = _healthcare_core
PRODUCT_DOWNLOADS['takaful_life'] = _healthcare_core + [
    DownloadFile(
        filename="daralnas-takaful-manager-v{ver}.tar.gz",
        description="Takaful Insurance Manager — policy management and claims",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=30.0,
        install_command="./install-takaful-manager.sh",
    ),
]
PRODUCT_DOWNLOADS['takaful_property'] = PRODUCT_DOWNLOADS['takaful_life']
PRODUCT_DOWNLOADS['takaful_business'] = PRODUCT_DOWNLOADS['takaful_life']

# ---------------------------------------------------------------------------
# REAL ESTATE
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['reit_investment'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-reit-portal-v{ver}.tar.gz",
        description="Halal REIT Investment Portal — manage Islamic real estate investments",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=35.0,
        install_command="./install-reit-portal.sh",
    ),
]
PRODUCT_DOWNLOADS['property_search'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-property-finder-v{ver}.tar.gz",
        description="Property Finder — halal-certified property search with map view",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64, HardwarePlatform.ANDROID_ARM64],
        version="1.0.0", size_mb=30.0,
        install_command="./install-property-finder.sh",
    ),
]

# ---------------------------------------------------------------------------
# CHARITY / ISLAMIC FINANCE
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['zakat_service'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-zakat-calculator-v{ver}.tar.gz",
        description="Zakat Calculator & Distributor — automated zakat calculation and payment",
        download_type=DownloadType.MOBILE_APP,
        platforms=[HardwarePlatform.ANDROID_ARM64, HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=15.0,
        install_command="./install-zakat-calculator.sh",
    ),
]
PRODUCT_DOWNLOADS['sadaqah_donation'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-sadaqah-app-v{ver}.tar.gz",
        description="Sadaqah Donation App — easy charitable giving with impact tracking",
        download_type=DownloadType.MOBILE_APP,
        platforms=[HardwarePlatform.ANDROID_ARM64, HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=12.0,
        install_command="./install-sadaqah-app.sh",
    ),
]
PRODUCT_DOWNLOADS['waqf_endowment'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-waqf-portal-v{ver}.tar.gz",
        description="Waqf Endowment Portal — manage Islamic endowment contributions",
        download_type=DownloadType.DESKTOP_APP,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=25.0,
        install_command="./install-waqf-portal.sh",
    ),
]

# ---------------------------------------------------------------------------
# SHARIA & CONSULTING
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['sharia_advisory'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-sharia-advisory-toolkit-v{ver}.tar.gz",
        description="Sharia Advisory Toolkit — compliance checking tools and guidelines",
        download_type=DownloadType.SDK,
        platforms=list(HardwarePlatform),
        version="1.0.0", size_mb=20.0,
        install_command="pip install daralnas-sharia-tools",
    ),
]
PRODUCT_DOWNLOADS['sharia_audit'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-sharia-audit-suite-v{ver}.tar.gz",
        description="Sharia Compliance Audit Suite — full audit tools with report generation",
        download_type=DownloadType.FULL_INSTALLER,
        platforms=[HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=45.0,
        install_command="./install-sharia-audit.sh",
    ),
]

# ---------------------------------------------------------------------------
# TELEHEALTH
# ---------------------------------------------------------------------------
PRODUCT_DOWNLOADS['telehealth_consultation'] = _core_downloads() + [
    DownloadFile(
        filename="daralnas-telehealth-client-v{ver}.tar.gz",
        description="Telehealth Client — video consultations with Islamic healthcare providers",
        download_type=DownloadType.MOBILE_APP,
        platforms=[HardwarePlatform.ANDROID_ARM64, HardwarePlatform.LINUX_X86_64, HardwarePlatform.MACOS_ARM64, HardwarePlatform.WINDOWS_X86_64],
        version="1.0.0", size_mb=35.0,
        install_command="./install-telehealth-client.sh",
    ),
]


# ============================================================================
# DOWNLOAD PACKAGE GENERATION
# ============================================================================

def generate_install_script(product_key: str) -> str:
    """Generate a product-specific install script that includes Fungi Mesh setup"""
    downloads = PRODUCT_DOWNLOADS.get(product_key, [])
    if not downloads:
        return ""

    script = f"""#!/bin/bash
# ============================================================================
# QuranChain™ Product Installer — {product_key}
# Includes: Fungi Mesh Node + MeshTalk Lite + QuranChain Light Client
# © 2026 QuranChain™ — Omar Mohammad Abunadi™
# ============================================================================
set -e

echo "🍄 QuranChain Product Installer — {product_key}"
echo "================================================="
echo ""

# Detect platform
ARCH=$(uname -m)
OS=$(uname -s | tr '[:upper:]' '[:lower:]')
if [[ "$ARCH" == "x86_64" ]]; then
    PLATFORM="${{OS}}-x86_64"
elif [[ "$ARCH" == "aarch64" || "$ARCH" == "arm64" ]]; then
    PLATFORM="${{OS}}-arm64"
elif [[ "$ARCH" == "armv7l" ]]; then
    PLATFORM="${{OS}}-armv7"
else
    echo "Unsupported architecture: $ARCH"
    exit 1
fi

echo "📋 Detected platform: $PLATFORM"
echo ""

# Step 1: Install Fungi Mesh Node
echo "🍄 Step 1/4: Installing Fungi Mesh Network Node v{FUNGI_MESH_VERSION}..."
curl -sSL {DOWNLOADS_BASE_URL}/fungi-mesh-node-${{PLATFORM}}-v{FUNGI_MESH_VERSION}.tar.gz | tar xz -C /opt/quranchain/
/opt/quranchain/fungi-mesh/configure.sh --auto-join --hub {FUNGI_MESH_ENDPOINT}
echo "✅ Fungi Mesh Node installed and connected to global network"
echo ""

# Step 2: Install MeshTalk Lite
echo "📡 Step 2/4: Installing MeshTalk OS Lite v{MESHTALK_LITE_VERSION}..."
curl -sSL {DOWNLOADS_BASE_URL}/meshtalk-lite-${{PLATFORM}}-v{MESHTALK_LITE_VERSION}.tar.gz | tar xz -C /opt/quranchain/
/opt/quranchain/meshtalk-lite/configure.sh --mesh-auto
echo "✅ MeshTalk Lite installed — peer-to-peer communication active"
echo ""

# Step 3: Install QuranChain Light Client
echo "🔗 Step 3/4: Installing QuranChain Light Client v{QURANCHAIN_LIGHT_VERSION}..."
curl -sSL {DOWNLOADS_BASE_URL}/quranchain-light-${{PLATFORM}}-v{QURANCHAIN_LIGHT_VERSION}.tar.gz | tar xz -C /opt/quranchain/
/opt/quranchain/quranchain-light/configure.sh --hub {HUB_ENDPOINT}
echo "✅ QuranChain Light Client synced"
echo ""

# Step 4: Install product-specific software
echo "📦 Step 4/4: Installing product software..."
"""

    for dl in downloads:
        if dl.filename.startswith("fungi-mesh") or dl.filename.startswith("meshtalk-lite") or dl.filename.startswith("quranchain-light"):
            continue
        script += f"""
echo "   Installing: {dl.description}"
curl -sSL {dl.download_url} | tar xz -C /opt/quranchain/
"""

    script += f"""
# Start services
echo ""
echo "🚀 Starting all services..."
systemctl enable --now quranchain-fungi-mesh 2>/dev/null || /opt/quranchain/fungi-mesh/start.sh &
systemctl enable --now quranchain-meshtalk 2>/dev/null || /opt/quranchain/meshtalk-lite/start.sh &
systemctl enable --now quranchain-light 2>/dev/null || /opt/quranchain/quranchain-light/start.sh &

echo ""
echo "============================================="
echo "✅ Installation Complete!"
echo "🍄 Fungi Mesh Node: CONNECTED to global mesh"
echo "📡 MeshTalk Lite: ACTIVE"
echo "🔗 QuranChain Light: SYNCED"
echo "📦 Product: {product_key} — READY"
echo "👑 Founder Royalty: 30% (IMMUTABLE)"
echo "============================================="
"""
    return script


def generate_docker_compose(product_key: str) -> str:
    """Generate Docker Compose for product deployment"""
    return f"""# QuranChain™ Product Docker Compose — {product_key}
# Includes Fungi Mesh Node for network expansion
# © 2026 QuranChain™ — Omar Mohammad Abunadi™

version: '3.8'

services:
  fungi-mesh-node:
    image: quranchain/fungi-mesh-node:{FUNGI_MESH_VERSION}
    container_name: fungi-mesh-{product_key}
    restart: always
    ports:
      - "5006:5006"
      - "5007:5007"
    environment:
      - MESH_AUTO_JOIN=true
      - MESH_HUB={FUNGI_MESH_ENDPOINT}
      - FOUNDER_ROYALTY=0.30
    volumes:
      - fungi_mesh_data:/data/fungi-mesh
    networks:
      - quranchain

  meshtalk-lite:
    image: quranchain/meshtalk-lite:{MESHTALK_LITE_VERSION}
    container_name: meshtalk-{product_key}
    restart: always
    depends_on:
      - fungi-mesh-node
    environment:
      - MESH_NODE=fungi-mesh-node:5006
    volumes:
      - meshtalk_data:/data/meshtalk
    networks:
      - quranchain

  quranchain-light:
    image: quranchain/quranchain-light:{QURANCHAIN_LIGHT_VERSION}
    container_name: qchain-{product_key}
    restart: always
    depends_on:
      - fungi-mesh-node
    ports:
      - "26657:26657"
    environment:
      - HUB_ENDPOINT={HUB_ENDPOINT}
      - FUNGI_MESH=fungi-mesh-node:5006
    volumes:
      - quranchain_data:/data/quranchain
    networks:
      - quranchain

  {product_key.replace('_', '-')}:
    image: quranchain/{product_key.replace('_', '-')}:latest
    container_name: {product_key.replace('_', '-')}
    restart: always
    depends_on:
      - fungi-mesh-node
      - quranchain-light
    environment:
      - FUNGI_MESH_NODE=fungi-mesh-node:5006
      - QURANCHAIN_NODE=quranchain-light:26657
      - FOUNDER_ROYALTY=0.30
    networks:
      - quranchain

volumes:
  fungi_mesh_data:
  meshtalk_data:
  quranchain_data:

networks:
  quranchain:
    driver: bridge
"""


# ============================================================================
# QUERY FUNCTIONS
# ============================================================================

def get_downloads_for_product(product_key: str) -> List[DownloadFile]:
    """Get all download files for a product"""
    return PRODUCT_DOWNLOADS.get(product_key, _core_downloads())


def get_all_product_downloads() -> Dict[str, List[DownloadFile]]:
    """Get the complete download catalog"""
    return PRODUCT_DOWNLOADS


def get_download_summary() -> Dict:
    """Get download catalog summary"""
    total_products = len(PRODUCT_DOWNLOADS)
    total_files = sum(len(files) for files in PRODUCT_DOWNLOADS.values())
    total_size_mb = sum(
        sum(f.size_mb for f in files)
        for files in PRODUCT_DOWNLOADS.values()
    )
    fungi_mesh_products = sum(
        1 for files in PRODUCT_DOWNLOADS.values()
        if any(f.includes_fungi_mesh for f in files)
    )

    return {
        'total_products_with_downloads': total_products,
        'total_download_files': total_files,
        'total_size_mb': round(total_size_mb, 1),
        'products_with_fungi_mesh': fungi_mesh_products,
        'fungi_mesh_coverage_pct': round(fungi_mesh_products / max(total_products, 1) * 100, 1),
        'supported_platforms': len(HardwarePlatform),
        'fungi_mesh_version': FUNGI_MESH_VERSION,
        'meshtalk_version': MESHTALK_LITE_VERSION,
        'quranchain_light_version': QURANCHAIN_LIGHT_VERSION,
    }


def get_products_missing_downloads(all_product_keys: List[str]) -> List[str]:
    """Find products that don't have downloads yet"""
    return [k for k in all_product_keys if k not in PRODUCT_DOWNLOADS]


def generate_all_install_scripts() -> Dict[str, str]:
    """Generate install scripts for all products"""
    return {key: generate_install_script(key) for key in PRODUCT_DOWNLOADS}


def generate_all_docker_compose() -> Dict[str, str]:
    """Generate Docker Compose files for all products"""
    return {key: generate_docker_compose(key) for key in PRODUCT_DOWNLOADS}


# ============================================================================
# MODULE INITIALIZATION
# ============================================================================

logger.info(f"📦 Product Download Catalog loaded: {len(PRODUCT_DOWNLOADS)} products with downloads")
logger.info(f"   🍄 Fungi Mesh bundled: 100% of products")
logger.info(f"   📡 MeshTalk Lite bundled: 100% of products")
logger.info(f"   🔗 QuranChain Light Client bundled: 100% of products")
logger.info(f"   🖥️  Supported platforms: {len(HardwarePlatform)}")
