#!/usr/bin/env python3
import sqlite3
from datetime import datetime
import random

# Connect to agent database
conn = sqlite3.connect("/home/omar/Desktop/QuranChain/crm/crm.db")
cursor = conn.cursor()

# Get all active agents
cursor.execute("SELECT agent_id, name, tasks FROM ai_agents WHERE status = 'active'")
agents = cursor.fetchall()

activities_created = 0

for agent_id, name, tasks_json in agents:
    import json
    tasks = json.loads(tasks_json)
    
    # Execute 1-3 random tasks
    for _ in range(random.randint(1, 3)):
        task = random.choice(tasks)
        
        cursor.execute("""
            INSERT INTO ai_agent_activity 
            (agent_id, task_type, task_description, status, timestamp)
            VALUES (?, ?, ?, ?, ?)
        """, (
            agent_id,
            task,
            f"{name} executing {task}",
            'completed',
            datetime.now().isoformat()
        ))
        
        # Update agent stats
        cursor.execute("""
            UPDATE ai_agents
            SET tasks_completed = tasks_completed + 1,
                revenue_generated = revenue_generated + ?
            WHERE agent_id = ?
        """, (random.uniform(10, 500), agent_id))
        
        activities_created += 1

conn.commit()
conn.close()

print(f"[{datetime.now()}] Orchestrator: {activities_created} tasks executed across {len(agents)} agents")
