#!/usr/bin/env python3
"""
$1 Apartment Option Takeover - Usage Example
Demonstrates how to use the strategy engines with real property data
"""

import json
from dollar_option_strategy import (
    DollarOptionScoringEngine,
    DealIdentificationEngine,
    DealStructuringEngine
)

# ============================================================================
# SAMPLE PROPERTY DATA
# ============================================================================

SAMPLE_PROPERTIES = [
    {
        "id": "prop_001",
        "name": "Sunnyvale Apartments",
        "address": "123 Main St, Memphis TN 38101",
        "type": "multifamily",
        "units": 64,
        "condition": "structurally_sound_needs_management",
        "estimated_price": 3200000,
        "avg_monthly_rent": 950,
        "comparable_market_rent": 1200,
        "below_market_rent_pct": 0.208,
        "vacancy_rate": 0.15,
        "cap_rate": 0.0625,
        "debt_service_coverage_ratio": 1.08,
        "days_on_market": 156,
        "market_tier": "USA_tier2",
        "seller_type": "mom_and_pop",
        "listing_description": "Motivated seller relocating. Bring all offers. Stabilization opportunity. Owner financing possible.",
    },
    {
        "id": "prop_002",
        "name": "Downtown Lofts",
        "address": "456 Commerce Ave, Nashville TN 37201",
        "type": "multifamily",
        "units": 48,
        "condition": "cosmetic_rehab",
        "estimated_price": 2400000,
        "avg_monthly_rent": 1100,
        "comparable_market_rent": 1350,
        "below_market_rent_pct": 0.185,
        "vacancy_rate": 0.12,
        "cap_rate": 0.0688,
        "debt_service_coverage_ratio": 1.12,
        "days_on_market": 108,
        "market_tier": "USA_tier2",
        "seller_type": "small_partners",
        "listing_description": "Partnership dissolving. Bring all offers. Excellent bones needs cosmetic rehab.",
    },
    {
        "id": "prop_003",
        "name": "Riverside Residences",
        "address": "789 Riverside Dr, Austin TX 78704",
        "type": "multifamily",
        "units": 85,
        "condition": "good",
        "estimated_price": 4750000,
        "avg_monthly_rent": 1200,
        "comparable_market_rent": 1320,
        "below_market_rent_pct": 0.091,
        "vacancy_rate": 0.08,
        "cap_rate": 0.0758,
        "debt_service_coverage_ratio": 1.25,
        "days_on_market": 45,
        "market_tier": "USA_tier2",
        "seller_type": "institutional",
        "listing_description": "Professional property. Strong fundamentals. Move-in ready.",
    },
    {
        "id": "prop_004",
        "name": "Oak Lawn Residences",
        "address": "321 Oak St, Dallas TX 75204",
        "type": "multifamily",
        "units": 72,
        "condition": "structurally_sound_needs_management",
        "estimated_price": 3600000,
        "avg_monthly_rent": 1050,
        "comparable_market_rent": 1350,
        "below_market_rent_pct": 0.222,
        "vacancy_rate": 0.18,
        "cap_rate": 0.0583,
        "debt_service_coverage_ratio": 1.05,
        "days_on_market": 187,
        "market_tier": "USA_tier2",
        "seller_type": "estate_heirs",
        "listing_description": "Estate property. Bring all offers. Owner financing. Inherited by heirs.",
    },
    {
        "id": "prop_005",
        "name": "Park Plaza Apartments",
        "address": "555 Park Ave, Charlotte NC 28202",
        "type": "multifamily",
        "units": 56,
        "condition": "fair",
        "estimated_price": 2800000,
        "avg_monthly_rent": 975,
        "comparable_market_rent": 1200,
        "below_market_rent_pct": 0.188,
        "vacancy_rate": 0.20,
        "cap_rate": 0.0629,
        "debt_service_coverage_ratio": 1.10,
        "days_on_market": 132,
        "market_tier": "USA_tier2",
        "seller_type": "mom_and_pop",
        "listing_description": "Value add opportunity. Owner relocating. Under managed property.",
    },
]

# ============================================================================
# EXAMPLE 1: Score Individual Properties
# ============================================================================

def example_1_score_properties():
    """Example 1: Score each property individually"""
    print("\n" + "="*70)
    print("EXAMPLE 1: SCORE INDIVIDUAL PROPERTIES")
    print("="*70 + "\n")

    scoring_engine = DollarOptionScoringEngine()

    for prop in SAMPLE_PROPERTIES:
        property_metrics = {
            "current_cap_rate": prop.get("cap_rate", 0),
            "below_market_rent_pct": prop.get("below_market_rent_pct", 0),
            "vacancy_rate": prop.get("vacancy_rate", 0),
            "debt_service_coverage_ratio": prop.get("debt_service_coverage_ratio", 1.25),
        }

        seller_motivation = {
            "seller_type": prop.get("seller_type"),
            "signals": [],  # Would detect from listing text
        }

        market = {
            "tier": prop.get("market_tier"),
            "population_growth_pct": 0.025,
        }

        structure = {
            "option_price": 1,
            "option_term_days": 90,
            "assignable": True,
        }

        score_result = scoring_engine.calculate_overall_score(
            property_metrics, seller_motivation, market, structure
        )

        print(f"📍 {prop['name']} ({prop['address']})")
        print(f"   Units: {prop['units']} | Price: ${prop['estimated_price']:,}")
        print(f"   Overall Score: {score_result['overall_score']:.1f}")
        print(f"   Rating: {score_result['deal_rating']}")
        print(f"   Breakdown: Financial={score_result['score_breakdown']['property_financials']:.1f}, "
              f"Seller={score_result['score_breakdown']['seller_motivation']:.1f}, "
              f"Market={score_result['score_breakdown']['market_opportunity']:.1f}")
        print()

# ============================================================================
# EXAMPLE 2: Filter and Score Batch
# ============================================================================

def example_2_filter_and_score():
    """Example 2: Filter and score entire batch"""
    print("\n" + "="*70)
    print("EXAMPLE 2: FILTER AND SCORE BATCH")
    print("="*70 + "\n")

    identification_engine = DealIdentificationEngine()

    # Filter by specs
    filtered = identification_engine.filter_by_property_specs(SAMPLE_PROPERTIES)
    print(f"✓ Filtered: {len(filtered)} properties from {len(SAMPLE_PROPERTIES)} by specs\n")

    # Score deals
    scored_deals = identification_engine.score_potential_deals(filtered, min_score_threshold=60)
    print(f"✓ Scored: {len(scored_deals)} high-quality deals found\n")

    # Display results
    print("TOP SCORED DEALS:\n")
    for i, deal in enumerate(scored_deals[:5], 1):
        prop = deal["property"]
        score_info = deal["score_analysis"]
        print(f"{i}. {prop['name']}")
        print(f"   Score: {score_info['overall_score']:.1f} - {score_info['deal_rating']}")
        print(f"   Units: {prop['units']} | Price: ${prop['estimated_price']:,}")
        print(f"   Below-Market Rent: {prop['below_market_rent_pct']*100:.1f}%")
        print(f"   Vacancy: {prop['vacancy_rate']*100:.1f}% | Cap Rate: {prop['cap_rate']*100:.2f}%")
        print()

# ============================================================================
# EXAMPLE 3: Full Deal Structuring
# ============================================================================

def example_3_full_deal_structure():
    """Example 3: Structure best deal completely"""
    print("\n" + "="*70)
    print("EXAMPLE 3: FULL DEAL STRUCTURING")
    print("="*70 + "\n")

    identification_engine = DealIdentificationEngine()
    structuring_engine = DealStructuringEngine()

    # Find best deal
    filtered = identification_engine.filter_by_property_specs(SAMPLE_PROPERTIES)
    scored_deals = identification_engine.score_potential_deals(filtered, min_score_threshold=60)

    if not scored_deals:
        print("No qualified deals found")
        return

    best_deal = scored_deals[0]
    prop = best_deal["property"]

    # Structure the deal
    structure = structuring_engine.build_option_structure(best_deal)
    returns = structuring_engine.calculate_project_returns(best_deal)

    print(f"🏆 BEST DEAL: {prop['name']}")
    print(f"   Location: {prop['address']}")
    print(f"   Score: {best_deal['score_analysis']['overall_score']:.1f}\n")

    print("DEAL STRUCTURE:")
    print(f"  • Instrument: {structure['instrument']}")
    print(f"  • Consideration: {structure['consideration']}")
    print(f"  • Strike Price: ${structure['strike_price']:,}")
    print(f"  • Option Term: {structure['option_term_days']} days")
    print(f"  • Assignable: {'Yes' if structure['is_assignable'] else 'No'}\n")

    print("OPTION PERIOD TASKS:")
    for task in structure['option_period_tasks'][:3]:
        print(f"  • {task['task']} ({task['duration_days']} days)")
    print(f"  • ... and {len(structure['option_period_tasks']) - 3} more tasks\n")

    print("EXIT STRATEGIES:")
    for exit_path in structure['exit_paths'][:3]:
        print(f"  • {exit_path['exit_path']}")
        print(f"    - Capital: ${exit_path.get('capital_required', 'N/A')}")
        print(f"    - Timeline: {exit_path.get('timeline', 'Flexible')}")
    print(f"  • ... and {len(structure['exit_paths']) - 3} more path\n")

    print("PROJECTED RETURNS:")
    print(f"  • Purchase Price: ${returns['purchase_price']:,}")
    print(f"  • Stabilized NOI (Annual): ${returns['stabilized_noi_annual']:,}")
    print(f"  • Founder Royalty (Annual): ${returns['founder_royalty_annual']:,}")
    print(f"  • Refinance Opportunity: ${returns['refinance_opportunity']['available_proceeds']:,}")
    print(f"  • Founder Royalty from Refi: ${returns['refinance_opportunity']['founder_royalty_from_refi']:,}")
    print(f"  • Total Year 1 Founder Royalty: ${returns['total_founder_royalty_year_1']:,}\n")

    print("FOUNDER ROYALTY:")
    print(f"  • Founder: {structure['founder_royalty']['founder']}")
    print(f"  • Signature: {structure['founder_royalty']['signature']}")
    print(f"  • Rate: {structure['founder_royalty']['rate_pct']}%")
    print(f"  • Settlement: {structure['founder_royalty']['settlement']}\n")

# ============================================================================
# EXAMPLE 4: Market Comparison
# ============================================================================

def example_4_market_comparison():
    """Example 4: Compare deals across markets"""
    print("\n" + "="*70)
    print("EXAMPLE 4: MARKET COMPARISON")
    print("="*70 + "\n")

    # Group by market
    markets = {}
    for prop in SAMPLE_PROPERTIES:
        market = prop.get("market_tier", "Unknown")
        if market not in markets:
            markets[market] = []
        markets[market].append(prop)

    print("PROPERTIES BY MARKET:\n")
    for market, props in markets.items():
        print(f"📍 {market}: {len(props)} properties")
        for prop in props:
            print(f"   • {prop['name']} - {prop['units']} units @ "
                  f"${prop['estimated_price']:,} ({prop['cap_rate']*100:.2f}% cap)")
        print()

# ============================================================================
# EXAMPLE 5: API-Style Request/Response
# ============================================================================

def example_5_api_request_response():
    """Example 5: API request/response format"""
    print("\n" + "="*70)
    print("EXAMPLE 5: API REQUEST/RESPONSE FORMAT")
    print("="*70 + "\n")

    # Simulated API request
    api_request = {
        "skill": "dollar_option_takeover",
        "objective": "Find $1 option opportunities in USA Tier 2 markets",
        "parameters": {
            "location": "USA_tier2",
            "min_units": 40,
            "max_units": 100,
            "min_cap_rate": 0.05,
            "properties": SAMPLE_PROPERTIES[:3],  # First 3 properties
        }
    }

    print("API REQUEST:")
    print(json.dumps(api_request, indent=2)[:500] + "...\n")

    # Process through engines
    identification_engine = DealIdentificationEngine()
    filtered = identification_engine.filter_by_property_specs(SAMPLE_PROPERTIES[:3])
    scored_deals = identification_engine.score_potential_deals(filtered, min_score_threshold=60)

    # Simulated API response (simplified)
    if scored_deals:
        best = scored_deals[0]
        api_response = {
            "id": "analysis_20251210_001",
            "skill": "dollar_option_takeover",
            "objective": api_request["objective"],
            "summary": f"Analyzed {len(SAMPLE_PROPERTIES[:3])} properties - "
                      f"{len(scored_deals)} qualified opportunities found",
            "raw_model": {
                "properties_analyzed": len(SAMPLE_PROPERTIES[:3]),
                "high_quality_deals": len(scored_deals),
                "top_deal": {
                    "name": best["property"]["name"],
                    "score": best["score_analysis"]["overall_score"],
                    "rating": best["score_analysis"]["deal_rating"],
                }
            }
        }

        print("API RESPONSE (sample):")
        print(json.dumps(api_response, indent=2))

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print("\n" + "╔" + "="*68 + "╗")
    print("║  $1 APARTMENT OPTION TAKEOVER - USAGE EXAMPLES              ║")
    print("║  Founder: Omar Mohammad Abunadi™                           ║")
    print("║  Signature: OMAR-QURANCHAIN-SOVEREIGN-FOUNDER-10PCT-ROYALTY║")
    print("╚" + "="*68 + "╝")

    # Run all examples
    example_1_score_properties()
    example_2_filter_and_score()
    example_3_full_deal_structure()
    example_4_market_comparison()
    example_5_api_request_response()

    print("\n" + "="*70)
    print("✅ ALL EXAMPLES COMPLETED")
    print("="*70)
    print("\nTo use with Real Estate General service:")
    print("  $ python3 real_estate_general.py")
    print("  $ curl -X POST http://localhost:8102/run_skill \\")
    print("      -H 'Content-Type: application/json' \\")
    print("      -d '{\"skill\": \"dollar_option_takeover\", ...}'")
    print()
