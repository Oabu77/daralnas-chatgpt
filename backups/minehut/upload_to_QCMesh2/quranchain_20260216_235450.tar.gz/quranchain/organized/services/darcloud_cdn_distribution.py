#!/usr/bin/env python3
"""
🌐 DARCLOUD CDN DISTRIBUTION SYSTEM
Content delivery network across MeshTalk OS and Fungi Mesh nodes
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import json
import time
import logging
import requests
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
import uvicorn

# Add project root to path
sys.path.insert(0, "/home/omar/Desktop/QuranChain")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] 🌐 CDN - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="DarCloud CDN Distribution System", version="1.0.0")

# CDN storage
CDN_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_cdn")
CDN_DIR.mkdir(exist_ok=True)

class CDNManager:
    """Manages CDN distribution across mesh network"""

    def __init__(self):
        self.nodes = self._get_mesh_nodes()
        self.content_cache = {}
        self.distribution_status = {}
        self.load_cdn_registry()
        logger.info(f"🌐 CDN Manager initialized with {len(self.nodes)} nodes")

    def _get_mesh_nodes(self) -> List[Dict]:
        """Get all mesh network nodes for CDN distribution"""
        # MeshTalk OS nodes (43 nodes)
        meshtalk_nodes = [
            {"id": f"meshtalk_{i}", "ip": f"10.0.0.{i+100}", "type": "meshtalk", "region": "global"}
            for i in range(43)
        ]

        # Fungi Mesh nodes (35 nodes)
        fungi_nodes = [
            {"id": f"fungi_{i}", "ip": f"10.0.1.{i+100}", "type": "fungi", "region": "global"}
            for i in range(35)
        ]

        # QuranChain validator nodes (additional distribution points)
        validator_nodes = [
            {"id": f"validator_{i}", "ip": f"10.0.2.{i+100}", "type": "validator", "region": "global"}
            for i in range(88)
        ]

        return meshtalk_nodes + fungi_nodes + validator_nodes

    def load_cdn_registry(self):
        """Load CDN content registry"""
        registry_file = CDN_DIR / "cdn_registry.json"
        if registry_file.exists():
            try:
                with open(registry_file, 'r') as f:
                    data = json.load(f)
                    self.content_cache = data.get('content_cache', {})
                    self.distribution_status = data.get('distribution_status', {})
                logger.info(f"📋 Loaded CDN registry with {len(self.content_cache)} content items")
            except Exception as e:
                logger.error(f"Failed to load CDN registry: {e}")

    def save_cdn_registry(self):
        """Save CDN content registry"""
        registry_file = CDN_DIR / "cdn_registry.json"
        try:
            data = {
                'content_cache': self.content_cache,
                'distribution_status': self.distribution_status,
                'last_updated': datetime.utcnow().isoformat() + "Z"
            }
            with open(registry_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info("💾 CDN registry saved")
        except Exception as e:
            logger.error(f"Failed to save CDN registry: {e}")

    def distribute_content(self, content_id: str, content_data: bytes, content_type: str = "text/html") -> Dict:
        """Distribute content across CDN nodes"""

        # Store content locally
        content_path = CDN_DIR / content_id
        with open(content_path, 'wb') as f:
            f.write(content_data)

        # Create content metadata
        content_info = {
            "content_id": content_id,
            "content_type": content_type,
            "size": len(content_data),
            "distributed_at": datetime.utcnow().isoformat() + "Z",
            "local_path": str(content_path),
            "cdn_urls": []
        }

        # Distribute to mesh nodes
        distribution_results = self._distribute_to_nodes(content_id, content_data, content_type)

        content_info["distribution_results"] = distribution_results
        content_info["cdn_urls"] = [result["url"] for result in distribution_results if result["success"]]

        self.content_cache[content_id] = content_info
        self.distribution_status[content_id] = {
            "total_nodes": len(self.nodes),
            "successful_distributions": len([r for r in distribution_results if r["success"]]),
            "failed_distributions": len([r for r in distribution_results if not r["success"]]),
            "last_updated": datetime.utcnow().isoformat() + "Z"
        }

        self.save_cdn_registry()

        logger.info(f"🌐 Content {content_id} distributed to {len(content_info['cdn_urls'])} CDN nodes")
        return content_info

    def _distribute_to_nodes(self, content_id: str, content_data: bytes, content_type: str) -> List[Dict]:
        """Distribute content to all mesh nodes"""
        results = []

        for node in self.nodes:
            try:
                # Simulate distribution to node
                # In real implementation, this would use mesh network protocols
                node_url = f"http://{node['ip']}:8080/cdn/{content_id}"

                # For simulation, we'll assume distribution succeeds
                # In production, this would make actual HTTP requests to mesh nodes
                result = {
                    "node_id": node["id"],
                    "node_type": node["type"],
                    "url": node_url,
                    "success": True,
                    "distributed_at": datetime.utcnow().isoformat() + "Z"
                }

                results.append(result)

            except Exception as e:
                logger.warning(f"Failed to distribute {content_id} to {node['id']}: {e}")
                results.append({
                    "node_id": node["id"],
                    "node_type": node["type"],
                    "url": None,
                    "success": False,
                    "error": str(e),
                    "distributed_at": datetime.utcnow().isoformat() + "Z"
                })

        return results

    def get_content_info(self, content_id: str) -> Optional[Dict]:
        """Get content information"""
        return self.content_cache.get(content_id)

    def get_content_urls(self, content_id: str) -> List[str]:
        """Get all CDN URLs for content"""
        content_info = self.get_content_info(content_id)
        if content_info:
            return content_info.get("cdn_urls", [])
        return []

    def purge_content(self, content_id: str) -> bool:
        """Purge content from CDN"""
        if content_id in self.content_cache:
            content_info = self.content_cache[content_id]

            # Remove local file
            try:
                if os.path.exists(content_info["local_path"]):
                    os.remove(content_info["local_path"])
            except Exception as e:
                logger.warning(f"Failed to remove local file for {content_id}: {e}")

            # Remove from cache
            del self.content_cache[content_id]
            if content_id in self.distribution_status:
                del self.distribution_status[content_id]

            self.save_cdn_registry()

            logger.info(f"🗑️ Content {content_id} purged from CDN")
            return True

        return False

    def get_cdn_stats(self) -> Dict:
        """Get CDN statistics"""
        total_content = len(self.content_cache)
        total_nodes = len(self.nodes)
        total_distributions = sum(
            status.get("successful_distributions", 0)
            for status in self.distribution_status.values()
        )

        return {
            "total_content": total_content,
            "total_nodes": total_nodes,
            "total_distributions": total_distributions,
            "average_distributions_per_content": total_distributions / max(total_content, 1),
            "node_types": {
                "meshtalk": len([n for n in self.nodes if n["type"] == "meshtalk"]),
                "fungi": len([n for n in self.nodes if n["type"] == "fungi"]),
                "validator": len([n for n in self.nodes if n["type"] == "validator"])
            }
        }

    def optimize_distribution(self):
        """Optimize content distribution across nodes"""
        # This would implement load balancing and geo-distribution logic
        logger.info("🔄 Optimizing CDN distribution...")

        # For now, just log the optimization
        stats = self.get_cdn_stats()
        logger.info(f"📊 CDN Stats: {stats}")

        # In production, this would redistribute content based on access patterns
        # and node performance metrics

    def list_content(self) -> List[Dict]:
        """List all CDN content"""
        return list(self.content_cache.values())

# Global CDN manager
cdn_manager = CDNManager()

# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.get("/")
def root():
    """DarCloud CDN Distribution Dashboard"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>🌐 DarCloud CDN Distribution System</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .header {{ background: linear-gradient(135deg, #FF9800 0%, #F57C00 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
            .stat-card {{ background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }}
            .stat-number {{ font-size: 2em; font-weight: bold; color: #FF9800; }}
            .content {{ margin-top: 30px; }}
            .content-card {{ background: white; margin: 10px 0; padding: 15px; border-radius: 8px; box-shadow: 0 1px 5px rgba(0,0,0,0.1); }}
            .nodes {{ background: #fff3cd; padding: 15px; border-radius: 8px; margin: 20px 0; }}
            .node-type {{ display: inline-block; background: #FF9800; color: white; padding: 5px 10px; margin: 2px; border-radius: 15px; font-size: 0.9em; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🌐 DarCloud CDN Distribution System</h1>
            <p>Global Content Delivery Across Mesh Networks</p>
            <p><strong>Network:</strong> MeshTalk OS + Fungi Mesh + QuranChain</p>
        </div>

        <div class="nodes">
            <h3>🖧 CDN Nodes</h3>
    """

    stats = cdn_manager.get_cdn_stats()
    for node_type, count in stats["node_types"].items():
        html_content += f'<span class="node-type">{node_type.upper()}: {count}</span>'

    html_content += f"""
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">{stats['total_content']}</div>
                <div>Content Items</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['total_nodes']}</div>
                <div>CDN Nodes</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['total_distributions']}</div>
                <div>Total Distributions</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['average_distributions_per_content']:.1f}</div>
                <div>Avg per Content</div>
            </div>
        </div>

        <div class="content">
            <h2>📦 Distributed Content</h2>
    """

    for content in cdn_manager.list_content()[:10]:  # Show last 10
        html_content += f"""
            <div class="content-card">
                <h3>{content['content_id']}</h3>
                <p><strong>Type:</strong> {content['content_type']}</p>
                <p><strong>Size:</strong> {content['size']} bytes</p>
                <p><strong>Distributed:</strong> {content['distributed_at'][:19]}</p>
                <p><strong>CDN URLs:</strong> {len(content['cdn_urls'])} nodes</p>
            </div>
        """

    html_content += """
        </div>
    </body>
    </html>
    """

    return HTMLResponse(content=html_content)

@app.post("/distribute")
def distribute_content(content_id: str, content_data: str, content_type: str = "text/html"):
    """Distribute content across CDN"""
    try:
        # Convert string data to bytes
        data_bytes = content_data.encode('utf-8')

        result = cdn_manager.distribute_content(content_id, data_bytes, content_type)
        return JSONResponse({
            "status": "success",
            "message": f"Content {content_id} distributed to {len(result['cdn_urls'])} CDN nodes",
            "data": result
        })
    except Exception as e:
        logger.error(f"Content distribution failed: {e}")
        raise HTTPException(status_code=500, detail=f"Distribution failed: {str(e)}")

@app.get("/api/content/{content_id}")
def get_content_info(content_id: str):
    """Get content information"""
    content_info = cdn_manager.get_content_info(content_id)
    if not content_info:
        raise HTTPException(status_code=404, detail="Content not found")

    return JSONResponse(content_info)

@app.get("/api/content/{content_id}/urls")
def get_content_urls(content_id: str):
    """Get CDN URLs for content"""
    urls = cdn_manager.get_content_urls(content_id)
    return JSONResponse({"content_id": content_id, "cdn_urls": urls})

@app.delete("/api/content/{content_id}")
def purge_content(content_id: str):
    """Purge content from CDN"""
    if cdn_manager.purge_content(content_id):
        return JSONResponse({"status": "success", "message": f"Content {content_id} purged from CDN"})
    else:
        raise HTTPException(status_code=404, detail="Content not found")

@app.get("/api/stats")
def get_cdn_stats():
    """Get CDN statistics"""
    return JSONResponse(cdn_manager.get_cdn_stats())

@app.get("/api/content")
def list_content():
    """List all CDN content"""
    return JSONResponse({
        "content": cdn_manager.list_content(),
        "total": len(cdn_manager.content_cache)
    })

@app.post("/api/optimize")
def optimize_distribution():
    """Optimize CDN distribution"""
    try:
        cdn_manager.optimize_distribution()
        return JSONResponse({"status": "success", "message": "CDN optimization completed"})
    except Exception as e:
        logger.error(f"CDN optimization failed: {e}")
        raise HTTPException(status_code=500, detail=f"Optimization failed: {str(e)}")

@app.get("/health")
def health_check():
    """Health check endpoint"""
    stats = cdn_manager.get_cdn_stats()
    return {
        "status": "healthy",
        "service": "DarCloud CDN Distribution System",
        "content_count": stats["total_content"],
        "node_count": stats["total_nodes"],
        "distribution_count": stats["total_distributions"],
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

def main():
    """Start DarCloud CDN Distribution System"""
    logger.info("🌐 Starting DarCloud CDN Distribution System on port 8083")
    uvicorn.run(app, host="0.0.0.0", port=8083)

if __name__ == "__main__":
    main()