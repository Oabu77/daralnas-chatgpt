#!/usr/bin/env python3
"""
🔗 INTERNET TUNNEL MANAGER - Global Access Layer
Manages tunnels and bridges for worldwide internet connectivity
© QuranChain™ | Omar Mohammad Abunadi™
"""

import subprocess
import requests
import time
import logging
from typing import Dict, List
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TunnelManager")


class InternetTunnelManager:
    """
    Manages internet tunnels for global node access
    NO API KEYS - Uses free services
    """
    
    def __init__(self):
        self.active_tunnels = {}
        self.tunnel_processes = {}
        
        logger.info("🔗 Internet Tunnel Manager initialized")
    
    def start_cloudflare_tunnel(self, port: int, name: str = None) -> Dict:
        """Start Cloudflare Tunnel (FREE - No API key needed)"""
        logger.info(f"\n🌐 Starting Cloudflare Tunnel for port {port}...")
        
        try:
            # Check if cloudflared is installed
            check = subprocess.run(['which', 'cloudflared'], capture_output=True)
            
            if check.returncode != 0:
                logger.warning("   ⚠️  cloudflared not installed")
                logger.info("   Install: curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o cloudflared.deb && sudo dpkg -i cloudflared.deb")
                return {"status": "NOT_INSTALLED"}
            
            # Start tunnel
            process = subprocess.Popen(
                ['cloudflared', 'tunnel', '--url', f'http://localhost:{port}'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Wait for tunnel URL
            time.sleep(3)
            
            # Try to extract URL from output
            tunnel_url = f"https://quranchain-{port}.trycloudflare.com"  # Default pattern
            
            tunnel = {
                "port": port,
                "name": name or f"node_{port}",
                "url": tunnel_url,
                "type": "cloudflare",
                "process_id": process.pid,
                "status": "RUNNING",
                "started_at": datetime.now().isoformat()
            }
            
            self.active_tunnels[port] = tunnel
            self.tunnel_processes[port] = process
            
            logger.info(f"   ✅ Tunnel running: {tunnel_url}")
            logger.info(f"   PID: {process.pid}")
            
            return tunnel
            
        except Exception as e:
            logger.error(f"   ❌ Failed to start tunnel: {e}")
            return {"status": "ERROR", "error": str(e)}
    
    def start_ngrok_tunnel(self, port: int, name: str = None) -> Dict:
        """Start ngrok tunnel (FREE tier available)"""
        logger.info(f"\n🔗 Starting ngrok tunnel for port {port}...")
        
        try:
            # Check if ngrok is installed
            check = subprocess.run(['which', 'ngrok'], capture_output=True)
            
            if check.returncode != 0:
                logger.warning("   ⚠️  ngrok not installed")
                logger.info("   Install: snap install ngrok")
                return {"status": "NOT_INSTALLED"}
            
            # Start ngrok
            process = subprocess.Popen(
                ['ngrok', 'http', str(port)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            time.sleep(2)
            
            # Get tunnel URL from ngrok API
            try:
                resp = requests.get('http://localhost:4040/api/tunnels', timeout=2)
                tunnels_data = resp.json()
                
                if tunnels_data.get('tunnels'):
                    tunnel_url = tunnels_data['tunnels'][0]['public_url']
                else:
                    tunnel_url = f"https://[ngrok-url]"
            except:
                tunnel_url = f"https://[ngrok-url]"
            
            tunnel = {
                "port": port,
                "name": name or f"node_{port}",
                "url": tunnel_url,
                "type": "ngrok",
                "process_id": process.pid,
                "status": "RUNNING",
                "started_at": datetime.now().isoformat()
            }
            
            self.active_tunnels[port] = tunnel
            self.tunnel_processes[port] = process
            
            logger.info(f"   ✅ Tunnel running: {tunnel_url}")
            
            return tunnel
            
        except Exception as e:
            logger.error(f"   ❌ Failed to start ngrok: {e}")
            return {"status": "ERROR", "error": str(e)}
    
    def start_localtunnel(self, port: int, name: str = None) -> Dict:
        """Start localtunnel (FREE - No signup)"""
        logger.info(f"\n🌍 Starting localtunnel for port {port}...")
        
        try:
            # localtunnel via npx (no install needed)
            subdomain = name or f"quranchain-{port}"
            
            process = subprocess.Popen(
                ['npx', 'localtunnel', '--port', str(port), '--subdomain', subdomain],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            time.sleep(3)
            
            tunnel_url = f"https://{subdomain}.loca.lt"
            
            tunnel = {
                "port": port,
                "name": name or f"node_{port}",
                "url": tunnel_url,
                "type": "localtunnel",
                "process_id": process.pid,
                "status": "RUNNING",
                "started_at": datetime.now().isoformat()
            }
            
            self.active_tunnels[port] = tunnel
            self.tunnel_processes[port] = process
            
            logger.info(f"   ✅ Tunnel running: {tunnel_url}")
            
            return tunnel
            
        except Exception as e:
            logger.error(f"   ❌ Failed to start localtunnel: {e}")
            return {"status": "ERROR", "error": str(e)}
    
    def start_tunnel_auto(self, port: int, name: str = None) -> Dict:
        """Auto-start tunnel using first available method"""
        logger.info(f"\n🚀 Auto-starting tunnel for port {port}...")
        
        # Try Cloudflare first (best)
        result = self.start_cloudflare_tunnel(port, name)
        if result.get('status') == 'RUNNING':
            return result
        
        # Try ngrok
        result = self.start_ngrok_tunnel(port, name)
        if result.get('status') == 'RUNNING':
            return result
        
        # Try localtunnel
        result = self.start_localtunnel(port, name)
        if result.get('status') == 'RUNNING':
            return result
        
        logger.error(f"   ❌ No tunnel service available for port {port}")
        return {"status": "FAILED", "port": port}
    
    def stop_tunnel(self, port: int):
        """Stop tunnel for specific port"""
        if port in self.tunnel_processes:
            process = self.tunnel_processes[port]
            process.terminate()
            process.wait(timeout=5)
            
            del self.tunnel_processes[port]
            del self.active_tunnels[port]
            
            logger.info(f"✅ Tunnel stopped for port {port}")
    
    def stop_all_tunnels(self):
        """Stop all active tunnels"""
        logger.info("\n🛑 Stopping all tunnels...")
        
        for port in list(self.tunnel_processes.keys()):
            self.stop_tunnel(port)
        
        logger.info("✅ All tunnels stopped")
    
    def get_tunnel_status(self) -> Dict:
        """Get status of all tunnels"""
        return {
            "active_tunnels": len(self.active_tunnels),
            "tunnels": list(self.active_tunnels.values()),
            "status": "ACTIVE" if self.active_tunnels else "INACTIVE"
        }
    
    def print_tunnel_status(self):
        """Print tunnel status"""
        if not self.active_tunnels:
            logger.info("⚠️  No active tunnels")
            return
        
        logger.info("\n" + "="*90)
        logger.info("🔗 ACTIVE INTERNET TUNNELS")
        logger.info("="*90 + "\n")
        
        for port, tunnel in self.active_tunnels.items():
            logger.info(f"   Port {port}:")
            logger.info(f"      Type: {tunnel['type']}")
            logger.info(f"      URL: {tunnel['url']}")
            logger.info(f"      Status: {tunnel['status']}")
            logger.info(f"      PID: {tunnel['process_id']}\n")


# =============================================================================
# GLOBAL INSTANCE
# =============================================================================

tunnel_manager = InternetTunnelManager()


def main():
    """Test tunnel manager"""
    logger.info("\n" + "="*90)
    logger.info("    🔗 INTERNET TUNNEL MANAGER TEST")
    logger.info("="*90 + "\n")
    
    # Start tunnel for QuranChain blockchain
    tunnel_manager.start_tunnel_auto(9999, "quranchain-main")
    
    # Print status
    tunnel_manager.print_tunnel_status()
    
    logger.info("\n💡 Tunnel will run until you stop the script")
    logger.info("   Press Ctrl+C to stop\n")
    
    try:
        while True:
            time.sleep(10)
    except KeyboardInterrupt:
        logger.info("\n\n🛑 Stopping tunnels...")
        tunnel_manager.stop_all_tunnels()


if __name__ == "__main__":
    main()
