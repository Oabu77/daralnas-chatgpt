# NO SIMULATIONS IN PRODUCTION
SIMULATION_MODE = False
ALLOW_TEST_TRANSACTIONS = False
REQUIRE_BLOCKCHAIN_CONFIRMATION = True

def enforce_no_simulation(tx):
    if not tx.get('blockchain_confirmed'):
        raise ValueError("SIMULATION DETECTED - Production mode requires real blockchain transactions")
    return True
