#!/usr/bin/env python3
"""
🛡️ AUTONOMOUS SYSTEM GUARDIAN - Self-Diagnostic, Self-Repair, Self-Improve
Monitors all QuranChain systems and automatically fixes/optimizes
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import time
import psutil
import requests
import subprocess
import logging
from datetime import datetime
from typing import Dict, List, Optional
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SystemGuardian")

# =============================================================================
# CRITICAL SYSTEM COMPONENTS
# =============================================================================

CRITICAL_SYSTEMS = {
    "quranchain_blockchain": {
        "port": 8101,
        "process_name": "quranchain_quantum_blockchain.py",
        "health_endpoint": "http://localhost:8101/api/v1/status",
        "auto_restart": True,
        "priority": "CRITICAL"
    },
    "network_agents": {
        "port": None,
        "process_name": "blockchain_network_agents.py",
        "log_file": "logs/network_agents.log",
        "auto_restart": True,
        "priority": "CRITICAL"
    },
    "settlement_integration": {
        "port": None,
        "process_name": "settlement_layer_integration.py",
        "auto_restart": False,
        "priority": "HIGH"
    },
    "auto_payout": {
        "port": None,
        "process_name": "auto_revenue_payout.py",
        "auto_restart": True,
        "priority": "CRITICAL"
    },
    "network_optimizer": {
        "port": None,
        "process_name": "network_bottleneck_optimizer.py",
        "log_file": "logs/network_optimizer.log",
        "auto_restart": True,
        "priority": "HIGH"
    },
    "darcloud_server": {
        "port": 8080,
        "process_name": "darcloud_autonomous_server.py",
        "health_endpoint": "http://localhost:8080/health",
        "auto_restart": True,
        "priority": "HIGH"
    }
}


class AutonomousSystemGuardian:
    """
    Self-healing, self-improving system guardian
    """
    
    def __init__(self):
        self.issues_detected = 0
        self.issues_fixed = 0
        self.optimizations_applied = 0
        self.uptime_start = datetime.now()
        self.last_diagnostic = None
        
        logger.info("🛡️ Autonomous System Guardian initialized")
        logger.info("   Self-diagnostic: ACTIVE")
        logger.info("   Auto-repair: ENABLED")
        logger.info("   Auto-improve: ENABLED")
    
    def run_full_diagnostic(self) -> Dict:
        """Complete system health check"""
        logger.info("\n" + "="*90)
        logger.info(f"🔍 FULL SYSTEM DIAGNOSTIC - {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}")
        logger.info("="*90 + "\n")
        
        diagnostic = {
            "timestamp": datetime.now().isoformat(),
            "system_health": "UNKNOWN",
            "components": {},
            "issues": [],
            "performance": {},
            "recommendations": []
        }
        
        # 1. Check critical processes
        logger.info("1️⃣  Checking Critical Processes...")
        for name, config in CRITICAL_SYSTEMS.items():
            status = self._check_process(name, config)
            diagnostic["components"][name] = status
            
            if not status["running"] and config["auto_restart"]:
                diagnostic["issues"].append(f"{name} not running")
                logger.warning(f"   ⚠️  {name}: DOWN - Will auto-restart")
            elif status["running"]:
                logger.info(f"   ✅ {name}: RUNNING")
        
        # 2. Check system resources
        logger.info("\n2️⃣  Checking System Resources...")
        resources = self._check_resources()
        diagnostic["performance"] = resources
        
        cpu_usage = resources["cpu_percent"]
        mem_usage = resources["memory_percent"]
        disk_usage = resources["disk_percent"]
        
        logger.info(f"   CPU: {cpu_usage:.1f}%")
        logger.info(f"   Memory: {mem_usage:.1f}%")
        logger.info(f"   Disk: {disk_usage:.1f}%")
        
        if cpu_usage > 80:
            diagnostic["issues"].append("High CPU usage")
            diagnostic["recommendations"].append("Optimize CPU-intensive processes")
        if mem_usage > 80:
            diagnostic["issues"].append("High memory usage")
            diagnostic["recommendations"].append("Clear memory caches")
        if disk_usage > 85:
            diagnostic["issues"].append("Low disk space")
            diagnostic["recommendations"].append("Clean up old logs")
        
        # 3. Check network connectivity
        logger.info("\n3️⃣  Checking Network Connectivity...")
        network = self._check_network()
        diagnostic["network"] = network
        
        if network["internet_connected"]:
            logger.info("   ✅ Internet: CONNECTED")
        else:
            diagnostic["issues"].append("No internet connection")
            logger.error("   ❌ Internet: DISCONNECTED")
        
        # 4. Check QuranChain blockchain
        logger.info("\n4️⃣  Checking QuranChain Blockchain...")
        blockchain_status = self._check_blockchain()
        diagnostic["blockchain"] = blockchain_status
        
        if blockchain_status["responding"]:
            logger.info(f"   ✅ Port 9999: ACTIVE")
        else:
            diagnostic["issues"].append("QuranChain blockchain not responding")
            logger.warning("   ⚠️  Port 9999: NOT RESPONDING")
        
        # 5. Check log files
        logger.info("\n5️⃣  Checking Log Files...")
        logs = self._check_logs()
        diagnostic["logs"] = logs
        
        for log_name, log_info in logs.items():
            if log_info["size_mb"] > 100:
                diagnostic["recommendations"].append(f"Rotate {log_name} (>{log_info['size_mb']:.0f}MB)")
        
        # 6. Determine overall health
        if len(diagnostic["issues"]) == 0:
            diagnostic["system_health"] = "EXCELLENT"
        elif len(diagnostic["issues"]) <= 2:
            diagnostic["system_health"] = "GOOD"
        elif len(diagnostic["issues"]) <= 5:
            diagnostic["system_health"] = "FAIR"
        else:
            diagnostic["system_health"] = "CRITICAL"
        
        logger.info("\n" + "="*90)
        logger.info(f"📊 DIAGNOSTIC COMPLETE - Health: {diagnostic['system_health']}")
        logger.info(f"   Issues Found: {len(diagnostic['issues'])}")
        logger.info(f"   Recommendations: {len(diagnostic['recommendations'])}")
        logger.info("="*90 + "\n")
        
        self.last_diagnostic = diagnostic
        return diagnostic
    
    def auto_repair(self, diagnostic: Dict) -> int:
        """Automatically fix detected issues"""
        logger.info("\n🔧 AUTO-REPAIR INITIATED...")
        
        fixes_applied = 0
        
        for issue in diagnostic["issues"]:
            logger.info(f"\n   Fixing: {issue}")
            
            # Restart downed services
            if "not running" in issue:
                service_name = issue.split()[0]
                if service_name in CRITICAL_SYSTEMS:
                    if self._restart_service(service_name, CRITICAL_SYSTEMS[service_name]):
                        logger.info(f"   ✅ Restarted {service_name}")
                        fixes_applied += 1
                    else:
                        logger.error(f"   ❌ Failed to restart {service_name}")
            
            # Clear memory if high usage
            elif "High memory usage" in issue:
                if self._clear_memory_caches():
                    logger.info("   ✅ Cleared memory caches")
                    fixes_applied += 1
            
            # Clean disk if low space
            elif "Low disk space" in issue:
                if self._clean_disk_space():
                    logger.info("   ✅ Cleaned disk space")
                    fixes_applied += 1
            
            # Restart network if disconnected
            elif "No internet connection" in issue:
                logger.info("   ⚠️  Internet issue - Cannot auto-fix (external)")
        
        self.issues_fixed += fixes_applied
        logger.info(f"\n✅ AUTO-REPAIR COMPLETE - {fixes_applied} issues fixed\n")
        
        return fixes_applied
    
    def auto_improve(self, diagnostic: Dict) -> int:
        """Apply performance optimizations"""
        logger.info("\n⚡ AUTO-IMPROVE INITIATED...")
        
        improvements = 0
        
        # Optimize based on resource usage
        resources = diagnostic.get("performance", {})
        cpu = resources.get("cpu_percent", 0)
        mem = resources.get("memory_percent", 0)
        
        # If CPU is underutilized, scale up agents
        if cpu < 30 and mem < 50:
            logger.info("   💡 Low resource usage - Can scale up operations")
            # Could spawn more network agents here
            improvements += 1
        
        # Rotate large log files
        logs = diagnostic.get("logs", {})
        for log_name, log_info in logs.items():
            if log_info["size_mb"] > 100:
                if self._rotate_log(log_info["path"]):
                    logger.info(f"   ✅ Rotated {log_name}")
                    improvements += 1
        
        # Optimize database if needed
        if os.path.exists("crm/crm.db"):
            size_mb = os.path.getsize("crm/crm.db") / (1024 * 1024)
            if size_mb > 50:
                if self._optimize_database():
                    logger.info("   ✅ Optimized database")
                    improvements += 1
        
        self.optimizations_applied += improvements
        logger.info(f"\n✅ AUTO-IMPROVE COMPLETE - {improvements} optimizations applied\n")
        
        return improvements
    
    def _check_process(self, name: str, config: Dict) -> Dict:
        """Check if a process is running"""
        process_name = config.get("process_name", "")
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                cmdline = " ".join(proc.info['cmdline'] or [])
                if process_name in cmdline:
                    return {
                        "running": True,
                        "pid": proc.info['pid'],
                        "cpu_percent": proc.cpu_percent(),
                        "memory_mb": proc.memory_info().rss / (1024 * 1024)
                    }
            except:
                pass
        
        return {"running": False}
    
    def _check_resources(self) -> Dict:
        """Check system resource usage"""
        return {
            "cpu_percent": psutil.cpu_percent(interval=1),
            "memory_percent": psutil.virtual_memory().percent,
            "disk_percent": psutil.disk_usage('/').percent,
            "cpu_count": psutil.cpu_count(),
            "memory_total_gb": psutil.virtual_memory().total / (1024**3),
            "disk_total_gb": psutil.disk_usage('/').total / (1024**3)
        }
    
    def _check_network(self) -> Dict:
        """Check network connectivity"""
        try:
            response = requests.get("https://www.google.com", timeout=5)
            return {
                "internet_connected": response.status_code == 200,
                "latency_ms": response.elapsed.total_seconds() * 1000
            }
        except:
            return {"internet_connected": False}
    
    def _check_blockchain(self) -> Dict:
        """Check QuranChain blockchain status"""
        try:
            response = requests.get("http://localhost:9999/api/v1/status", timeout=2)
            return {
                "responding": response.status_code == 200,
                "status_code": response.status_code
            }
        except:
            return {"responding": False}
    
    def _check_logs(self) -> Dict:
        """Check log file sizes"""
        logs = {}
        log_dir = "logs"
        
        if os.path.exists(log_dir):
            for filename in os.listdir(log_dir):
                if filename.endswith(".log"):
                    filepath = os.path.join(log_dir, filename)
                    try:
                        size_mb = os.path.getsize(filepath) / (1024 * 1024)
                        logs[filename] = {
                            "path": filepath,
                            "size_mb": size_mb
                        }
                    except:
                        pass
        
        return logs
    
    def _restart_service(self, name: str, config: Dict) -> bool:
        """Restart a service"""
        try:
            process_name = config["process_name"]
            
            # Kill existing process
            subprocess.run(f"pkill -f {process_name}", shell=True)
            time.sleep(2)
            
            # Restart
            log_file = config.get("log_file", f"logs/{name}.log")
            subprocess.Popen(
                f"python3 {process_name} > {log_file} 2>&1 &",
                shell=True,
                cwd="/home/omar/Desktop/QuranChain"
            )
            
            time.sleep(3)
            
            # Verify started
            status = self._check_process(name, config)
            return status["running"]
        except Exception as e:
            logger.error(f"Restart failed: {e}")
            return False
    
    def _clear_memory_caches(self) -> bool:
        """Clear system memory caches"""
        try:
            subprocess.run("sync", shell=True)
            subprocess.run("echo 3 > /proc/sys/vm/drop_caches", shell=True)
            return True
        except:
            return False
    
    def _clean_disk_space(self) -> bool:
        """Clean up disk space"""
        try:
            cleaned = 0
            
            # Remove old snapshots
            snapshot_dir = ".snapshots"
            if os.path.exists(snapshot_dir):
                files = sorted(os.listdir(snapshot_dir))
                # Keep last 100, delete older
                for f in files[:-100]:
                    os.remove(os.path.join(snapshot_dir, f))
                    cleaned += 1
            
            # Compress old logs
            log_dir = "logs"
            if os.path.exists(log_dir):
                for f in os.listdir(log_dir):
                    if f.endswith(".log"):
                        filepath = os.path.join(log_dir, f)
                        size_mb = os.path.getsize(filepath) / (1024 * 1024)
                        if size_mb > 50:
                            subprocess.run(f"gzip {filepath}", shell=True)
                            cleaned += 1
            
            return cleaned > 0
        except Exception as e:
            logger.error(f"Disk cleanup failed: {e}")
            return False
    
    def _rotate_log(self, log_path: str) -> bool:
        """Rotate a log file"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            new_path = f"{log_path}.{timestamp}"
            os.rename(log_path, new_path)
            subprocess.run(f"gzip {new_path}", shell=True)
            return True
        except:
            return False
    
    def _optimize_database(self) -> bool:
        """Optimize SQLite database"""
        try:
            import sqlite3
            conn = sqlite3.connect("crm/crm.db")
            conn.execute("VACUUM")
            conn.execute("ANALYZE")
            conn.close()
            return True
        except:
            return False
    
    def generate_health_report(self) -> str:
        """Generate human-readable health report"""
        if not self.last_diagnostic:
            return "No diagnostic data available"
        
        d = self.last_diagnostic
        uptime = datetime.now() - self.uptime_start
        
        report = f"""
╔══════════════════════════════════════════════════════════════════════════╗
║               🛡️ QURANCHAIN™ SYSTEM HEALTH REPORT                        ║
╚══════════════════════════════════════════════════════════════════════════╝

📅 Report Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}
⏱️  System Uptime: {uptime.days}d {uptime.seconds//3600}h {(uptime.seconds//60)%60}m

🎯 OVERALL HEALTH: {d['system_health']}

📊 SYSTEM RESOURCES:
   CPU Usage: {d['performance']['cpu_percent']:.1f}%
   Memory Usage: {d['performance']['memory_percent']:.1f}%
   Disk Usage: {d['performance']['disk_percent']:.1f}%

🔧 CRITICAL COMPONENTS:
"""
        
        for name, status in d['components'].items():
            if status['running']:
                report += f"   ✅ {name:30} RUNNING (PID: {status['pid']})\n"
            else:
                report += f"   ❌ {name:30} DOWN\n"
        
        report += f"""
⚠️  ISSUES DETECTED: {len(d['issues'])}
"""
        for issue in d['issues']:
            report += f"   • {issue}\n"
        
        report += f"""
💡 RECOMMENDATIONS: {len(d['recommendations'])}
"""
        for rec in d['recommendations']:
            report += f"   • {rec}\n"
        
        report += f"""
📈 GUARDIAN STATISTICS:
   Issues Detected: {self.issues_detected}
   Issues Fixed: {self.issues_fixed}
   Optimizations Applied: {self.optimizations_applied}

═══════════════════════════════════════════════════════════════════════════
"""
        
        return report
    
    def run_continuous_monitoring(self, interval_minutes: int = 5):
        """Run continuous monitoring loop"""
        logger.info("\n🛡️ Starting continuous monitoring...")
        logger.info(f"   Diagnostic interval: {interval_minutes} minutes")
        logger.info("   Auto-repair: ENABLED")
        logger.info("   Auto-improve: ENABLED\n")
        
        while True:
            try:
                # Run diagnostic
                diagnostic = self.run_full_diagnostic()
                self.issues_detected += len(diagnostic["issues"])
                
                # Auto-repair
                if diagnostic["issues"]:
                    self.auto_repair(diagnostic)
                
                # Auto-improve
                if diagnostic["recommendations"]:
                    self.auto_improve(diagnostic)
                
                # Generate and save report
                report = self.generate_health_report()
                print(report)
                
                # Save to file
                report_file = f".system_health_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                with open(report_file, 'w') as f:
                    f.write(report)
                
                # Wait for next cycle
                logger.info(f"⏸️  Next diagnostic in {interval_minutes} minutes...\n")
                time.sleep(interval_minutes * 60)
                
            except KeyboardInterrupt:
                logger.info("\n🛑 Monitoring stopped by user")
                break
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                time.sleep(60)


# =============================================================================
# GLOBAL INSTANCE
# =============================================================================

guardian = AutonomousSystemGuardian()


def main():
    """Run autonomous system guardian"""
    logger.info("\n" + "="*90)
    logger.info("    🛡️ QURANCHAIN™ AUTONOMOUS SYSTEM GUARDIAN")
    logger.info("    Self-Diagnostic | Self-Repair | Self-Improve")
    logger.info("="*90 + "\n")
    
    # Run initial diagnostic
    diagnostic = guardian.run_full_diagnostic()
    
    # Auto-repair if needed
    if diagnostic["issues"]:
        guardian.auto_repair(diagnostic)
    
    # Auto-improve
    if diagnostic["recommendations"]:
        guardian.auto_improve(diagnostic)
    
    # Print report
    print(guardian.generate_health_report())
    
    # Start continuous monitoring
    guardian.run_continuous_monitoring(interval_minutes=5)


if __name__ == "__main__":
    main()
