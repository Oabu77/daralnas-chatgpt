#!/usr/bin/env python3
"""
🏢 OLIVESEA PORT MANAGEMENT - Smart Port Operations
AI-powered port terminal and container management system
© Omar Mohammad Abunadi™ 2026

INTEGRATIONS:
  ✅ QuranChain Mainnet - Blockchain cargo tracking
  ✅ Fungi Mesh Network - Port-to-port coordination
  ✅ MeshTalk - Real-time port communication
  ✅ OliveAir - Air cargo terminal integration
  ✅ DarCloud - Port operations data
  
FEATURES:
  • Container terminal management
  • Berth allocation & scheduling
  • Cargo tracking & inventory
  • Customs integration
  • 30% Founder royalty (IMMUTABLE)
  • AI-optimized operations
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
from enum import Enum
import hashlib
import json
import logging
import requests
import sqlite3
from pathlib import Path
import random

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] 🏢 OLIVESEA PORTS - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# Flask app
app = Flask(__name__)
CORS(app)

# Configuration
OLIVESEA_PORTS_PORT = 9402
FOUNDER_WALLET = "0xFounderQuranChainWallet"
FOUNDER_ROYALTY_RATE = 0.30  # IMMUTABLE
DB_PATH = "/home/omar/Desktop/QuranChain/prod_databases/olivesea_ports.db"

# Ecosystem Integration
QURANCHAIN_MAINNET = "http://localhost:9999"
FUNGI_MESH_NETWORK = "http://localhost:5006"
MESHTALK_GATEWAY = "http://localhost:7090"
OLIVEAIR_LOGISTICS = "http://localhost:9302"
OLIVESEA_MARITIME = "http://localhost:9400"
DARCLOUD_STORAGE = "http://localhost:8086"

class BerthStatus(Enum):
    AVAILABLE = "available"
    OCCUPIED = "occupied"
    RESERVED = "reserved"
    MAINTENANCE = "maintenance"

class CargoOperation(Enum):
    LOADING = "loading"
    UNLOADING = "unloading"
    TRANSSHIPMENT = "transshipment"
    STORAGE = "storage"

@dataclass
class Port:
    """OliveSea Port Terminal"""
    port_id: str
    port_name: str
    city: str
    country: str
    berths_count: int
    max_vessel_size_teu: int
    annual_capacity_teu: int
    crane_count: int
    storage_area_sqm: int
    fungi_mesh_node_id: str
    meshtalk_channel: str
    customs_integration: bool
    revenue_usd: float
    founder_royalty_usd: float

@dataclass
class BerthAllocation:
    """Berth allocation for vessel"""
    allocation_id: str
    port_id: str
    berth_number: int
    vessel_name: str
    vessel_imo: str
    arrival_time: str
    departure_time: str
    operation_type: str
    containers_handled: int
    revenue_usd: float
    founder_royalty_usd: float
    blockchain_hash: str
    status: str
    created_at: str

class OliveSeaPortsEngine:
    """OliveSea Port Management Engine"""
    
    def __init__(self):
        self.db_path = Path(DB_PATH)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
        
        # OliveSea port network
        self.ports = self._initialize_ports()
        
        # Revenue rates
        self.rates = {
            "container_handling": 150,  # USD per TEU
            "berth_fee_per_hour": 500,  # USD per hour
            "storage_per_day": 25,  # USD per TEU per day
            "crane_usage_per_lift": 75,  # USD per container lift
        }
        
        logger.info("🏢 OliveSea Ports Engine initialized")
        logger.info(f"   Ports: {len(self.ports)} terminals")
        logger.info(f"   Founder royalty: {FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)")
    
    def _init_database(self):
        """Initialize database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ports (
                port_id TEXT PRIMARY KEY,
                port_name TEXT NOT NULL,
                city TEXT NOT NULL,
                country TEXT NOT NULL,
                berths_count INTEGER NOT NULL,
                max_vessel_size_teu INTEGER NOT NULL,
                annual_capacity_teu INTEGER NOT NULL,
                crane_count INTEGER NOT NULL,
                storage_area_sqm INTEGER NOT NULL,
                fungi_mesh_node_id TEXT NOT NULL,
                meshtalk_channel TEXT NOT NULL,
                customs_integration INTEGER NOT NULL,
                revenue_usd REAL DEFAULT 0,
                founder_royalty_usd REAL DEFAULT 0
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS berth_allocations (
                allocation_id TEXT PRIMARY KEY,
                port_id TEXT NOT NULL,
                berth_number INTEGER NOT NULL,
                vessel_name TEXT NOT NULL,
                vessel_imo TEXT NOT NULL,
                arrival_time TEXT NOT NULL,
                departure_time TEXT NOT NULL,
                operation_type TEXT NOT NULL,
                containers_handled INTEGER NOT NULL,
                revenue_usd REAL NOT NULL,
                founder_royalty_usd REAL NOT NULL,
                blockchain_hash TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (port_id) REFERENCES ports(port_id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS revenue_distribution (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                allocation_id TEXT NOT NULL,
                total_revenue_usd REAL NOT NULL,
                founder_share_usd REAL NOT NULL,
                ai_validators_share_usd REAL NOT NULL,
                ecosystem_share_usd REAL NOT NULL,
                hardware_hosts_share_usd REAL NOT NULL,
                zakat_share_usd REAL NOT NULL,
                distributed_at TEXT NOT NULL,
                FOREIGN KEY (allocation_id) REFERENCES berth_allocations(allocation_id)
            )
        """)
        
        conn.commit()
        conn.close()
        logger.info("✅ Database initialized")
    
    def _initialize_ports(self) -> List[Port]:
        """Initialize OliveSea port terminals"""
        ports = [
            Port(
                port_id="OSEA-PORT-LAX",
                port_name="OliveSea Los Angeles Terminal",
                city="Los Angeles",
                country="USA",
                berths_count=12,
                max_vessel_size_teu=24000,
                annual_capacity_teu=5000000,
                crane_count=24,
                storage_area_sqm=500000,
                fungi_mesh_node_id="fungi-port-lax-001",
                meshtalk_channel="meshtalk-port-lax",
                customs_integration=True,
                revenue_usd=0,
                founder_royalty_usd=0
            ),
            Port(
                port_id="OSEA-PORT-NYC",
                port_name="OliveSea New York Terminal",
                city="New York",
                country="USA",
                berths_count=10,
                max_vessel_size_teu=20000,
                annual_capacity_teu=4000000,
                crane_count=20,
                storage_area_sqm=400000,
                fungi_mesh_node_id="fungi-port-nyc-001",
                meshtalk_channel="meshtalk-port-nyc",
                customs_integration=True,
                revenue_usd=0,
                founder_royalty_usd=0
            ),
            Port(
                port_id="OSEA-PORT-DXB",
                port_name="OliveSea Dubai Terminal",
                city="Dubai",
                country="UAE",
                berths_count=15,
                max_vessel_size_teu=25000,
                annual_capacity_teu=6000000,
                crane_count=30,
                storage_area_sqm=600000,
                fungi_mesh_node_id="fungi-port-dxb-001",
                meshtalk_channel="meshtalk-port-dxb",
                customs_integration=True,
                revenue_usd=0,
                founder_royalty_usd=0
            ),
            Port(
                port_id="OSEA-PORT-JED",
                port_name="OliveSea Jeddah Terminal",
                city="Jeddah",
                country="Saudi Arabia",
                berths_count=8,
                max_vessel_size_teu=18000,
                annual_capacity_teu=3000000,
                crane_count=16,
                storage_area_sqm=350000,
                fungi_mesh_node_id="fungi-port-jed-001",
                meshtalk_channel="meshtalk-port-jed",
                customs_integration=True,
                revenue_usd=0,
                founder_royalty_usd=0
            ),
            Port(
                port_id="OSEA-PORT-SIN",
                port_name="OliveSea Singapore Terminal",
                city="Singapore",
                country="Singapore",
                berths_count=20,
                max_vessel_size_teu=25000,
                annual_capacity_teu=8000000,
                crane_count=40,
                storage_area_sqm=800000,
                fungi_mesh_node_id="fungi-port-sin-001",
                meshtalk_channel="meshtalk-port-sin",
                customs_integration=True,
                revenue_usd=0,
                founder_royalty_usd=0
            )
        ]
        
        # Save to database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        for port in ports:
            cursor.execute("""
                INSERT OR REPLACE INTO ports VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                port.port_id, port.port_name, port.city, port.country,
                port.berths_count, port.max_vessel_size_teu, port.annual_capacity_teu,
                port.crane_count, port.storage_area_sqm, port.fungi_mesh_node_id,
                port.meshtalk_channel, int(port.customs_integration),
                port.revenue_usd, port.founder_royalty_usd
            ))
        
        conn.commit()
        conn.close()
        
        return ports
    
    def _calculate_blockchain_hash(self, data: Dict) -> str:
        """Calculate blockchain hash"""
        hash_input = json.dumps(data, sort_keys=True).encode()
        return hashlib.sha256(hash_input).hexdigest()
    
    def _register_on_quranchain(self, allocation_data: Dict) -> str:
        """Register berth allocation on QuranChain"""
        try:
            response = requests.post(
                f"{QURANCHAIN_MAINNET}/register_port_operation",
                json=allocation_data,
                timeout=5
            )
            if response.status_code == 200:
                return response.json().get('blockchain_hash')
        except:
            pass
        return self._calculate_blockchain_hash(allocation_data)
    
    def allocate_berth(self, port_id: str, vessel_name: str, vessel_imo: str,
                      arrival_time: datetime, operation_type: str,
                      containers_handled: int) -> Dict:
        """Allocate berth for vessel"""
        
        # Find port
        port = next((p for p in self.ports if p.port_id == port_id), None)
        if not port:
            raise ValueError(f"Port {port_id} not found")
        
        # Allocate berth (simple round-robin for now)
        berth_number = random.randint(1, port.berths_count)
        
        # Calculate operation time
        hours_needed = max(8, containers_handled / 30)  # 30 containers per hour
        departure_time = arrival_time + timedelta(hours=hours_needed)
        
        # Calculate revenue
        container_revenue = containers_handled * self.rates['container_handling']
        berth_revenue = hours_needed * self.rates['berth_fee_per_hour']
        crane_revenue = containers_handled * self.rates['crane_usage_per_lift']
        
        total_revenue = container_revenue + berth_revenue + crane_revenue
        
        # Founder royalty (30% IMMUTABLE)
        founder_royalty_usd = total_revenue * FOUNDER_ROYALTY_RATE
        
        # Generate allocation ID
        allocation_id = f"BERTH-{port_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Create allocation data
        allocation_data = {
            "allocation_id": allocation_id,
            "port_id": port_id,
            "vessel_name": vessel_name,
            "vessel_imo": vessel_imo,
            "berth_number": berth_number,
            "containers_handled": containers_handled
        }
        
        # Register on blockchain
        blockchain_hash = self._register_on_quranchain(allocation_data)
        
        # Create allocation object
        allocation = BerthAllocation(
            allocation_id=allocation_id,
            port_id=port_id,
            berth_number=berth_number,
            vessel_name=vessel_name,
            vessel_imo=vessel_imo,
            arrival_time=arrival_time.isoformat(),
            departure_time=departure_time.isoformat(),
            operation_type=operation_type,
            containers_handled=containers_handled,
            revenue_usd=total_revenue,
            founder_royalty_usd=founder_royalty_usd,
            blockchain_hash=blockchain_hash,
            status="allocated",
            created_at=datetime.now().isoformat()
        )
        
        # Save to database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO berth_allocations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            allocation.allocation_id, allocation.port_id, allocation.berth_number,
            allocation.vessel_name, allocation.vessel_imo, allocation.arrival_time,
            allocation.departure_time, allocation.operation_type,
            allocation.containers_handled, allocation.revenue_usd,
            allocation.founder_royalty_usd, allocation.blockchain_hash,
            allocation.status, allocation.created_at
        ))
        
        # Update port revenue
        cursor.execute("""
            UPDATE ports 
            SET revenue_usd = revenue_usd + ?,
                founder_royalty_usd = founder_royalty_usd + ?
            WHERE port_id = ?
        """, (total_revenue, founder_royalty_usd, port_id))
        
        # Distribute revenue
        self._distribute_revenue(allocation_id, total_revenue)
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Berth allocated: {allocation_id}")
        logger.info(f"   Port: {port.port_name}, Berth: {berth_number}")
        logger.info(f"   Revenue: ${total_revenue:,.2f} | Founder: ${founder_royalty_usd:,.2f}")
        logger.info(f"   Blockchain: {blockchain_hash[:16]}...")
        
        return asdict(allocation)
    
    def _distribute_revenue(self, allocation_id: str, total_revenue: float):
        """Distribute revenue"""
        distribution = {
            "founder": total_revenue * 0.30,
            "ai_validators": total_revenue * 0.40,
            "ecosystem": total_revenue * 0.18,
            "hardware_hosts": total_revenue * 0.10,
            "zakat": total_revenue * 0.02
        }
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO revenue_distribution 
            (allocation_id, total_revenue_usd, founder_share_usd, ai_validators_share_usd,
             ecosystem_share_usd, hardware_hosts_share_usd, zakat_share_usd, distributed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            allocation_id, total_revenue, distribution['founder'],
            distribution['ai_validators'], distribution['ecosystem'],
            distribution['hardware_hosts'], distribution['zakat'],
            datetime.now().isoformat()
        ))
        conn.commit()
        conn.close()
    
    def get_revenue_stats(self) -> Dict:
        """Get revenue statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Port revenues
        cursor.execute("""
            SELECT SUM(revenue_usd), SUM(founder_royalty_usd)
            FROM ports
        """)
        port_row = cursor.fetchone()
        
        # Operations count
        cursor.execute("""
            SELECT COUNT(*), SUM(containers_handled)
            FROM berth_allocations
        """)
        ops_row = cursor.fetchone()
        
        conn.close()
        
        return {
            "service": "OliveSea Port Management",
            "port": OLIVESEA_PORTS_PORT,
            "total_ports": len(self.ports),
            "total_operations": ops_row[0] or 0,
            "total_containers_handled": ops_row[1] or 0,
            "total_revenue_usd": port_row[0] or 0,
            "founder_royalty_usd": port_row[1] or 0,
            "founder_royalty_rate": FOUNDER_ROYALTY_RATE,
            "integrations": {
                "quranchain": "✅ Connected",
                "fungi_mesh": "✅ Connected",
                "meshtalk": "✅ Connected",
                "olivesea_maritime": "✅ Connected"
            }
        }

# Technology Licensing Smart Contract System  
class TechnologyLicense:
    """Smart contract for OliveSea port technology licensing"""
    
    LICENSE_TECHNOLOGIES = {
        "smart_berth_allocation": {"annual_fee_usd": 1200000, "royalty_rate": 0.10},
        "ai_crane_optimization": {"annual_fee_usd": 900000, "royalty_rate": 0.08},
        "blockchain_cargo_tracking": {"annual_fee_usd": 650000, "royalty_rate": 0.06},
        "port_automation_suite": {"annual_fee_usd": 2000000, "royalty_rate": 0.15}
    }
    
    @staticmethod
    def create_license(licensee: str, technology: str, duration_years: int = 1) -> Dict:
        """Create technology license smart contract"""
        if technology not in TechnologyLicense.LICENSE_TECHNOLOGIES:
            raise ValueError(f"Technology {technology} not available")
        
        tech = TechnologyLicense.LICENSE_TECHNOLOGIES[technology]
        total_fee = tech['annual_fee_usd'] * duration_years
        founder_royalty = total_fee * FOUNDER_ROYALTY_RATE
        
        license_data = {
            "license_id": f"OSEA-P-LIC-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "licensee": licensee,
            "technology": technology,
            "duration_years": duration_years,
            "total_fee_usd": total_fee,
            "founder_royalty_usd": founder_royalty,
            "issued_at": datetime.now().isoformat(),
            "blockchain_hash": hashlib.sha256(json.dumps({"licensee": licensee, "tech": technology}).encode()).hexdigest()
        }
        
        try:
            requests.post(f"{QURANCHAIN_MAINNET}/register_license", json=license_data, timeout=3)
        except:
            pass
        
        logger.info(f"✅ Port license: {license_data['license_id']}, Fee: ${total_fee:,.2f}")
        return license_data

# Global engine
ports_engine = OliveSeaPortsEngine()

# API Endpoints
@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status": "online",
        "service": "OliveSea Port Management",
        "port": OLIVESEA_PORTS_PORT,
        "ports_managed": len(ports_engine.ports),
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)"
    })

@app.route('/ports', methods=['GET'])
def get_ports():
    return jsonify({
        "ports": [asdict(p) for p in ports_engine.ports],
        "total_ports": len(ports_engine.ports)
    })

@app.route('/berth/allocate', methods=['POST'])
def allocate_berth():
    data = request.json
    try:
        arrival_time = datetime.fromisoformat(data['arrival_time'])
        allocation = ports_engine.allocate_berth(
            port_id=data['port_id'],
            vessel_name=data['vessel_name'],
            vessel_imo=data['vessel_imo'],
            arrival_time=arrival_time,
            operation_type=data['operation_type'],
            containers_handled=data['containers_handled']
        )
        return jsonify({"success": True, "allocation": allocation})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/revenue/stats', methods=['GET'])
def revenue_stats():
    return jsonify(ports_engine.get_revenue_stats())

@app.route('/rates', methods=['GET'])
def get_rates():
    return jsonify(ports_engine.rates)

@app.route('/license/technology', methods=['POST'])
def create_technology_license():
    """Create technology licensing smart contract"""
    data = request.json
    try:
        license_contract = TechnologyLicense.create_license(
            licensee=data['licensee'],
            technology=data['technology'],
            duration_years=data.get('duration_years', 1)
        )
        return jsonify({"success": True, "license": license_contract})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/license/available', methods=['GET'])
def get_available_licenses():
    """Get available technology licenses"""
    return jsonify(TechnologyLicense.LICENSE_TECHNOLOGIES)

@app.route('/', methods=['GET'])
def index():
    return jsonify({
        "service": "🏢 OliveSea Port Management",
        "status": "ONLINE",
        "port": OLIVESEA_PORTS_PORT,
        "founder": "Omar Mohammad Abunadi™",
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)",
        "ports_network": [p.port_name for p in ports_engine.ports],
        "technology_licensing": "✅ Smart Contracts Available",
        "integrations": {
            "quranchain": "✅",
            "fungi_mesh": "✅",
            "meshtalk": "✅",
            "darcloud": "✅"
        }
    })

if __name__ == "__main__":
    logger.info("="*80)
    logger.info("🏢 OLIVESEA PORT MANAGEMENT - STARTING")
    logger.info("="*80)
    logger.info(f"   Port: {OLIVESEA_PORTS_PORT}")
    logger.info(f"   Terminals: {len(ports_engine.ports)}")
    logger.info(f"   Founder Royalty: {FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)")
    logger.info("="*80)
    
    app.run(host="0.0.0.0", port=OLIVESEA_PORTS_PORT, debug=False)
