#!/usr/bin/env python3

"""
DARCLOUD WEBSITE BUILDER - FASTAPI REST API & DASHBOARD
Production-ready API for website hosting management, customer registration, and AI website design
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, File, UploadFile
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from typing import Optional, List
import asyncio
import json
from datetime import datetime
import sys
import os

# Add QuranChain to path
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from organized.services.website_hosting_platform import (
    DarcloudWebsiteHostingAPI,
    PlanTier,
    PRICING,
    FOUNDER_ROYALTY_RATE
)

# ============================================================================
# FASTAPI APP SETUP
# ============================================================================

app = FastAPI(
    title="Darcloud Website Hosting API",
    description="Production-ready website hosting, domain registration, and AI website design platform",
    version="1.0.0"
)

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize platform
api = DarcloudWebsiteHostingAPI()

# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class CustomerRegistrationRequest(BaseModel):
    email: EmailStr
    company_name: str
    phone: str
    website_idea: Optional[str] = None

class WebsiteCreationRequest(BaseModel):
    domain: str
    plan_tier: str
    website_style: Optional[str] = "minimal"

class DomainSearchRequest(BaseModel):
    domain_name: str

class WebsiteDesignRequest(BaseModel):
    design_style: str  # "minimal", "corporate", "creative", "ecommerce"
    industry: str
    color_scheme: Optional[str] = None
    target_audience: Optional[str] = None

class PaymentRequest(BaseModel):
    plan_tier: str
    billing_period: str  # "monthly" or "yearly"

# ============================================================================
# CUSTOMER ENDPOINTS
# ============================================================================

@app.post("/api/v1/customers/register")
async def register_customer(request: CustomerRegistrationRequest, background_tasks: BackgroundTasks):
    """
    Register new customer for Darcloud website hosting
    
    Returns: customer_id, welcome message, getting started guide
    """
    try:
        result = await api.customer_service.register_customer(
            email=request.email,
            company_name=request.company_name,
            phone=request.phone
        )
        
        if result["status"] == "error":
            raise HTTPException(status_code=400, detail=result["error"])
        
        # Send welcome email in background
        background_tasks.add_task(send_welcome_email, request.email, result["customer_id"])
        
        return {
            "status": "success",
            "customer_id": result["customer_id"],
            "message": "Welcome to Darcloud! ✨",
            "next_steps": [
                "Create your first website",
                "Register a domain",
                "Design with AI agent",
                "Launch in 2-3 days"
            ]
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/customers/{customer_id}")
async def get_customer_profile(customer_id: str):
    """Get customer profile and dashboard data"""
    try:
        profile = await api.customer_service.get_customer_profile(customer_id)
        
        if not profile:
            raise HTTPException(status_code=404, detail="Customer not found")
        
        return {
            "status": "success",
            "customer": profile,
            "dashboard": {
                "websites_created": profile["websites_count"],
                "total_spent": profile["total_spent"],
                "plan_tier": profile["plan_tier"],
                "member_since": profile["created_at"]
            }
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/customers/{customer_id}/upgrade-plan")
async def upgrade_plan(customer_id: str, request: PaymentRequest, background_tasks: BackgroundTasks):
    """Upgrade customer plan tier"""
    try:
        result = await api.customer_service.upgrade_plan(customer_id, request.plan_tier)
        
        # Process payment in background
        pricing = PRICING.get(PlanTier[request.plan_tier.upper()])
        amount = pricing["yearly"] if request.billing_period == "yearly" else pricing["monthly"]
        
        background_tasks.add_task(
            api.revenue_engine.process_payment,
            customer_id,
            amount,
            f"plan_upgrade_{request.plan_tier}"
        )
        
        return {
            "status": "success",
            "customer_id": customer_id,
            "new_tier": request.plan_tier,
            "amount": amount,
            "billing_period": request.billing_period
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# WEBSITE ENDPOINTS
# ============================================================================

@app.post("/api/v1/websites/create")
async def create_website(request: WebsiteCreationRequest, customer_id: str, background_tasks: BackgroundTasks):
    """
    Create new WordPress website for customer
    
    Includes: domain setup, WordPress installation, basic configuration
    """
    try:
        # Create website
        result = await api.create_website(
            customer_id=customer_id,
            domain=request.domain,
            plan_tier=request.plan_tier
        )
        
        if result["status"] == "error":
            raise HTTPException(status_code=400, detail=result["error"])
        
        # Register domain in background
        background_tasks.add_task(
            api.domain_service.register_domain,
            type('DomainReg', (), {
                'domain': request.domain,
                'registrar': 'cloudflare',
                'dns_provider': 'cloudflare'
            }),
            customer_id
        )
        
        return {
            "status": "success",
            "website_id": result["website_id"],
            "domain": result["domain"],
            "wordpress_url": result["wordpress_url"],
            "admin_url": result["admin_url"],
            "deployment_status": "provisioning",
            "estimated_ready_time": "5-10 minutes",
            "next_step": "Request AI website design"
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/websites/{website_id}")
async def get_website_details(website_id: str):
    """Get website details and status"""
    try:
        query = 'SELECT * FROM websites WHERE website_id = ?'
        result = api.db.execute_query(query, (website_id,))
        
        if not result:
            raise HTTPException(status_code=404, detail="Website not found")
        
        row = result[0]
        return {
            "status": "success",
            "website": {
                "website_id": row[0],
                "domain": row[2],
                "status": row[3],
                "plan_tier": row[4],
                "wordpress_url": row[5],
                "created_at": row[8]
            }
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/websites/{website_id}/design")
async def request_website_design(website_id: str, customer_id: str, request: WebsiteDesignRequest, background_tasks: BackgroundTasks):
    """
    Request AI-powered website design
    
    The design agent will:
    - Analyze your industry and style preferences
    - Generate layout suggestions
    - Recommend WordPress theme and plugins
    - Create content structure
    """
    try:
        result = await api.request_website_design(
            customer_id=customer_id,
            website_id=website_id,
            design_style=request.design_style,
            industry=request.industry
        )
        
        if result["status"] == "error":
            raise HTTPException(status_code=400, detail=result["error"])
        
        design_plan = result["design_plan"]
        
        # Deploy design in background
        background_tasks.add_task(
            api.design_agent.deploy_design,
            website_id,
            design_plan
        )
        
        return {
            "status": "success",
            "design_request_id": design_plan["request_id"],
            "website_id": website_id,
            "design_style": request.design_style,
            "industry": request.industry,
            "deployment_status": "deploying",
            "estimated_completion": "2-3 days",
            "design_details": {
                "theme": design_plan["theme"],
                "plugins": design_plan["plugins"],
                "color_scheme": design_plan["color_scheme"],
                "layout_suggestions": design_plan["layout_suggestions"],
                "content_sections": design_plan["content_sections"]
            }
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# DOMAIN ENDPOINTS
# ============================================================================

@app.post("/api/v1/domains/search")
async def search_domains(request: DomainSearchRequest):
    """
    Search available domains
    
    Returns: availability, pricing, registration options
    """
    try:
        results = await api.domain_service.search_domains(request.domain_name)
        
        available = [d for d in results if d.available]
        taken = [d for d in results if not d.available]
        
        return {
            "status": "success",
            "search_term": request.domain_name,
            "available": [
                {
                    "domain": d.domain,
                    "tld": d.tld,
                    "price_yearly": d.price_yearly,
                    "premium": d.premium
                }
                for d in available
            ],
            "taken": [d.domain for d in taken],
            "total_available": len(available)
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/domains/{domain}/register")
async def register_domain(domain: str, customer_id: str, background_tasks: BackgroundTasks):
    """Register domain for customer"""
    try:
        result = await api.domain_service.register_domain(
            type('DomainReg', (), {
                'domain': domain,
                'registrar': 'cloudflare',
                'status': 'pending',
                'expiry_date': None,
                'auto_renew': True,
                'registrar_id': '',
                'dns_provider': 'cloudflare'
            }),
            customer_id
        )
        
        return {
            "status": "success",
            "domain": result["domain"],
            "registrar": result["registrar"],
            "expiry_date": result["expiry_date"],
            "auto_renewal": True,
            "dns_instructions": "DNS configured via Cloudflare"
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# PRICING & PLANS ENDPOINTS
# ============================================================================

@app.get("/api/v1/pricing")
async def get_pricing():
    """Get all pricing tiers and plans"""
    return {
        "status": "success",
        "plans": {
            "starter": {
                "name": "Starter",
                "monthly": PRICING[PlanTier.STARTER]["monthly"],
                "yearly": PRICING[PlanTier.STARTER]["yearly"],
                "features": PRICING[PlanTier.STARTER]["features"],
                "best_for": "New websites and blogs"
            },
            "professional": {
                "name": "Professional",
                "monthly": PRICING[PlanTier.PROFESSIONAL]["monthly"],
                "yearly": PRICING[PlanTier.PROFESSIONAL]["yearly"],
                "features": PRICING[PlanTier.PROFESSIONAL]["features"],
                "best_for": "Growing businesses"
            },
            "enterprise": {
                "name": "Enterprise",
                "monthly": PRICING[PlanTier.ENTERPRISE]["monthly"],
                "yearly": PRICING[PlanTier.ENTERPRISE]["yearly"],
                "features": PRICING[PlanTier.ENTERPRISE]["features"],
                "best_for": "High-volume e-commerce and SaaS"
            }
        },
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE * 100}% (immutable)",
        "note": "All pricing includes Cloudflare global CDN, SSL encryption, and daily backups"
    }

# ============================================================================
# MARKETING & CAPTURE ENDPOINTS
# ============================================================================

@app.get("/", response_class=HTMLResponse)
async def landing_page():
    """Main landing page with customer capture"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Darcloud - AI-Powered Website Hosting</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 100px 20px; text-align: center; }
            .header h1 { font-size: 3.5em; margin-bottom: 20px; }
            .header p { font-size: 1.3em; margin-bottom: 30px; opacity: 0.95; }
            .cta-button { background: white; color: #667eea; padding: 15px 40px; font-size: 1.1em; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
            .cta-button:hover { transform: scale(1.05); }
            .container { max-width: 1200px; margin: 0 auto; padding: 40px 20px; }
            .features { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; margin-bottom: 60px; }
            .feature { padding: 30px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #667eea; }
            .feature h3 { color: #667eea; margin-bottom: 10px; }
            .signup-section { background: #f8f9fa; padding: 60px 40px; border-radius: 10px; margin: 60px 0; }
            .form-group { margin-bottom: 15px; }
            .form-group input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 1em; }
            .form-group input:focus { outline: none; border-color: #667eea; box-shadow: 0 0 5px rgba(102, 126, 234, 0.5); }
            .pricing-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; }
            .price-card { border: 2px solid #ddd; padding: 40px; border-radius: 10px; text-align: center; }
            .price-card.featured { border-color: #667eea; box-shadow: 0 10px 30px rgba(102, 126, 234, 0.2); }
            .price-card h3 { margin-bottom: 15px; font-size: 1.5em; }
            .price-card .amount { font-size: 2.5em; color: #667eea; margin-bottom: 20px; }
            .price-card ul { list-style: none; margin-bottom: 30px; text-align: left; }
            .price-card li { padding: 10px 0; border-bottom: 1px solid #eee; }
            .footer { background: #1a1a1a; color: white; padding: 40px 20px; text-align: center; }
            .dashboard-link { margin-top: 20px; }
            .dashboard-link input { padding: 10px 20px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🌐 Darcloud Website Hosting</h1>
            <p>AI-Powered WordPress Hosting with Intelligent Website Design Agent</p>
            <p style="font-size: 1em; margin-top: 20px;">Create professional websites in 2-3 days • Global CDN • 30% Founder Share</p>
        </div>
        
        <div class="container">
            <!-- Features -->
            <div style="margin-bottom: 60px;">
                <h2 style="text-align: center; margin-bottom: 40px; color: #333;">Why Choose Darcloud?</h2>
                <div class="features">
                    <div class="feature">
                        <h3>🤖 AI Website Designer</h3>
                        <p>Intelligent agent designs your website based on your industry and style preferences</p>
                    </div>
                    <div class="feature">
                        <h3>⚡ Lightning Fast</h3>
                        <p>Global Cloudflare CDN with 60-75% latency reduction and automatic caching</p>
                    </div>
                    <div class="feature">
                        <h3>🔒 Bank-Level Security</h3>
                        <p>TLS 1.3, WAF protection, DDoS mitigation, automatic SSL certificates</p>
                    </div>
                    <div class="feature">
                        <h3>💰 Transparent Pricing</h3>
                        <p>Simple pricing starting at $4.99/month with 30% founder royalty</p>
                    </div>
                    <div class="feature">
                        <h3>🌍 Global Reach</h3>
                        <p>Serve users worldwide with 232 Cloudflare POPs for maximum performance</p>
                    </div>
                    <div class="feature">
                        <h3>📦 All-In-One Platform</h3>
                        <p>Website hosting, domain registration, SSL, backups, all included</p>
                    </div>
                </div>
            </div>
            
            <!-- Customer Signup -->
            <div class="signup-section">
                <h2 style="text-align: center; color: #333; margin-bottom: 40px;">Get Started Today - It's Free!</h2>
                <form id="registrationForm" style="max-width: 500px; margin: 0 auto;">
                    <div class="form-group">
                        <input type="email" placeholder="Email Address" id="email" required>
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Company/Website Name" id="company" required>
                    </div>
                    <div class="form-group">
                        <input type="tel" placeholder="Phone Number" id="phone" required>
                    </div>
                    <div class="form-group">
                        <textarea id="idea" placeholder="What's your website idea? (optional)" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-family: inherit; min-height: 100px;"></textarea>
                    </div>
                    <button type="submit" class="cta-button" style="width: 100%; font-size: 1.1em;">Create Free Account</button>
                </form>
                <p style="text-align: center; margin-top: 20px; color: #666;">✨ No credit card required • Free tier gives you full features</p>
            </div>
            
            <!-- Pricing -->
            <div style="margin-bottom: 60px;">
                <h2 style="text-align: center; margin-bottom: 40px; color: #333;">Simple, Transparent Pricing</h2>
                <div class="pricing-grid">
                    <div class="price-card">
                        <h3>Starter</h3>
                        <p style="color: #666; margin-bottom: 15px;">For new websites</p>
                        <div class="amount">$4.99<span style="font-size: 0.4em;">/month</span></div>
                        <ul>
                            <li>✓ Basic WordPress</li>
                            <li>✓ 5GB Storage</li>
                            <li>✓ Free SSL</li>
                            <li>✓ Email Support</li>
                            <li>✓ Global CDN</li>
                        </ul>
                        <button class="cta-button">Start Free</button>
                    </div>
                    <div class="price-card featured">
                        <div style="background: #667eea; color: white; padding: 10px; border-radius: 5px; margin: -40px -40px 30px; font-weight: bold;">⭐ MOST POPULAR</div>
                        <h3>Professional</h3>
                        <p style="color: #666; margin-bottom: 15px;">For growing businesses</p>
                        <div class="amount">$14.99<span style="font-size: 0.4em;">/month</span></div>
                        <ul>
                            <li>✓ Everything in Starter</li>
                            <li>✓ 50GB Storage</li>
                            <li>✓ Premium Plugins</li>
                            <li>✓ Priority Support</li>
                            <li>✓ Daily Backups</li>
                        </ul>
                        <button class="cta-button">Start Free</button>
                    </div>
                    <div class="price-card">
                        <h3>Enterprise</h3>
                        <p style="color: #666; margin-bottom: 15px;">For e-commerce & SaaS</p>
                        <div class="amount">$49.99<span style="font-size: 0.4em;">/month</span></div>
                        <ul>
                            <li>✓ Full Customization</li>
                            <li>✓ Unlimited Storage</li>
                            <li>✓ All Premium Plugins</li>
                            <li>✓ 24/7 Support</li>
                            <li>✓ Weekly Backups</li>
                        </ul>
                        <button class="cta-button">Contact Sales</button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Access -->
            <div class="dashboard-link" style="text-align: center; margin: 40px 0;">
                <h3 style="margin-bottom: 20px;">Already a Darcloud Customer?</h3>
                <input type="text" placeholder="Enter your Customer ID" id="customerId" style="width: 300px; max-width: 100%; padding: 12px;">
                <button onclick="goToDashboard()" class="cta-button" style="margin-left: 10px;">Access Dashboard</button>
            </div>
        </div>
        
        <div class="footer">
            <p>&copy; 2026 Darcloud. All rights reserved. | 30% Founder Royalty | Powered by DarCloud Ecosystem</p>
        </div>
        
        <script>
            document.getElementById('registrationForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const email = document.getElementById('email').value;
                const company = document.getElementById('company').value;
                const phone = document.getElementById('phone').value;
                
                try {
                    const response = await fetch('/api/v1/customers/register', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            email: email,
                            company_name: company,
                            phone: phone,
                            website_idea: document.getElementById('idea').value
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.status === 'success') {
                        alert(`Welcome to Darcloud! 🎉\\n\\nYour Customer ID: ${data.customer_id}\\n\\nNext steps:\\n${data.next_steps.join('\\n')}`);
                        document.getElementById('registrationForm').reset();
                    } else {
                        alert('Error: ' + data.detail);
                    }
                } catch (error) {
                    alert('Error registering: ' + error.message);
                }
            });
            
            function goToDashboard() {
                const customerId = document.getElementById('customerId').value;
                if (customerId) {
                    window.location.href = `/dashboard/${customerId}`;
                } else {
                    alert('Please enter your Customer ID');
                }
            }
        </script>
    </body>
    </html>
    """

# ============================================================================
# DASHBOARD ENDPOINT
# ============================================================================

@app.get("/dashboard/{customer_id}", response_class=HTMLResponse)
async def customer_dashboard(customer_id: str):
    """Customer dashboard"""
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Darcloud Dashboard</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; }}
            .navbar {{ background: #667eea; color: white; padding: 20px; display: flex; justify-content: space-between; align-items: center; }}
            .navbar h1 {{ font-size: 1.5em; }}
            .container {{ max-width: 1200px; margin: 40px auto; padding: 0 20px; }}
            .card {{ background: white; padding: 30px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            .card h2 {{ color: #333; margin-bottom: 15px; }}
            .button {{ background: #667eea; color: white; padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 1em; margin-right: 10px; }}
            .button:hover {{ background: #5568d3; }}
            .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }}
            .stat {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }}
            .stat-value {{ font-size: 2em; font-weight: bold; }}
            .stat-label {{ font-size: 0.9em; opacity: 0.9; margin-top: 10px; }}
        </style>
    </head>
    <body>
        <div class="navbar">
            <h1>🌐 Darcloud Dashboard</h1>
            <p>Customer ID: {customer_id}</p>
        </div>
        
        <div class="container">
            <!-- Profile Stats -->
            <div class="grid" style="margin-bottom: 30px;">
                <div class="stat">
                    <div class="stat-value" id="websites">0</div>
                    <div class="stat-label">Websites</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="spent">$0</div>
                    <div class="stat-label">Total Spent</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="plan">Starter</div>
                    <div class="stat-label">Current Plan</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="member">Today</div>
                    <div class="stat-label">Member Since</div>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="card">
                <h2>Quick Actions</h2>
                <button class="button" onclick="createWebsite()">+ Create Website</button>
                <button class="button" onclick="searchDomain()">🔍 Search Domain</button>
                <button class="button" onclick="upgradePlan()">⬆️ Upgrade Plan</button>
                <button class="button" onclick="logout()">Logout</button>
            </div>
            
            <!-- Websites List -->
            <div class="card">
                <h2>Your Websites</h2>
                <div id="websites-list" style="margin-top: 20px;"></div>
            </div>
        </div>
        
        <script>
            const customerId = '{customer_id}';
            
            async function loadProfile() {{
                try {{
                    const response = await fetch(`/api/v1/customers/${{customerId}}`);
                    const data = await response.json();
                    
                    if (data.status === 'success') {{
                        const profile = data.customer;
                        document.getElementById('websites').textContent = profile.websites_count;
                        document.getElementById('spent').textContent = '$' + profile.total_spent.toFixed(2);
                        document.getElementById('plan').textContent = profile.plan_tier.charAt(0).toUpperCase() + profile.plan_tier.slice(1);
                        document.getElementById('member').textContent = new Date(profile.created_at).toLocaleDateString();
                    }}
                }} catch (e) {{
                    console.error('Error loading profile:', e);
                }}
            }}
            
            function createWebsite() {{
                const domain = prompt('Enter domain (e.g., mywebsite.com):');
                if (domain) {{
                    alert(`Creating website for ${{domain}}... This will take 5-10 minutes.`);
                    // Make API call to create website
                }}
            }}
            
            function searchDomain() {{
                const domain = prompt('Search domain (e.g., mycompany):');
                if (domain) {{
                    window.location.href = `/api/v1/domains/search?domain=${{domain}}`;
                }}
            }}
            
            function upgradePlan() {{
                alert('Upgrade your plan to Professional ($14.99/month) or Enterprise ($49.99/month)');
            }}
            
            function logout() {{
                if (confirm('Logout?')) {{
                    window.location.href = '/';
                }}
            }}
            
            // Load profile on page load
            loadProfile();
        </script>
    </body>
    </html>
    """

# ============================================================================
# HEALTH && INFO ENDPOINTS
# ============================================================================

@app.get("/api/v1/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Darcloud Website Hosting",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/v1/info")
async def service_info():
    """Service information"""
    return {
        "name": "Darcloud Website Hosting Platform",
        "description": "Production-ready website hosting with AI website design agent",
        "version": "1.0.0",
        "features": [
            "WordPress hosting",
            "Domain registration",
            "AI website designer",
            "Global CDN",
            "SSL encryption",
            "Customer management",
            "Revenue tracking"
        ],
        "endpoints": {
            "customers": "/api/v1/customers/register",
            "websites": "/api/v1/websites/create",
            "domains": "/api/v1/domains/search",
            "pricing": "/api/v1/pricing",
            "dashboard": "/dashboard/{customer_id}"
        },
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE * 100}%"
    }

# ============================================================================
# BACKGROUND TASKS
# ============================================================================

async def send_welcome_email(email: str, customer_id: str):
    """Send welcome email (mock)"""
    # In production: integrate with email service
    print(f"📧 Welcome email sent to {email} | Customer ID: {customer_id}")

# ============================================================================
# RUN SERVER
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    print("🚀 Starting Darcloud Website Hosting API Server")
    print("📊 Database: /home/omar/Desktop/QuranChain/crm/websites.db")
    print("🌐 Server: http://localhost:8787")
    print("📖 Docs: http://localhost:8787/docs")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8787,
        log_level="info"
    )
