#!/usr/bin/env python3
"""
🔐 DARCLOUD SSL CERTIFICATE MANAGER
Automatic SSL certificate generation and management for Islamic domains
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import json
import time
import logging
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
import uvicorn

# Add project root to path
sys.path.insert(0, "/home/omar/Desktop/QuranChain")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] 🔐 SSL - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="DarCloud SSL Certificate Manager", version="1.0.0")

# SSL storage
SSL_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_ssl")
SSL_DIR.mkdir(exist_ok=True)

class SSLCertificateManager:
    """Manages SSL certificates for Islamic domains"""

    def __init__(self):
        self.certificates = {}
        self.load_certificate_registry()
        logger.info("🔐 SSL Certificate Manager initialized")

    def load_certificate_registry(self):
        """Load SSL certificates from registry"""
        registry_file = SSL_DIR / "certificates.json"
        if registry_file.exists():
            try:
                with open(registry_file, 'r') as f:
                    data = json.load(f)
                    self.certificates = data.get('certificates', {})
                logger.info(f"📋 Loaded {len(self.certificates)} SSL certificates from registry")
            except Exception as e:
                logger.error(f"Failed to load SSL registry: {e}")

    def save_certificate_registry(self):
        """Save SSL certificates to registry"""
        registry_file = SSL_DIR / "certificates.json"
        try:
            data = {
                'certificates': self.certificates,
                'last_updated': datetime.utcnow().isoformat() + "Z"
            }
            with open(registry_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info("💾 SSL certificate registry saved")
        except Exception as e:
            logger.error(f"Failed to save SSL registry: {e}")

    def generate_ssl_certificate(self, domain: str, owner: str = "Omar Mohammad Abunadi™") -> Dict:
        """Generate SSL certificate for domain"""

        # Check if certificate already exists
        if domain in self.certificates:
            existing_cert = self.certificates[domain]
            expiry_date = datetime.fromisoformat(existing_cert['expiry_date'][:-1])
            if expiry_date > datetime.utcnow() + timedelta(days=30):
                logger.info(f"✅ SSL certificate for {domain} is still valid")
                return existing_cert

        # Generate new certificate
        cert_info = self._generate_self_signed_cert(domain, owner)

        self.certificates[domain] = cert_info
        self.save_certificate_registry()

        logger.info(f"✅ SSL certificate generated for {domain}")
        return cert_info

    def _generate_self_signed_cert(self, domain: str, owner: str) -> Dict:
        """Generate self-signed SSL certificate"""

        # Certificate paths
        cert_dir = SSL_DIR / domain.replace(".", "_")
        cert_dir.mkdir(exist_ok=True)

        key_file = cert_dir / "private.key"
        cert_file = cert_dir / "certificate.crt"
        csr_file = cert_dir / "certificate.csr"

        # Generate private key
        try:
            subprocess.run([
                "openssl", "genrsa", "-out", str(key_file), "2048"
            ], check=True, capture_output=True)

            # Generate certificate signing request
            subprocess.run([
                "openssl", "req", "-new", "-key", str(key_file),
                "-out", str(csr_file), "-subj",
                f"/C=SA/ST=Riyadh/L=Riyadh/O=QuranChain/CN={domain}/emailAddress=admin@{domain}"
            ], check=True, capture_output=True)

            # Generate self-signed certificate (valid for 1 year)
            subprocess.run([
                "openssl", "x509", "-req", "-days", "365",
                "-in", str(csr_file), "-signkey", str(key_file),
                "-out", str(cert_file)
            ], check=True, capture_output=True)

            # Get certificate info
            result = subprocess.run([
                "openssl", "x509", "-in", str(cert_file), "-text", "-noout"
            ], capture_output=True, text=True, check=True)

            # Parse expiry date
            expiry_date = datetime.utcnow() + timedelta(days=365)

            cert_info = {
                "domain": domain,
                "owner": owner,
                "certificate_file": str(cert_file),
                "private_key_file": str(key_file),
                "csr_file": str(csr_file),
                "issued_at": datetime.utcnow().isoformat() + "Z",
                "expiry_date": expiry_date.isoformat() + "Z",
                "issuer": "QuranChain SSL Authority",
                "algorithm": "RSA-2048",
                "status": "active",
                "auto_renew": True,
                "certificate_data": self._read_certificate_data(cert_file),
                "private_key_data": self._read_certificate_data(key_file)
            }

            logger.info(f"🔐 Self-signed SSL certificate generated for {domain}")
            return cert_info

        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to generate SSL certificate for {domain}: {e}")
            raise Exception(f"SSL certificate generation failed: {e}")

    def _read_certificate_data(self, file_path: Path) -> str:
        """Read certificate file content"""
        try:
            with open(file_path, 'r') as f:
                return f.read()
        except Exception as e:
            logger.error(f"Failed to read certificate file {file_path}: {e}")
            return ""

    def get_ssl_certificate(self, domain: str) -> Optional[Dict]:
        """Get SSL certificate for domain"""
        return self.certificates.get(domain)

    def renew_ssl_certificate(self, domain: str) -> bool:
        """Renew SSL certificate for domain"""
        if domain not in self.certificates:
            return False

        try:
            # Generate new certificate
            new_cert = self._generate_self_signed_cert(domain, self.certificates[domain]['owner'])

            # Update registry
            self.certificates[domain] = new_cert
            self.save_certificate_registry()

            logger.info(f"🔄 SSL certificate renewed for {domain}")
            return True

        except Exception as e:
            logger.error(f"Failed to renew SSL certificate for {domain}: {e}")
            return False

    def delete_ssl_certificate(self, domain: str) -> bool:
        """Delete SSL certificate for domain"""
        if domain in self.certificates:
            cert_info = self.certificates[domain]

            # Remove certificate files
            try:
                for file_path in [cert_info.get('certificate_file'), cert_info.get('private_key_file'), cert_info.get('csr_file')]:
                    if file_path and Path(file_path).exists():
                        Path(file_path).unlink()
            except Exception as e:
                logger.warning(f"Failed to remove certificate files for {domain}: {e}")

            # Remove from registry
            del self.certificates[domain]
            self.save_certificate_registry()

            logger.info(f"🗑️ SSL certificate deleted for {domain}")
            return True

        return False

    def list_certificates(self) -> List[Dict]:
        """List all SSL certificates"""
        return list(self.certificates.values())

    def get_expiring_certificates(self, days: int = 30) -> List[Dict]:
        """Get certificates expiring within specified days"""
        expiring = []
        cutoff_date = datetime.utcnow() + timedelta(days=days)

        for cert in self.certificates.values():
            expiry_date = datetime.fromisoformat(cert['expiry_date'][:-1])
            if expiry_date <= cutoff_date:
                expiring.append(cert)

        return expiring

    def auto_renew_certificates(self):
        """Auto-renew expiring certificates"""
        expiring = self.get_expiring_certificates(30)

        for cert in expiring:
            if cert.get('auto_renew', False):
                self.renew_ssl_certificate(cert['domain'])

        if expiring:
            logger.info(f"🔄 Auto-renewed {len(expiring)} SSL certificates")

# Global SSL manager
ssl_manager = SSLCertificateManager()

# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.get("/")
def root():
    """DarCloud SSL Certificate Manager Dashboard"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>🔐 DarCloud SSL Certificate Manager</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .header {{ background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
            .stat-card {{ background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }}
            .stat-number {{ font-size: 2em; font-weight: bold; color: #2196F3; }}
            .certificates {{ margin-top: 30px; }}
            .cert-card {{ background: white; margin: 10px 0; padding: 15px; border-radius: 8px; box-shadow: 0 1px 5px rgba(0,0,0,0.1); }}
            .expiring {{ background: #fff3cd; border-left: 4px solid #ffc107; }}
            .expired {{ background: #f8d7da; border-left: 4px solid #dc3545; }}
            .valid {{ background: #d1ecf1; border-left: 4px solid #17a2b8; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🔐 DarCloud SSL Certificate Manager</h1>
            <p>Automatic SSL Certificate Generation & Management</p>
            <p><strong>Authority:</strong> QuranChain SSL Authority</p>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">{len(ssl_manager.certificates)}</div>
                <div>SSL Certificates</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{len(ssl_manager.get_expiring_certificates(30))}</div>
                <div>Expiring Soon</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">RSA-2048</div>
                <div>Algorithm</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">365</div>
                <div>Days Valid</div>
            </div>
        </div>

        <div class="certificates">
            <h2>📋 SSL Certificates</h2>
    """

    for cert in ssl_manager.list_certificates():
        expiry_date = datetime.fromisoformat(cert['expiry_date'][:-1])
        days_until_expiry = (expiry_date - datetime.utcnow()).days

        if days_until_expiry < 0:
            css_class = "expired"
            status_text = "EXPIRED"
        elif days_until_expiry <= 30:
            css_class = "expiring"
            status_text = f"EXPIRES IN {days_until_expiry} DAYS"
        else:
            css_class = "valid"
            status_text = "VALID"

        html_content += f"""
            <div class="cert-card {css_class}">
                <h3>{cert['domain']}</h3>
                <p><strong>Owner:</strong> {cert['owner']}</p>
                <p><strong>Issued:</strong> {cert['issued_at'][:19]}</p>
                <p><strong>Expires:</strong> {cert['expiry_date'][:19]}</p>
                <p><strong>Status:</strong> <span style="font-weight: bold;">{status_text}</span></p>
                <p><strong>Algorithm:</strong> {cert['algorithm']}</p>
            </div>
        """

    html_content += """
        </div>
    </body>
    </html>
    """

    return HTMLResponse(content=html_content)

@app.post("/generate/{domain}")
def generate_ssl_certificate(domain: str, owner: str = "Omar Mohammad Abunadi™"):
    """Generate SSL certificate for domain"""
    try:
        result = ssl_manager.generate_ssl_certificate(domain, owner)
        return JSONResponse({
            "status": "success",
            "message": f"SSL certificate generated for {domain}",
            "data": result
        })
    except Exception as e:
        logger.error(f"SSL generation failed for {domain}: {e}")
        raise HTTPException(status_code=500, detail=f"SSL generation failed: {str(e)}")

@app.get("/api/certificates")
def list_certificates():
    """List all SSL certificates"""
    return JSONResponse({
        "certificates": ssl_manager.list_certificates(),
        "total": len(ssl_manager.certificates)
    })

@app.get("/api/certificate/{domain}")
def get_ssl_certificate(domain: str):
    """Get SSL certificate for domain"""
    cert = ssl_manager.get_ssl_certificate(domain)
    if not cert:
        raise HTTPException(status_code=404, detail="SSL certificate not found")

    return JSONResponse(cert)

@app.post("/api/renew/{domain}")
def renew_ssl_certificate(domain: str):
    """Renew SSL certificate for domain"""
    if ssl_manager.renew_ssl_certificate(domain):
        return JSONResponse({"status": "success", "message": f"SSL certificate renewed for {domain}"})
    else:
        raise HTTPException(status_code=404, detail="SSL certificate not found")

@app.delete("/api/certificate/{domain}")
def delete_ssl_certificate(domain: str):
    """Delete SSL certificate for domain"""
    if ssl_manager.delete_ssl_certificate(domain):
        return JSONResponse({"status": "success", "message": f"SSL certificate deleted for {domain}"})
    else:
        raise HTTPException(status_code=404, detail="SSL certificate not found")

@app.get("/api/expiring")
def get_expiring_certificates(days: int = 30):
    """Get certificates expiring within specified days"""
    expiring = ssl_manager.get_expiring_certificates(days)
    return JSONResponse({
        "expiring_certificates": expiring,
        "total": len(expiring)
    })

@app.post("/api/auto-renew")
def auto_renew_certificates():
    """Auto-renew expiring certificates"""
    try:
        ssl_manager.auto_renew_certificates()
        return JSONResponse({"status": "success", "message": "Auto-renewal completed"})
    except Exception as e:
        logger.error(f"Auto-renewal failed: {e}")
        raise HTTPException(status_code=500, detail=f"Auto-renewal failed: {str(e)}")

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "DarCloud SSL Certificate Manager",
        "certificates_count": len(ssl_manager.certificates),
        "expiring_soon": len(ssl_manager.get_expiring_certificates(30)),
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

def main():
    """Start DarCloud SSL Certificate Manager"""
    logger.info("🔐 Starting DarCloud SSL Certificate Manager on port 8082")
    uvicorn.run(app, host="0.0.0.0", port=8089)

if __name__ == "__main__":
    main()