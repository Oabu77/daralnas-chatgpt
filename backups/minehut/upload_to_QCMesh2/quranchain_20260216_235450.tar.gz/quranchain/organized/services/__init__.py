"""QuranChain package initializer."""
