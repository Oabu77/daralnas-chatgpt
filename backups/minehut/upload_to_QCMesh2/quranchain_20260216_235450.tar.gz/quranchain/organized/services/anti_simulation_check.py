#!/usr/bin/env python3
"""
🚨 ANTI-SIMULATION ENFORCEMENT
Prevents re-introduction of simulation code in production revenue systems
Run this before every commit/deployment
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import re
import sys
from pathlib import Path

# Files that MUST NOT contain simulations in production
PRODUCTION_FILES = [
    "continuous_monitoring_dashboard.py",
    "blockchain_readers.py",
    "real_revenue_db.py",
    "auto_revenue_payout.py",
    "network_congestion_ai.py",
    "blockchain_gas_toll_system.py",
    "fiat_payment_collection.py",
]

# Forbidden patterns that indicate simulation/test data
FORBIDDEN_PATTERNS = [
    (r"import\s+random", "import random"),
    (r"random\.randint", "random.randint()"),
    (r"random\.choice", "random.choice()"),
    (r"random\.uniform", "random.uniform()"),
    (r"fake_|test_|mock_|simulate|simulation", "simulation keywords"),
    (r"revenue_multiplier", "revenue_multiplier (removed in favor of real founder_share)"),
    (r"#\s*TODO.*remove.*simulation", "TODO comments about removing simulations"),
]

# Warnings (allowed but should be reviewed)
WARNING_PATTERNS = [
    (r"avg_fee.*\*", "Using avg_fee in calculation (should use real txid)"),
]

def check_file(filepath: str):
    """
    Check file for forbidden simulation code
    Returns: (passed, violations, warnings)
    """
    violations = []
    warnings = []
    
    if not os.path.exists(filepath):
        return True, []  # File doesn't exist, skip
    
    with open(filepath, 'r') as f:
        content = f.read()
        lines = content.splitlines()
    
    # Check for forbidden patterns
    for pattern, description in FORBIDDEN_PATTERNS:
        matches = re.finditer(pattern, content, re.IGNORECASE)
        for match in matches:
            # Find line number
            line_num = content[:match.start()].count('\n') + 1
            line_text = lines[line_num - 1].strip()
            
            # Skip if it's in a comment explaining what NOT to do
            if line_text.startswith('#') and ('NOT' in line_text.upper() or 'NEVER' in line_text.upper()):
                continue
            
            violations.append({
                'file': filepath,
                'line': line_num,
                'pattern': description,
                'code': line_text
            })
    
    # Check warnings
    for pattern, description in WARNING_PATTERNS:
        matches = re.finditer(pattern, content, re.IGNORECASE)
        for match in matches:
            line_num = content[:match.start()].count('\n') + 1
            line_text = lines[line_num - 1].strip()
            
            warnings.append({
                'file': filepath,
                'line': line_num,
                'pattern': description,
                'code': line_text
            })
    
    passed = len(violations) == 0
    return passed, violations, warnings


def main():
    print("🚨 ANTI-SIMULATION ENFORCEMENT CHECK")
    print("="*80)
    print("Scanning production revenue files for simulation code...")
    print()
    
    workspace = Path("/home/omar/Desktop/QuranChain")
    all_passed = True
    all_violations = []
    all_warnings = []
    
    for filename in PRODUCTION_FILES:
        filepath = workspace / filename
        passed, violations, warnings = check_file(str(filepath))
        
        if not passed:
            all_passed = False
            all_violations.extend(violations)
            print(f"❌ FAILED: {filename}")
            for v in violations:
                print(f"   Line {v['line']}: {v['pattern']}")
                print(f"   Code: {v['code']}")
        else:
            print(f"✅ PASSED: {filename}")
        
        if warnings:
            all_warnings.extend(warnings)
            for w in warnings:
                print(f"   ⚠️  Line {w['line']}: {w['pattern']}")
    
    print()
    print("="*80)
    
    if all_passed:
        print("✅ ALL CHECKS PASSED - No simulation code detected")
        print()
        print("💡 REMINDER:")
        print("   - All revenue must link to txid/tx hash or payment processor charge ID")
        print("   - NO random values in production")
        print("   - If no transactions: show $0.00")
        print("   - If APIs down: show 'degraded' with last known totals")
        print("   - 80% founder share (30% direct + 40% AI-Managed Validators)")
        return 0
    else:
        print(f"❌ ENFORCEMENT FAILED - {len(all_violations)} violations found")
        print()
        print("🔧 FIX REQUIRED:")
        for v in all_violations:
            print(f"   {v['file']}:{v['line']} - {v['pattern']}")
        print()
        print("⛔ DEPLOYMENT BLOCKED - Remove all simulation code before deploying")
        return 1


if __name__ == "__main__":
    sys.exit(main())
