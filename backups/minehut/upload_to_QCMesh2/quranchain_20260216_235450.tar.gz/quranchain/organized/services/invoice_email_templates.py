#!/usr/bin/env python3

from datetime import datetime
from typing import Optional

def generate_network_provider_invoice_email(
    provider_name: str,
    billing_id: str,
    total_due_usd: float,
    due_date: str,
    period_start: str,
    period_end: str,
    invoice_details: Optional[dict] = None
) -> tuple[str, str]:
    """
    Generate invoice email for network provider customers
    
    Returns:
        tuple: (text_body, html_body)
    """
    
    # Text version
    text_body = f"""
Invoice for DarCloud Network Services

Dear {provider_name} Accounts Receivable Department,

This is your invoice for DarCloud network services.

Invoice Details:
================
Invoice ID: {billing_id}
Provider: {provider_name}
Billing Period: {period_start} to {period_end}
Total Amount Due: ${total_due_usd:,.2f} USD
Due Date: {due_date}

Payment Instructions:
====================
1. ACH/Wire Transfer:
   Account Holder: DarCloud Network Services
   Bank: [Your bank details in .env]
   Please reference Invoice ID: {billing_id}

2. Cryptocurrency:
   ETH Address: 0x4e90944C093f7727ff89a30AF96A556deB95cCB8
   BTC Address: 3NaWi32bU27P6Dbo6FQTauyBWghmEnApix
   Include Invoice ID in memo: {billing_id}

3. Online Payment Portal:
   https://billing.darcloud.net/pay/{billing_id}

For questions or payment confirmation, contact:
billing@darcloud.net

Thank you for your business!

DarCloud Billing Department
https://darcloud.net
"""

    # HTML version
    html_body = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }}
        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }}
        .invoice-box {{ background: white; padding: 20px; border-left: 4px solid #667eea; margin: 20px 0; }}
        .amount {{ font-size: 28px; font-weight: bold; color: #667eea; }}
        .payment-method {{ background: white; padding: 15px; margin: 10px 0; border-radius: 4px; border: 1px solid #ddd; }}
        .payment-method h4 {{ margin-top: 0; color: #667eea; }}
        .footer {{ text-align: center; color: #666; margin-top: 30px; font-size: 12px; }}
        .button {{ display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 4px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🌐 DarCloud</h1>
            <p>Network Services Invoice</p>
        </div>
        
        <div class="content">
            <p>Dear <strong>{provider_name}</strong> Accounts Receivable Department,</p>
            
            <p>This is your invoice for DarCloud network services.</p>
            
            <div class="invoice-box">
                <h3>Invoice Details</h3>
                <table style="width: 100%;">
                    <tr>
                        <td><strong>Invoice ID:</strong></td>
                        <td>{billing_id}</td>
                    </tr>
                    <tr>
                        <td><strong>Provider:</strong></td>
                        <td>{provider_name}</td>
                    </tr>
                    <tr>
                        <td><strong>Billing Period:</strong></td>
                        <td>{period_start} to {period_end}</td>
                    </tr>
                    <tr>
                        <td><strong>Due Date:</strong></td>
                        <td>{due_date}</td>
                    </tr>
                </table>
                
                <div style="text-align: center; margin-top: 20px;">
                    <p style="margin: 5px 0;">Amount Due:</p>
                    <div class="amount">${total_due_usd:,.2f} USD</div>
                </div>
            </div>
            
            <h3>Payment Methods</h3>
            
            <div class="payment-method">
                <h4>💳 Online Payment Portal</h4>
                <p>Pay securely online with credit card, debit card, or bank transfer:</p>
                <a href="https://billing.darcloud.net/pay/{billing_id}" class="button">Pay Now</a>
            </div>
            
            <div class="payment-method">
                <h4>🏦 ACH/Wire Transfer</h4>
                <p><strong>Account Holder:</strong> DarCloud Network Services<br>
                <strong>Reference:</strong> Invoice ID {billing_id}</p>
                <p><em>Bank details available upon request at billing@darcloud.net</em></p>
            </div>
            
            <div class="payment-method">
                <h4>₿ Cryptocurrency Payment</h4>
                <p><strong>ETH Address:</strong><br>
                <code style="background: #f0f0f0; padding: 5px; display: block; word-break: break-all;">0x4e90944C093f7727ff89a30AF96A556deB95cCB8</code></p>
                <p><strong>BTC Address:</strong><br>
                <code style="background: #f0f0f0; padding: 5px; display: block; word-break: break-all;">3NaWi32bU27P6Dbo6FQTauyBWghmEnApix</code></p>
                <p><em>Please include Invoice ID {billing_id} in transaction memo</em></p>
            </div>
            
            <p style="margin-top: 30px;">For questions or payment confirmation, please contact us at <a href="mailto:billing@darcloud.net">billing@darcloud.net</a></p>
            
            <p><strong>Thank you for your business!</strong></p>
            
            <div class="footer">
                <p>DarCloud Billing Department<br>
                <a href="https://darcloud.net">https://darcloud.net</a></p>
            </div>
        </div>
    </div>
</body>
</html>
"""

    return text_body, html_body


def generate_merchant_invoice_email(
    merchant_name: str,
    merchant_email: str,
    invoice_id: str,
    total_due_usd: float,
    due_date: str,
    service_description: str
) -> tuple[str, str]:
    """
    Generate invoice email for fiat payment merchant customers
    
    Returns:
        tuple: (text_body, html_body)
    """
    
    text_body = f"""
Invoice for QuranChain Services

Dear {merchant_name},

This is your invoice for QuranChain blockchain services.

Invoice Details:
================
Invoice ID: {invoice_id}
Customer: {merchant_name}
Service: {service_description}
Total Amount Due: ${total_due_usd:,.2f} USD
Due Date: {due_date}

Payment Instructions:
====================
1. Pay online at: https://pay.quranchain.net/invoice/{invoice_id}
2. Credit Card or Bank Transfer accepted

For questions, contact: billing@darcloud.net

Thank you!

QuranChain Billing
"""

    html_body = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }}
        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }}
        .invoice-box {{ background: white; padding: 20px; border-left: 4px solid #2ecc71; margin: 20px 0; }}
        .amount {{ font-size: 28px; font-weight: bold; color: #2ecc71; }}
        .button {{ display: inline-block; padding: 12px 30px; background: #2ecc71; color: white; text-decoration: none; border-radius: 4px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📖 QuranChain</h1>
            <p>Blockchain Services Invoice</p>
        </div>
        
        <div class="content">
            <p>Dear <strong>{merchant_name}</strong>,</p>
            
            <div class="invoice-box">
                <h3>Invoice Details</h3>
                <p><strong>Invoice ID:</strong> {invoice_id}</p>
                <p><strong>Service:</strong> {service_description}</p>
                <p><strong>Due Date:</strong> {due_date}</p>
                
                <div style="text-align: center; margin-top: 20px;">
                    <p style="margin: 5px 0;">Amount Due:</p>
                    <div class="amount">${total_due_usd:,.2f} USD</div>
                </div>
            </div>
            
            <div style="text-align: center;">
                <a href="https://pay.quranchain.net/invoice/{invoice_id}" class="button">Pay Invoice Now</a>
            </div>
            
            <p style="margin-top: 30px;">For questions, contact <a href="mailto:billing@darcloud.net">billing@darcloud.net</a></p>
        </div>
    </div>
</body>
</html>
"""

    return text_body, html_body
