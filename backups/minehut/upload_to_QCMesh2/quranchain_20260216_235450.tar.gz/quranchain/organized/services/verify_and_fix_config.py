#!/usr/bin/env python3
"""
QuranChain™ Configuration Verification & Auto-Fix
Ensures all systems are properly configured and running
"""

import subprocess
import os
import socket
import time
from datetime import datetime

class ConfigurationVerifier:
    """Verify and auto-fix QuranChain configuration"""
    
    def __init__(self):
        self.issues_found = []
        self.fixes_applied = []
        
    def print_header(self):
        print("\n" + "="*90)
        print("🔧 QURANCHAIN™ CONFIGURATION VERIFICATION & AUTO-FIX")
        print(f"   Timestamp: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}")
        print("="*90 + "\n")
    
    def check_process(self, name: str) -> bool:
        """Check if process is running"""
        try:
            result = subprocess.run(
                ['pgrep', '-f', name],
                capture_output=True,
                text=True,
                timeout=2
            )
            return bool(result.stdout.strip())
        except:
            return False
    
    def check_port(self, port: int) -> bool:
        """Check if port is listening"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            return result == 0
        except:
            return False
    
    def verify_critical_processes(self):
        """Verify all critical processes are running"""
        print("1️⃣  CRITICAL PROCESSES CHECK:")
        print("-"*90)
        
        processes = {
            'QuranChain Blockchain': 'quranchain_quantum_blockchain.py',
            'DarCloud Server': 'darcloud_autonomous_server.py',
            'System Guardian': 'autonomous_system_guardian.py',
        }
        
        for name, process_name in processes.items():
            if self.check_process(process_name):
                print(f"   ✅ {name:30s} RUNNING")
            else:
                print(f"   ❌ {name:30s} DOWN")
                self.issues_found.append(f"{name} not running")
        
        print()
    
    def verify_ports(self):
        """Verify critical ports are listening"""
        print("2️⃣  PORT AVAILABILITY CHECK:")
        print("-"*90)
        
        ports = {
            8101: 'Financial General API',
            9999: 'QuranChain Quantum Blockchain',
            9090: 'DarCloud Server',
            7777: 'Transaction Monitor'
        }
        
        for port, service in ports.items():
            if self.check_port(port):
                print(f"   ✅ Port {port:5d} ({service:30s}) LISTENING")
            else:
                print(f"   ⚠️  Port {port:5d} ({service:30s}) NOT RESPONDING")
                # Port not responding is not always critical
        
        print()
    
    def verify_file_structure(self):
        """Verify critical files exist"""
        print("3️⃣  FILE STRUCTURE CHECK:")
        print("-"*90)
        
        critical_files = [
            'quranchain_quantum_blockchain.py',
            'blockchain_gas_toll_system.py',
            'auto_revenue_payout.py',
            'autonomous_system_guardian.py',
            'darcloud_autonomous_server.py',
            'NO_SIMULATIONS_POLICY.py'
        ]
        
        for filename in critical_files:
            if os.path.exists(filename):
                size = os.path.getsize(filename)
                print(f"   ✅ {filename:45s} ({size:,} bytes)")
            else:
                print(f"   ❌ {filename:45s} MISSING")
                self.issues_found.append(f"Missing file: {filename}")
        
        print()
    
    def verify_directories(self):
        """Verify critical directories exist"""
        print("4️⃣  DIRECTORY STRUCTURE CHECK:")
        print("-"*90)
        
        directories = ['logs', 'monitoring_logs', 'pids', '.snapshots', 'crm']
        
        for dirname in directories:
            if os.path.exists(dirname) and os.path.isdir(dirname):
                file_count = len(os.listdir(dirname))
                print(f"   ✅ {dirname:20s} EXISTS ({file_count} files)")
            else:
                print(f"   ⚠️  {dirname:20s} MISSING - Creating...")
                try:
                    os.makedirs(dirname, exist_ok=True)
                    print(f"      ✅ Created {dirname}")
                    self.fixes_applied.append(f"Created directory: {dirname}")
                except Exception as e:
                    print(f"      ❌ Failed: {e}")
        
        print()
    
    def verify_revenue_configuration(self):
        """Verify revenue collection is properly configured"""
        print("5️⃣  REVENUE SYSTEM CONFIGURATION:")
        print("-"*90)
        
        # Check blockchain_gas_toll_system
        try:
            import sys
            sys.path.insert(0, os.getcwd())
            
            # Try to import the ledger
            if os.path.exists('blockchain_gas_toll_system.py'):
                with open('blockchain_gas_toll_system.py', 'r') as f:
                    content = f.read()
                    if 'blockchain_gas_toll_ledger' in content:
                        print("   ✅ Gas Toll System: blockchain_gas_toll_ledger found")
                    else:
                        print("   ⚠️  Gas Toll System: ledger variable not found")
                    
                    if 'FOUNDER_ROYALTY_RATE = 0.30' in content:
                        print("   ✅ Founder Royalty: 30% configured")
                    else:
                        print("   ⚠️  Founder Royalty: Rate not found")
            else:
                print("   ❌ Gas Toll System: File not found")
                self.issues_found.append("blockchain_gas_toll_system.py missing")
            
            # Check auto_revenue_payout
            if os.path.exists('auto_revenue_payout.py'):
                with open('auto_revenue_payout.py', 'r') as f:
                    content = f.read()
                    if '3NaWi32bU27P6Dbo6FQTauyBWghmEnApix' in content:
                        print("   ✅ Kraken BTC Wallet: Configured")
                    if '0x4e90944C093f7727ff89a30AF96A556deB95cCB8' in content:
                        print("   ✅ Kraken ETH Wallet: Configured")
            else:
                print("   ❌ Auto-Payout System: File not found")
                self.issues_found.append("auto_revenue_payout.py missing")
                
        except Exception as e:
            print(f"   ⚠️  Revenue verification error: {str(e)[:60]}")
        
        print()
    
    def verify_network_connectivity(self):
        """Verify internet and blockchain connectivity"""
        print("6️⃣  NETWORK CONNECTIVITY:")
        print("-"*90)
        
        # Internet check
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=2)
            print("   ✅ Internet: CONNECTED")
        except:
            print("   ❌ Internet: DISCONNECTED")
            self.issues_found.append("No internet connection")
        
        # Localhost connectivity
        try:
            socket.create_connection(("127.0.0.1", 9999), timeout=1)
            print("   ✅ QuranChain Quantum API (localhost:9999): REACHABLE")
        except:
            print("   ⚠️  QuranChain Quantum API (localhost:9999): NOT RESPONDING")
        
        print()
    
    def verify_logs(self):
        """Check log files are being written"""
        print("7️⃣  LOG FILE STATUS:")
        print("-"*90)
        
        log_files = [
            'logs/system_guardian.log',
            'logs/darcloud.log',
            'monitoring_logs/quantum_blockchain.log'
        ]
        
        for log_file in log_files:
            if os.path.exists(log_file):
                size = os.path.getsize(log_file)
                mtime = os.path.getmtime(log_file)
                age = time.time() - mtime
                
                if age < 300:  # Less than 5 minutes old
                    print(f"   ✅ {log_file:45s} ACTIVE ({size:,} bytes, {int(age)}s ago)")
                else:
                    print(f"   ⚠️  {log_file:45s} STALE ({size:,} bytes, {int(age/60)}m ago)")
            else:
                print(f"   ⚠️  {log_file:45s} NOT FOUND")
        
        print()
    
    def display_summary(self):
        """Display verification summary"""
        print("="*90)
        print("📊 VERIFICATION SUMMARY:")
        print("="*90)
        
        if not self.issues_found and not self.fixes_applied:
            print("\n   ✅ ALL SYSTEMS CONFIGURED CORRECTLY")
            print("   ✅ No issues found")
            print("   ✅ QuranChain infrastructure is ready")
        else:
            if self.fixes_applied:
                print(f"\n   🔧 FIXES APPLIED ({len(self.fixes_applied)}):")
                for fix in self.fixes_applied:
                    print(f"      ✅ {fix}")
            
            if self.issues_found:
                print(f"\n   ⚠️  ISSUES DETECTED ({len(self.issues_found)}):")
                for issue in self.issues_found:
                    print(f"      ⚠️  {issue}")
                
                print("\n   💡 RECOMMENDATIONS:")
                if any("not running" in issue for issue in self.issues_found):
                    print("      • Check process logs for startup errors")
                    print("      • Restart services: ./deploy_all_systems.sh")
                if any("missing" in issue.lower() for issue in self.issues_found):
                    print("      • Restore missing files from backup")
                    print("      • Re-run deployment scripts")
        
        print("\n" + "="*90)
        print("✅ Verification complete - Autonomous guardian will continue monitoring")
        print("="*90 + "\n")
    
    def run_full_verification(self):
        """Run complete configuration verification"""
        self.print_header()
        self.verify_critical_processes()
        self.verify_ports()
        self.verify_file_structure()
        self.verify_directories()
        self.verify_revenue_configuration()
        self.verify_network_connectivity()
        self.verify_logs()
        self.display_summary()

if __name__ == "__main__":
    verifier = ConfigurationVerifier()
    verifier.run_full_verification()
