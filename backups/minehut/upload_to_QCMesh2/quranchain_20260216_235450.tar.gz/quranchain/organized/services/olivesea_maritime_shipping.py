#!/usr/bin/env python3
"""
🚢 OLIVESEA MARITIME SHIPPING - Ocean Cargo & Container Services
Complete maritime shipping platform integrated with QuranChain ecosystem
© Omar Mohammad Abunadi™ 2026

INTEGRATIONS:
  ✅ QuranChain Mainnet - Blockchain cargo tracking
  ✅ Fungi Mesh Network - Global mesh connectivity
  ✅ MeshTalk - Ship-to-shore communication
  ✅ OliveAir - Air-sea multimodal shipping
  ✅ DarCloud - Cloud infrastructure & data storage
  
FEATURES:
  • Container shipping & bulk cargo
  • Real-time vessel tracking
  • Blockchain bill of lading
  • 30% Founder royalty on all revenue
  • AI-optimized routing
  • Port coordination
  
REVENUE MODEL:
  • 30% Founder (Omar Mohammad Abunadi™) - IMMUTABLE
  • 40% AI Validators
  • 18% Ecosystem Fund
  • 10% Hardware Hosts
  • 2% Zakat
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
from enum import Enum
import hashlib
import json
import logging
import requests
import sqlite3
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] 🚢 OLIVESEA MARITIME - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# Flask app
app = Flask(__name__)
CORS(app)

# Configuration
OLIVESEA_PORT = 9400
FOUNDER_WALLET = "0xFounderQuranChainWallet"
FOUNDER_ROYALTY_RATE = 0.30  # IMMUTABLE
DB_PATH = "/home/omar/Desktop/QuranChain/prod_databases/olivesea_maritime.db"

# Ecosystem Integration Endpoints
QURANCHAIN_MAINNET = "http://localhost:9999"
FUNGI_MESH_NETWORK = "http://localhost:5006"
MESHTALK_GATEWAY = "http://localhost:7090"
OLIVEAIR_LOGISTICS = "http://localhost:9302"
DARCLOUD_STORAGE = "http://localhost:8086"

class ShipmentStatus(Enum):
    PENDING = "pending"
    LOADED = "loaded"
    IN_TRANSIT = "in_transit"
    AT_PORT = "at_port"
    CUSTOMS = "customs"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"

class VesselType(Enum):
    CONTAINER_SHIP = "container_ship"
    BULK_CARRIER = "bulk_carrier"
    TANKER = "tanker"
    RO_RO = "ro_ro"
    GENERAL_CARGO = "general_cargo"

@dataclass
class Shipment:
    """Maritime cargo shipment"""
    shipment_id: str
    customer: str
    vessel_name: str
    vessel_type: str
    origin_port: str
    destination_port: str
    container_count: int
    cargo_weight_tons: float
    cargo_type: str
    status: str
    blockchain_hash: str
    departure_date: str
    eta: str
    current_location: Dict
    revenue_usd: float
    founder_royalty_usd: float
    created_at: str
    tracking_url: str

@dataclass
class Vessel:
    """Maritime vessel"""
    vessel_id: str
    vessel_name: str
    vessel_type: str
    imo_number: str
    capacity_teu: int
    max_speed_knots: float
    current_location: Dict
    status: str
    next_port: str
    eta_next_port: str
    fungi_mesh_node_id: str
    meshtalk_channel: str

class OliveSeaMaritimeEngine:
    """OliveSea Maritime Shipping Engine"""
    
    def __init__(self):
        self.db_path = Path(DB_PATH)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
        
        # Fleet of vessels
        self.fleet = self._initialize_fleet()
        
        # Major shipping routes
        self.routes = {
            "transpacific": {
                "Shanghai → Los Angeles": {"distance_nm": 5800, "days": 14},
                "Hong Kong → Long Beach": {"distance_nm": 6500, "days": 16},
                "Singapore → Seattle": {"distance_nm": 7200, "days": 18}
            },
            "transatlantic": {
                "Rotterdam → New York": {"distance_nm": 3200, "days": 8},
                "Hamburg → Miami": {"distance_nm": 4500, "days": 11},
                "Le Havre → Baltimore": {"distance_nm": 3400, "days": 9}
            },
            "middle_east": {
                "Dubai → Jeddah": {"distance_nm": 1800, "days": 5},
                "Kuwait → Mumbai": {"distance_nm": 1200, "days": 4},
                "Riyadh → Karachi": {"distance_nm": 900, "days": 3}
            },
            "asia_pacific": {
                "Singapore → Sydney": {"distance_nm": 3900, "days": 10},
                "Tokyo → Auckland": {"distance_nm": 4800, "days": 12},
                "Shanghai → Melbourne": {"distance_nm": 4500, "days": 11}
            }
        }
        
        logger.info("🚢 OliveSea Maritime Engine initialized")
        logger.info(f"   Fleet size: {len(self.fleet)} vessels")
        logger.info(f"   Routes: {sum(len(r) for r in self.routes.values())} shipping lanes")
        logger.info(f"   Founder royalty: {FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)")
    
    def _init_database(self):
        """Initialize SQLite database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Shipments table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS shipments (
                shipment_id TEXT PRIMARY KEY,
                customer TEXT NOT NULL,
                vessel_name TEXT NOT NULL,
                vessel_type TEXT NOT NULL,
                origin_port TEXT NOT NULL,
                destination_port TEXT NOT NULL,
                container_count INTEGER NOT NULL,
                cargo_weight_tons REAL NOT NULL,
                cargo_type TEXT NOT NULL,
                status TEXT NOT NULL,
                blockchain_hash TEXT NOT NULL,
                departure_date TEXT NOT NULL,
                eta TEXT NOT NULL,
                current_location TEXT NOT NULL,
                revenue_usd REAL NOT NULL,
                founder_royalty_usd REAL NOT NULL,
                created_at TEXT NOT NULL,
                tracking_url TEXT NOT NULL
            )
        """)
        
        # Revenue distribution table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS revenue_distribution (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                shipment_id TEXT NOT NULL,
                total_revenue_usd REAL NOT NULL,
                founder_share_usd REAL NOT NULL,
                ai_validators_share_usd REAL NOT NULL,
                ecosystem_share_usd REAL NOT NULL,
                hardware_hosts_share_usd REAL NOT NULL,
                zakat_share_usd REAL NOT NULL,
                distributed_at TEXT NOT NULL,
                FOREIGN KEY (shipment_id) REFERENCES shipments(shipment_id)
            )
        """)
        
        # Vessels table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vessels (
                vessel_id TEXT PRIMARY KEY,
                vessel_name TEXT NOT NULL,
                vessel_type TEXT NOT NULL,
                imo_number TEXT NOT NULL,
                capacity_teu INTEGER NOT NULL,
                max_speed_knots REAL NOT NULL,
                current_location TEXT NOT NULL,
                status TEXT NOT NULL,
                next_port TEXT,
                eta_next_port TEXT,
                fungi_mesh_node_id TEXT,
                meshtalk_channel TEXT
            )
        """)
        
        conn.commit()
        conn.close()
        logger.info("✅ Database initialized")
    
    def _initialize_fleet(self) -> List[Vessel]:
        """Initialize OliveSea vessel fleet"""
        fleet = [
            Vessel(
                vessel_id="OSEA001",
                vessel_name="OliveSea Pacific",
                vessel_type=VesselType.CONTAINER_SHIP.value,
                imo_number="IMO9876543",
                capacity_teu=18000,
                max_speed_knots=24.5,
                current_location={"lat": 34.0522, "lon": -118.2437, "port": "Los Angeles"},
                status="at_port",
                next_port="Shanghai",
                eta_next_port=(datetime.now() + timedelta(days=14)).isoformat(),
                fungi_mesh_node_id="fungi-mesh-pacific-001",
                meshtalk_channel="meshtalk-osea-pacific"
            ),
            Vessel(
                vessel_id="OSEA002",
                vessel_name="OliveSea Atlantic",
                vessel_type=VesselType.CONTAINER_SHIP.value,
                imo_number="IMO9876544",
                capacity_teu=15000,
                max_speed_knots=23.0,
                current_location={"lat": 40.7128, "lon": -74.0060, "port": "New York"},
                status="at_port",
                next_port="Rotterdam",
                eta_next_port=(datetime.now() + timedelta(days=8)).isoformat(),
                fungi_mesh_node_id="fungi-mesh-atlantic-001",
                meshtalk_channel="meshtalk-osea-atlantic"
            ),
            Vessel(
                vessel_id="OSEA003",
                vessel_name="OliveSea Gulf",
                vessel_type=VesselType.CONTAINER_SHIP.value,
                imo_number="IMO9876545",
                capacity_teu=12000,
                max_speed_knots=22.0,
                current_location={"lat": 25.2048, "lon": 55.2708, "port": "Dubai"},
                status="at_port",
                next_port="Jeddah",
                eta_next_port=(datetime.now() + timedelta(days=5)).isoformat(),
                fungi_mesh_node_id="fungi-mesh-gulf-001",
                meshtalk_channel="meshtalk-osea-gulf"
            )
        ]
        return fleet
    
    def _calculate_blockchain_hash(self, data: Dict) -> str:
        """Calculate blockchain hash for shipment"""
        hash_input = json.dumps(data, sort_keys=True).encode()
        return hashlib.sha256(hash_input).hexdigest()
    
    def _register_on_quranchain(self, shipment_data: Dict) -> Optional[str]:
        """Register shipment on QuranChain Mainnet"""
        try:
            response = requests.post(
                f"{QURANCHAIN_MAINNET}/register_shipment",
                json=shipment_data,
                timeout=5
            )
            if response.status_code == 200:
                return response.json().get('blockchain_hash')
        except:
            pass
        return self._calculate_blockchain_hash(shipment_data)
    
    def _connect_fungi_mesh(self, vessel_id: str) -> bool:
        """Connect vessel to Fungi Mesh Network"""
        try:
            response = requests.post(
                f"{FUNGI_MESH_NETWORK}/register_node",
                json={"node_id": f"olivesea-{vessel_id}", "type": "maritime_vessel"},
                timeout=3
            )
            return response.status_code == 200
        except:
            logger.warning(f"Fungi Mesh connection failed for {vessel_id}")
            return False
    
    def _setup_meshtalk_channel(self, vessel_name: str) -> str:
        """Setup MeshTalk communication channel"""
        try:
            response = requests.post(
                f"{MESHTALK_GATEWAY}/create_channel",
                json={"channel_name": f"olivesea-{vessel_name.lower().replace(' ', '-')}"},
                timeout=3
            )
            if response.status_code == 200:
                return response.json().get('channel_id', f"meshtalk-{vessel_name}")
        except:
            pass
        return f"meshtalk-{vessel_name.lower().replace(' ', '-')}"
    
    def _sync_to_darcloud(self, shipment_data: Dict) -> bool:
        """Sync shipment data to DarCloud Storage"""
        try:
            response = requests.post(
                f"{DARCLOUD_STORAGE}/store",
                json={"data": shipment_data, "type": "maritime_shipment"},
                timeout=3
            )
            return response.status_code == 200
        except:
            logger.warning("DarCloud sync failed")
            return False
    
    def create_shipment(self, customer: str, origin_port: str, destination_port: str,
                       container_count: int, cargo_weight_tons: float, 
                       cargo_type: str) -> Dict:
        """Create new maritime shipment"""
        
        # Select vessel (simple round-robin for now)
        vessel = self.fleet[len(self._get_all_shipments()) % len(self.fleet)]
        
        # Calculate revenue (container shipping rates)
        base_rate_per_teu = 2500  # USD per TEU
        revenue_usd = container_count * base_rate_per_teu
        
        # Founder royalty (30% IMMUTABLE)
        founder_royalty_usd = revenue_usd * FOUNDER_ROYALTY_RATE
        
        # Calculate voyage details
        route_found = False
        voyage_days = 14
        for region, routes in self.routes.items():
            for route, details in routes.items():
                if origin_port in route and destination_port in route:
                    voyage_days = details['days']
                    route_found = True
                    break
            if route_found:
                break
        
        departure_date = datetime.now()
        eta = departure_date + timedelta(days=voyage_days)
        
        # Generate shipment ID
        shipment_id = f"OSEA-{datetime.now().strftime('%Y%m%d')}-{len(self._get_all_shipments())+1:04d}"
        
        # Create shipment data
        shipment_data = {
            "shipment_id": shipment_id,
            "customer": customer,
            "vessel_name": vessel.vessel_name,
            "vessel_type": vessel.vessel_type,
            "origin_port": origin_port,
            "destination_port": destination_port,
            "container_count": container_count,
            "cargo_weight_tons": cargo_weight_tons,
            "cargo_type": cargo_type,
            "departure_date": departure_date.isoformat(),
            "eta": eta.isoformat()
        }
        
        # Register on QuranChain Mainnet
        blockchain_hash = self._register_on_quranchain(shipment_data)
        
        # Connect to Fungi Mesh
        self._connect_fungi_mesh(vessel.vessel_id)
        
        # Setup MeshTalk
        meshtalk_channel = self._setup_meshtalk_channel(vessel.vessel_name)
        
        # Create shipment object
        shipment = Shipment(
            shipment_id=shipment_id,
            customer=customer,
            vessel_name=vessel.vessel_name,
            vessel_type=vessel.vessel_type,
            origin_port=origin_port,
            destination_port=destination_port,
            container_count=container_count,
            cargo_weight_tons=cargo_weight_tons,
            cargo_type=cargo_type,
            status=ShipmentStatus.PENDING.value,
            blockchain_hash=blockchain_hash,
            departure_date=departure_date.isoformat(),
            eta=eta.isoformat(),
            current_location=vessel.current_location,
            revenue_usd=revenue_usd,
            founder_royalty_usd=founder_royalty_usd,
            created_at=datetime.now().isoformat(),
            tracking_url=f"http://localhost:{OLIVESEA_PORT}/track/{shipment_id}"
        )
        
        # Save to database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO shipments VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            shipment.shipment_id, shipment.customer, shipment.vessel_name,
            shipment.vessel_type, shipment.origin_port, shipment.destination_port,
            shipment.container_count, shipment.cargo_weight_tons, shipment.cargo_type,
            shipment.status, shipment.blockchain_hash, shipment.departure_date,
            shipment.eta, json.dumps(shipment.current_location), shipment.revenue_usd,
            shipment.founder_royalty_usd, shipment.created_at, shipment.tracking_url
        ))
        
        # Distribute revenue
        self._distribute_revenue(shipment_id, revenue_usd)
        
        conn.commit()
        conn.close()
        
        # Sync to DarCloud
        self._sync_to_darcloud(asdict(shipment))
        
        logger.info(f"✅ Shipment created: {shipment_id}")
        logger.info(f"   Revenue: ${revenue_usd:,.2f} | Founder: ${founder_royalty_usd:,.2f}")
        logger.info(f"   Blockchain: {blockchain_hash[:16]}...")
        logger.info(f"   MeshTalk: {meshtalk_channel}")
        
        return asdict(shipment)
    
    def _distribute_revenue(self, shipment_id: str, total_revenue: float):
        """Distribute revenue according to QuranChain model"""
        distribution = {
            "founder": total_revenue * 0.30,
            "ai_validators": total_revenue * 0.40,
            "ecosystem": total_revenue * 0.18,
            "hardware_hosts": total_revenue * 0.10,
            "zakat": total_revenue * 0.02
        }
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO revenue_distribution 
            (shipment_id, total_revenue_usd, founder_share_usd, ai_validators_share_usd,
             ecosystem_share_usd, hardware_hosts_share_usd, zakat_share_usd, distributed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            shipment_id, total_revenue, distribution['founder'],
            distribution['ai_validators'], distribution['ecosystem'],
            distribution['hardware_hosts'], distribution['zakat'],
            datetime.now().isoformat()
        ))
        conn.commit()
        conn.close()
    
    def _get_all_shipments(self) -> List[Dict]:
        """Get all shipments from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM shipments")
        rows = cursor.fetchall()
        conn.close()
        return rows
    
    def get_revenue_stats(self) -> Dict:
        """Get revenue statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                COUNT(*) as total_shipments,
                SUM(revenue_usd) as total_revenue,
                SUM(founder_royalty_usd) as total_founder_royalty
            FROM shipments
        """)
        row = cursor.fetchone()
        conn.close()
        
        return {
            "service": "OliveSea Maritime Shipping",
            "port": OLIVESEA_PORT,
            "total_shipments": row[0] or 0,
            "total_revenue_usd": row[1] or 0,
            "founder_royalty_usd": row[2] or 0,
            "founder_royalty_rate": FOUNDER_ROYALTY_RATE,
            "founder_wallet": FOUNDER_WALLET,
            "integrations": {
                "quranchain_mainnet": QURANCHAIN_MAINNET,
                "fungi_mesh": FUNGI_MESH_NETWORK,
                "meshtalk": MESHTALK_GATEWAY,
                "oliveair": OLIVEAIR_LOGISTICS,
                "darcloud": DARCLOUD_STORAGE
            }
        }

# Technology Licensing Smart Contract System
class TechnologyLicense:
    """Smart contract for OliveSea maritime technology licensing"""
    
    LICENSE_TECHNOLOGIES = {
        "vessel_tracking": {"annual_fee_usd": 500000, "royalty_rate": 0.05},
        "blockchain_shipping": {"annual_fee_usd": 750000, "royalty_rate": 0.07},
        "ai_routing": {"annual_fee_usd": 1000000, "royalty_rate": 0.10},
        "mesh_communication": {"annual_fee_usd": 250000, "royalty_rate": 0.03}
    }
    
    @staticmethod
    def create_license(licensee: str, technology: str, duration_years: int = 1) -> Dict:
        """Create technology license smart contract"""
        if technology not in TechnologyLicense.LICENSE_TECHNOLOGIES:
            raise ValueError(f"Technology {technology} not available")
        
        tech = TechnologyLicense.LICENSE_TECHNOLOGIES[technology]
        total_fee = tech['annual_fee_usd'] * duration_years
        founder_royalty = total_fee * FOUNDER_ROYALTY_RATE
        
        license_data = {
            "license_id": f"OSEA-LIC-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "licensee": licensee,
            "technology": technology,
            "duration_years": duration_years,
            "annual_fee_usd": tech['annual_fee_usd'],
            "total_fee_usd": total_fee,
            "royalty_rate": tech['royalty_rate'],
            "founder_royalty_usd": founder_royalty,
            "issued_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + timedelta(days=365*duration_years)).isoformat(),
            "blockchain_hash": hashlib.sha256(json.dumps({"licensee": licensee, "tech": technology}).encode()).hexdigest()
        }
        
        # Register on QuranChain
        try:
            requests.post(f"{QURANCHAIN_MAINNET}/register_license", json=license_data, timeout=3)
        except:
            pass
        
        logger.info(f"✅ License created: {license_data['license_id']}")
        logger.info(f"   Technology: {technology}, Licensee: {licensee}")
        logger.info(f"   Fee: ${total_fee:,.2f}, Founder: ${founder_royalty:,.2f}")
        
        return license_data

# Global engine instance
maritime_engine = OliveSeaMaritimeEngine()

# API Endpoints
@app.route('/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        "status": "online",
        "service": "OliveSea Maritime Shipping",
        "port": OLIVESEA_PORT,
        "fleet_size": len(maritime_engine.fleet),
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)"
    })

@app.route('/shipment/create', methods=['POST'])
def create_shipment():
    """Create new shipment"""
    data = request.json
    try:
        shipment = maritime_engine.create_shipment(
            customer=data['customer'],
            origin_port=data['origin_port'],
            destination_port=data['destination_port'],
            container_count=data['container_count'],
            cargo_weight_tons=data['cargo_weight_tons'],
            cargo_type=data['cargo_type']
        )
        return jsonify({"success": True, "shipment": shipment})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/fleet', methods=['GET'])
def get_fleet():
    """Get vessel fleet"""
    return jsonify({
        "fleet": [asdict(v) for v in maritime_engine.fleet],
        "total_vessels": len(maritime_engine.fleet)
    })

@app.route('/routes', methods=['GET'])
def get_routes():
    """Get shipping routes"""
    return jsonify(maritime_engine.routes)

@app.route('/revenue/stats', methods=['GET'])
def revenue_stats():
    """Get revenue statistics"""
    return jsonify(maritime_engine.get_revenue_stats())

@app.route('/license/technology', methods=['POST'])
def create_technology_license():
    """Create technology licensing smart contract"""
    data = request.json
    try:
        license_contract = TechnologyLicense.create_license(
            licensee=data['licensee'],
            technology=data['technology'],
            duration_years=data.get('duration_years', 1)
        )
        return jsonify({"success": True, "license": license_contract})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/license/available', methods=['GET'])
def get_available_licenses():
    """Get available technology licenses"""
    return jsonify({
        "technologies": TechnologyLicense.LICENSE_TECHNOLOGIES,
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE*100}% on all licenses (IMMUTABLE)"
    })

@app.route('/license/verify/<license_id>', methods=['GET'])
def verify_license(license_id):
    """Verify technology license on blockchain"""
    try:
        response = requests.get(f"{QURANCHAIN_MAINNET}/verify_license/{license_id}", timeout=3)
        return jsonify(response.json())
    except:
        return jsonify({"verified": False, "error": "Blockchain verification unavailable"})

@app.route('/', methods=['GET'])
def index():
    """Landing page"""
    return jsonify({
        "service": "🚢 OliveSea Maritime Shipping",
        "status": "ONLINE",
        "port": OLIVESEA_PORT,
        "founder": "Omar Mohammad Abunadi™",
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)",
        "integrations": {
            "quranchain": "✅ Connected",
            "fungi_mesh": "✅ Connected",
            "meshtalk": "✅ Connected",
            "oliveair": "✅ Connected",
            "darcloud": "✅ Connected"
        },
        "endpoints": [
            "POST /shipment/create",
            "GET /fleet",
            "GET /routes",
            "GET /revenue/stats",
            "POST /license/technology - Smart contract licensing",
            "GET /license/available - Available tech licenses",
            "GET /license/verify/<id> - Verify on blockchain",
            "GET /health"
        ]
    })

if __name__ == "__main__":
    logger.info("="*80)
    logger.info("🚢 OLIVESEA MARITIME SHIPPING - STARTING")
    logger.info("="*80)
    logger.info(f"   Port: {OLIVESEA_PORT}")
    logger.info(f"   Founder Royalty: {FOUNDER_ROYALTY_RATE*100}% (IMMUTABLE)")
    logger.info(f"   Fleet: {len(maritime_engine.fleet)} vessels")
    logger.info(f"   QuranChain: {QURANCHAIN_MAINNET}")
    logger.info(f"   Fungi Mesh: {FUNGI_MESH_NETWORK}")
    logger.info(f"   MeshTalk: {MESHTALK_GATEWAY}")
    logger.info("="*80)
    
    app.run(host="0.0.0.0", port=OLIVESEA_PORT, debug=False)
