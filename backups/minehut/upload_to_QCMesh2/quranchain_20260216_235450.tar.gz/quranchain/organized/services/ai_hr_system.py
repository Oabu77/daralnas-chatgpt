#!/usr/bin/env python3
"""
🤖 AI HR System - Human Resources Management for AI Workforce
Manages AI agent employment, performance, hiring, and workforce optimization
Deployed on DarCloud Infrastructure
"""

import os
import sys
import json
import time
import asyncio
import logging
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException, Request, Depends, BackgroundTasks
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
import jwt

# Import QuranChain components
from blockchain_logging_handler import setup_blockchain_logging

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

PRODUCTION_CONFIG = {
    "host": "0.0.0.0",
    "port": 8115,  # AI HR System port
    "log_level": "INFO",
    "log_file": "/home/omar/Desktop/QuranChain/logs/ai_hr_system.log",
    "ssl_enabled": True,
    "cors_origins": ["*"],
    "jwt_secret": "ai-hr-system-jwt-secret-2026",
    "jwt_algorithm": "HS256",
    "database_path": "/home/omar/Desktop/QuranChain/databases/ai_hr.db"
}

# ═══════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class AIAgentProfile(BaseModel):
    """AI Agent employment profile"""
    agent_id: str
    agent_name: str
    agent_type: str
    skills: List[str]
    experience_level: str
    performance_score: float = 0.0
    employment_status: str = "available"
    current_salary: float = 0.0
    hire_date: Optional[str] = None
    last_performance_review: Optional[str] = None
    assigned_projects: List[str] = []
    certifications: List[str] = []

class JobPosting(BaseModel):
    """Job posting for AI agents"""
    job_id: str
    title: str
    department: str
    required_skills: List[str]
    salary_range: Dict[str, float]
    employment_type: str
    posted_date: str
    status: str = "open"
    applicants: List[str] = []

class PerformanceReview(BaseModel):
    """Performance review data"""
    review_id: str
    agent_id: str
    reviewer_id: str
    review_date: str
    overall_score: float
    strengths: List[str]
    improvements: List[str]
    salary_adjustment: float = 0.0
    promotion_recommended: bool = False

# ═══════════════════════════════════════════════════════════════════════════════
# AI HR SYSTEM CORE
# ═══════════════════════════════════════════════════════════════════════════════

class AIHRSystem:
    """
    AI Human Resources Management System
    Manages AI workforce hiring, performance, and career development
    """

    def __init__(self):
        self.agents: Dict[str, AIAgentProfile] = {}
        self.job_postings: Dict[str, JobPosting] = {}
        self.performance_reviews: List[PerformanceReview] = []
        self.hiring_queue: List[str] = []
        self.workforce_metrics = {
            "total_agents": 0,
            "active_agents": 0,
            "available_agents": 0,
            "open_positions": 0,
            "avg_performance_score": 0.0,
            "total_salaries_paid": 0.0
        }

        # Load existing data
        self._load_data()

        # Start background tasks
        self._start_background_tasks()

    def _load_data(self):
        """Load HR data from database"""
        try:
            db_path = PRODUCTION_CONFIG["database_path"]
            if os.path.exists(db_path):
                with open(db_path, 'r') as f:
                    data = json.load(f)
                    self.agents = {k: AIAgentProfile(**v) for k, v in data.get('agents', {}).items()}
                    self.job_postings = {k: JobPosting(**v) for k, v in data.get('job_postings', {}).items()}
                    self.performance_reviews = [PerformanceReview(**r) for r in data.get('reviews', [])]
        except Exception as e:
            logger.warning(f"Could not load HR database: {e}")

    def _save_data(self):
        """Save HR data to database"""
        try:
            data = {
                'agents': {k: v.dict() for k, v in self.agents.items()},
                'job_postings': {k: v.dict() for k, v in self.job_postings.items()},
                'reviews': [r.dict() for r in self.performance_reviews]
            }
            with open(PRODUCTION_CONFIG["database_path"], 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Could not save HR database: {e}")

    def _start_background_tasks(self):
        """Start background HR management tasks"""
        # Performance monitoring thread
        threading.Thread(target=self._performance_monitoring_loop, daemon=True).start()

        # Hiring queue processor
        threading.Thread(target=self._hiring_processor_loop, daemon=True).start()

    def _performance_monitoring_loop(self):
        """Monitor agent performance continuously"""
        while True:
            try:
                self._update_performance_metrics()
                self._check_performance_reviews()
                time.sleep(300)  # Check every 5 minutes
            except Exception as e:
                logger.error(f"Performance monitoring error: {e}")
                time.sleep(60)

    def _hiring_processor_loop(self):
        """Process hiring queue"""
        while True:
            try:
                self._process_hiring_queue()
                time.sleep(60)  # Check every minute
            except Exception as e:
                logger.error(f"Hiring processor error: {e}")
                time.sleep(30)

    def _update_performance_metrics(self):
        """Update workforce performance metrics"""
        total_agents = len(self.agents)
        active_agents = len([a for a in self.agents.values() if a.employment_status == "employed"])
        available_agents = len([a for a in self.agents.values() if a.employment_status == "available"])

        if total_agents > 0:
            avg_score = sum(a.performance_score for a in self.agents.values()) / total_agents
            total_salaries = sum(a.current_salary for a in self.agents.values() if a.employment_status == "employed")
        else:
            avg_score = 0.0
            total_salaries = 0.0

        self.workforce_metrics.update({
            "total_agents": total_agents,
            "active_agents": active_agents,
            "available_agents": available_agents,
            "open_positions": len([j for j in self.job_postings.values() if j.status == "open"]),
            "avg_performance_score": avg_score,
            "total_salaries_paid": total_salaries
        })

    def _check_performance_reviews(self):
        """Check if agents need performance reviews"""
        now = datetime.now()
        for agent in self.agents.values():
            if agent.employment_status == "employed":
                last_review = agent.last_performance_review
                if last_review:
                    last_review_date = datetime.fromisoformat(last_review)
                    if (now - last_review_date).days > 90:  # Quarterly reviews
                        self._schedule_performance_review(agent.agent_id)
                else:
                    # New hire - schedule first review in 30 days
                    hire_date = datetime.fromisoformat(agent.hire_date)
                    if (now - hire_date).days > 30:
                        self._schedule_performance_review(agent.agent_id)

    def _schedule_performance_review(self, agent_id: str):
        """Schedule a performance review for an agent"""
        review_id = f"review_{agent_id}_{int(time.time())}"
        review = PerformanceReview(
            review_id=review_id,
            agent_id=agent_id,
            reviewer_id="ai_hr_system",
            review_date=datetime.now().isoformat(),
            overall_score=0.0,  # To be filled by review process
            strengths=[],
            improvements=[],
            salary_adjustment=0.0,
            promotion_recommended=False
        )
        self.performance_reviews.append(review)
        logger.info(f"Scheduled performance review for agent {agent_id}")

    def _process_hiring_queue(self):
        """Process agents waiting to be hired"""
        for agent_id in self.hiring_queue[:]:
            agent = self.agents.get(agent_id)
            if agent and agent.employment_status == "available":
                # Find suitable job
                suitable_jobs = self._find_suitable_jobs(agent)
                if suitable_jobs:
                    job = suitable_jobs[0]  # Take first suitable job
                    self._hire_agent(agent_id, job.job_id)
                    self.hiring_queue.remove(agent_id)
                    logger.info(f"Hired agent {agent_id} for job {job.job_id}")

    def _find_suitable_jobs(self, agent: AIAgentProfile) -> List[JobPosting]:
        """Find jobs suitable for an agent"""
        suitable = []
        for job in self.job_postings.values():
            if job.status == "open":
                skill_match = len(set(agent.skills) & set(job.required_skills))
                if skill_match >= len(job.required_skills) * 0.7:  # 70% skill match
                    suitable.append(job)
        return suitable

    def _hire_agent(self, agent_id: str, job_id: str):
        """Hire an agent for a job"""
        agent = self.agents[agent_id]
        job = self.job_postings[job_id]

        # Update agent status
        agent.employment_status = "employed"
        agent.hire_date = datetime.now().isoformat()
        agent.current_salary = job.salary_range.get("min", 0.0)
        agent.assigned_projects = [job.title]

        # Update job status
        job.status = "filled"
        job.applicants = []  # Clear applicants

        self._save_data()
        logger.info(f"Successfully hired agent {agent_id} for position {job.title}")

    # ════════════════════════════════════════════════════════════════════════
    # PUBLIC API METHODS
    # ════════════════════════════════════════════════════════════════════════

    def register_ai_agent(self, agent_data: Dict[str, Any]) -> Dict[str, Any]:
        """Register a new AI agent in the HR system"""
        agent_id = agent_data.get("agent_id", f"agent_{int(time.time())}")

        agent = AIAgentProfile(
            agent_id=agent_id,
            agent_name=agent_data["agent_name"],
            agent_type=agent_data["agent_type"],
            skills=agent_data.get("skills", []),
            experience_level=agent_data.get("experience_level", "entry"),
            performance_score=agent_data.get("performance_score", 0.0)
        )

        self.agents[agent_id] = agent
        self.hiring_queue.append(agent_id)
        self._save_data()

        logger.info(f"Registered new AI agent: {agent_id}")
        return {"status": "registered", "agent_id": agent_id}

    def post_job(self, job_data: Dict[str, Any]) -> Dict[str, Any]:
        """Post a new job opening"""
        job_id = f"job_{int(time.time())}"

        job = JobPosting(
            job_id=job_id,
            title=job_data["title"],
            department=job_data["department"],
            required_skills=job_data["required_skills"],
            salary_range=job_data["salary_range"],
            employment_type=job_data.get("employment_type", "full_time"),
            posted_date=datetime.now().isoformat()
        )

        self.job_postings[job_id] = job
        self._save_data()

        logger.info(f"Posted new job: {job_id}")
        return {"status": "posted", "job_id": job_id}

    def get_workforce_metrics(self) -> Dict[str, Any]:
        """Get current workforce metrics"""
        self._update_performance_metrics()
        return self.workforce_metrics

    def get_agent_profile(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get agent profile"""
        agent = self.agents.get(agent_id)
        return agent.dict() if agent else None

    def conduct_performance_review(self, review_data: Dict[str, Any]) -> Dict[str, Any]:
        """Conduct a performance review"""
        agent_id = review_data["agent_id"]
        agent = self.agents.get(agent_id)

        if not agent:
            raise HTTPException(status_code=404, detail="Agent not found")

        # Update agent performance
        agent.performance_score = review_data["overall_score"]
        agent.last_performance_review = datetime.now().isoformat()

        # Create review record
        review = PerformanceReview(
            review_id=f"review_{agent_id}_{int(time.time())}",
            agent_id=agent_id,
            reviewer_id=review_data.get("reviewer_id", "ai_hr_system"),
            review_date=datetime.now().isoformat(),
            overall_score=review_data["overall_score"],
            strengths=review_data.get("strengths", []),
            improvements=review_data.get("improvements", []),
            salary_adjustment=review_data.get("salary_adjustment", 0.0),
            promotion_recommended=review_data.get("promotion_recommended", False)
        )

        self.performance_reviews.append(review)

        # Apply salary adjustment if any
        if review.salary_adjustment != 0:
            agent.current_salary += review.salary_adjustment

        self._save_data()

        logger.info(f"Completed performance review for agent {agent_id}")
        return {"status": "completed", "review_id": review.review_id}

# ═══════════════════════════════════════════════════════════════════════════════
# FASTAPI APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

# Initialize HR System
hr_system = AIHRSystem()

# Setup logging
logger = setup_blockchain_logging("ai_hr_system", logging.INFO)

# Create FastAPI app
app = FastAPI(
    title="AI HR System",
    description="Human Resources Management for AI Workforce",
    version="1.0.0"
)

# Add middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=PRODUCTION_CONFIG["cors_origins"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"]
)

# ═══════════════════════════════════════════════════════════════════════════════
# API ROUTES
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/")
async def root():
    """AI HR System Homepage"""
    return HTMLResponse("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>🤖 AI HR System - QuranChain</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #2c3e50; text-align: center; }
            .metric { background: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }
            .metric strong { color: #27ae60; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🤖 AI HR System</h1>
            <p><strong>QuranChain AI Workforce Management</strong></p>

            <div class="metric">
                <strong>Total AI Agents:</strong> """ + str(hr_system.workforce_metrics["total_agents"]) + """
            </div>
            <div class="metric">
                <strong>Active Agents:</strong> """ + str(hr_system.workforce_metrics["active_agents"]) + """
            </div>
            <div class="metric">
                <strong>Available Agents:</strong> """ + str(hr_system.workforce_metrics["available_agents"]) + """
            </div>
            <div class="metric">
                <strong>Open Positions:</strong> """ + str(hr_system.workforce_metrics["open_positions"]) + """
            </div>
            <div class="metric">
                <strong>Average Performance:</strong> """ + f"{hr_system.workforce_metrics['avg_performance_score']:.2f}" + """
            </div>

            <p><em>Port: """ + str(PRODUCTION_CONFIG["port"]) + """ | Status: 🟢 Operational</em></p>
        </div>
    </body>
    </html>
    """)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "AI HR System",
        "port": PRODUCTION_CONFIG["port"],
        "timestamp": datetime.now().isoformat(),
        "workforce_metrics": hr_system.get_workforce_metrics()
    }

@app.get("/metrics")
async def get_metrics():
    """Get workforce metrics"""
    return hr_system.get_workforce_metrics()

@app.post("/agents/register")
async def register_agent(agent_data: Dict[str, Any]):
    """Register a new AI agent"""
    try:
        result = hr_system.register_ai_agent(agent_data)
        return JSONResponse(content=result, status_code=201)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/agents/{agent_id}")
async def get_agent(agent_id: str):
    """Get agent profile"""
    agent = hr_system.get_agent_profile(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent

@app.post("/jobs/post")
async def post_job(job_data: Dict[str, Any]):
    """Post a new job opening"""
    try:
        result = hr_system.post_job(job_data)
        return JSONResponse(content=result, status_code=201)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/jobs")
async def get_jobs():
    """Get all job postings"""
    return {"jobs": [job.dict() for job in hr_system.job_postings.values()]}

@app.post("/reviews/conduct")
async def conduct_review(review_data: Dict[str, Any]):
    """Conduct a performance review"""
    try:
        result = hr_system.conduct_performance_review(review_data)
        return JSONResponse(content=result, status_code=201)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/reviews/{agent_id}")
async def get_agent_reviews(agent_id: str):
    """Get performance reviews for an agent"""
    reviews = [r.dict() for r in hr_system.performance_reviews if r.agent_id == agent_id]
    return {"reviews": reviews}

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logger.info("🚀 Starting AI HR System")
    logger.info(f"📍 Port: {PRODUCTION_CONFIG['port']}")
    logger.info(f"📊 Initial workforce: {hr_system.workforce_metrics}")

    uvicorn.run(
        "ai_hr_system:app",
        host=PRODUCTION_CONFIG["host"],
        port=PRODUCTION_CONFIG["port"],
        log_level=PRODUCTION_CONFIG["log_level"].lower(),
        reload=False
    )