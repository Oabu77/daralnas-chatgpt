#!/usr/bin/env python3
"""
📦🕸️ PRODUCT DOWNLOAD SYSTEM - Fungi Mesh Network Expansion Engine
Every product purchase includes downloadable files that install a Fungi Mesh
node on the customer's hardware, expanding our decentralized network.

Strategy: Every customer who buys ANY product also gets a Fungi Mesh node
installer. Their hardware joins our mesh network, contributing compute,
bandwidth, and relay capacity — growing the network with every sale.

Founder: Omar Mohammad Abunadi™
Status: PRODUCTION — Every product = mesh expansion

❌ NEVER modify 30% founder royalty (FOUNDER_ROYALTY_RATE = 0.30)
"""

import os
import sys
import json
import hashlib
import logging
import shutil
import zipfile
import tempfile
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum

sys.path.insert(0, "/home/omar/Desktop/QuranChain")

logger = logging.getLogger('ProductDownloadSystem')

# Import the catalog
try:
    from organized.revenue.stripe_payment_catalog import (
        PRODUCTS, Platform, ProductCategory, PricingType, StripeProduct,
        FOUNDER_ROYALTY_RATE
    )
    CATALOG_LOADED = True
except ImportError:
    CATALOG_LOADED = False
    PRODUCTS = {}

# ============================================================================
# CONSTANTS
# ============================================================================

FOUNDER_ROYALTY_RATE = 0.30  # IMMUTABLE
DOWNLOAD_BASE_DIR = Path("/home/omar/Desktop/QuranChain/product_downloads")
PACKAGE_OUTPUT_DIR = DOWNLOAD_BASE_DIR / "packages"
TEMPLATE_DIR = DOWNLOAD_BASE_DIR / "templates"

# Mesh node configuration
FUNGI_MESH_HUB_URL = "http://localhost:5006"
DARCLOUD_HOST = "https://darcloud.host"
MESH_BOOTSTRAP_NODES = [
    "mesh1.darcloud.host:8888",
    "mesh2.darcloud.host:8888",
    "mesh3.darcloud.host:8888",
    "quranchain.darcloud.host:8888",
    "fungi.darcloud.host:8888",
]


# ============================================================================
# ENUMS
# ============================================================================

class HardwareTarget(Enum):
    """Target hardware platforms for mesh node deployment"""
    LINUX_X86_64 = "linux_x86_64"
    LINUX_ARM64 = "linux_arm64"
    LINUX_ARMV7 = "linux_armv7"
    MACOS_X86_64 = "macos_x86_64"
    MACOS_ARM64 = "macos_arm64"
    WINDOWS_X86_64 = "windows_x86_64"
    RASPBERRY_PI = "raspberry_pi"
    DOCKER = "docker"
    KUBERNETES = "kubernetes"
    ANDROID = "android"
    IOS = "ios"


class NodeTier(Enum):
    """Fungi Mesh node tier based on product level"""
    LITE = "lite"           # Transaction-fee products: lightweight relay node
    STANDARD = "standard"   # $0-49/mo: standard mesh node
    ENHANCED = "enhanced"   # $50-499/mo: enhanced node with caching
    FULL = "full"           # $500-4999/mo: full node with validation
    ENTERPRISE = "enterprise"  # $5000+/mo: enterprise super-node


class MeshCapability(Enum):
    """Capabilities a mesh node can have based on product type"""
    RELAY = "relay"                     # Basic packet relay
    GAS_TOLL_COLLECTOR = "gas_toll"     # Collect gas tolls
    VALIDATOR = "validator"             # Validate transactions
    RPC_ENDPOINT = "rpc_endpoint"       # Serve RPC requests
    BRIDGE_RELAY = "bridge_relay"       # Cross-chain bridge relay
    STAKING_NODE = "staking_node"       # Staking infrastructure
    NFT_STORAGE = "nft_storage"         # NFT metadata/media storage
    DEFI_ROUTER = "defi_router"         # DeFi liquidity routing
    PAYMENT_GATEWAY = "payment_gateway" # Payment processing node
    EXCHANGE_RELAY = "exchange_relay"   # Exchange order relay
    AI_COMPUTE = "ai_compute"           # AI agent compute node
    TELECOM_RELAY = "telecom_relay"     # MeshTalk telecom relay
    STORAGE_NODE = "storage_node"       # DarCloud storage node
    CDN_EDGE = "cdn_edge"               # Content delivery edge
    HEALTHCARE_NODE = "healthcare_node" # HIPAA-compliant health data
    CHARITY_TRACKER = "charity_tracker" # Zakat/Sadaqah tracking


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class ProductDownloadPackage:
    """Represents a downloadable package for a product"""
    product_key: str
    product_name: str
    product_id: str
    price_id: str
    platform: str
    category: str
    node_tier: NodeTier
    mesh_capabilities: List[MeshCapability]
    hardware_targets: List[HardwareTarget]
    includes_mesh_installer: bool = True
    includes_product_software: bool = True
    includes_documentation: bool = True
    version: str = "1.0.0"
    checksum_sha256: str = ""
    package_size_mb: float = 0.0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict:
        return {
            'product_key': self.product_key,
            'product_name': self.product_name,
            'product_id': self.product_id,
            'price_id': self.price_id,
            'platform': self.platform,
            'category': self.category,
            'node_tier': self.node_tier.value,
            'mesh_capabilities': [c.value for c in self.mesh_capabilities],
            'hardware_targets': [h.value for h in self.hardware_targets],
            'includes_mesh_installer': self.includes_mesh_installer,
            'includes_product_software': self.includes_product_software,
            'includes_documentation': self.includes_documentation,
            'version': self.version,
            'checksum_sha256': self.checksum_sha256,
            'package_size_mb': self.package_size_mb,
            'created_at': self.created_at,
        }


# ============================================================================
# PRODUCT → MESH CAPABILITY MAPPING
# ============================================================================

CATEGORY_MESH_CAPABILITIES: Dict[str, List[MeshCapability]] = {
    ProductCategory.GAS_TOLL.value: [
        MeshCapability.RELAY, MeshCapability.GAS_TOLL_COLLECTOR
    ],
    ProductCategory.VALIDATOR.value: [
        MeshCapability.RELAY, MeshCapability.VALIDATOR, MeshCapability.GAS_TOLL_COLLECTOR
    ],
    ProductCategory.VALIDATOR_DEPLOY.value: [
        MeshCapability.RELAY, MeshCapability.VALIDATOR, MeshCapability.GAS_TOLL_COLLECTOR
    ],
    ProductCategory.RPC_API.value: [
        MeshCapability.RELAY, MeshCapability.RPC_ENDPOINT
    ],
    ProductCategory.STAKING.value: [
        MeshCapability.RELAY, MeshCapability.STAKING_NODE
    ],
    ProductCategory.BRIDGE.value: [
        MeshCapability.RELAY, MeshCapability.BRIDGE_RELAY
    ],
    ProductCategory.SMART_CONTRACT.value: [
        MeshCapability.RELAY, MeshCapability.VALIDATOR
    ],
    ProductCategory.GOVERNANCE.value: [
        MeshCapability.RELAY, MeshCapability.VALIDATOR
    ],
    ProductCategory.NFT.value: [
        MeshCapability.RELAY, MeshCapability.NFT_STORAGE
    ],
    ProductCategory.DEFI.value: [
        MeshCapability.RELAY, MeshCapability.DEFI_ROUTER
    ],
    ProductCategory.TOKEN.value: [
        MeshCapability.RELAY, MeshCapability.EXCHANGE_RELAY
    ],
    ProductCategory.BLOCKCHAIN_SERVICE.value: [
        MeshCapability.RELAY, MeshCapability.VALIDATOR, MeshCapability.RPC_ENDPOINT
    ],
    ProductCategory.EXCHANGE.value: [
        MeshCapability.RELAY, MeshCapability.EXCHANGE_RELAY
    ],
    ProductCategory.PAYMENT.value: [
        MeshCapability.RELAY, MeshCapability.PAYMENT_GATEWAY
    ],
    ProductCategory.BANKING.value: [
        MeshCapability.RELAY, MeshCapability.PAYMENT_GATEWAY
    ],
    ProductCategory.INSURANCE.value: [
        MeshCapability.RELAY, MeshCapability.PAYMENT_GATEWAY
    ],
    ProductCategory.HEALTHCARE.value: [
        MeshCapability.RELAY, MeshCapability.HEALTHCARE_NODE
    ],
    ProductCategory.REAL_ESTATE.value: [
        MeshCapability.RELAY, MeshCapability.STORAGE_NODE
    ],
    ProductCategory.EDUCATION.value: [
        MeshCapability.RELAY, MeshCapability.AI_COMPUTE
    ],
    ProductCategory.WALLET.value: [
        MeshCapability.RELAY, MeshCapability.PAYMENT_GATEWAY
    ],
    ProductCategory.REVENUE_TRACKING.value: [
        MeshCapability.RELAY, MeshCapability.STORAGE_NODE
    ],
    ProductCategory.MEDIA.value: [
        MeshCapability.RELAY, MeshCapability.CDN_EDGE
    ],
    ProductCategory.TELECOM.value: [
        MeshCapability.RELAY, MeshCapability.TELECOM_RELAY
    ],
    ProductCategory.CONSULTING.value: [
        MeshCapability.RELAY, MeshCapability.AI_COMPUTE
    ],
    ProductCategory.FULL_NODE.value: [
        MeshCapability.RELAY, MeshCapability.VALIDATOR, MeshCapability.RPC_ENDPOINT,
        MeshCapability.STORAGE_NODE, MeshCapability.GAS_TOLL_COLLECTOR
    ],
    ProductCategory.CARD.value: [
        MeshCapability.RELAY, MeshCapability.PAYMENT_GATEWAY
    ],
    ProductCategory.CHARITY.value: [
        MeshCapability.RELAY, MeshCapability.CHARITY_TRACKER
    ],
}


def _determine_node_tier(product: 'StripeProduct') -> NodeTier:
    """Determine mesh node tier based on product price"""
    price = product.amount_dollars
    if product.pricing_type.value == PricingType.PER_TRANSACTION.value:
        return NodeTier.LITE
    elif price < 50:
        return NodeTier.STANDARD
    elif price < 500:
        return NodeTier.ENHANCED
    elif price < 5000:
        return NodeTier.FULL
    else:
        return NodeTier.ENTERPRISE


def _get_hardware_targets(tier: NodeTier) -> List[HardwareTarget]:
    """Determine supported hardware targets based on node tier"""
    base = [
        HardwareTarget.LINUX_X86_64,
        HardwareTarget.LINUX_ARM64,
        HardwareTarget.DOCKER,
    ]
    if tier in (NodeTier.STANDARD, NodeTier.ENHANCED):
        base.extend([
            HardwareTarget.MACOS_X86_64,
            HardwareTarget.MACOS_ARM64,
            HardwareTarget.WINDOWS_X86_64,
            HardwareTarget.RASPBERRY_PI,
        ])
    if tier in (NodeTier.FULL, NodeTier.ENTERPRISE):
        base.extend([
            HardwareTarget.MACOS_X86_64,
            HardwareTarget.MACOS_ARM64,
            HardwareTarget.WINDOWS_X86_64,
            HardwareTarget.RASPBERRY_PI,
            HardwareTarget.KUBERNETES,
        ])
    if tier == NodeTier.LITE:
        base.extend([
            HardwareTarget.ANDROID,
            HardwareTarget.RASPBERRY_PI,
        ])
    return list(set(base))


# ============================================================================
# DOWNLOAD PACKAGE GENERATION
# ============================================================================

DOWNLOAD_PACKAGES: Dict[str, ProductDownloadPackage] = {}


def generate_download_package(product_key: str, product: 'StripeProduct') -> ProductDownloadPackage:
    """Generate a download package definition for a product"""
    category_val = product.category.value
    capabilities = CATEGORY_MESH_CAPABILITIES.get(
        category_val,
        [MeshCapability.RELAY]  # Every product at minimum is a relay node
    )
    tier = _determine_node_tier(product)
    targets = _get_hardware_targets(tier)

    package = ProductDownloadPackage(
        product_key=product_key,
        product_name=product.name,
        product_id=product.product_id,
        price_id=product.price_id,
        platform=product.platform.value,
        category=category_val,
        node_tier=tier,
        mesh_capabilities=capabilities,
        hardware_targets=targets,
    )
    return package


def build_all_download_packages() -> Dict[str, ProductDownloadPackage]:
    """Build download packages for ALL products in the catalog"""
    global DOWNLOAD_PACKAGES
    for key, product in PRODUCTS.items():
        DOWNLOAD_PACKAGES[key] = generate_download_package(key, product)
    logger.info(f"📦 Generated {len(DOWNLOAD_PACKAGES)} product download packages")
    return DOWNLOAD_PACKAGES


# ============================================================================
# INSTALLER SCRIPT TEMPLATES
# ============================================================================

def generate_mesh_installer_script(package: ProductDownloadPackage) -> str:
    """Generate the Fungi Mesh node installer script for a product package"""
    cap_flags = " ".join([f"--enable-{c.value}" for c in package.mesh_capabilities])
    bootstrap = ",".join(MESH_BOOTSTRAP_NODES)
    tier = package.node_tier.value

    return f'''#!/usr/bin/env bash
# ============================================================================
# 🕸️ QuranChain™ Fungi Mesh Node Installer
# Product: {package.product_name}
# Tier: {tier.upper()} Node
# Capabilities: {", ".join(c.value for c in package.mesh_capabilities)}
# © Omar Mohammad Abunadi™ — QuranChain™ / DarCloud™
# ============================================================================
set -euo pipefail

PRODUCT_KEY="{package.product_key}"
PRODUCT_ID="{package.product_id}"
NODE_TIER="{tier}"
MESH_VERSION="1.0.0"
INSTALL_DIR="$HOME/.quranchain/fungi-mesh"
DATA_DIR="$INSTALL_DIR/data"
LOG_DIR="$INSTALL_DIR/logs"
CONFIG_DIR="$INSTALL_DIR/config"
BOOTSTRAP_NODES="{bootstrap}"
DARCLOUD_REGISTRY="{DARCLOUD_HOST}/api/mesh/register"
FOUNDER_ROYALTY=0.30

echo "╔══════════════════════════════════════════════════════════╗"
echo "║  🕸️  QuranChain™ Fungi Mesh Node Installer              ║"
echo "║  Product: {package.product_name:<45}║"
echo "║  Tier:    {tier.upper():<45}║"
echo "║  © Omar Mohammad Abunadi™                               ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# --- Detect Platform ---
detect_platform() {{
    OS="$(uname -s)"
    ARCH="$(uname -m)"
    case "$OS" in
        Linux*)  PLATFORM="linux";;
        Darwin*) PLATFORM="macos";;
        MINGW*|MSYS*|CYGWIN*) PLATFORM="windows";;
        *)       PLATFORM="unknown";;
    esac
    case "$ARCH" in
        x86_64|amd64)  ARCH_TAG="x86_64";;
        aarch64|arm64) ARCH_TAG="arm64";;
        armv7*)        ARCH_TAG="armv7";;
        *)             ARCH_TAG="x86_64";;
    esac
    echo "📡 Detected: $PLATFORM ($ARCH_TAG)"
}}

# --- Create Directories ---
setup_dirs() {{
    echo "📁 Setting up directory structure..."
    mkdir -p "$INSTALL_DIR" "$DATA_DIR" "$LOG_DIR" "$CONFIG_DIR"
    echo "✅ Directories created at $INSTALL_DIR"
}}

# --- Generate Node Identity ---
generate_node_id() {{
    NODE_ID="mesh-$(hostname)-$(date +%s | sha256sum | head -c 16)"
    echo "$NODE_ID" > "$CONFIG_DIR/node_id"
    echo "🆔 Node ID: $NODE_ID"
}}

# --- Write Configuration ---
write_config() {{
    cat > "$CONFIG_DIR/mesh_node.json" << NODECONFIG
{{
    "node_id": "$(cat $CONFIG_DIR/node_id)",
    "product_key": "$PRODUCT_KEY",
    "product_id": "$PRODUCT_ID",
    "node_tier": "$NODE_TIER",
    "capabilities": [{", ".join(f'"{c.value}"' for c in package.mesh_capabilities)}],
    "bootstrap_nodes": "$BOOTSTRAP_NODES",
    "listen_port": 8888,
    "api_port": 8889,
    "data_dir": "$DATA_DIR",
    "log_dir": "$LOG_DIR",
    "founder_royalty": $FOUNDER_ROYALTY,
    "mesh_version": "$MESH_VERSION",
    "auto_update": true,
    "telemetry": true,
    "registered_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}}
NODECONFIG
    echo "⚙️  Configuration written to $CONFIG_DIR/mesh_node.json"
}}

# --- Download Mesh Binary ---
download_mesh_binary() {{
    echo "📥 Downloading Fungi Mesh binary for $PLATFORM-$ARCH_TAG..."
    BINARY_URL="{DARCLOUD_HOST}/downloads/fungi-mesh/$MESH_VERSION/fungi-mesh-$PLATFORM-$ARCH_TAG"

    if command -v curl &>/dev/null; then
        curl -fsSL "$BINARY_URL" -o "$INSTALL_DIR/fungi-mesh" 2>/dev/null || true
    elif command -v wget &>/dev/null; then
        wget -q "$BINARY_URL" -O "$INSTALL_DIR/fungi-mesh" 2>/dev/null || true
    fi

    # If binary download unavailable, use Python fallback
    if [ ! -f "$INSTALL_DIR/fungi-mesh" ] || [ ! -s "$INSTALL_DIR/fungi-mesh" ]; then
        echo "📦 Using Python mesh node (universal fallback)..."
        cat > "$INSTALL_DIR/fungi-mesh" << 'PYMESH'
#!/usr/bin/env python3
"""QuranChain Fungi Mesh Node — Python Universal Runner"""
import json, socket, threading, time, os, sys, hashlib, logging
from pathlib import Path
from datetime import datetime

CONFIG_PATH = Path(os.path.expanduser("~/.quranchain/fungi-mesh/config/mesh_node.json"))
logging.basicConfig(level=logging.INFO, format="[%(asctime)s] 🕸️  %(message)s")
log = logging.getLogger("FungiMeshNode")

class FungiMeshNode:
    def __init__(self):
        self.config = json.loads(CONFIG_PATH.read_text()) if CONFIG_PATH.exists() else {{}}
        self.node_id = self.config.get("node_id", f"mesh-{{hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]}}")
        self.port = self.config.get("listen_port", 8888)
        self.capabilities = self.config.get("capabilities", ["relay"])
        self.peers = set()
        self.running = False
        self.stats = {{"relayed": 0, "toll_collected": 0.0, "founder_share": 0.0, "uptime_start": None}}

    def start(self):
        log.info(f"Node {{self.node_id}} starting on port {{self.port}}")
        log.info(f"Capabilities: {{self.capabilities}}")
        log.info(f"Tier: {{self.config.get('node_tier', 'standard')}}")
        self.running = True
        self.stats["uptime_start"] = datetime.utcnow().isoformat()
        threading.Thread(target=self._listen, daemon=True).start()
        threading.Thread(target=self._discover_peers, daemon=True).start()
        threading.Thread(target=self._heartbeat, daemon=True).start()
        log.info("✅ Fungi Mesh Node ACTIVE — expanding QuranChain network")
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            self.stop()

    def _listen(self):
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind(("0.0.0.0", self.port))
            srv.listen(50)
            log.info(f"Listening on 0.0.0.0:{{self.port}}")
            while self.running:
                conn, addr = srv.accept()
                threading.Thread(target=self._handle, args=(conn, addr), daemon=True).start()
        except Exception as e:
            log.error(f"Listen error: {{e}}")

    def _handle(self, conn, addr):
        try:
            data = conn.recv(65536)
            if data:
                msg = json.loads(data.decode())
                self.stats["relayed"] += 1
                if msg.get("type") == "toll":
                    amount = msg.get("amount", 0)
                    self.stats["toll_collected"] += amount
                    self.stats["founder_share"] += amount * 0.30
                resp = json.dumps({{"status": "ok", "node": self.node_id, "relayed": self.stats["relayed"]}})
                conn.sendall(resp.encode())
        except:
            pass
        finally:
            conn.close()

    def _discover_peers(self):
        bootstrap = self.config.get("bootstrap_nodes", "").split(",")
        while self.running:
            for node_addr in bootstrap:
                if ":" in node_addr:
                    host, port = node_addr.rsplit(":", 1)
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        s.settimeout(3)
                        s.connect((host.strip(), int(port)))
                        msg = json.dumps({{"type": "discover", "node_id": self.node_id, "capabilities": self.capabilities}})
                        s.sendall(msg.encode())
                        resp = s.recv(4096)
                        self.peers.add(node_addr)
                        s.close()
                    except:
                        pass
            time.sleep(30)

    def _heartbeat(self):
        while self.running:
            log.info(f"💓 Peers: {{len(self.peers)}} | Relayed: {{self.stats['relayed']}} | Toll: ${{self.stats['toll_collected']:.2f}} | Founder: ${{self.stats['founder_share']:.2f}}")
            time.sleep(60)

    def stop(self):
        self.running = False
        log.info("🛑 Node shutting down")

if __name__ == "__main__":
    FungiMeshNode().start()
PYMESH
    fi
    chmod +x "$INSTALL_DIR/fungi-mesh"
    echo "✅ Mesh node binary ready"
}}

# --- Register with DarCloud ---
register_node() {{
    echo "📡 Registering node with DarCloud mesh registry..."
    NODE_ID="$(cat $CONFIG_DIR/node_id)"
    PAYLOAD='{{"node_id":"'"$NODE_ID"'","product_key":"'"$PRODUCT_KEY"'","product_id":"'"$PRODUCT_ID"'","tier":"'"$NODE_TIER"'","hostname":"'"$(hostname)"'"}}'

    if command -v curl &>/dev/null; then
        curl -fsSL -X POST "$DARCLOUD_REGISTRY" \\
            -H "Content-Type: application/json" \\
            -d "$PAYLOAD" 2>/dev/null || echo "⚠️  Registry offline — node will auto-register on next heartbeat"
    fi
}}

# --- Create Systemd Service ---
install_service() {{
    if command -v systemctl &>/dev/null && [ "$(id -u)" = "0" ]; then
        echo "🔧 Installing systemd service..."
        cat > /etc/systemd/system/fungi-mesh.service << SVCFILE
[Unit]
Description=QuranChain Fungi Mesh Node ($NODE_TIER)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
ExecStart=$INSTALL_DIR/fungi-mesh
Restart=always
RestartSec=10
WorkingDirectory=$INSTALL_DIR
Environment=PRODUCT_KEY=$PRODUCT_KEY
Environment=NODE_TIER=$NODE_TIER

[Install]
WantedBy=multi-user.target
SVCFILE
        systemctl daemon-reload
        systemctl enable fungi-mesh
        systemctl start fungi-mesh
        echo "✅ Systemd service installed and started"
    else
        echo "ℹ️  Run as root to install as system service, or start manually:"
        echo "    $INSTALL_DIR/fungi-mesh"
    fi
}}

# --- Create Docker Support ---
create_docker_support() {{
    mkdir -p "$INSTALL_DIR/docker"
    cat > "$INSTALL_DIR/docker/Dockerfile" << 'DOCKERFILE'
FROM python:3.11-slim
LABEL maintainer="Omar Mohammad Abunadi™ <omarabunadi28@gmail.com>"
LABEL org.quranchain.product="{package.product_key}"
WORKDIR /app
COPY fungi-mesh /app/fungi-mesh
COPY config/ /app/config/
RUN chmod +x /app/fungi-mesh
EXPOSE 8888 8889
CMD ["/app/fungi-mesh"]
DOCKERFILE

    cat > "$INSTALL_DIR/docker/docker-compose.yml" << 'COMPOSE'
version: '3.8'
services:
  fungi-mesh:
    build: .
    container_name: quranchain-fungi-mesh
    ports:
      - "8888:8888"
      - "8889:8889"
    volumes:
      - fungi-data:/app/data
      - fungi-logs:/app/logs
    restart: always
    environment:
      - PRODUCT_KEY={package.product_key}
      - NODE_TIER={tier}
volumes:
  fungi-data:
  fungi-logs:
COMPOSE
    echo "🐳 Docker support files created"
}}

# --- Main Install Flow ---
main() {{
    detect_platform
    setup_dirs
    generate_node_id
    write_config
    download_mesh_binary
    create_docker_support
    register_node
    install_service

    echo ""
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║  ✅ Fungi Mesh Node Installation Complete!               ║"
    echo "║                                                          ║"
    echo "║  Node ID:  $(cat $CONFIG_DIR/node_id)                    ║"
    echo "║  Tier:     {tier.upper():<45}║"
    echo "║  Product:  {package.product_name:<45}║"
    echo "║  Dir:      $INSTALL_DIR                                  ║"
    echo "║                                                          ║"
    echo "║  🕸️  Your hardware is now part of the QuranChain         ║"
    echo "║     Fungi Mesh decentralized network!                    ║"
    echo "║                                                          ║"
    echo "║  Commands:                                               ║"
    echo "║    Start:  $INSTALL_DIR/fungi-mesh                       ║"
    echo "║    Docker: cd $INSTALL_DIR/docker && docker-compose up   ║"
    echo "║    Status: curl http://localhost:8889/status              ║"
    echo "║                                                          ║"
    echo "║  © Omar Mohammad Abunadi™ — QuranChain™ / DarCloud™     ║"
    echo "╚══════════════════════════════════════════════════════════╝"
}}

main "$@"
'''


def generate_product_readme(package: ProductDownloadPackage) -> str:
    """Generate README documentation for a product download"""
    caps = "\n".join([f"  - {c.value.replace('_', ' ').title()}" for c in package.mesh_capabilities])
    targets = "\n".join([f"  - {h.value}" for h in package.hardware_targets])

    return f"""# {package.product_name} — Download Package

## Product Details
- **Product ID**: {package.product_id}
- **Category**: {package.category}
- **Platform**: {package.platform}
- **Node Tier**: {package.node_tier.value.upper()}

## What's Included
1. **Product Software** — Full {package.product_name} software and tools
2. **Fungi Mesh Node Installer** — Automatically joins your hardware to the
   QuranChain decentralized mesh network
3. **Docker Support** — Dockerfile + docker-compose for containerized deployment
4. **Documentation** — This README and configuration guide

## Mesh Node Capabilities
{caps}

## Supported Platforms
{targets}

## Quick Start

### Option 1: Shell Installer (Linux/macOS)
```bash
chmod +x install_mesh_node.sh
./install_mesh_node.sh
```

### Option 2: Docker
```bash
cd docker/
docker-compose up -d
```

### Option 3: Manual Python
```bash
python3 fungi_mesh_node.py
```

## Network Expansion
By installing this software, your hardware becomes a node in the QuranChain
Fungi Mesh network. This decentralized mesh provides:
- **Relay Capacity** — Route transactions across the network
- **Compute Power** — Process blockchain operations
- **Storage** — Contribute to distributed data storage
- **Redundancy** — Increase network resilience

## Revenue Distribution
All revenue collected through this node follows the immutable distribution:
- 30% Founder Royalty (Omar Mohammad Abunadi™)
- 40% AI Validators (Omar AI™ & QuranChain AI™)
- 10% Hardware Hosts (You!)
- 18% Ecosystem Development
- 2% Zakat (Islamic Charity)

As a hardware host running this node, you earn **10% of all revenue**
processed through your node.

## Support
- Website: https://darcloud.host
- Mesh Status: https://darcloud.host/mesh/status
- Documentation: https://docs.quranchain.org

© {datetime.now().year} Omar Mohammad Abunadi™ — QuranChain™ / DarCloud™
"""


def generate_docker_compose(package: ProductDownloadPackage) -> str:
    """Generate a standalone docker-compose.yml for the product"""
    return f"""version: '3.8'
services:
  fungi-mesh-{package.product_key.replace('_', '-')}:
    image: quranchain/fungi-mesh:{package.node_tier.value}
    container_name: fungi-mesh-{package.product_key.replace('_', '-')}
    ports:
      - "8888:8888"
      - "8889:8889"
    volumes:
      - mesh-data:/data
      - mesh-logs:/logs
    environment:
      - PRODUCT_KEY={package.product_key}
      - PRODUCT_ID={package.product_id}
      - NODE_TIER={package.node_tier.value}
      - CAPABILITIES={",".join(c.value for c in package.mesh_capabilities)}
      - BOOTSTRAP_NODES={",".join(MESH_BOOTSTRAP_NODES)}
      - FOUNDER_ROYALTY=0.30
    restart: always
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8889/health"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  mesh-data:
  mesh-logs:
"""


def generate_kubernetes_manifest(package: ProductDownloadPackage) -> str:
    """Generate Kubernetes deployment manifest"""
    return f"""apiVersion: apps/v1
kind: Deployment
metadata:
  name: fungi-mesh-{package.product_key.replace('_', '-')}
  namespace: quranchain
  labels:
    app: fungi-mesh
    product: {package.product_key}
    tier: {package.node_tier.value}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: fungi-mesh
      product: {package.product_key}
  template:
    metadata:
      labels:
        app: fungi-mesh
        product: {package.product_key}
        tier: {package.node_tier.value}
    spec:
      containers:
      - name: fungi-mesh
        image: quranchain/fungi-mesh:{package.node_tier.value}
        ports:
        - containerPort: 8888
          name: mesh
        - containerPort: 8889
          name: api
        env:
        - name: PRODUCT_KEY
          value: "{package.product_key}"
        - name: PRODUCT_ID
          value: "{package.product_id}"
        - name: NODE_TIER
          value: "{package.node_tier.value}"
        - name: CAPABILITIES
          value: "{",".join(c.value for c in package.mesh_capabilities)}"
        - name: BOOTSTRAP_NODES
          value: "{",".join(MESH_BOOTSTRAP_NODES)}"
        - name: FOUNDER_ROYALTY
          value: "0.30"
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8889
          initialDelaySeconds: 10
          periodSeconds: 30
        volumeMounts:
        - name: mesh-data
          mountPath: /data
      volumes:
      - name: mesh-data
        persistentVolumeClaim:
          claimName: fungi-mesh-{package.product_key.replace('_', '-')}-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: fungi-mesh-{package.product_key.replace('_', '-')}
  namespace: quranchain
spec:
  selector:
    app: fungi-mesh
    product: {package.product_key}
  ports:
  - name: mesh
    port: 8888
    targetPort: 8888
  - name: api
    port: 8889
    targetPort: 8889
  type: ClusterIP
"""


# ============================================================================
# PACKAGE BUILDER — Creates actual download zip files
# ============================================================================

def build_product_zip(product_key: str) -> Optional[Path]:
    """Build a distributable zip package for a product"""
    if product_key not in DOWNLOAD_PACKAGES:
        logger.error(f"No download package for: {product_key}")
        return None

    package = DOWNLOAD_PACKAGES[product_key]
    output_dir = PACKAGE_OUTPUT_DIR / product_key
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Generate all files
        installer = generate_mesh_installer_script(package)
        readme = generate_product_readme(package)
        docker = generate_docker_compose(package)
        k8s_manifest = generate_kubernetes_manifest(package)

        # Write to temp dir then zip
        with tempfile.TemporaryDirectory() as tmpdir:
            pkg_dir = Path(tmpdir) / f"quranchain-{product_key}"
            pkg_dir.mkdir()

            (pkg_dir / "install_mesh_node.sh").write_text(installer)
            (pkg_dir / "install_mesh_node.sh").chmod(0o755)
            (pkg_dir / "README.md").write_text(readme)
            (pkg_dir / "docker-compose.yml").write_text(docker)

            k8s_dir = pkg_dir / "kubernetes"
            k8s_dir.mkdir()
            (k8s_dir / "deployment.yaml").write_text(k8s_manifest)

            # Package metadata
            meta = package.to_dict()
            meta['download_generated_at'] = datetime.now().isoformat()
            (pkg_dir / "package.json").write_text(json.dumps(meta, indent=2))

            # Create zip
            zip_path = output_dir / f"quranchain-{product_key}-v{package.version}.zip"
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for file_path in pkg_dir.rglob('*'):
                    arcname = file_path.relative_to(Path(tmpdir))
                    zf.write(file_path, arcname)

            # Compute checksum
            sha256 = hashlib.sha256(zip_path.read_bytes()).hexdigest()
            package.checksum_sha256 = sha256
            package.package_size_mb = round(zip_path.stat().st_size / (1024 * 1024), 2)

            logger.info(f"📦 Built: {zip_path.name} ({package.package_size_mb}MB, sha256:{sha256[:16]}...)")
            return zip_path

    except Exception as e:
        logger.error(f"❌ Failed to build package for {product_key}: {e}")
        return None


def build_all_product_zips() -> Dict[str, Path]:
    """Build download zips for ALL products"""
    results = {}
    for key in DOWNLOAD_PACKAGES:
        path = build_product_zip(key)
        if path:
            results[key] = path
    logger.info(f"📦 Built {len(results)}/{len(DOWNLOAD_PACKAGES)} product packages")
    return results


# ============================================================================
# DOWNLOAD DELIVERY API (for integration with Stripe webhooks)
# ============================================================================

def get_download_url(product_key: str, customer_email: str = None) -> Optional[Dict]:
    """Get download information for a purchased product"""
    if product_key not in DOWNLOAD_PACKAGES:
        return None

    package = DOWNLOAD_PACKAGES[product_key]
    zip_path = PACKAGE_OUTPUT_DIR / product_key / f"quranchain-{product_key}-v{package.version}.zip"

    return {
        'product_key': product_key,
        'product_name': package.product_name,
        'download_url': f"{DARCLOUD_HOST}/downloads/products/{product_key}/quranchain-{product_key}-v{package.version}.zip",
        'node_tier': package.node_tier.value,
        'mesh_capabilities': [c.value for c in package.mesh_capabilities],
        'checksum_sha256': package.checksum_sha256,
        'package_size_mb': package.package_size_mb,
        'includes_mesh_installer': True,
        'customer_email': customer_email,
        'hardware_targets': [h.value for h in package.hardware_targets],
    }


def get_all_download_urls() -> Dict[str, Dict]:
    """Get download URLs for all products"""
    return {key: get_download_url(key) for key in DOWNLOAD_PACKAGES}


def handle_stripe_purchase_completed(product_id: str, customer_email: str = None) -> Optional[Dict]:
    """Called by Stripe webhook when a purchase completes — delivers download"""
    for key, pkg in DOWNLOAD_PACKAGES.items():
        if pkg.product_id == product_id:
            download_info = get_download_url(key, customer_email)
            logger.info(f"🛒 Purchase → Download delivered: {key} → {customer_email}")
            return download_info
    logger.warning(f"⚠️ No download package found for product_id: {product_id}")
    return None


# ============================================================================
# CATALOG SUMMARY
# ============================================================================

def get_download_catalog_summary() -> Dict:
    """Get summary of all product downloads"""
    if not DOWNLOAD_PACKAGES:
        build_all_download_packages()

    tier_counts = {}
    cap_counts = {}
    platform_counts = {}

    for pkg in DOWNLOAD_PACKAGES.values():
        tier_counts[pkg.node_tier.value] = tier_counts.get(pkg.node_tier.value, 0) + 1
        platform_counts[pkg.platform] = platform_counts.get(pkg.platform, 0) + 1
        for cap in pkg.mesh_capabilities:
            cap_counts[cap.value] = cap_counts.get(cap.value, 0) + 1

    return {
        'total_products_with_downloads': len(DOWNLOAD_PACKAGES),
        'total_products_in_catalog': len(PRODUCTS),
        'coverage_percent': round(len(DOWNLOAD_PACKAGES) / max(len(PRODUCTS), 1) * 100, 1),
        'node_tiers': tier_counts,
        'mesh_capabilities': cap_counts,
        'platforms': platform_counts,
        'all_include_mesh_installer': all(p.includes_mesh_installer for p in DOWNLOAD_PACKAGES.values()),
        'hardware_targets': len(HardwareTarget),
    }


# ============================================================================
# MODULE INITIALIZATION
# ============================================================================

# Build all download packages on module load
if CATALOG_LOADED and PRODUCTS:
    build_all_download_packages()

logger.info(f"📦 Product Download System loaded: {len(DOWNLOAD_PACKAGES)} packages")
logger.info(f"🕸️ Every product includes Fungi Mesh node installer")
logger.info(f"💻 Hardware targets: {len(HardwareTarget)} platforms supported")
