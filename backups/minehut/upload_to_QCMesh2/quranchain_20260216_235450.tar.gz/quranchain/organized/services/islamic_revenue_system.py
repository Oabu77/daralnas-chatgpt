#!/usr/bin/env python3
"""
Complete Islamic Coin Integration - Revenue Collection System
Integrates all components: Crypto pairing, fiat exchange, smart contracts, CRM
© QuranChain™ | Omar Mohammad Abunadi™
"""

from crypto_to_islamic_pairing import CryptoToIslamicPairing
from islamic_domestic_coins import ISLAMIC_COINS
import json
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('IslamicRevenue')


class IslamicCoinRevenueSystem:
    """
    Complete revenue system using Islamic domestic coins
    NO USD CONVERSION - All pairing to Islamic coins
    """
    
    def __init__(self):
        self.pairing_system = CryptoToIslamicPairing()
        self.total_revenue_by_coin = {coin: 0 for coin in ISLAMIC_COINS.keys()}
        self.founder_revenue_by_coin = {coin: 0 for coin in ISLAMIC_COINS.keys()}
        self.transactions = []
        
        logger.info("☪️  Islamic Coin Revenue System initialized")
        logger.info("   NO USD - Only Islamic domestic coins")
    
    def process_crypto_payment(
        self,
        crypto: str,
        amount: float,
        customer_id: str,
        invoice_id: str = None,
        target_coin: str = "QURAN"
    ):
        """
        Process cryptocurrency payment
        
        Args:
            crypto: Cryptocurrency received (BTC, ETH, etc.)
            amount: Amount received
            customer_id: Customer identifier
            invoice_id: Optional invoice ID
            target_coin: Islamic coin to pair to
        """
        
        # Pair to Islamic coin
        result = self.pairing_system.receive_crypto_payment(
            crypto, amount, target_coin
        )
        
        # Track revenue
        self.total_revenue_by_coin[target_coin] += result['total_islamic_amount']
        self.founder_revenue_by_coin[target_coin] += result['founder_royalty']
        
        # Record transaction
        transaction = {
            **result,
            'customer_id': customer_id,
            'invoice_id': invoice_id,
            'transaction_type': 'crypto_payment',
            'processed_at': datetime.utcnow().isoformat()
        }
        
        self.transactions.append(transaction)
        
        # Log to CRM if available
        try:
            from crm.crm_database import CRMDatabase
            crm = CRMDatabase()
            
            crm.add_revenue_event({
                'source': f'crypto_{crypto}',
                'amount_usd': result.get('usd_value_reference', 0),
                'islamic_coin': target_coin,
                'islamic_amount': result['total_islamic_amount'],
                'founder_share_usd': result.get('usd_value_reference', 0) * 0.30,
                'founder_share_islamic': result['founder_royalty'],
                'customer_id': customer_id
            })
            
            logger.info("✅ Revenue logged to CRM")
        except Exception as e:
            logger.warning(f"CRM logging failed: {e}")
        
        return transaction
    
    def process_fiat_payment(
        self,
        amount_usd: float,
        customer_id: str,
        invoice_id: str = None,
        target_coin: str = "QURAN"
    ):
        """
        Process fiat payment (USD, EUR, etc.)
        
        Args:
            amount_usd: Amount in USD
            customer_id: Customer identifier
            invoice_id: Optional invoice ID
            target_coin: Islamic coin to purchase
        """
        
        # Exchange for Islamic coins
        result = self.pairing_system.receive_fiat_payment(
            amount_usd, target_coin, "USD"
        )
        
        # Track revenue
        coin = result['coin']
        self.total_revenue_by_coin[coin] += result['total_coins']
        self.founder_revenue_by_coin[coin] += result['founder_royalty']
        
        # Record transaction
        transaction = {
            **result,
            'customer_id': customer_id,
            'invoice_id': invoice_id,
            'transaction_type': 'fiat_payment',
            'processed_at': datetime.utcnow().isoformat()
        }
        
        self.transactions.append(transaction)
        
        # Log to CRM
        try:
            from crm.crm_database import CRMDatabase
            crm = CRMDatabase()
            
            crm.add_revenue_event({
                'source': 'fiat_usd',
                'amount_usd': amount_usd,
                'islamic_coin': coin,
                'islamic_amount': result['total_coins'],
                'founder_share_usd': amount_usd * 0.30,
                'founder_share_islamic': result['founder_royalty'],
                'customer_id': customer_id
            })
            
            logger.info("✅ Revenue logged to CRM")
        except Exception as e:
            logger.warning(f"CRM logging failed: {e}")
        
        return transaction
    
    def get_revenue_summary(self):
        """Get complete revenue summary across all Islamic coins"""
        
        total_transactions = len(self.transactions)
        crypto_transactions = [t for t in self.transactions if t['transaction_type'] == 'crypto_payment']
        fiat_transactions = [t for t in self.transactions if t['transaction_type'] == 'fiat_payment']
        
        # Calculate total USD value reference (for accounting)
        total_usd_reference = sum(
            t.get('usd_value_reference', 0) or t.get('fiat_amount', 0)
            for t in self.transactions
        )
        
        founder_usd_reference = total_usd_reference * 0.30
        
        return {
            'total_transactions': total_transactions,
            'crypto_payments': len(crypto_transactions),
            'fiat_payments': len(fiat_transactions),
            'total_usd_reference': total_usd_reference,
            'founder_usd_reference': founder_usd_reference,
            'total_revenue_by_coin': self.total_revenue_by_coin,
            'founder_revenue_by_coin': self.founder_revenue_by_coin,
            'coin_count': len([coin for coin, amount in self.total_revenue_by_coin.items() if amount > 0])
        }
    
    def display_revenue_dashboard(self):
        """Display complete revenue dashboard"""
        
        summary = self.get_revenue_summary()
        
        print("\n" + "="*80)
        print("☪️  ISLAMIC COIN REVENUE DASHBOARD")
        print("="*80 + "\n")
        
        print(f"📊 TRANSACTION SUMMARY:")
        print(f"   Total Transactions: {summary['total_transactions']}")
        print(f"   Crypto Payments: {summary['crypto_payments']}")
        print(f"   Fiat Payments: {summary['fiat_payments']}")
        print(f"   Active Coin Types: {summary['coin_count']}")
        
        print(f"\n💵 USD VALUE REFERENCE (for accounting):")
        print(f"   Total: ${summary['total_usd_reference']:,.2f}")
        print(f"   Founder (30%): ${summary['founder_usd_reference']:,.2f}")
        
        print(f"\n🪙 ISLAMIC COIN BALANCES:")
        for coin, amount in summary['total_revenue_by_coin'].items():
            if amount > 0:
                founder_amount = summary['founder_revenue_by_coin'][coin]
                coin_info = ISLAMIC_COINS[coin]
                
                print(f"\n   {coin} - {coin_info.name}")
                print(f"      Total Minted: {amount:,.0f} {coin}")
                print(f"      Founder Share: {founder_amount:,.0f} {coin} (30%)")
                print(f"      Public Share: {amount - founder_amount:,.0f} {coin} (70%)")
        
        print("\n" + "="*80)
        print("✅ NO USD CONVERSION - Pure Islamic Coin Economy")
        print("="*80 + "\n")


def demo_islamic_revenue_system():
    """Demonstrate the complete Islamic coin revenue system"""
    
    print("\n" + "="*80)
    print("🧪 TESTING ISLAMIC COIN REVENUE SYSTEM")
    print("="*80 + "\n")
    
    revenue = IslamicCoinRevenueSystem()
    
    # Scenario 1: Customer pays with 2 ETH for QURAN
    print("📝 Scenario 1: Customer pays 2 ETH → QURAN")
    revenue.process_crypto_payment(
        crypto="ETH",
        amount=2.0,
        customer_id="CUST-001",
        invoice_id="INV-001",
        target_coin="QURAN"
    )
    
    # Scenario 2: Customer pays with 0.1 BTC for DAN (real estate)
    print("\n📝 Scenario 2: Customer pays 0.1 BTC → DAN (real estate)")
    revenue.process_crypto_payment(
        crypto="BTC",
        amount=0.1,
        customer_id="CUST-002",
        invoice_id="INV-002",
        target_coin="DAN"
    )
    
    # Scenario 3: Customer pays $500 USD for HALAL
    print("\n📝 Scenario 3: Customer pays $500 USD → HALAL")
    revenue.process_fiat_payment(
        amount_usd=500,
        customer_id="CUST-003",
        invoice_id="INV-003",
        target_coin="HALAL"
    )
    
    # Scenario 4: Customer pays 50 SOL for UMRAH (Hajj booking)
    print("\n📝 Scenario 4: Customer pays 50 SOL → UMRAH (Hajj)")
    revenue.process_crypto_payment(
        crypto="SOL",
        amount=50,
        customer_id="CUST-004",
        invoice_id="INV-004",
        target_coin="UMRAH"
    )
    
    # Scenario 5: Customer pays $1000 USD for MASJID (mosque governance)
    print("\n📝 Scenario 5: Customer pays $1,000 USD → MASJID")
    revenue.process_fiat_payment(
        amount_usd=1000,
        customer_id="CUST-005",
        invoice_id="INV-005",
        target_coin="MASJID"
    )
    
    # Display dashboard
    revenue.display_revenue_dashboard()
    
    # Save to file
    with open('islamic_revenue_summary.json', 'w') as f:
        json.dump(revenue.get_revenue_summary(), f, indent=2)
    
    print("\n✅ Revenue summary saved to: islamic_revenue_summary.json")
    print("="*80 + "\n")


if __name__ == '__main__':
    demo_islamic_revenue_system()
