#!/usr/bin/env python3
"""
🤖 AI HR Guardian Agent
Protects and monitors the AI HR System service
Deployed on DarCloud Infrastructure - Port 9315
"""

import os
import sys
import time
import json
import requests
import logging
import threading
from datetime import datetime, timedelta
from pathlib import Path

# Add project root to path
sys.path.insert(0, '/home/omar/Desktop/QuranChain')

from blockchain_logging_handler import setup_blockchain_logging

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

GUARDIAN_CONFIG = {
    "service_name": "ai_hr_system",
    "service_port": 8115,
    "guardian_port": 9315,
    "health_check_interval": 30,  # seconds
    "auto_restart": True,
    "max_restart_attempts": 3,
    "log_file": "/home/omar/Desktop/QuranChain/logs/ai_workforce/ai_hr_guardian.log",
    "pid_file": "/home/omar/Desktop/QuranChain/logs/ai_workforce/ai_hr_guardian.pid"
}

# ═══════════════════════════════════════════════════════════════════════════════
# AI HR GUARDIAN AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class AIHRGuardianAgent:
    """
    Guardian agent for AI HR System protection and monitoring
    """

    def __init__(self):
        self.service_name = GUARDIAN_CONFIG["service_name"]
        self.service_port = GUARDIAN_CONFIG["service_port"]
        self.guardian_port = GUARDIAN_CONFIG["guardian_port"]
        self.health_check_interval = GUARDIAN_CONFIG["health_check_interval"]
        self.auto_restart = GUARDIAN_CONFIG["auto_restart"]
        self.max_restart_attempts = GUARDIAN_CONFIG["max_restart_attempts"]

        self.restart_attempts = 0
        self.last_health_check = None
        self.service_status = "unknown"
        self.monitoring_active = True

        # Start monitoring thread
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()

    def _monitoring_loop(self):
        """Main monitoring loop"""
        logger.info(f"🛡️  Starting AI HR Guardian monitoring on port {self.guardian_port}")

        while self.monitoring_active:
            try:
                self._perform_health_check()
                self._check_service_integrity()
                time.sleep(self.health_check_interval)
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                time.sleep(10)

    def _perform_health_check(self):
        """Check if AI HR service is healthy"""
        try:
            response = requests.get(
                f"https://ai-hr.quranchain.io/health",
                timeout=5
            )

            if response.status_code == 200:
                health_data = response.json()
                if health_data.get("status") == "healthy":
                    self.service_status = "healthy"
                    self.restart_attempts = 0  # Reset restart counter
                    self.last_health_check = datetime.now()

                    # Log workforce metrics
                    metrics = health_data.get("workforce_metrics", {})
                    logger.info(f"✅ AI HR System healthy - Agents: {metrics.get('total_agents', 0)}, "
                              f"Active: {metrics.get('active_agents', 0)}, "
                              f"Positions: {metrics.get('open_positions', 0)}")
                    return True
                else:
                    logger.warning("AI HR System returned unhealthy status")
            else:
                logger.warning(f"AI HR System health check failed with status {response.status_code}")

        except requests.exceptions.RequestException as e:
            logger.warning(f"AI HR System health check failed: {e}")

        self.service_status = "unhealthy"
        self._handle_service_failure()
        return False

    def _check_service_integrity(self):
        """Check service integrity and security"""
        try:
            # Check if service process is running
            import subprocess
            result = subprocess.run(
                ["pgrep", "-f", "ai_hr_system"],
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                logger.error("AI HR System process not found")
                self._handle_service_failure()
                return

            # Check port accessibility
            result = subprocess.run(
                ["netstat", "-tlnp"],
                capture_output=True,
                text=True
            )

            if f":{self.service_port} " not in result.stdout:
                logger.error(f"AI HR System port {self.service_port} not accessible")
                self._handle_service_failure()
                return

            # Check database integrity
            db_path = "/home/omar/Desktop/QuranChain/databases/ai_hr.db"
            if os.path.exists(db_path):
                if os.path.getsize(db_path) == 0:
                    logger.warning("AI HR database is empty")
            else:
                logger.warning("AI HR database not found")

        except Exception as e:
            logger.error(f"Integrity check error: {e}")

    def _handle_service_failure(self):
        """Handle service failure and attempt restart"""
        if not self.auto_restart:
            logger.error("Auto-restart disabled, manual intervention required")
            return

        if self.restart_attempts >= self.max_restart_attempts:
            logger.critical(f"Max restart attempts ({self.max_restart_attempts}) exceeded")
            self._send_alert("MAX_RESTARTS_EXCEEDED")
            return

        logger.warning(f"Attempting to restart AI HR System (attempt {self.restart_attempts + 1}/{self.max_restart_attempts})")

        try:
            # Use deployment script to restart
            import subprocess
            result = subprocess.run(
                ["/home/omar/Desktop/QuranChain/deploy_ai_hr_system.sh", "restart"],
                capture_output=True,
                text=True,
                cwd="/home/omar/Desktop/QuranChain"
            )

            if result.returncode == 0:
                self.restart_attempts += 1
                logger.info("AI HR System restart initiated successfully")
                self._send_alert("SERVICE_RESTARTED")
            else:
                logger.error(f"Failed to restart AI HR System: {result.stderr}")
                self._send_alert("RESTART_FAILED")

        except Exception as e:
            logger.error(f"Restart error: {e}")
            self._send_alert("RESTART_ERROR")

    def _send_alert(self, alert_type: str):
        """Send alert about service issues"""
        alert_data = {
            "alert_type": alert_type,
            "service": self.service_name,
            "timestamp": datetime.now().isoformat(),
            "guardian_port": self.guardian_port,
            "service_port": self.service_port,
            "restart_attempts": self.restart_attempts
        }

        logger.warning(f"🚨 ALERT: {alert_type} - {json.dumps(alert_data)}")

        # TODO: Integrate with central monitoring system
        # This could send alerts to QuranChain monitoring dashboard

    def get_status(self) -> dict:
        """Get guardian status"""
        return {
            "guardian_name": "AI HR Guardian",
            "service_name": self.service_name,
            "service_port": self.service_port,
            "guardian_port": self.guardian_port,
            "service_status": self.service_status,
            "last_health_check": self.last_health_check.isoformat() if self.last_health_check else None,
            "restart_attempts": self.restart_attempts,
            "monitoring_active": self.monitoring_active,
            "auto_restart": self.auto_restart
        }

# ═══════════════════════════════════════════════════════════════════════════════
# FASTAPI APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware

# Setup logging
logger = setup_blockchain_logging("ai_hr_guardian", logging.INFO)

# Initialize guardian
guardian = AIHRGuardianAgent()

# Create FastAPI app
app = FastAPI(
    title="AI HR Guardian Agent",
    description="Protection and monitoring for AI HR System",
    version="1.0.0"
)

# Add middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Guardian Agent Homepage"""
    status = guardian.get_status()
    return HTMLResponse(f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>🛡️ AI HR Guardian - QuranChain</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .container {{ max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            h1 {{ color: #2c3e50; text-align: center; }}
            .status {{ background: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }}
            .healthy {{ background: #d4edda; color: #155724; }}
            .unhealthy {{ background: #f8d7da; color: #721c24; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🛡️ AI HR Guardian Agent</h1>
            <p><strong>QuranChain Service Protection</strong></p>

            <div class="status {'healthy' if status['service_status'] == 'healthy' else 'unhealthy'}">
                <strong>Service Status:</strong> {status['service_status'].upper()}
            </div>
            <div class="status">
                <strong>Protected Service:</strong> {status['service_name']} (Port {status['service_port']})
            </div>
            <div class="status">
                <strong>Last Health Check:</strong> {status['last_health_check'] or 'Never'}
            </div>
            <div class="status">
                <strong>Restart Attempts:</strong> {status['restart_attempts']}
            </div>

            <p><em>Guardian Port: {status['guardian_port']} | Status: 🛡️ Active</em></p>
        </div>
    </body>
    </html>
    """)

@app.get("/health")
async def health_check():
    """Guardian health check"""
    return {
        "status": "healthy",
        "service": "AI HR Guardian",
        "port": GUARDIAN_CONFIG["guardian_port"],
        "timestamp": datetime.now().isoformat(),
        "protected_service": guardian.get_status()
    }

@app.get("/status")
async def get_status():
    """Get guardian status"""
    return guardian.get_status()

@app.post("/restart-service")
async def restart_service():
    """Manually restart the protected service"""
    try:
        import subprocess
        result = subprocess.run(
            ["/home/omar/Desktop/QuranChain/deploy_ai_hr_system.sh", "restart"],
            capture_output=True,
            text=True,
            cwd="/home/omar/Desktop/QuranChain"
        )

        if result.returncode == 0:
            return {"status": "restarted", "message": "AI HR System restart initiated"}
        else:
            raise HTTPException(status_code=500, detail=f"Restart failed: {result.stderr}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn

    logger.info("🚀 Starting AI HR Guardian Agent")
    logger.info(f"🛡️  Protecting AI HR System on port {GUARDIAN_CONFIG['service_port']}")
    logger.info(f"📍 Guardian Port: {GUARDIAN_CONFIG['guardian_port']}")

    # Save PID file
    with open(GUARDIAN_CONFIG["pid_file"], 'w') as f:
        f.write(str(os.getpid()))

    uvicorn.run(
        "ai_hr_guardian_agent:app",
        host="0.0.0.0",
        port=GUARDIAN_CONFIG["guardian_port"],
        log_level="info",
        reload=False
    )