#!/usr/bin/env python3
"""
☁️ DARCLOUD - COMPLETE CLOUD PLATFORM
═══════════════════════════════════════════════════════════════
Decentralized Cloud Computing & Storage Platform
Like AWS + iCloud + Google Drive, but Islamic & Decentralized

Services:
  🌐 Web Hosting - Deploy websites across mesh networks
  🖥️ Cloud Computing - Virtual machines, serverless functions
  💾 Personal Storage - File storage, backup, sync across devices
  📊 Big Data - Distributed data processing & analytics
  🔒 Security - End-to-end encryption, Islamic compliance

© QuranChain™ | Omar Mohammad Abunadi™
═══════════════════════════════════════════════════════════════
"""

import os
import sys
import json
import time
import threading
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

# Add project root to path
sys.path.insert(0, "/home/omar/Desktop/QuranChain")

# Import QuranChain integration
try:
    from organized.ai_agents.quranchain_quantum_blockchain import ServiceIntegrationHub, QuantumBlockchain
    QURANCHAIN_INTEGRATION = True
except ImportError:
    QURANCHAIN_INTEGRATION = False
    ServiceIntegrationHub = None
    QuantumBlockchain = None

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] 🌐 WEBHOST - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="DarCloud - Complete Cloud Platform", version="2.0.0")

# Service directories
WEBSITES_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_websites")
CLOUD_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_cloud")
STORAGE_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_storage")

# Create directories
WEBSITES_DIR.mkdir(exist_ok=True)
CLOUD_DIR.mkdir(exist_ok=True)
STORAGE_DIR.mkdir(exist_ok=True)

# Domain registry
DOMAIN_REGISTRY = {}

class WebHostingEngine:
    """Manages website deployments across mesh networks"""

    def __init__(self):
        self.deployed_sites = {}
        self.load_website_registry()
        
        # QuranChain Integration
        self.quranchain_integration = None
        self.revenue_collected = 0.0
        self.founder_revenue = 0.0
        self.setup_quranchain_integration()
        
        logger.info("🌐 Web Hosting Engine initialized")
        if self.quranchain_integration:
            logger.info("✅ DarCloud integrated with QuranChain Network")

    def setup_quranchain_integration(self):
        """Setup integration with QuranChain Network"""
        if not QURANCHAIN_INTEGRATION:
            logger.warning("⚠️ QuranChain integration not available")
            return
            
        try:
            # Initialize QuranChain blockchain
            self.blockchain = QuantumBlockchain()
            self.quranchain_integration = ServiceIntegrationHub(self.blockchain)
            logger.info("✅ DarCloud connected to QuranChain Quantum Blockchain Hub")
            
            # Start revenue reporting thread
            revenue_thread = threading.Thread(target=self.report_revenue_loop, daemon=True)
            revenue_thread.start()
            
        except Exception as e:
            logger.error(f"❌ Failed to integrate with QuranChain: {e}")
            self.quranchain_integration = None

    def report_revenue_loop(self):
        """Continuously report revenue to QuranChain network"""
        while True:
            try:
                if self.quranchain_integration:
                    self.report_revenue_to_quranchain()
                time.sleep(300)  # Report every 5 minutes
            except Exception as e:
                logger.error(f"Revenue reporting error: {e}")
                time.sleep(60)  # Retry in 1 minute on error

    def report_revenue_to_quranchain(self):
        """Report hosting revenue to QuranChain network"""
        if not self.quranchain_integration:
            return
            
        # Calculate revenue from all services
        websites_revenue = len(self.deployed_sites) * 10.0  # $10/month per website
        
        # Safely get cloud computing revenue
        vm_revenue = 0.0
        try:
            if 'cloud_computing_engine' in globals():
                vm_revenue = sum(vm.get("cost_per_hour", 0) * 24 * 30 for vm in cloud_computing_engine.virtual_machines.values())  # Monthly cost
        except:
            pass
            
        # Safely get storage revenue
        storage_revenue = 0.0
        try:
            if 'personal_storage_engine' in globals():
                storage_revenue = len(personal_storage_engine.user_accounts) * 5.0  # $5/month per user
        except:
            pass
        
        total_revenue = websites_revenue + vm_revenue + storage_revenue
        founder_share = total_revenue * 0.30  # 30% founder royalty
        
        revenue_data = {
            "service": "darcloud_complete_platform",
            "revenue_breakdown": {
                "web_hosting": websites_revenue,
                "cloud_computing": vm_revenue,
                "personal_storage": storage_revenue
            },
            "total_revenue_usd": total_revenue,
            "founder_revenue_usd": founder_share,
            "websites_hosted": len(self.deployed_sites),
            "virtual_machines": len(cloud_computing_engine.virtual_machines) if 'cloud_computing_engine' in globals() else 0,
            "storage_users": len(personal_storage_engine.user_accounts) if 'personal_storage_engine' in globals() else 0,
            "mesh_nodes": 88,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
        
        # Log revenue to QuranChain
        try:
            # This would integrate with the revenue aggregator in the future
            logger.info(f"💰 DarCloud Revenue: ${total_revenue:.2f} (Web: ${websites_revenue:.2f}, Cloud: ${vm_revenue:.2f}, Storage: ${storage_revenue:.2f}) - Founder: ${founder_share:.2f}")
        except Exception as e:
            logger.error(f"Failed to report revenue: {e}")

    def get_quranchain_status(self) -> Dict:
        """Get QuranChain integration status"""
        if not self.quranchain_integration:
            return {"integrated": False, "status": "not_connected"}
            
        try:
            # Check integration hub health
            health = self.quranchain_integration.check_service_health(
                "darcloud_web_hosting", "localhost", 8080
            )
            return {
                "integrated": True,
                "status": health.get("status", "unknown"),
                "revenue_reported": self.revenue_collected,
                "founder_revenue": self.founder_revenue
            }
        except Exception as e:
            return {"integrated": True, "status": "error", "error": str(e)}

    def load_website_registry(self):
        """Load deployed websites from registry"""
        registry_file = WEBSITES_DIR / "registry.json"
        if registry_file.exists():
            try:
                with open(registry_file, 'r') as f:
                    self.deployed_sites = json.load(f)
                logger.info(f"📋 Loaded {len(self.deployed_sites)} websites from registry")
            except Exception as e:
                logger.error(f"Failed to load registry: {e}")

    def save_website_registry(self):
        """Save deployed websites to registry"""
        registry_file = WEBSITES_DIR / "registry.json"
        try:
            with open(registry_file, 'w') as f:
                json.dump(self.deployed_sites, f, indent=2)
            logger.info("💾 Website registry saved")
        except Exception as e:
            logger.error(f"Failed to save registry: {e}")

    def deploy_website(self, domain: str, files: Dict[str, bytes], owner: str = "Omar Mohammad Abunadi™") -> Dict:
        """Deploy website across mesh network"""

        # Create website directory
        site_dir = WEBSITES_DIR / domain
        site_dir.mkdir(exist_ok=True)

        # Save files
        deployed_files = []
        for filename, content in files.items():
            file_path = site_dir / filename
            file_path.parent.mkdir(parents=True, exist_ok=True)

            with open(file_path, 'wb') as f:
                f.write(content)

            deployed_files.append(filename)
            logger.info(f"📄 Deployed {filename} for {domain}")

        # Register website
        site_info = {
            "domain": domain,
            "owner": owner,
            "deployed_at": datetime.utcnow().isoformat() + "Z",
            "files": deployed_files,
            "mesh_nodes": self.get_mesh_distribution(),
            "cdn_enabled": True,
            "ssl_enabled": True,
            "status": "active"
        }

        self.deployed_sites[domain] = site_info
        self.save_website_registry()

        # Distribute across mesh network
        self.distribute_to_mesh(domain, site_info)

        logger.info(f"✅ Website {domain} deployed across mesh network")
        return site_info

    def get_mesh_distribution(self) -> List[Dict]:
        """Get mesh network distribution for website"""
        # Distribute across all 88 validator nodes
        nodes = []

        # Fungi Mesh nodes (35)
        for i in range(1, 36):
            nodes.append({
                "node_id": f"fungi-{i:03d}",
                "network": "Fungi Mesh",
                "region": self.get_region_for_node(i),
                "status": "active"
            })

        # MeshTalk OS nodes (43)
        for i in range(1, 44):
            nodes.append({
                "node_id": f"meshtalk-{i:03d}",
                "network": "MeshTalk OS",
                "region": self.get_region_for_node(i + 35),
                "status": "active"
            })

        return nodes

    def get_region_for_node(self, node_num: int) -> str:
        """Get region for node number"""
        regions = ["Americas", "Europe", "Asia", "Africa", "Oceania", "Middle East"]
        return regions[node_num % len(regions)]

    def distribute_to_mesh(self, domain: str, site_info: Dict):
        """Distribute website across mesh network"""
        # In a real implementation, this would sync files to all mesh nodes
        # For now, we'll simulate the distribution
        logger.info(f"🌐 Distributing {domain} to {len(site_info['mesh_nodes'])} mesh nodes")

        # Simulate distribution delay
        time.sleep(0.1)

        logger.info(f"✅ {domain} distributed across mesh network")

    def get_website_info(self, domain: str) -> Optional[Dict]:
        """Get website information"""
        return self.deployed_sites.get(domain)

    def list_websites(self) -> List[Dict]:
        """List all deployed websites"""
        return list(self.deployed_sites.values())

    def delete_website(self, domain: str) -> bool:
        """Delete website from mesh network"""
        if domain in self.deployed_sites:
            # Remove from registry
            del self.deployed_sites[domain]
            self.save_website_registry()

            # Remove files
            site_dir = WEBSITES_DIR / domain
            if site_dir.exists():
                import shutil
                shutil.rmtree(site_dir)

            logger.info(f"🗑️ Website {domain} deleted from mesh network")
            return True

        return False

class CloudComputingEngine:
    """AWS-like cloud computing services"""

    def __init__(self):
        self.virtual_machines = {}
        self.serverless_functions = {}
        self.containers = {}
        self.load_cloud_resources()
        logger.info("🖥️ Cloud Computing Engine initialized")

    def load_cloud_resources(self):
        """Load cloud resources from registry"""
        vm_file = CLOUD_DIR / "virtual_machines.json"
        if vm_file.exists():
            try:
                with open(vm_file, 'r') as f:
                    self.virtual_machines = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load VMs: {e}")

        functions_file = CLOUD_DIR / "functions.json"
        if functions_file.exists():
            try:
                with open(functions_file, 'r') as f:
                    self.serverless_functions = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load functions: {e}")

    def create_virtual_machine(self, name: str, specs: Dict, owner: str = "Omar Mohammad Abunadi™") -> Dict:
        """Create a virtual machine (like EC2)"""
        vm_id = f"vm-{name}-{int(time.time())}"

        vm_config = {
            "vm_id": vm_id,
            "name": name,
            "owner": owner,
            "specs": specs,
            "status": "running",
            "created_at": datetime.utcnow().isoformat() + "Z",
            "mesh_nodes": self.get_mesh_distribution(),
            "cost_per_hour": self.calculate_vm_cost(specs)
        }

        self.virtual_machines[vm_id] = vm_config
        self.save_cloud_resources()
        logger.info(f"🖥️ VM {name} created with ID {vm_id}")
        return vm_config

    def deploy_serverless_function(self, name: str, code: str, runtime: str, owner: str = "Omar Mohammad Abunadi™") -> Dict:
        """Deploy serverless function (like Lambda)"""
        function_id = f"func-{name}-{int(time.time())}"

        function_config = {
            "function_id": function_id,
            "name": name,
            "owner": owner,
            "runtime": runtime,
            "code": code,
            "status": "deployed",
            "created_at": datetime.utcnow().isoformat() + "Z",
            "mesh_nodes": self.get_mesh_distribution(),
            "invocations": 0
        }

        self.serverless_functions[function_id] = function_config
        self.save_cloud_resources()
        logger.info(f"⚡ Serverless function {name} deployed with ID {function_id}")
        return function_config

    def calculate_vm_cost(self, specs: Dict) -> float:
        """Calculate VM cost per hour"""
        base_cost = 0.10  # Base cost per hour
        cpu_multiplier = specs.get("cpu_cores", 1) * 0.05
        ram_multiplier = specs.get("ram_gb", 1) * 0.02
        storage_multiplier = specs.get("storage_gb", 10) * 0.01
        return round(base_cost + cpu_multiplier + ram_multiplier + storage_multiplier, 3)

    def get_mesh_distribution(self) -> List[Dict]:
        """Get mesh distribution for cloud resources"""
        return web_hosting_engine.get_mesh_distribution()

    def save_cloud_resources(self):
        """Save cloud resources to disk"""
        try:
            with open(CLOUD_DIR / "virtual_machines.json", 'w') as f:
                json.dump(self.virtual_machines, f, indent=2)
            with open(CLOUD_DIR / "functions.json", 'w') as f:
                json.dump(self.serverless_functions, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save cloud resources: {e}")

class PersonalStorageEngine:
    """iCloud/Google Drive-like personal storage"""

    def __init__(self):
        self.user_accounts = {}
        self.file_metadata = {}
        self.load_storage_data()
        logger.info("💾 Personal Storage Engine initialized")

    def load_storage_data(self):
        """Load storage data from registry"""
        accounts_file = STORAGE_DIR / "user_accounts.json"
        if accounts_file.exists():
            try:
                with open(accounts_file, 'r') as f:
                    self.user_accounts = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load user accounts: {e}")

        metadata_file = STORAGE_DIR / "file_metadata.json"
        if metadata_file.exists():
            try:
                with open(metadata_file, 'r') as f:
                    self.file_metadata = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load file metadata: {e}")

    def create_user_account(self, user_id: str, email: str, plan: str = "free") -> Dict:
        """Create user storage account"""
        account = {
            "user_id": user_id,
            "email": email,
            "plan": plan,
            "storage_used_gb": 0.0,
            "storage_limit_gb": self.get_plan_limit(plan),
            "files_count": 0,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "status": "active"
        }

        self.user_accounts[user_id] = account
        self.save_storage_data()
        logger.info(f"👤 Created storage account for {email} ({plan} plan)")
        return account

    def upload_file(self, user_id: str, filename: str, file_data: bytes, folder: str = "/") -> Dict:
        """Upload file to user's storage"""
        if user_id not in self.user_accounts:
            raise HTTPException(status_code=404, detail="User account not found")

        account = self.user_accounts[user_id]

        # Check storage limit
        file_size_gb = len(file_data) / (1024**3)
        if account["storage_used_gb"] + file_size_gb > account["storage_limit_gb"]:
            raise HTTPException(status_code=413, detail="Storage limit exceeded")

        # Save file
        user_dir = STORAGE_DIR / user_id / folder.strip("/")
        user_dir.mkdir(parents=True, exist_ok=True)

        file_path = user_dir / filename
        with open(file_path, 'wb') as f:
            f.write(file_data)

        # Update metadata
        file_id = f"{user_id}_{filename}_{int(time.time())}"
        file_meta = {
            "file_id": file_id,
            "user_id": user_id,
            "filename": filename,
            "folder": folder,
            "size_bytes": len(file_data),
            "uploaded_at": datetime.utcnow().isoformat() + "Z",
            "mesh_replicas": len(self.get_mesh_distribution())
        }

        self.file_metadata[file_id] = file_meta

        # Update account stats
        account["storage_used_gb"] += file_size_gb
        account["files_count"] += 1
        self.save_storage_data()

        # Replicate across mesh
        self.replicate_file_across_mesh(file_path, file_meta)

        logger.info(f"📁 File {filename} uploaded for user {user_id}")
        return file_meta

    def get_plan_limit(self, plan: str) -> float:
        """Get storage limit for plan"""
        limits = {
            "free": 5.0,      # 5GB
            "basic": 50.0,    # 50GB
            "premium": 500.0, # 500GB
            "enterprise": 5000.0  # 5TB
        }
        return limits.get(plan, 5.0)

    def get_mesh_distribution(self) -> List[Dict]:
        """Get mesh distribution for storage"""
        return web_hosting_engine.get_mesh_distribution()

    def replicate_file_across_mesh(self, file_path: Path, metadata: Dict):
        """Replicate file across mesh network"""
        # Simulate mesh replication
        logger.info(f"🌐 Replicating {metadata['filename']} across {metadata['mesh_replicas']} mesh nodes")

    def save_storage_data(self):
        """Save storage data to disk"""
        try:
            with open(STORAGE_DIR / "user_accounts.json", 'w') as f:
                json.dump(self.user_accounts, f, indent=2)
            with open(STORAGE_DIR / "file_metadata.json", 'w') as f:
                json.dump(self.file_metadata, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save storage data: {e}")

# Global service engines
web_hosting_engine = WebHostingEngine()
cloud_computing_engine = CloudComputingEngine()
personal_storage_engine = PersonalStorageEngine()

# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.get("/")
def root():
    """DarCloud Complete Cloud Platform Dashboard"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>☁️ DarCloud - Complete Cloud Platform</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }}
            .services {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 20px 0; }}
            .service-card {{ background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            .service-header {{ display: flex; align-items: center; margin-bottom: 15px; }}
            .service-icon {{ font-size: 2em; margin-right: 10px; }}
            .service-stats {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }}
            .stat-item {{ text-align: center; padding: 10px; background: #f8f9fa; border-radius: 5px; }}
            .stat-number {{ font-size: 1.5em; font-weight: bold; color: #667eea; }}
            .section {{ margin-top: 30px; }}
            .item-card {{ background: white; margin: 10px 0; padding: 15px; border-radius: 8px; box-shadow: 0 1px 5px rgba(0,0,0,0.1); }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>☁️ DarCloud - Complete Cloud Platform</h1>
            <p>AWS + iCloud + Google Drive, but Islamic & Decentralized</p>
            <p><strong>Founder:</strong> Omar Mohammad Abunadi™ | <strong>QuranChain Integrated:</strong> ✅</p>
        </div>

        <div class="services">
            <!-- Web Hosting Service -->
            <div class="service-card">
                <div class="service-header">
                    <span class="service-icon">🌐</span>
                    <h3>Web Hosting</h3>
                </div>
                <div class="service-stats">
                    <div class="stat-item">
                        <div class="stat-number">{len(web_hosting_engine.deployed_sites)}</div>
                        <div>Websites</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">88</div>
                        <div>CDN Nodes</div>
                    </div>
                </div>
            </div>

            <!-- Cloud Computing Service -->
            <div class="service-card">
                <div class="service-header">
                    <span class="service-icon">🖥️</span>
                    <h3>Cloud Computing</h3>
                </div>
                <div class="service-stats">
                    <div class="stat-item">
                        <div class="stat-number">{len(cloud_computing_engine.virtual_machines)}</div>
                        <div>VMs</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">{len(cloud_computing_engine.serverless_functions)}</div>
                        <div>Functions</div>
                    </div>
                </div>
            </div>

            <!-- Personal Storage Service -->
            <div class="service-card">
                <div class="service-header">
                    <span class="service-icon">💾</span>
                    <h3>Personal Storage</h3>
                </div>
                <div class="service-stats">
                    <div class="stat-item">
                        <div class="stat-number">{len(personal_storage_engine.user_accounts)}</div>
                        <div>Users</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">{len(personal_storage_engine.file_metadata)}</div>
                        <div>Files</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Websites Section -->
        <div class="section">
            <h2>🌐 Hosted Websites</h2>
"""

    for site in web_hosting_engine.list_websites():
        html_content += f"""
            <div class="item-card">
                <h3>{site['domain']}</h3>
                <p><strong>Owner:</strong> {site['owner']} | <strong>Status:</strong> {site['status']}</p>
                <p><strong>Files:</strong> {len(site['files'])} | <strong>CDN:</strong> {site['cdn_enabled']} | <strong>SSL:</strong> {site['ssl_enabled']}</p>
            </div>
"""

    # Virtual Machines Section
    html_content += f"""
        </div>

        <div class="section">
            <h2>🖥️ Virtual Machines</h2>
"""

    for vm in cloud_computing_engine.virtual_machines.values():
        html_content += f"""
            <div class="item-card">
                <h3>{vm['name']}</h3>
                <p><strong>ID:</strong> {vm['vm_id']} | <strong>Status:</strong> {vm['status']}</p>
                <p><strong>Specs:</strong> {vm['specs']['cpu_cores']} CPU, {vm['specs']['ram_gb']}GB RAM, {vm['specs']['storage_gb']}GB Storage</p>
                <p><strong>Cost:</strong> ${vm['cost_per_hour']}/hour</p>
            </div>
"""

    # Storage Accounts Section
    html_content += f"""
        </div>

        <div class="section">
            <h2>💾 Storage Accounts</h2>
"""

    for account in personal_storage_engine.user_accounts.values():
        html_content += f"""
            <div class="item-card">
                <h3>{account['email']}</h3>
                <p><strong>User ID:</strong> {account['user_id']} | <strong>Plan:</strong> {account['plan']}</p>
                <p><strong>Storage:</strong> {account['storage_used_gb']:.2f}GB / {account['storage_limit_gb']:.0f}GB | <strong>Files:</strong> {account['files_count']}</p>
            </div>
"""

    html_content += """
        </div>
    </body>
    </html>
    """

    return HTMLResponse(content=html_content)

@app.post("/deploy")
async def deploy_website(
    domain: str = Form(...),
    owner: str = Form("Omar Mohammad Abunadi™"),
    files: List[UploadFile] = File(...)
):
    """Deploy website to mesh network"""
    try:
        file_data = {}
        for file in files:
            content = await file.read()
            file_data[file.filename] = content

        result = web_hosting_engine.deploy_website(domain, file_data, owner)

        return JSONResponse({
            "status": "success",
            "message": f"Website {domain} deployed successfully",
            "data": result
        })

    except Exception as e:
        logger.error(f"Deployment failed: {e}")
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")

@app.get("/site/{domain}")
def serve_website(domain: str):
    """Serve website from mesh network"""
    site_info = web_hosting_engine.get_website_info(domain)
    if not site_info:
        raise HTTPException(status_code=404, detail="Website not found")

    site_dir = WEBSITES_DIR / domain

    # Try to serve index.html first
    index_file = site_dir / "index.html"
    if index_file.exists():
        return FileResponse(index_file, media_type="text/html")

    # Try index.htm
    index_file = site_dir / "index.htm"
    if index_file.exists():
        return FileResponse(index_file, media_type="text/html")

    # Try to serve the first HTML file found
    for file_path in site_dir.glob("*.html"):
        return FileResponse(file_path, media_type="text/html")

    # Try to serve the first HTM file found
    for file_path in site_dir.glob("*.htm"):
        return FileResponse(file_path, media_type="text/html")

    raise HTTPException(status_code=404, detail="Index file not found")

@app.get("/api/websites")
def list_websites():
    """List all hosted websites"""
    return JSONResponse({
        "websites": web_hosting_engine.list_websites(),
        "total": len(web_hosting_engine.deployed_sites)
    })

@app.get("/api/website/{domain}")
def get_website_info(domain: str):
    """Get website information"""
    site_info = web_hosting_engine.get_website_info(domain)
    if not site_info:
        raise HTTPException(status_code=404, detail="Website not found")

    return JSONResponse(site_info)

@app.delete("/api/website/{domain}")
def delete_website(domain: str):
    """Delete website from mesh network"""
    if web_hosting_engine.delete_website(domain):
        return JSONResponse({"status": "success", "message": f"Website {domain} deleted"})
    else:
        raise HTTPException(status_code=404, detail="Website not found")

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "DarCloud Complete Cloud Platform",
        "services": {
            "web_hosting": {
                "websites_hosted": len(web_hosting_engine.deployed_sites),
                "status": "active"
            },
            "cloud_computing": {
                "virtual_machines": len(cloud_computing_engine.virtual_machines),
                "serverless_functions": len(cloud_computing_engine.serverless_functions),
                "status": "active"
            },
            "personal_storage": {
                "user_accounts": len(personal_storage_engine.user_accounts),
                "total_files": len(personal_storage_engine.file_metadata),
                "status": "active"
            }
        },
        "mesh_nodes": 88,
        "quranchain_integrated": web_hosting_engine.quranchain_integration is not None,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

@app.get("/quranchain/status")
def quranchain_status():
    """QuranChain integration status"""
    return web_hosting_engine.get_quranchain_status()

# =============================================================================
# CLOUD COMPUTING ENDPOINTS (AWS-like)
# =============================================================================

@app.post("/api/cloud/vm/create")
def create_virtual_machine(name: str, cpu_cores: int = 1, ram_gb: int = 1, storage_gb: int = 10):
    """Create a virtual machine (like AWS EC2)"""
    specs = {
        "cpu_cores": cpu_cores,
        "ram_gb": ram_gb,
        "storage_gb": storage_gb
    }
    vm = cloud_computing_engine.create_virtual_machine(name, specs)
    return JSONResponse(vm)

@app.post("/api/cloud/function/deploy")
def deploy_serverless_function(name: str, code: str, runtime: str = "python3.9"):
    """Deploy serverless function (like AWS Lambda)"""
    function = cloud_computing_engine.deploy_serverless_function(name, code, runtime)
    return JSONResponse(function)

@app.get("/api/cloud/vms")
def list_virtual_machines():
    """List all virtual machines"""
    return JSONResponse(list(cloud_computing_engine.virtual_machines.values()))

@app.get("/api/cloud/functions")
def list_serverless_functions():
    """List all serverless functions"""
    return JSONResponse(list(cloud_computing_engine.serverless_functions.values()))

# =============================================================================
# PERSONAL STORAGE ENDPOINTS (iCloud/Google Drive-like)
# =============================================================================

@app.post("/api/storage/account/create")
def create_storage_account(user_id: str, email: str, plan: str = "free"):
    """Create personal storage account"""
    account = personal_storage_engine.create_user_account(user_id, email, plan)
    return JSONResponse(account)

@app.post("/api/storage/upload")
def upload_file(user_id: str, folder: str = "/", file: UploadFile = File(...)):
    """Upload file to personal storage"""
    file_data = file.file.read()
    file_meta = personal_storage_engine.upload_file(user_id, file.filename, file_data, folder)
    return JSONResponse(file_meta)

@app.get("/api/storage/accounts")
def list_storage_accounts():
    """List all storage accounts"""
    return JSONResponse(list(personal_storage_engine.user_accounts.values()))

@app.get("/api/storage/files/{user_id}")
def list_user_files(user_id: str):
    """List files for a user"""
    user_files = [f for f in personal_storage_engine.file_metadata.values() if f["user_id"] == user_id]
    return JSONResponse(user_files)

def main():
    """Start DarCloud Complete Cloud Platform"""
    logger.info("☁️ Starting DarCloud Complete Cloud Platform on port 8080")
    uvicorn.run(app, host="0.0.0.0", port=8080)

if __name__ == "__main__":
    main()