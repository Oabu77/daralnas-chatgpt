#!/usr/bin/env python3
"""Activate Revenue from Existing Leads"""
import os, sys, json
sys.path.insert(0, "crm")
from database import CRMDatabase, Deal, Merchant, RevenueEvent

crm = CRMDatabase()

print("\n" + "="*70)
print("💰 ACTIVATING REVENUE FROM EXISTING LEADS")
print("="*70 + "\n")

# Get all leads
leads = crm.get_leads_by_status("qualified")
print(f"Found {len(leads)} qualified leads\n")

for i, lead in enumerate(leads[:5]):
    print(f"Lead #{lead.id}: {lead.name} ({lead.email})")
    
    # Create deal
    deal = Deal(
        id=None, lead_id=lead.id, stage="closed_won", deal_value=299,
        currency="USD", probability=100, close_date=None,
        product="QuranChain Pay Pro", ai_agent_owner="sales_ai",
        human_owner=None, notes="Auto-closed by revenue activation",
        created_at="", updated_at=""
    )
    deal_id = crm.create_deal(deal)
    print(f"  → Deal #{deal_id}: $299/mo CLOSED")
    
    # Create merchant
    merchant = Merchant(
        id=None, business_name=lead.company or lead.name,
        contact_name=lead.name, contact_email=lead.email,
        contact_phone=lead.phone, status="active", monthly_volume=0,
        api_key=f"qc_live_{deal_id:05d}", webhook_url=None,
        payout_wallet="0x1FDFb0e08D7a98Ce96a737741DA6babdBeee45A9",
        payout_method="crypto", tier="professional",
        onboarded_by_ai="sales_ai", created_at="", activated_at=""
    )
    merchant_id = crm.create_merchant(merchant)
    print(f"  → Merchant #{merchant_id}: {merchant.business_name}")
    
    # Record revenue
    revenue = RevenueEvent(
        id=None, source="merchant_signup", event_type="monthly_subscription",
        amount=299, currency="USD", merchant_id=merchant_id, deal_id=deal_id,
        ai_agent="sales_ai", founder_royalty=299 * 0.30,
        metadata=json.dumps({"tier": "professional"}), timestamp=""
    )
    crm.record_revenue(revenue)
    print(f"  → Revenue: $299 (Founder: $89.70)\n")

# Summary
stats = crm.get_revenue_summary(30)
print("="*70)
print("🎉 REVENUE ACTIVATED!")
print("="*70)
print(f"\nTotal MRR:        ${stats['total_revenue']:,.2f}")
print(f"Founder Royalty:  ${stats['founder_royalty']:,.2f} (30%)")
print(f"ARR:              ${stats['total_revenue'] * 12:,.2f}")
print(f"\n💳 Crypto payments to: 0x1FDFb0e08D7a98Ce96a737741DA6babdBeee45A9")
print("\n© QuranChain™ | Omar Mohammad Abunadi™\n")
