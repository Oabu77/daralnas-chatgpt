#!/usr/bin/env python3
"""
OliveAir Airlines - Commercial Aviation Service
Port: 9310
Founder: Omar Mohammad Abunadi
30% Immutable Founder Royalty
"""

from flask import Flask, jsonify, request
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Dict
import hashlib
import json
import sqlite3
import os

app = Flask(__name__)

# IMMUTABLE FOUNDER ROYALTY
FOUNDER_ROYALTY_RATE = 0.30  # 30% - NEVER CHANGE THIS
FOUNDER_WALLET = "QRC-FOUNDER-OMAR-ABUNADI"

# Revenue Distribution
REVENUE_DISTRIBUTION = {
    "founder": 0.30,      # Omar Mohammad Abunadi - IMMUTABLE
    "ai_validators": 0.40,  # Omar AI™ & QuranChain AI™
    "hardware_hosts": 0.10,
    "ecosystem": 0.18,
    "zakat": 0.02
}

# Database
DB_PATH = "prod_databases/oliveair_airlines.db"

@dataclass
class Aircraft:
    """Aircraft in OliveAir fleet"""
    tail_number: str
    aircraft_type: str  # Boeing 737, A320, etc.
    capacity: int
    status: str  # active, maintenance, grounded
    home_base: str
    
@dataclass
class Flight:
    """Flight operation"""
    flight_id: str
    flight_number: str
    aircraft: str
    route: str
    origin: str
    destination: str
    departure_time: str
    arrival_time: str
    passengers: int
    fare_revenue: float
    blockchain_hash: str
    timestamp: str

@dataclass
class Route:
    """Flight route"""
    route_id: str
    origin: str
    destination: str
    distance_km: int
    flight_time_hours: float
    frequency: str  # daily, weekly, etc.

class OliveAirAirlines:
    """OliveAir Airlines Management System"""
    
    def __init__(self):
        self.init_database()
        self.init_fleet()
        self.init_routes()
        
    def init_database(self):
        """Initialize SQLite database"""
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Aircraft table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS aircraft (
                tail_number TEXT PRIMARY KEY,
                aircraft_type TEXT,
                capacity INTEGER,
                status TEXT,
                home_base TEXT,
                registration_date TEXT
            )
        """)
        
        # Flights table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS flights (
                flight_id TEXT PRIMARY KEY,
                flight_number TEXT,
                aircraft TEXT,
                route TEXT,
                origin TEXT,
                destination TEXT,
                departure_time TEXT,
                arrival_time TEXT,
                passengers INTEGER,
                fare_revenue REAL,
                founder_royalty REAL,
                blockchain_hash TEXT,
                timestamp TEXT
            )
        """)
        
        # Routes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS routes (
                route_id TEXT PRIMARY KEY,
                origin TEXT,
                destination TEXT,
                distance_km INTEGER,
                flight_time_hours REAL,
                frequency TEXT
            )
        """)
        
        conn.commit()
        conn.close()
        
    def init_fleet(self):
        """Initialize OliveAir aircraft fleet"""
        fleet = [
            Aircraft("OA-001", "Boeing 737-800", 189, "active", "Dubai International"),
            Aircraft("OA-002", "Airbus A320neo", 180, "active", "Riyadh King Khalid"),
            Aircraft("OA-003", "Boeing 787-9", 296, "active", "Jeddah King Abdulaziz"),
            Aircraft("OA-004", "Airbus A350-900", 325, "active", "Istanbul Airport"),
            Aircraft("OA-005", "Boeing 777-300ER", 396, "active", "Dubai International"),
        ]
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        for aircraft in fleet:
            cursor.execute("""
                INSERT OR IGNORE INTO aircraft 
                (tail_number, aircraft_type, capacity, status, home_base, registration_date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (aircraft.tail_number, aircraft.aircraft_type, aircraft.capacity,
                  aircraft.status, aircraft.home_base, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
    def init_routes(self):
        """Initialize flight routes"""
        routes = [
            Route("RT-001", "Dubai", "Riyadh", 872, 1.5, "daily"),
            Route("RT-002", "Dubai", "Jeddah", 1854, 2.5, "daily"),
            Route("RT-003", "Dubai", "Cairo", 2420, 3.5, "daily"),
            Route("RT-004", "Dubai", "Istanbul", 3340, 4.5, "daily"),
            Route("RT-005", "Riyadh", "Jeddah", 848, 1.5, "daily"),
            Route("RT-006", "Jeddah", "Cairo", 1388, 2.0, "daily"),
            Route("RT-007", "Dubai", "Karachi", 1209, 2.0, "daily"),
            Route("RT-008", "Dubai", "Lahore", 1936, 2.5, "weekly"),
            Route("RT-009", "Riyadh", "Istanbul", 2646, 3.5, "weekly"),
            Route("RT-010", "Dubai", "London", 5476, 7.0, "weekly"),
        ]
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        for route in routes:
            cursor.execute("""
                INSERT OR IGNORE INTO routes
                (route_id, origin, destination, distance_km, flight_time_hours, frequency)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (route.route_id, route.origin, route.destination,
                  route.distance_km, route.flight_time_hours, route.frequency))
        
        conn.commit()
        conn.close()
        
    def create_flight(self, flight_number: str, aircraft: str, route_id: str,
                     departure_time: str, passengers: int, fare_revenue: float) -> Flight:
        """Create new flight operation"""
        
        # Get route details
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM routes WHERE route_id = ?", (route_id,))
        route_data = cursor.fetchone()
        
        if not route_data:
            raise ValueError(f"Route {route_id} not found")
        
        # Calculate founder royalty
        founder_royalty = fare_revenue * FOUNDER_ROYALTY_RATE
        
        # Create flight ID and blockchain hash
        flight_id = f"FLT-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        blockchain_data = f"{flight_id}:{flight_number}:{aircraft}:{fare_revenue}:{founder_royalty}"
        blockchain_hash = hashlib.sha256(blockchain_data.encode()).hexdigest()
        
        flight = Flight(
            flight_id=flight_id,
            flight_number=flight_number,
            aircraft=aircraft,
            route=route_id,
            origin=route_data[1],
            destination=route_data[2],
            departure_time=departure_time,
            arrival_time="calculated",  # Would calculate based on route
            passengers=passengers,
            fare_revenue=fare_revenue,
            blockchain_hash=blockchain_hash,
            timestamp=datetime.now().isoformat()
        )
        
        # Store in database
        cursor.execute("""
            INSERT INTO flights
            (flight_id, flight_number, aircraft, route, origin, destination,
             departure_time, arrival_time, passengers, fare_revenue, founder_royalty,
             blockchain_hash, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (flight.flight_id, flight.flight_number, flight.aircraft, flight.route,
              flight.origin, flight.destination, flight.departure_time, flight.arrival_time,
              flight.passengers, flight.fare_revenue, founder_royalty,
              flight.blockchain_hash, flight.timestamp))
        
        conn.commit()
        conn.close()
        
        return flight
    
    def get_fleet_status(self) -> Dict:
        """Get current fleet status"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM aircraft")
        aircraft = cursor.fetchall()
        
        conn.close()
        
        return {
            "total_aircraft": len(aircraft),
            "active": len([a for a in aircraft if a[3] == "active"]),
            "fleet": [
                {
                    "tail_number": a[0],
                    "type": a[1],
                    "capacity": a[2],
                    "status": a[3],
                    "base": a[4]
                }
                for a in aircraft
            ]
        }
    
    def get_routes(self) -> List[Dict]:
        """Get all routes"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM routes")
        routes = cursor.fetchall()
        
        conn.close()
        
        return [
            {
                "route_id": r[0],
                "origin": r[1],
                "destination": r[2],
                "distance_km": r[3],
                "flight_time_hours": r[4],
                "frequency": r[5]
            }
            for r in routes
        ]

# Initialize service
airline = OliveAirAirlines()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "OliveAir Airlines",
        "port": 9310,
        "founder": "Omar Mohammad Abunadi",
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE * 100}%",
        "network_integrations": {
            "quranchain": "Connected",
            "fungi_mesh": "Connected",
            "meshtalk": "Connected",
            "darcloud": "Connected"
        }
    })

@app.route('/fleet', methods=['GET'])
def get_fleet():
    """Get fleet status"""
    return jsonify(airline.get_fleet_status())

@app.route('/routes', methods=['GET'])
def get_routes():
    """Get all routes"""
    return jsonify({
        "routes": airline.get_routes(),
        "total_routes": len(airline.get_routes())
    })

@app.route('/flight/create', methods=['POST'])
def create_flight():
    """Create new flight"""
    data = request.json
    
    try:
        flight = airline.create_flight(
            flight_number=data['flight_number'],
            aircraft=data['aircraft'],
            route_id=data['route_id'],
            departure_time=data['departure_time'],
            passengers=data['passengers'],
            fare_revenue=data['fare_revenue']
        )
        
        return jsonify({
            "success": True,
            "flight": asdict(flight),
            "founder_royalty": f"${flight.fare_revenue * FOUNDER_ROYALTY_RATE:.2f}",
            "blockchain_hash": flight.blockchain_hash
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/stats', methods=['GET'])
def get_stats():
    """Get airline statistics"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*), SUM(fare_revenue), SUM(passengers) FROM flights")
    stats = cursor.fetchone()
    
    total_flights = stats[0] or 0
    total_revenue = stats[1] or 0
    total_passengers = stats[2] or 0
    
    conn.close()
    
    return jsonify({
        "total_flights": total_flights,
        "total_revenue": f"${total_revenue:,.2f}",
        "total_passengers": total_passengers,
        "founder_royalty_collected": f"${total_revenue * FOUNDER_ROYALTY_RATE:,.2f}",
        "fleet_size": airline.get_fleet_status()["total_aircraft"],
        "active_routes": len(airline.get_routes())
    })

if __name__ == '__main__':
    print("="*80)
    print("✈️ OLIVEAIR AIRLINES - STARTING")
    print("="*80)
    print(f"Founder: Omar Mohammad Abunadi")
    print(f"Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print(f"Port: 9310")
    print(f"Fleet: {airline.get_fleet_status()['total_aircraft']} aircraft")
    print(f"Routes: {len(airline.get_routes())} active routes")
    print("="*80)
    
    app.run(host='0.0.0.0', port=9310, debug=False)
