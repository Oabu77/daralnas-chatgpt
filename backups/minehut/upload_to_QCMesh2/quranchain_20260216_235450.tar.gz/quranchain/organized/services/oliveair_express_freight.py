#!/usr/bin/env python3
"""
OliveAir Express Freight - Air Cargo & Express Delivery
Port: 9311
Founder: Omar Mohammad Abunadi
30% Immutable Founder Royalty
"""

from flask import Flask, jsonify, request
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Dict
import hashlib
import json
import sqlite3
import os

app = Flask(__name__)

# IMMUTABLE FOUNDER ROYALTY
FOUNDER_ROYALTY_RATE = 0.30  # 30% - NEVER CHANGE THIS
FOUNDER_WALLET = "QRC-FOUNDER-OMAR-ABUNADI"

# Revenue Distribution
REVENUE_DISTRIBUTION = {
    "founder": 0.30,      # Omar Mohammad Abunadi - IMMUTABLE
    "ai_validators": 0.40,  # Omar AI™ & QuranChain AI™
    "hardware_hosts": 0.10,
    "ecosystem": 0.18,
    "zakat": 0.02
}

# Database
DB_PATH = "prod_databases/oliveair_express.db"

@dataclass
class CargoShipment:
    """Air cargo shipment"""
    shipment_id: str
    tracking_number: str
    service_type: str  # express, standard, economy
    origin: str
    destination: str
    weight_kg: float
    dimensions: str
    value_usd: float
    shipping_fee: float
    status: str
    blockchain_hash: str
    timestamp: str

@dataclass
class FreightRoute:
    """Cargo route"""
    route_id: str
    origin: str
    destination: str
    service_type: str
    transit_time_hours: int
    rate_per_kg: float

class OliveAirExpress:
    """OliveAir Express Freight System"""
    
    def __init__(self):
        self.init_database()
        self.init_routes()
        
    def init_database(self):
        """Initialize SQLite database"""
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Shipments table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS shipments (
                shipment_id TEXT PRIMARY KEY,
                tracking_number TEXT UNIQUE,
                service_type TEXT,
                origin TEXT,
                destination TEXT,
                weight_kg REAL,
                dimensions TEXT,
                value_usd REAL,
                shipping_fee REAL,
                founder_royalty REAL,
                status TEXT,
                blockchain_hash TEXT,
                timestamp TEXT
            )
        """)
        
        # Routes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS routes (
                route_id TEXT PRIMARY KEY,
                origin TEXT,
                destination TEXT,
                service_type TEXT,
                transit_time_hours INTEGER,
                rate_per_kg REAL
            )
        """)
        
        conn.commit()
        conn.close()
        
    def init_routes(self):
        """Initialize freight routes"""
        routes = [
            # Express Routes (24-48 hours)
            FreightRoute("FR-EXP-001", "Dubai", "Riyadh", "express", 24, 8.50),
            FreightRoute("FR-EXP-002", "Dubai", "Jeddah", "express", 36, 9.00),
            FreightRoute("FR-EXP-003", "Dubai", "Cairo", "express", 48, 10.50),
            FreightRoute("FR-EXP-004", "Dubai", "Istanbul", "express", 48, 11.00),
            FreightRoute("FR-EXP-005", "Riyadh", "London", "express", 48, 15.00),
            
            # Standard Routes (3-5 days)
            FreightRoute("FR-STD-001", "Dubai", "Karachi", "standard", 72, 5.50),
            FreightRoute("FR-STD-002", "Dubai", "Mumbai", "standard", 96, 6.00),
            FreightRoute("FR-STD-003", "Riyadh", "Jakarta", "standard", 120, 7.50),
            
            # Economy Routes (5-7 days)
            FreightRoute("FR-ECO-001", "Dubai", "Singapore", "economy", 144, 3.50),
            FreightRoute("FR-ECO-002", "Jeddah", "Lagos", "economy", 168, 4.00),
        ]
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        for route in routes:
            cursor.execute("""
                INSERT OR IGNORE INTO routes
                (route_id, origin, destination, service_type, transit_time_hours, rate_per_kg)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (route.route_id, route.origin, route.destination,
                  route.service_type, route.transit_time_hours, route.rate_per_kg))
        
        conn.commit()
        conn.close()
        
    def create_shipment(self, origin: str, destination: str, weight_kg: float,
                       dimensions: str, value_usd: float, service_type: str) -> CargoShipment:
        """Create new cargo shipment"""
        
        # Find matching route
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM routes 
            WHERE origin = ? AND destination = ? AND service_type = ?
        """, (origin, destination, service_type))
        route_data = cursor.fetchone()
        
        if not route_data:
            raise ValueError(f"No {service_type} route from {origin} to {destination}")
        
        rate_per_kg = route_data[5]
        shipping_fee = weight_kg * rate_per_kg
        founder_royalty = shipping_fee * FOUNDER_ROYALTY_RATE
        
        # Generate tracking number and IDs
        shipment_id = f"OAEX-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        tracking_number = f"OA{datetime.now().strftime('%Y%m%d%H%M%S%f')[:16]}"
        
        blockchain_data = f"{shipment_id}:{tracking_number}:{weight_kg}:{shipping_fee}:{founder_royalty}"
        blockchain_hash = hashlib.sha256(blockchain_data.encode()).hexdigest()
        
        shipment = CargoShipment(
            shipment_id=shipment_id,
            tracking_number=tracking_number,
            service_type=service_type,
            origin=origin,
            destination=destination,
            weight_kg=weight_kg,
            dimensions=dimensions,
            value_usd=value_usd,
            shipping_fee=shipping_fee,
            status="booked",
            blockchain_hash=blockchain_hash,
            timestamp=datetime.now().isoformat()
        )
        
        # Store in database
        cursor.execute("""
            INSERT INTO shipments
            (shipment_id, tracking_number, service_type, origin, destination,
             weight_kg, dimensions, value_usd, shipping_fee, founder_royalty,
             status, blockchain_hash, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (shipment.shipment_id, shipment.tracking_number, shipment.service_type,
              shipment.origin, shipment.destination, shipment.weight_kg,
              shipment.dimensions, shipment.value_usd, shipment.shipping_fee,
              founder_royalty, shipment.status, shipment.blockchain_hash,
              shipment.timestamp))
        
        conn.commit()
        conn.close()
        
        return shipment
    
    def track_shipment(self, tracking_number: str) -> Dict:
        """Track shipment status"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM shipments WHERE tracking_number = ?", (tracking_number,))
        shipment = cursor.fetchone()
        
        conn.close()
        
        if not shipment:
            return {"error": "Shipment not found"}
        
        return {
            "tracking_number": shipment[1],
            "status": shipment[10],
            "origin": shipment[3],
            "destination": shipment[4],
            "weight_kg": shipment[5],
            "service_type": shipment[2],
            "blockchain_verified": True,
            "blockchain_hash": shipment[11]
        }
    
    def get_routes(self) -> List[Dict]:
        """Get all freight routes"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM routes")
        routes = cursor.fetchall()
        
        conn.close()
        
        return [
            {
                "route_id": r[0],
                "origin": r[1],
                "destination": r[2],
                "service_type": r[3],
                "transit_time_hours": r[4],
                "rate_per_kg": f"${r[5]:.2f}"
            }
            for r in routes
        ]

# Initialize service
express = OliveAirExpress()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "OliveAir Express Freight",
        "port": 9311,
        "founder": "Omar Mohammad Abunadi",
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE * 100}%",
        "network_integrations": {
            "quranchain": "Connected",
            "fungi_mesh": "Connected",
            "meshtalk": "Connected",
            "darcloud": "Connected",
            "oliveair_airlines": "Integrated"
        }
    })

@app.route('/routes', methods=['GET'])
def get_routes():
    """Get all freight routes"""
    return jsonify({
        "routes": express.get_routes(),
        "total_routes": len(express.get_routes())
    })

@app.route('/shipment/create', methods=['POST'])
def create_shipment():
    """Create new shipment"""
    data = request.json
    
    try:
        shipment = express.create_shipment(
            origin=data['origin'],
            destination=data['destination'],
            weight_kg=data['weight_kg'],
            dimensions=data['dimensions'],
            value_usd=data['value_usd'],
            service_type=data['service_type']
        )
        
        return jsonify({
            "success": True,
            "shipment": asdict(shipment),
            "tracking_number": shipment.tracking_number,
            "shipping_fee": f"${shipment.shipping_fee:.2f}",
            "founder_royalty": f"${shipment.shipping_fee * FOUNDER_ROYALTY_RATE:.2f}",
            "blockchain_hash": shipment.blockchain_hash
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/track/<tracking_number>', methods=['GET'])
def track_shipment(tracking_number):
    """Track shipment"""
    return jsonify(express.track_shipment(tracking_number))

@app.route('/stats', methods=['GET'])
def get_stats():
    """Get freight statistics"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*), SUM(shipping_fee), SUM(weight_kg) FROM shipments")
    stats = cursor.fetchone()
    
    total_shipments = stats[0] or 0
    total_revenue = stats[1] or 0
    total_weight = stats[2] or 0
    
    conn.close()
    
    return jsonify({
        "total_shipments": total_shipments,
        "total_revenue": f"${total_revenue:,.2f}",
        "total_weight_kg": f"{total_weight:,.2f}",
        "founder_royalty_collected": f"${total_revenue * FOUNDER_ROYALTY_RATE:,.2f}",
        "active_routes": len(express.get_routes())
    })

if __name__ == '__main__':
    print("="*80)
    print("📦 OLIVEAIR EXPRESS FREIGHT - STARTING")
    print("="*80)
    print(f"Founder: Omar Mohammad Abunadi")
    print(f"Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print(f"Port: 9311")
    print(f"Active Routes: {len(express.get_routes())}")
    print("="*80)
    
    app.run(host='0.0.0.0', port=9311, debug=False)
