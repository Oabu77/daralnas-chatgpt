#!/usr/bin/env python3
"""
🌐 QURANCHAIN™ GATEWAY PRIMARY API
Main gateway for all QuranChain services integration
Port: 8000
Founder: Omar Mohammad Abunadi™
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import logging
from datetime import datetime

PORT = 8000

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] GATEWAY: %(message)s')
logger = logging.getLogger(__name__)


class GatewayHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/health' or self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = {
                "service": "QuranChain Gateway Primary",
                "status": "healthy",
                "port": PORT,
                "timestamp": datetime.utcnow().isoformat(),
                "founder": "Omar Mohammad Abunadi™"
            }
            self.wfile.write(json.dumps(response, indent=2).encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, format, *args):
        pass


if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", PORT), GatewayHandler)
    logger.info(f"🌐 Gateway Primary started on port {PORT}")
    logger.info("✅ QuranChain Gateway is LIVE")
    server.serve_forever()
