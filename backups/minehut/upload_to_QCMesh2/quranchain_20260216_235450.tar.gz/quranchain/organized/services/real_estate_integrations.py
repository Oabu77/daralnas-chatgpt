#!/usr/bin/env python3
"""
Zillow & Redfin API Integration for Real Estate General
Connects to property data sources for live market analysis
"""

import requests
import os
from typing import Dict, List, Optional, Any
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# ============================================================================
# ZILLOW INTEGRATION
# ============================================================================

class ZillowAPI:
    """Zillow API Client for property data"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("ZILLOW_API_KEY")
        self.base_url = "https://zillow-api.p.rapidapi.com"
        self.headers = {
            "X-RapidAPI-Key": self.api_key,
            "X-RapidAPI-Host": "zillow-api.p.rapidapi.com"
        }
    
    def search_properties(self, location: str, filters: Optional[Dict] = None) -> List[Dict]:
        """
        Search for properties on Zillow
        
        Args:
            location: Address or location string
            filters: Optional filters (min_price, max_price, beds, baths, etc.)
        
        Returns:
            List of property listings
        """
        try:
            params = {
                "location": location,
            }
            
            if filters:
                params.update(filters)
            
            response = requests.get(
                f"{self.base_url}/search",
                headers=self.headers,
                params=params,
                timeout=10
            )
            
            if response.status_code == 200:
                logger.info(f"Zillow search successful for: {location}")
                return response.json().get("results", [])
            else:
                logger.error(f"Zillow API error: {response.status_code}")
                return []
        
        except Exception as e:
            logger.error(f"Zillow search failed: {str(e)}")
            return []
    
    def get_property_details(self, zpid: str) -> Optional[Dict]:
        """
        Get detailed information about a specific property
        
        Args:
            zpid: Zillow Property ID
        
        Returns:
            Property details dict
        """
        try:
            response = requests.get(
                f"{self.base_url}/property",
                headers=self.headers,
                params={"zpid": zpid},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get property details: {response.status_code}")
                return None
        
        except Exception as e:
            logger.error(f"Property details fetch failed: {str(e)}")
            return None
    
    def get_rental_data(self, location: str) -> Optional[Dict]:
        """
        Get rental market data for a location
        
        Args:
            location: City or area
        
        Returns:
            Rental market data
        """
        try:
            response = requests.get(
                f"{self.base_url}/rentals",
                headers=self.headers,
                params={"location": location},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
        
        except Exception as e:
            logger.error(f"Rental data fetch failed: {str(e)}")
            return None
    
    def get_zestimate(self, zpid: str) -> Optional[Dict]:
        """
        Get Zillow Zestimate (property value estimate)
        
        Args:
            zpid: Zillow Property ID
        
        Returns:
            Zestimate data
        """
        try:
            response = requests.get(
                f"{self.base_url}/zestimate",
                headers=self.headers,
                params={"zpid": zpid},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
        
        except Exception as e:
            logger.error(f"Zestimate fetch failed: {str(e)}")
            return None

# ============================================================================
# REDFIN INTEGRATION
# ============================================================================

class RedfinAPI:
    """Redfin API Client for property data"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("REDFIN_API_KEY")
        self.base_url = "https://api.redfin.com"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
    
    def search_properties(self, location: str, filters: Optional[Dict] = None) -> List[Dict]:
        """
        Search for properties on Redfin
        
        Args:
            location: Address or location string
            filters: Optional filters (price_range, property_type, etc.)
        
        Returns:
            List of property listings
        """
        try:
            params = {
                "query": location,
            }
            
            if filters:
                params.update(filters)
            
            response = requests.get(
                f"{self.base_url}/api/v1/search",
                headers=self.headers,
                params=params,
                timeout=10
            )
            
            if response.status_code == 200:
                logger.info(f"Redfin search successful for: {location}")
                return response.json().get("properties", [])
            else:
                logger.error(f"Redfin API error: {response.status_code}")
                return []
        
        except Exception as e:
            logger.error(f"Redfin search failed: {str(e)}")
            return []
    
    def get_property_details(self, property_id: str) -> Optional[Dict]:
        """
        Get detailed information about a specific property
        
        Args:
            property_id: Redfin Property ID
        
        Returns:
            Property details dict
        """
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/properties/{property_id}",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get property details: {response.status_code}")
                return None
        
        except Exception as e:
            logger.error(f"Property details fetch failed: {str(e)}")
            return None
    
    def get_market_data(self, location: str) -> Optional[Dict]:
        """
        Get market data for a location
        
        Args:
            location: City or area
        
        Returns:
            Market data including trends
        """
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/market",
                headers=self.headers,
                params={"location": location},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
        
        except Exception as e:
            logger.error(f"Market data fetch failed: {str(e)}")
            return None
    
    def get_price_history(self, property_id: str) -> Optional[List[Dict]]:
        """
        Get price history for a property
        
        Args:
            property_id: Redfin Property ID
        
        Returns:
            List of price history events
        """
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/properties/{property_id}/price-history",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json().get("history", [])
            else:
                return None
        
        except Exception as e:
            logger.error(f"Price history fetch failed: {str(e)}")
            return None
    
    def get_comparable_sales(self, property_id: str, radius_miles: int = 1) -> Optional[List[Dict]]:
        """
        Get comparable sales (comps) for a property
        
        Args:
            property_id: Redfin Property ID
            radius_miles: Search radius in miles
        
        Returns:
            List of comparable properties
        """
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/properties/{property_id}/comps",
                headers=self.headers,
                params={"radius": radius_miles},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json().get("comparable_properties", [])
            else:
                return None
        
        except Exception as e:
            logger.error(f"Comparable sales fetch failed: {str(e)}")
            return None

# ============================================================================
# UNIFIED REAL ESTATE DATA PROVIDER
# ============================================================================

class RealEstateDataProvider:
    """Unified interface for Zillow and Redfin data"""
    
    def __init__(self, zillow_key: Optional[str] = None, redfin_key: Optional[str] = None):
        self.zillow = ZillowAPI(zillow_key)
        self.redfin = RedfinAPI(redfin_key)
    
    def search_all_sources(self, location: str, filters: Optional[Dict] = None) -> Dict[str, List]:
        """
        Search both Zillow and Redfin
        
        Returns:
            Dict with results from both sources
        """
        return {
            "zillow": self.zillow.search_properties(location, filters),
            "redfin": self.redfin.search_properties(location, filters)
        }
    
    def get_market_comparison(self, location: str) -> Dict[str, Any]:
        """
        Get market data from both sources for comparison
        
        Returns:
            Market data comparison
        """
        zillow_rental = self.zillow.get_rental_data(location)
        redfin_market = self.redfin.get_market_data(location)
        
        return {
            "zillow_rental_data": zillow_rental,
            "redfin_market_data": redfin_market,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    def analyze_property_opportunity(self, location: str, property_type: str = "residential") -> Dict:
        """
        Comprehensive analysis combining both sources
        
        Returns:
            Investment opportunity analysis
        """
        zillow_results = self.zillow.search_properties(
            location, 
            {"property_type": property_type}
        )
        redfin_results = self.redfin.search_properties(location)
        
        zillow_market = self.zillow.get_rental_data(location)
        redfin_market = self.redfin.get_market_data(location)
        
        analysis = {
            "location": location,
            "property_type": property_type,
            "data_sources": {
                "zillow": {
                    "properties_found": len(zillow_results),
                    "rental_data": zillow_market
                },
                "redfin": {
                    "properties_found": len(redfin_results),
                    "market_data": redfin_market
                }
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return analysis

if __name__ == "__main__":
    # Example usage
    provider = RealEstateDataProvider()
    
    # Search all sources
    print("Searching for properties in New York...")
    results = provider.search_all_sources("New York, NY")
    print(f"Zillow results: {len(results['zillow'])} properties")
    print(f"Redfin results: {len(results['redfin'])} properties")
    
    # Market comparison
    print("\nGetting market comparison...")
    comparison = provider.get_market_comparison("New York, NY")
    # Strategy definition (from user prompt)
    STRATEGY = {
        "strategy_name": "1_dollar_apartment_option_takeover",
        "founder": "Omar Mohammad Abunadi",
        "ownership_signature": "OMAR-QURANCHAIN-SOVEREIGN-FOUNDER-10PCT-ROYALTY",
        "asset_profile": {
            "property_type": "multifamily_apartments",
            "min_units": 20,
            "max_units": 150,
            "target_markets": ["USA_tier2", "USA_tier3", "Jordan", "KSA", "Mexico", "GCC"],
            "condition_focus": "structurally_sound_needs_management_or_cosmetic_rehab"
        },
        "financial_profile": {
            "min_current_cap_rate": 0.05,
            "target_cap_rate_with_upside": 0.08,
            "min_vacancy": 0.05,
            "max_vacancy": 0.20,
            "below_market_rent_pct_min": 0.10,
            "below_market_rent_pct_max": 0.30,
            "loan_flags": [
                "balloon_coming_due",
                "adjustable_rate_stress",
                "high_debt_service_to_noi"
            ]
        },
        "seller_profile": {
            "preferred_sellers": [
                "mom_and_pop_owners",
                "small_partner_groups",
                "estates_or_heirs"
            ],
            "motivation_signals": [
                "burnout",
                "relocation",
                "divorce",
                "partnership_breakup",
                "time_pressure",
                "tax_pressure"
            ],
            "avoid": [
                "large_institutional_sellers_only",
                "sellers_who_explicitly_reject_creative_deals"
            ]
        },
        "search_keywords": [
            "motivated seller",
            "seller will carry",
            "owner financing",
            "bring all offers",
            "partnership dissolved",
            "owner relocating",
            "value add",
            "under managed",
            "stabilization opportunity"
        ],
        "deal_structure": {
            "instrument": "exclusive_assignable_purchase_option",
            "option_price": 1,
            "strike_price_type": "fixed_purchase_price",
            "typical_term_days_min": 60,
            "typical_term_days_max": 180,
            "requires_assignability": True,
            "requires_data_access": True,
            "consideration_notes": [
                "1 USD plus good_and_valuable_consideration",
                "services_consulting_problem_solving_for_seller"
            ]
        },
        "during_option_period": {
            "tasks": [
                "full_financial_due_diligence",
                "physical_inspection",
                "quranchain_tokenization_model",
                "refinance_scenarios",
                "investor_and_lender_lineup"
            ]
        },
        "exit_paths": [
            "assign_option_for_fee",
            "close_and_refinance_into_dar_al_nas_portfolio",
            "joint_venture_with_seller"
        ],
        "founder_royalty": {
            "rate_pct": 10.0,
            "basis": "net_income_or_net_project_program_revenue",
            "settlement": "quranchain_smart_contracts"
        }
    }


    def summarize_strategy(strategy: dict) -> dict:
            """Return a compact summary of the strategy for logging or display."""
            asset = strategy.get("asset_profile", {})
            fin = strategy.get("financial_profile", {})
            return {
                    "strategy_name": strategy.get("strategy_name"),
                    "property_type": asset.get("property_type"),
                    "units_range": (asset.get("min_units"), asset.get("max_units")),
                    "target_markets": asset.get("target_markets", []),
                    "target_cap_rate": (fin.get("min_current_cap_rate"), fin.get("target_cap_rate_with_upside"))
            }


    def normalize_market_name(market: str) -> str:
            """Map strategy market tags into a human-readable search string for the provider."""
