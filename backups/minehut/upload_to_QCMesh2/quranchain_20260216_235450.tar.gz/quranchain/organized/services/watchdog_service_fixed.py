#!/usr/bin/env python3
"""
🐕 QURANCHAIN™ WATCHDOG SERVICE
Auto-healing service monitor that ensures all critical services stay running
Founder: Omar Mohammad Abunadi™
"""

import time
import requests
import subprocess
import logging
import os
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime
from pathlib import Path

# Configuration
QURANCHAIN_DIR = Path("/home/omar/Desktop/QuranChain")
LOG_FILE = QURANCHAIN_DIR / "monitoring_logs" / "watchdog_service.log"
CHECK_INTERVAL = 300  # 5 minutes

# Setup logging
LOG_FILE.parent.mkdir(exist_ok=True)
setup_blockchain_logging()
logger = logging.getLogger(__name__)

# Critical services to monitor
SERVICES = {
    'quantum_blockchain': {'port': 9999, 'file': 'quranchain_quantum_blockchain.py'},
    'marketing_ai': {'port': 7300, 'file': 'ai_workforce/marketing_ai/agent.py'},
    'sales_ai': {'port': 7301, 'file': 'ai_workforce/sales_ai/agent.py'},
}

def check_service_health(name, config):
    """Check if service is healthy"""
    try:
        resp = requests.get(f"http://127.0.0.1:{config['port']}/health", timeout=2)
        return resp.status_code == 200
    except:
        return False

def restart_service(name, config):
    """Restart a failed service"""
    logger.warning(f"🔄 Restarting {name}...")
    
    # Kill existing process
    try:
        subprocess.run(['pkill', '-9', '-f', config['file']], check=False)
        time.sleep(2)
    except:
        pass
    
    # Start service
    try:
        log_file = QURANCHAIN_DIR / "monitoring_logs" / f"{name}.log"
        with open(log_file, 'a') as f:
            subprocess.Popen(
                ['python3', str(QURANCHAIN_DIR / config['file'])],
                stdout=f,
                stderr=subprocess.STDOUT,
                cwd=QURANCHAIN_DIR
            )
        logger.info(f"✅ {name} restarted successfully")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to restart {name}: {e}")
        return False

def main():
    logger.info("🐕 QuranChain Watchdog Service started")
    logger.info(f"Monitoring {len(SERVICES)} critical services every {CHECK_INTERVAL}s")
    
    while True:
        try:
            for name, config in SERVICES.items():
                if not check_service_health(name, config):
                    logger.warning(f"⚠️  {name} health check failed")
                    restart_service(name, config)
                    time.sleep(5)  # Wait before next check
            
            time.sleep(CHECK_INTERVAL)
            
        except KeyboardInterrupt:
            logger.info("Watchdog service stopped by user")
            break
        except Exception as e:
            logger.error(f"Watchdog error: {e}")
            time.sleep(60)

if __name__ == "__main__":
    main()
