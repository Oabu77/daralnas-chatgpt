#!/usr/bin/env python3
"""
🎯 QURANCHAIN™ LIVE REVENUE TRACKER
Real-time revenue tracking with sound alerts and visual notifications
Features: Live updates, sound alerts, revenue animations, blockchain breakdown
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime, timedelta
from collections import deque
import threading

# Try to use system sound commands
def play_revenue_sound(amount_usd: float):
    """Play a sound alert when revenue is collected"""
    try:
        # Calculate pitch based on revenue amount (higher amount = higher pitch)
        duration = min(1.0, amount_usd / 100.0)  # Scale duration by amount
        frequency = min(2000, 400 + (amount_usd * 5))  # Higher revenue = higher pitch
        
        # Try different sound methods
        try:
            # Method 1: Use paplay (PulseAudio)
            subprocess.run([
                'paplay', '--channels=1', '--rate=22050', '--format=u8',
                '/dev/stdin'
            ], input=b'\x7f' * int(22050 * duration), timeout=2, stderr=subprocess.DEVNULL)
        except:
            try:
                # Method 2: Use beep command
                subprocess.run(['beep', '-f', str(int(frequency)), '-l', str(int(duration * 1000))], timeout=2, stderr=subprocess.DEVNULL)
            except:
                try:
                    # Method 3: Use speaker-test
                    subprocess.run(['speaker-test', '-t', 'sine', '-f', str(int(frequency)), '-l', '1'], timeout=2, stderr=subprocess.DEVNULL)
                except:
                    pass
    except:
        pass


class LiveRevenueTracker:
    """Real-time revenue tracking with live display"""

    def __init__(self):
        self.revenue_history = deque(maxlen=1440)  # Last 24 hours of minute-level data
        self.current_session_start = datetime.now()
        self.total_revenue_this_session = 0.0
        self.previous_revenue = 0.0
        self.revenue_updates = deque(maxlen=100)  # Last 100 revenue events
        self.is_running = False
        self.data_file = "/home/omar/Desktop/QuranChain/monitoring_reports/latest_snapshot.json"
        
        # Track by blockchain
        self.revenue_by_blockchain = {}
        self.last_blockchain_revenues = {}

    def load_latest_snapshot(self) -> dict:
        """Load the latest monitoring snapshot"""
        try:
            with open(self.data_file, 'r') as f:
                return json.load(f)
        except:
            return None

    def check_for_new_revenue(self):
        """Check if new revenue has been collected"""
        snapshot = self.load_latest_snapshot()
        if not snapshot or 'revenue' not in snapshot:
            return None

        current_revenue = snapshot['revenue']['daily_usd']
        revenue_diff = current_revenue - self.previous_revenue

        if revenue_diff > 0:
            self.previous_revenue = current_revenue
            self.total_revenue_this_session += revenue_diff

            # Record update
            update = {
                'timestamp': datetime.now().isoformat(),
                'amount': revenue_diff,
                'total_session': self.total_revenue_this_session,
                'by_blockchain': snapshot['revenue']['by_blockchain'],
                'by_service': snapshot['revenue']['by_service'],
            }
            self.revenue_updates.append(update)

            # Play sound alert
            play_revenue_sound(revenue_diff)

            return update

        return None

    def get_session_duration(self) -> str:
        """Get formatted session duration"""
        duration = datetime.now() - self.current_session_start
        hours = duration.total_seconds() // 3600
        minutes = (duration.total_seconds() % 3600) // 60
        seconds = int(duration.total_seconds() % 60)
        return f"{int(hours):02d}:{int(minutes):02d}:{seconds:02d}"

    def get_revenue_rate(self) -> float:
        """Calculate current revenue rate (USD per minute)"""
        duration_minutes = (datetime.now() - self.current_session_start).total_seconds() / 60
        if duration_minutes > 0:
            return self.total_revenue_this_session / duration_minutes
        return 0.0

    def get_projected_daily(self) -> float:
        """Project revenue for a full day"""
        rate_per_minute = self.get_revenue_rate()
        return rate_per_minute * 60 * 24

    def get_projected_monthly(self) -> float:
        """Project revenue for a full month"""
        return self.get_projected_daily() * 30

    def render_header(self):
        """Render tracker header"""
        print("\033[2J\033[H")  # Clear screen
        print("=" * 140)
        print("💰 QURANCHAIN™ LIVE REVENUE TRACKER".center(140))
        print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}".center(140))
        print("=" * 140)
        print()

    def render_revenue_summary(self):
        """Render revenue summary with animations"""
        snapshot = self.load_latest_snapshot()
        if not snapshot:
            print("⚠️  No data available")
            return

        revenue = snapshot['revenue']

        # Revenue bars with visual indicators
        print("💰 CURRENT REVENUE (Real-time)")
        print("-" * 140)
        
        # Hourly
        hourly = revenue['hourly_usd']
        bar_length = int(hourly / 5)  # 5 chars per dollar
        bar = "█" * min(bar_length, 50) + "░" * max(0, 50 - bar_length)
        print(f"Hourly:              ${hourly:>8.2f}  {bar} [{bar_length} units]")
        
        # Daily
        daily = revenue['daily_usd']
        bar_length = int(daily / 20)  # 20 chars per dollar
        bar = "█" * min(bar_length, 50) + "░" * max(0, 50 - bar_length)
        print(f"Daily:               ${daily:>8.2f}  {bar} [{bar_length} units]")
        
        # Monthly projected
        monthly = revenue['monthly_projected_usd']
        bar_length = int(monthly / 500)  # 500 chars per dollar
        bar = "█" * min(bar_length, 50) + "░" * max(0, 50 - bar_length)
        print(f"Monthly Projected:   ${monthly:>8.2f}  {bar} [{bar_length} units]")
        
        # Founder share
        founder_daily = revenue['founder_share_daily']
        founder_monthly = revenue['founder_share_monthly_projected']
        print()
        print(f"👤 FOUNDER SHARE (30% - IMMUTABLE)")
        print(f"   Daily:     ${founder_daily:>8.2f}")
        print(f"   Monthly:   ${founder_monthly:>8.2f}")
        print()

    def render_session_stats(self):
        """Render current session statistics"""
        print("📊 SESSION STATISTICS")
        print("-" * 140)
        print(f"Session Duration:     {self.get_session_duration()}")
        print(f"Revenue This Session: ${self.total_revenue_this_session:.2f}")
        print(f"Current Rate:         ${self.get_revenue_rate():.2f} per minute")
        print(f"Projected Daily Rate: ${self.get_projected_daily():.2f}")
        print(f"Projected Monthly:    ${self.get_projected_monthly():.2f}")
        print()

    def render_blockchain_breakdown(self):
        """Render revenue by blockchain"""
        snapshot = self.load_latest_snapshot()
        if not snapshot:
            return

        print("⛓️  REVENUE BY BLOCKCHAIN")
        print("-" * 140)
        print(f"{'Blockchain':<25} {'Revenue':<15} {'% of Total':<15} {'Transactions':<15} {'Avg Fee':<15}")
        print("-" * 140)

        blockchains = snapshot['blockchains']
        total_revenue = sum(bc.get('revenue_usd', 0) for bc in blockchains.values())

        for bc_id, bc in sorted(blockchains.items(), key=lambda x: x[1].get('revenue_usd', 0), reverse=True):
            revenue = bc.get('revenue_usd', 0)
            txns = bc.get('transactions_collected', 0)
            fee = bc.get('avg_fee_usd', 0)
            pct = (revenue / total_revenue * 100) if total_revenue > 0 else 0

            # Add money emoji for visual impact
            money_emoji = "💰" * int(pct / 10) if pct > 0 else ""

            print(f"{bc['name']:<25} ${revenue:<14.2f} {pct:<14.1f}% {txns:<15} ${fee:<14.4f} {money_emoji}")

        print()

    def render_recent_transactions(self):
        """Render recent revenue transactions"""
        print("🔔 RECENT REVENUE EVENTS (Last 20)")
        print("-" * 140)
        print(f"{'Time':<20} {'Amount':<15} {'Session Total':<20} {'Top Blockchain':<30} {'Alert':<40}")
        print("-" * 140)

        for i, update in enumerate(list(self.revenue_updates)[-20:]):
            time_str = update['timestamp'].split('T')[1].split('.')[0]
            amount = update['amount']
            session_total = update['total_session']
            
            # Find top blockchain
            by_chain = update['by_blockchain']
            top_chain = max(by_chain.items(), key=lambda x: x[1])[0] if by_chain else "N/A"
            top_amount = by_chain.get(top_chain, 0) if by_chain else 0
            
            # Alert indicator
            if amount > 50:
                alert = "🚀 MAJOR REVENUE EVENT! 🚀"
            elif amount > 20:
                alert = "💸 SIGNIFICANT REVENUE"
            elif amount > 5:
                alert = "💵 REVENUE COLLECTED"
            else:
                alert = "✅ Revenue"

            print(f"{time_str:<20} ${amount:<14.2f} ${session_total:<19.2f} {top_chain:<30} {alert:<40}")

        print()

    def render_revenue_timeline(self):
        """Render revenue over time graph"""
        print("📈 REVENUE TIMELINE (Last 10 Events)")
        print("-" * 140)

        max_amount = max([u['amount'] for u in self.revenue_updates], default=1)
        scale = 100 / max(max_amount, 1)

        for update in list(self.revenue_updates)[-10:]:
            amount = update['amount']
            bar_length = int(amount * scale / 2)  # Scale to fit
            bar = "█" * bar_length + "░" * max(0, 50 - bar_length)
            time_str = update['timestamp'].split('T')[1].split('.')[0]

            print(f"{time_str}  ${amount:>8.2f}  {bar}")

        print()

    def render_service_breakdown(self):
        """Render revenue by service"""
        snapshot = self.load_latest_snapshot()
        if not snapshot or 'revenue' not in snapshot:
            return

        print("🏢 REVENUE BY SERVICE")
        print("-" * 140)
        print(f"{'Service':<30} {'Revenue':<15} {'% of Total':<15}")
        print("-" * 140)

        by_service = snapshot['revenue']['by_service']
        total = sum(by_service.values())

        for service, revenue in sorted(by_service.items(), key=lambda x: x[1], reverse=True):
            pct = (revenue / total * 100) if total > 0 else 0
            bar = "💲" * int(pct / 5)
            print(f"{service:<30} ${revenue:<14.2f} {pct:<14.1f}% {bar}")

        print()

    def render_network_status(self):
        """Render network status"""
        snapshot = self.load_latest_snapshot()
        if not snapshot:
            return

        net = snapshot['network_summary']

        print("🌐 NETWORK STATUS")
        print("-" * 140)
        print(f"Services Online:      {net['services_online']}/{net['total_services']}")
        print(f"Blockchains Online:   {net['blockchains_online']}/{net['total_blockchains']}")
        print(f"Average Congestion:   {net['average_congestion']:.1f}%")
        print()

    def render_full_dashboard(self):
        """Render complete revenue tracker"""
        self.render_header()
        self.render_revenue_summary()
        self.render_session_stats()
        self.render_blockchain_breakdown()
        self.render_service_breakdown()
        self.render_recent_transactions()
        self.render_revenue_timeline()
        self.render_network_status()

        print("=" * 140)
        print("🔊 Sound alerts enabled | Updates every 5 seconds | Press Ctrl+C to stop".center(140))
        print("=" * 140)

    def run_tracker(self):
        """Run the live revenue tracker"""
        self.is_running = True
        print("🚀 Starting Live Revenue Tracker...")
        time.sleep(2)

        try:
            while self.is_running:
                # Check for new revenue
                update = self.check_for_new_revenue()

                if update:
                    print(f"🔊 REVENUE ALERT: +${update['amount']:.2f} collected!")
                    print(f"   Session Total: ${update['total_session']:.2f}")

                # Render dashboard
                self.render_full_dashboard()

                # Wait before next check
                time.sleep(5)

        except KeyboardInterrupt:
            self.is_running = False
            print("\n✅ Live Revenue Tracker stopped gracefully")
            print(f"📊 Total revenue this session: ${self.total_revenue_this_session:.2f}")
            print(f"📈 Session duration: {self.get_session_duration()}")


def main():
    """Main entry point"""
    tracker = LiveRevenueTracker()
    tracker.run_tracker()


if __name__ == "__main__":
    main()
