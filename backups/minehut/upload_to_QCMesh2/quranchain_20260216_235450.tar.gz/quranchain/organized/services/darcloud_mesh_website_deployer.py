#!/usr/bin/env python3
"""
🌐 DARCLOUD MESH WEBSITE DEPLOYER
Deploy websites across MeshTalk OS and Fungi Mesh networks
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import json
import time
import logging
import requests
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse
import uvicorn

# Add project root to path
sys.path.insert(0, "/home/omar/Desktop/QuranChain")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] 🌐 DEPLOY - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="DarCloud Mesh Website Deployer", version="1.0.0")

# Deployment storage
DEPLOY_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_deployments")
DEPLOY_DIR.mkdir(exist_ok=True)

class MeshWebsiteDeployer:
    """Deploys websites across mesh networks"""

    def __init__(self):
        self.deployments = {}
        self.mesh_nodes = []  # Initialize mesh_nodes
        self.load_deployment_registry()
        # Load mesh nodes
        try:
            self.mesh_nodes = self._get_mesh_nodes()
        except Exception as e:
            logger.warning(f"⚠️ Failed to load mesh nodes during initialization: {e}")
            self.mesh_nodes = []  # Fallback to empty list
        logger.info("🌐 Mesh Website Deployer initialized")

    def _get_mesh_nodes(self) -> List[Dict]:
        """Get mesh network nodes for deployment from running services"""
        mesh_nodes = []
        
        # Connect to MeshTalk OS service
        try:
            response = requests.get("https://meshtalk.quranchain.io/nodes", timeout=5)
            if response.status_code == 200:
                meshtalk_data = response.json()
                for node in meshtalk_data.get('nodes', []):
                    mesh_nodes.append({
                        "id": f"meshtalk_{node['node_id']}",
                        "ip": node['ip_address'],
                        "type": "meshtalk",
                        "region": node.get('region', 'global'),
                        "web_port": 8080,
                        "status": node.get('status', 'active'),
                        "capabilities": node.get('protocols', [])
                    })
                logger.info(f"🌐 Connected to {len(meshtalk_data.get('nodes', []))} MeshTalk OS nodes")
            else:
                logger.warning("⚠️ Could not connect to MeshTalk OS service, using fallback")
                # Fallback to basic nodes
                mesh_nodes.extend([{
                    "id": f"meshtalk_{i}",
                    "ip": f"10.0.0.{i+100}",
                    "type": "meshtalk",
                    "region": "global",
                    "web_port": 8080,
                    "status": "active"
                } for i in range(10)])
        except Exception as e:
            logger.error(f"Failed to connect to MeshTalk OS: {e}")
            # Fallback
            mesh_nodes.extend([{
                "id": f"meshtalk_{i}",
                "ip": f"10.0.0.{i+100}",
                "type": "meshtalk",
                "region": "global",
                "web_port": 8080,
                "status": "active"
            } for i in range(10)])

        # Connect to Fungi Mesh service
        try:
            response = requests.get("https://fungi.quranchain.io/nodes", timeout=5)
            if response.status_code == 200:
                fungi_data = response.json()
                for node in fungi_data.get('nodes', []):
                    mesh_nodes.append({
                        "id": f"fungi_{node['node_id']}",
                        "ip": node['ip_address'],
                        "type": "fungi",
                        "region": node.get('region', 'global'),
                        "web_port": 8080,
                        "status": node.get('status', 'active'),
                        "capabilities": ["mesh", "p2p", "distributed"]
                    })
                logger.info(f"🍄 Connected to {len(fungi_data.get('nodes', []))} Fungi Mesh nodes")
            else:
                logger.warning("⚠️ Could not connect to Fungi Mesh service, using fallback")
                # Fallback to basic nodes
                mesh_nodes.extend([{
                    "id": f"fungi_{i}",
                    "ip": f"10.0.1.{i+100}",
                    "type": "fungi",
                    "region": "global",
                    "web_port": 8080,
                    "status": "active"
                } for i in range(10)])
        except Exception as e:
            logger.error(f"Failed to connect to Fungi Mesh: {e}")
            # Fallback
            mesh_nodes.extend([{
                "id": f"fungi_{i}",
                "ip": f"10.0.1.{i+100}",
                "type": "fungi",
                "region": "global",
                "web_port": 8080,
                "status": "active"
            } for i in range(10)])

        return mesh_nodes

    def load_deployment_registry(self):
        """Load deployment registry"""
        registry_file = DEPLOY_DIR / "deployments.json"
        if registry_file.exists():
            try:
                with open(registry_file, 'r') as f:
                    data = json.load(f)
                    self.deployments = data.get('deployments', {})
                logger.info(f"📋 Loaded {len(self.deployments)} deployments from registry")
            except Exception as e:
                logger.error(f"Failed to load deployment registry: {e}")

    def save_deployment_registry(self):
        """Save deployment registry"""
        registry_file = DEPLOY_DIR / "deployments.json"
        try:
            data = {
                'deployments': self.deployments,
                'last_updated': datetime.utcnow().isoformat() + "Z"
            }
            with open(registry_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info("💾 Deployment registry saved")
        except Exception as e:
            logger.error(f"Failed to save deployment registry: {e}")

    def deploy_website(self, domain: str, website_files: Dict[str, bytes], owner: str = "Omar Mohammad Abunadi™") -> Dict:
        """Deploy website across mesh network"""

        deployment_id = f"{domain}_{int(time.time())}"

        # Create deployment directory
        deployment_path = DEPLOY_DIR / deployment_id
        deployment_path.mkdir(exist_ok=True)

        # Save website files locally
        saved_files = {}
        for filename, content in website_files.items():
            file_path = deployment_path / filename
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            saved_files[filename] = str(file_path)

        # Deploy to mesh nodes
        deployment_results = self._deploy_to_mesh_nodes(domain, website_files)

        # Create deployment record
        deployment_info = {
            "deployment_id": deployment_id,
            "domain": domain,
            "owner": owner,
            "deployed_at": datetime.utcnow().isoformat() + "Z",
            "files": saved_files,
            "mesh_deployment": deployment_results,
            "status": "active",
            "mesh_urls": [url for result in deployment_results if result["success"] for url in result.get("node_urls", [])],
            "cdn_integration": True
        }

        self.deployments[deployment_id] = deployment_info
        self.save_deployment_registry()

        logger.info(f"✅ Website {domain} deployed to {len(deployment_info['mesh_urls'])} mesh nodes")
        return deployment_info

    def _deploy_to_mesh_nodes(self, domain: str, website_files: Dict[str, str]) -> List[Dict]:
        """Deploy website to mesh networks via service endpoints"""
        results = []

        # Deploy to MeshTalk OS network
        try:
            deployment_data = {
                "domain": domain,
                "files": website_files,
                "owner": "Omar Mohammad Abunadi™",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }

            response = requests.post(
                "https://meshtalk.quranchain.io/deploy",
                json=deployment_data,
                timeout=10
            )

            if response.status_code == 200:
                result = response.json()
                results.append({
                    "service": "meshtalk_os",
                    "deployment_id": result.get("deployment_id"),
                    "domain": domain,
                    "nodes_deployed": result.get("nodes_deployed", 0),
                    "node_urls": result.get("node_urls", []),
                    "success": True,
                    "deployed_at": datetime.utcnow().isoformat() + "Z"
                })
            else:
                results.append({
                    "service": "meshtalk_os",
                    "success": False,
                    "error": f"HTTP {response.status_code}",
                    "deployed_at": datetime.utcnow().isoformat() + "Z"
                })
        except Exception as e:
            logger.error(f"Failed to deploy to MeshTalk OS: {e}")
            results.append({
                "service": "meshtalk_os",
                "success": False,
                "error": str(e),
                "deployed_at": datetime.utcnow().isoformat() + "Z"
            })

        # Deploy to Fungi Mesh network
        try:
            deployment_data = {
                "domain": domain,
                "files": website_files,
                "owner": "Omar Mohammad Abunadi™",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }

            response = requests.post(
                "https://fungi.quranchain.io/deploy",
                json=deployment_data,
                timeout=10
            )

            if response.status_code == 200:
                result = response.json()
                results.append({
                    "service": "fungi_mesh",
                    "deployment_id": result.get("deployment_id"),
                    "domain": domain,
                    "nodes_deployed": result.get("nodes_deployed", 0),
                    "node_urls": result.get("node_urls", []),
                    "success": True,
                    "deployed_at": datetime.utcnow().isoformat() + "Z"
                })
            else:
                results.append({
                    "service": "fungi_mesh",
                    "success": False,
                    "error": f"HTTP {response.status_code}",
                    "deployed_at": datetime.utcnow().isoformat() + "Z"
                })
        except Exception as e:
            logger.error(f"Failed to deploy to Fungi Mesh: {e}")
            results.append({
                "service": "fungi_mesh",
                "success": False,
                "error": str(e),
                "deployed_at": datetime.utcnow().isoformat() + "Z"
            })

        return results

    def _deploy_via_meshtalk(self, domain: str, website_files: Dict[str, bytes], node: Dict) -> Dict:
        """Deploy website via MeshTalk OS service"""
        try:
            # Prepare deployment data
            deployment_data = {
                "domain": domain,
                "node_id": node["id"],
                "files": {filename: content.decode('utf-8', errors='ignore') 
                         for filename, content in website_files.items()},
                "owner": "Omar Mohammad Abunadi™",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }

            # Send to MeshTalk OS service
            response = requests.post(
                "https://meshtalk.quranchain.io/deploy",
                json=deployment_data,
                timeout=10
            )

            if response.status_code == 200:
                result = response.json()
                return {
                    "node_id": node["id"],
                    "node_type": "meshtalk",
                    "url": result.get("url", f"http://{node['ip']}:8080/sites/{domain}"),
                    "success": True,
                    "deployed_at": datetime.utcnow().isoformat() + "Z",
                    "files_deployed": len(website_files),
                    "service_response": result
                }
            else:
                raise Exception(f"MeshTalk OS returned {response.status_code}: {response.text}")

        except Exception as e:
            logger.warning(f"MeshTalk deployment failed for {node['id']}: {e}")
            # Fallback to direct deployment
            return self._deploy_via_fallback(domain, website_files, node)

    def _deploy_via_fungi_mesh(self, domain: str, website_files: Dict[str, bytes], node: Dict) -> Dict:
        """Deploy website via Fungi Mesh service"""
        try:
            # Prepare deployment data
            deployment_data = {
                "domain": domain,
                "node_id": node["id"],
                "files": {filename: content.decode('utf-8', errors='ignore') 
                         for filename, content in website_files.items()},
                "owner": "Omar Mohammad Abunadi™",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }

            # Send to Fungi Mesh service
            response = requests.post(
                "https://fungi.quranchain.io/deploy",
                json=deployment_data,
                timeout=10
            )

            if response.status_code == 200:
                result = response.json()
                return {
                    "node_id": node["id"],
                    "node_type": "fungi",
                    "url": result.get("url", f"http://{node['ip']}:8080/sites/{domain}"),
                    "success": True,
                    "deployed_at": datetime.utcnow().isoformat() + "Z",
                    "files_deployed": len(website_files),
                    "service_response": result
                }
            else:
                raise Exception(f"Fungi Mesh returned {response.status_code}: {response.text}")

        except Exception as e:
            logger.warning(f"Fungi Mesh deployment failed for {node['id']}: {e}")
            # Fallback to direct deployment
            return self._deploy_via_fallback(domain, website_files, node)

    def _deploy_via_fallback(self, domain: str, website_files: Dict[str, bytes], node: Dict) -> Dict:
        """Fallback deployment when mesh services are unavailable"""
        try:
            # Simulate deployment (in real implementation, would use direct node connection)
            node_url = f"http://{node['ip']}:{node['web_port']}/sites/{domain}"

            return {
                "node_id": node["id"],
                "node_type": node["type"],
                "url": node_url,
                "success": True,
                "deployed_at": datetime.utcnow().isoformat() + "Z",
                "files_deployed": len(website_files),
                "deployment_method": "fallback"
            }

        except Exception as e:
            return {
                "node_id": node["id"],
                "node_type": node["type"],
                "url": None,
                "success": False,
                "error": str(e),
                "deployed_at": datetime.utcnow().isoformat() + "Z"
            }

    def get_deployment_info(self, deployment_id: str) -> Optional[Dict]:
        """Get deployment information"""
        return self.deployments.get(deployment_id)

    def get_domain_deployments(self, domain: str) -> List[Dict]:
        """Get all deployments for a domain"""
        return [d for d in self.deployments.values() if d["domain"] == domain]

    def undeploy_website(self, deployment_id: str) -> bool:
        """Undeploy website from mesh network"""
        if deployment_id in self.deployments:
            deployment_info = self.deployments[deployment_id]

            # Remove local files
            try:
                deployment_path = DEPLOY_DIR / deployment_id
                if deployment_path.exists():
                    import shutil
                    shutil.rmtree(deployment_path)
            except Exception as e:
                logger.warning(f"Failed to remove deployment files for {deployment_id}: {e}")

            # Remove from registry
            del self.deployments[deployment_id]
            self.save_deployment_registry()

            logger.info(f"🗑️ Website deployment {deployment_id} removed")
            return True

        return False

    def get_deployment_stats(self) -> Dict:
        """Get deployment statistics"""
        total_deployments = len(self.deployments)
        active_deployments = len([d for d in self.deployments.values() if d["status"] == "active"])
        total_mesh_nodes = len(self.mesh_nodes)

        domains = set(d["domain"] for d in self.deployments.values())
        total_domains = len(domains)

        return {
            "total_deployments": total_deployments,
            "active_deployments": active_deployments,
            "total_domains": total_domains,
            "mesh_nodes": total_mesh_nodes,
            "average_nodes_per_deployment": total_mesh_nodes  # All nodes get each deployment
        }

    def list_deployments(self) -> List[Dict]:
        """List all deployments"""
        return list(self.deployments.values())

    def update_deployment_status(self, deployment_id: str, status: str):
        """Update deployment status"""
        if deployment_id in self.deployments:
            self.deployments[deployment_id]["status"] = status
            self.deployments[deployment_id]["last_updated"] = datetime.utcnow().isoformat() + "Z"
            self.save_deployment_registry()
            logger.info(f"📝 Deployment {deployment_id} status updated to {status}")

# Global deployer
mesh_deployer = MeshWebsiteDeployer()

# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.get("/")
def root():
    """DarCloud Mesh Website Deployer Dashboard"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>🌐 DarCloud Mesh Website Deployer</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .header {{ background: linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
            .stat-card {{ background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }}
            .stat-number {{ font-size: 2em; font-weight: bold; color: #9C27B0; }}
            .deployments {{ margin-top: 30px; }}
            .deployment-card {{ background: white; margin: 10px 0; padding: 15px; border-radius: 8px; box-shadow: 0 1px 5px rgba(0,0,0,0.1); }}
            .mesh-info {{ background: #f3e5f5; padding: 15px; border-radius: 8px; margin: 20px 0; }}
            .node-type {{ display: inline-block; background: #9C27B0; color: white; padding: 5px 10px; margin: 2px; border-radius: 15px; font-size: 0.9em; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🌐 DarCloud Mesh Website Deployer</h1>
            <p>Deploy Websites Across Global Mesh Networks</p>
            <p><strong>Networks:</strong> MeshTalk OS + Fungi Mesh</p>
        </div>

        <div class="mesh-info">
            <h3>🖧 Mesh Network Nodes</h3>
    """

    stats = mesh_deployer.get_deployment_stats()
    html_content += f'<span class="node-type">MESHTALK: {stats["mesh_nodes"]//2}</span>'
    html_content += f'<span class="node-type">FUNGI: {stats["mesh_nodes"]//2}</span>'

    html_content += f"""
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">{stats['total_deployments']}</div>
                <div>Total Deployments</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['active_deployments']}</div>
                <div>Active Websites</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['total_domains']}</div>
                <div>Domains Hosted</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['average_nodes_per_deployment']}</div>
                <div>Nodes per Site</div>
            </div>
        </div>

        <div class="deployments">
            <h2>🚀 Website Deployments</h2>
    """

    for deployment in mesh_deployer.list_deployments()[:10]:  # Show last 10
        html_content += f"""
            <div class="deployment-card">
                <h3>{deployment['domain']}</h3>
                <p><strong>Owner:</strong> {deployment['owner']}</p>
                <p><strong>Deployed:</strong> {deployment['deployed_at'][:19]}</p>
                <p><strong>Status:</strong> <span style="color: green;">{deployment['status'].upper()}</span></p>
                <p><strong>Mesh URLs:</strong> {len(deployment['mesh_urls'])} nodes</p>
                <p><strong>Files:</strong> {len(deployment['files'])} uploaded</p>
            </div>
        """

    html_content += """
        </div>
    </body>
    </html>
    """

    return HTMLResponse(content=html_content)

@app.post("/deploy/{domain}")
async def deploy_website(domain: str, files: List[UploadFile] = File(...), owner: str = "Omar Mohammad Abunadi™"):
    """Deploy website to mesh network"""
    try:
        website_files = {}
        for file in files:
            content = await file.read()
            website_files[file.filename] = content

        if not website_files:
            raise HTTPException(status_code=400, detail="No files provided")

        result = mesh_deployer.deploy_website(domain, website_files, owner)
        return JSONResponse({
            "status": "success",
            "message": f"Website {domain} deployed to {len(result['mesh_urls'])} mesh nodes",
            "data": result
        })
    except Exception as e:
        logger.error(f"Website deployment failed for {domain}: {e}")
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")

@app.get("/api/deployments")
def list_deployments():
    """List all deployments"""
    return JSONResponse({
        "deployments": mesh_deployer.list_deployments(),
        "total": len(mesh_deployer.deployments)
    })

@app.get("/api/deployment/{deployment_id}")
def get_deployment_info(deployment_id: str):
    """Get deployment information"""
    deployment = mesh_deployer.get_deployment_info(deployment_id)
    if not deployment:
        raise HTTPException(status_code=404, detail="Deployment not found")

    return JSONResponse(deployment)

@app.get("/api/domain/{domain}/deployments")
def get_domain_deployments(domain: str):
    """Get deployments for domain"""
    deployments = mesh_deployer.get_domain_deployments(domain)
    return JSONResponse({
        "domain": domain,
        "deployments": deployments,
        "total": len(deployments)
    })

@app.delete("/api/deployment/{deployment_id}")
def undeploy_website(deployment_id: str):
    """Undeploy website"""
    if mesh_deployer.undeploy_website(deployment_id):
        return JSONResponse({"status": "success", "message": f"Deployment {deployment_id} removed"})
    else:
        raise HTTPException(status_code=404, detail="Deployment not found")

@app.get("/api/stats")
def get_deployment_stats():
    """Get deployment statistics"""
    return JSONResponse(mesh_deployer.get_deployment_stats())

@app.put("/api/deployment/{deployment_id}/status")
def update_deployment_status(deployment_id: str, status: str):
    """Update deployment status"""
    try:
        mesh_deployer.update_deployment_status(deployment_id, status)
        return JSONResponse({"status": "success", "message": f"Deployment {deployment_id} status updated"})
    except Exception as e:
        logger.error(f"Status update failed: {e}")
        raise HTTPException(status_code=500, detail=f"Status update failed: {str(e)}")

@app.get("/health")
def health_check():
    """Health check endpoint"""
    stats = mesh_deployer.get_deployment_stats()
    return {
        "status": "healthy",
        "service": "DarCloud Mesh Website Deployer",
        "deployments_count": stats["total_deployments"],
        "active_deployments": stats["active_deployments"],
        "mesh_nodes": stats["mesh_nodes"],
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

def main():
    """Start DarCloud Mesh Website Deployer"""
    logger.info("🌐 Starting DarCloud Mesh Website Deployer on port 8084")
    uvicorn.run(app, host="0.0.0.0", port=8084)

if __name__ == "__main__":
    main()