#!/usr/bin/env python3
"""
Complete Revenue Automation System
Monitors crypto payments → Auto-sells to USD → Tracks revenue
© QuranChain™ | Omar Mohammad Abunadi™
"""

import time
import requests
import sys
from datetime import datetime
sys.path.insert(0, "crm")
from crm.database import CRMDatabase, RevenueEvent
from kraken_auto_cashout import KrakenAutoSeller

# Configuration
FOUNDER_WALLET = '0x49F3Ad3f8d3A3F1E677DEe8B1abf9A76f3cE2422'  # Founder Ethereum wallet address
CRYPTO_BRIDGE_URL = 'http://localhost:7500'
CHECK_INTERVAL = 300  # 5 minutes

class CompleteRevenueAutomation:
    """Automated revenue collection and conversion"""
    
    def __init__(self):
        self.crm = CRMDatabase()
        self.kraken = KrakenAutoSeller()
        self.last_check = {}
        
        print("\n" + "="*70)
        print("🚀 COMPLETE REVENUE AUTOMATION INITIALIZED")
        print("="*70)
        print(f"   Founder Wallet: {FOUNDER_WALLET}")
        print(f"   Check Interval: {CHECK_INTERVAL}s")
        print(f"   Kraken Auto-Sell: ✅ READY")
        print("="*70 + "\n")
    
    def check_crypto_payments(self) -> dict:
        """Check for new crypto payments"""
        try:
            resp = requests.get(f"{CRYPTO_BRIDGE_URL}/check-balances", timeout=5)
            balances = resp.json()
            return balances.get('wallets', {})
        except Exception as e:
            print(f"⚠️  Crypto bridge error: {e}")
            return {}
    
    def process_payment(self, crypto: str, amount: float, usd_value: float):
        """Process a detected payment"""
        print(f"\n{'='*70}")
        print(f"💰 NEW PAYMENT DETECTED!")
        print(f"{'='*70}")
        print(f"   Crypto: {crypto}")
        print(f"   Amount: {amount}")
        print(f"   USD Value: ${usd_value:,.2f}")
        
        # Calculate founder royalty (30%)
        founder_royalty = usd_value * 0.30
        merchant_share = usd_value * 0.70
        
        print(f"\n   Founder Royalty (30%): ${founder_royalty:,.2f}")
        print(f"   Merchant Share (70%): ${merchant_share:,.2f}")
        
        # Auto-sell to USD on Kraken
        if amount > 0.001:  # Minimum threshold
            print(f"\n🔄 Auto-selling {amount} {crypto} to USD on Kraken...")
            result = self.kraken.sell_crypto_to_usd(crypto, amount)
            
            if result.get('success'):
                print(f"   ✅ Sold to USD - Order ID: {result.get('order_id')}")
                
                # Record revenue in CRM
                revenue = RevenueEvent(
                    id=None,
                    source='crypto_payment',
                    event_type='crypto_to_usd_conversion',
                    amount=usd_value,
                    currency='USD',
                    merchant_id=None,
                    deal_id=None,
                    ai_agent='kraken_auto_cashout',
                    founder_royalty=founder_royalty,
                    metadata=f'{{"crypto": "{crypto}", "amount": {amount}, "order_id": "{result.get("order_id")}"}}',
                    timestamp=''
                )
                self.crm.record_revenue(revenue)
                print(f"   ✅ Revenue recorded in CRM")
                
                return True
            else:
                print(f"   ❌ Sell failed: {result.get('error')}")
                return False
        else:
            print(f"   ⏸️  Amount too small, holding for accumulation")
            return False
    
    def monitor_loop(self):
        """Continuous monitoring loop"""
        print("🔍 Starting continuous revenue monitoring...\n")
        
        while True:
            try:
                # Check crypto balances
                wallets = self.check_crypto_payments()
                
                for crypto, wallet_data in wallets.items():
                    balance = wallet_data.get('balance', 0)
                    usd_value = wallet_data.get('balance_usd', 0)
                    
                    # Check if balance increased
                    last_balance = self.last_check.get(crypto, 0)
                    
                    if balance > last_balance and usd_value > 0:
                        # New payment detected!
                        new_amount = balance - last_balance
                        new_usd = usd_value - self.last_check.get(f'{crypto}_usd', 0)
                        
                        self.process_payment(crypto, new_amount, new_usd)
                    
                    # Update last check
                    self.last_check[crypto] = balance
                    self.last_check[f'{crypto}_usd'] = usd_value
                
                # Show status
                timestamp = datetime.now().strftime("%H:%M:%S")
                print(f"[{timestamp}] ✓ Checked - Next check in {CHECK_INTERVAL}s")
                
                time.sleep(CHECK_INTERVAL)
                
            except KeyboardInterrupt:
                print("\n\n⏹️  Monitoring stopped by user")
                break
            except Exception as e:
                print(f"\n⚠️  Error: {e}")
                time.sleep(60)  # Wait 1 min on error
    
    def get_revenue_summary(self):
        """Get complete revenue summary"""
        stats = self.crm.get_revenue_summary(30)
        
        print("\n" + "="*70)
        print("📊 COMPLETE REVENUE SUMMARY (Last 30 Days)")
        print("="*70)
        print(f"   Total Revenue: ${stats['total_revenue']:,.2f}")
        print(f"   Founder Royalty (30%): ${stats['founder_royalty']:,.2f}")
        print(f"   Monthly Recurring: ${stats['total_revenue']:,.2f}/mo")
        print(f"   Annual Recurring: ${stats['total_revenue'] * 12:,.2f}/yr")
        print("="*70 + "\n")
        
        return stats


def main():
    """Main entry point"""
    automation = CompleteRevenueAutomation()
    
    # Show current status
    automation.get_revenue_summary()
    
    # Check Kraken balance
    print("💰 Kraken Account Balance:")
    balance = automation.kraken.get_balance()
    if 'result' in balance:
        if balance['result']:
            for curr, amt in balance['result'].items():
                if float(amt) > 0:
                    print(f"   {curr}: {amt}")
        else:
            print("   (empty - ready for incoming payments)")
    print()
    
    # Start monitoring
    print("Starting automated monitoring in 5 seconds...")
    print("Press Ctrl+C to stop\n")
    time.sleep(5)
    
    automation.monitor_loop()


if __name__ == '__main__':
    main()
