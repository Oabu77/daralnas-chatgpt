#!/usr/bin/env python3
"""
☁️ DARCLOUD PERSONAL CLOUD SERVICE
iCloud-like personal cloud storage, backup, and sync
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import json
import time
import logging
import hashlib
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, BinaryIO
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Depends
from fastapi.responses import JSONResponse, StreamingResponse
import uvicorn

# Add project root to path
sys.path.insert(0, "/home/omar/Desktop/QuranChain")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] ☁️ PERSONAL - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(title="DarCloud Personal Cloud", version="1.0.0")

# Personal cloud storage
PERSONAL_DIR = Path("/home/omar/Desktop/QuranChain/darcloud_personal")
PERSONAL_DIR.mkdir(exist_ok=True)

USERS_DIR = PERSONAL_DIR / "users"
USERS_DIR.mkdir(exist_ok=True)

class PersonalCloudEngine:
    """iCloud-like personal cloud storage"""

    def __init__(self):
        self.users = {}
        self.devices = {}
        self.files = {}
        self.load_personal_registry()
        logger.info("☁️ Personal Cloud Engine initialized")

    def load_personal_registry(self):
        """Load personal cloud registry"""
        registry_file = PERSONAL_DIR / "personal_registry.json"
        if registry_file.exists():
            try:
                with open(registry_file, 'r') as f:
                    data = json.load(f)
                    self.users = data.get('users', {})
                    self.devices = data.get('devices', {})
                    self.files = data.get('files', {})
                logger.info(f"📋 Loaded personal cloud with {len(self.users)} users")
            except Exception as e:
                logger.error(f"Failed to load personal registry: {e}")

    def save_personal_registry(self):
        """Save personal cloud registry"""
        registry_file = PERSONAL_DIR / "personal_registry.json"
        try:
            data = {
                'users': self.users,
                'devices': self.devices,
                'files': self.files,
                'last_updated': datetime.utcnow().isoformat() + "Z"
            }
            with open(registry_file, 'w') as f:
                json.dump(data, f, indent=2)
            logger.info("💾 Personal cloud registry saved")
        except Exception as e:
            logger.error(f"Failed to save personal registry: {e}")

    def create_user_account(self, user_id: str, email: str, name: str = "User") -> Dict:
        """Create iCloud-like user account"""

        if user_id in self.users:
            raise ValueError(f"User {user_id} already exists")

        # Create user directory
        user_path = USERS_DIR / user_id
        user_path.mkdir(exist_ok=True)

        # Create subdirectories like iCloud
        (user_path / "Documents").mkdir(exist_ok=True)
        (user_path / "Photos").mkdir(exist_ok=True)
        (user_path / "Backup").mkdir(exist_ok=True)
        (user_path / "Desktop").mkdir(exist_ok=True)
        (user_path / "Drive").mkdir(exist_ok=True)

        # Create user account
        user_info = {
            "user_id": user_id,
            "email": email,
            "name": name,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "storage_quota_gb": 1000,  # 1TB like iCloud
            "storage_used_gb": 0,
            "devices": [],
            "features": [
                "iCloud Photos",
                "iCloud Drive",
                "iCloud Backup",
                "Find My",
                "iCloud Keychain",
                "BlockChain Storage"
            ],
            "blockchain_stored": True,
            "auto_backup": True,
            "family_sharing": False
        }

        self.users[user_id] = user_info
        self.save_personal_registry()

        logger.info(f"👤 Created iCloud account for {email}")
        return user_info

    def register_device(self, user_id: str, device_id: str, device_name: str, device_type: str = "iPhone") -> Dict:
        """Register device for iCloud sync"""

        if user_id not in self.users:
            raise ValueError(f"User {user_id} does not exist")

        device_info = {
            "device_id": device_id,
            "device_name": device_name,
            "device_type": device_type,
            "user_id": user_id,
            "registered_at": datetime.utcnow().isoformat() + "Z",
            "last_sync": None,
            "storage_used_gb": 0,
            "backup_enabled": True,
            "find_my_enabled": True
        }

        device_key = f"{user_id}/{device_id}"
        self.devices[device_key] = device_info

        # Add to user's devices
        if device_id not in self.users[user_id]["devices"]:
            self.users[user_id]["devices"].append(device_id)

        self.save_personal_registry()

        logger.info(f"📱 Registered {device_type} {device_name} for {user_id}")
        return device_info

    def upload_file(self, user_id: str, file_path: str, file_data: bytes, category: str = "Documents") -> Dict:
        """Upload file to personal cloud (iCloud-like)"""

        if user_id not in self.users:
            raise ValueError(f"User {user_id} does not exist")

        # Calculate hash and size
        file_hash = hashlib.sha256(file_data).hexdigest()
        file_size = len(file_data)
        file_size_gb = file_size / (1024**3)

        # Check storage quota
        user = self.users[user_id]
        if user["storage_used_gb"] + file_size_gb > user["storage_quota_gb"]:
            raise ValueError("Storage quota exceeded")

        # Create file path
        user_path = USERS_DIR / user_id / category
        user_path.mkdir(exist_ok=True)

        file_name = Path(file_path).name
        storage_path = user_path / file_name

        # Save file
        with open(storage_path, 'wb') as f:
            f.write(file_data)

        # Create file metadata
        file_info = {
            "user_id": user_id,
            "file_path": file_path,
            "file_name": file_name,
            "category": category,
            "file_hash": file_hash,
            "size_bytes": file_size,
            "size_gb": round(file_size_gb, 4),
            "uploaded_at": datetime.utcnow().isoformat() + "Z",
            "last_modified": datetime.utcnow().isoformat() + "Z",
            "storage_path": str(storage_path),
            "blockchain_tx_id": f"qc_personal_{file_hash[:16]}",
            "blockchain_stored": True,
            "sync_status": "synced",
            "versions": 1
        }

        # Store in files registry
        file_key = f"{user_id}/{file_path}"
        if file_key not in self.files:
            self.files[file_key] = []

        self.files[file_key].append(file_info)

        # Update user storage
        user["storage_used_gb"] += file_size_gb
        self.save_personal_registry()

        logger.info(f"📤 Uploaded {file_name} to {user_id}'s {category} ({file_size} bytes)")
        return file_info

    def download_file(self, user_id: str, file_path: str) -> Optional[bytes]:
        """Download file from personal cloud"""
        file_key = f"{user_id}/{file_path}"
        if file_key in self.files and self.files[file_key]:
            file_info = self.files[file_key][-1]  # Latest version
            storage_path = Path(file_info["storage_path"])

            if storage_path.exists():
                with open(storage_path, 'rb') as f:
                    return f.read()

        return None

    def list_files(self, user_id: str, category: str = None) -> List[Dict]:
        """List user's files (iCloud-like)"""
        if user_id not in self.users:
            return []

        files = []
        for file_key, versions in self.files.items():
            if file_key.startswith(f"{user_id}/"):
                file_info = versions[-1]  # Latest version
                if category is None or file_info["category"] == category:
                    files.append({
                        "file_path": file_info["file_path"],
                        "file_name": file_info["file_name"],
                        "category": file_info["category"],
                        "size_gb": file_info["size_gb"],
                        "uploaded_at": file_info["uploaded_at"],
                        "sync_status": file_info["sync_status"]
                    })

        return files

    def get_user_storage_stats(self, user_id: str) -> Optional[Dict]:
        """Get user's storage statistics"""
        if user_id not in self.users:
            return None

        user = self.users[user_id]
        return {
            "user_id": user_id,
            "storage_quota_gb": user["storage_quota_gb"],
            "storage_used_gb": round(user["storage_used_gb"], 2),
            "storage_available_gb": round(user["storage_quota_gb"] - user["storage_used_gb"], 2),
            "usage_percentage": round((user["storage_used_gb"] / user["storage_quota_gb"]) * 100, 1),
            "devices_count": len(user["devices"]),
            "files_count": len([f for f in self.files.keys() if f.startswith(f"{user_id}/")]),
            "categories": list(set(f.split("/")[1] for f in self.files.keys() if f.startswith(f"{user_id}/")))
        }

    def create_backup(self, user_id: str, device_id: str) -> Dict:
        """Create device backup (iCloud-like)"""
        device_key = f"{user_id}/{device_id}"
        if device_key not in self.devices:
            raise ValueError(f"Device {device_id} not registered for user {user_id}")

        backup_info = {
            "backup_id": f"backup_{int(time.time())}",
            "user_id": user_id,
            "device_id": device_id,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "size_gb": 0,  # Would be calculated from actual backup
            "status": "completed",
            "blockchain_stored": True,
            "incremental": True
        }

        # Update device last sync
        self.devices[device_key]["last_sync"] = backup_info["created_at"]

        self.save_personal_registry()

        logger.info(f"💾 Created backup for {device_id} of user {user_id}")
        return backup_info

    def get_personal_stats(self) -> Dict:
        """Get personal cloud statistics"""
        total_users = len(self.users)
        total_devices = len(self.devices)
        total_files = len(self.files)
        total_storage_gb = sum(user["storage_used_gb"] for user in self.users.values())

        return {
            "total_users": total_users,
            "total_devices": total_devices,
            "total_files": total_files,
            "total_storage_gb": round(total_storage_gb, 2),
            "average_storage_per_user_gb": round(total_storage_gb / max(total_users, 1), 2),
            "features": ["iCloud Photos", "iCloud Drive", "iCloud Backup", "Find My", "Blockchain Storage"],
            "storage_backend": "QuranChain Blockchain"
        }

# Global personal cloud engine
personal_cloud = PersonalCloudEngine()

# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.get("/")
def root():
    """DarCloud Personal Cloud Dashboard"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>☁️ DarCloud Personal Cloud</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .header {{ background: linear-gradient(135deg, #007AFF 0%, #5856D6 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
            .stat-card {{ background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }}
            .stat-number {{ font-size: 2em; font-weight: bold; color: #007AFF; }}
            .users {{ margin-top: 30px; }}
            .user-card {{ background: white; margin: 10px 0; padding: 15px; border-radius: 8px; box-shadow: 0 1px 5px rgba(0,0,0,0.1); }}
            .icloud-info {{ background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 20px 0; }}
            .icloud-tag {{ display: inline-block; background: #007AFF; color: white; padding: 5px 10px; margin: 2px; border-radius: 15px; font-size: 0.9em; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>☁️ DarCloud Personal Cloud</h1>
            <p>iCloud-like Personal Storage & Backup</p>
            <p><strong>Owner:</strong> Omar Mohammad Abunadi™</p>
        </div>

        <div class="icloud-info">
            <h3>📱 iCloud-like Features</h3>
            <span class="icloud-tag">iCloud Photos</span>
            <span class="icloud-tag">iCloud Drive</span>
            <span class="icloud-tag">iCloud Backup</span>
            <span class="icloud-tag">Find My</span>
            <span class="icloud-tag">1TB Storage</span>
            <span class="icloud-tag">Blockchain Backend</span>
        </div>
    """

    stats = personal_cloud.get_personal_stats()
    html_content += f"""
        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">{stats['total_users']}</div>
                <div>iCloud Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['total_devices']}</div>
                <div>Devices</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['total_files']}</div>
                <div>Files Stored</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{stats['total_storage_gb']}GB</div>
                <div>Storage Used</div>
            </div>
        </div>

        <div class="users">
            <h2>👥 iCloud Users</h2>
    """

    for user_id, user in personal_cloud.users.items():
        storage_stats = personal_cloud.get_user_storage_stats(user_id)
        if storage_stats:
            html_content += f"""
                <div class="user-card">
                    <h3>{user['name']}</h3>
                    <p><strong>Email:</strong> {user['email']}</p>
                    <p><strong>Storage:</strong> {storage_stats['storage_used_gb']}GB / {storage_stats['storage_quota_gb']}GB</p>
                    <p><strong>Devices:</strong> {storage_stats['devices_count']}</p>
                    <p><strong>Files:</strong> {storage_stats['files_count']}</p>
                    <p><strong>Blockchain Stored:</strong> ✅</p>
                </div>
            """

    html_content += """
        </div>
    </body>
    </html>
    """

    return HTMLResponse(content=html_content)

@app.post("/users")
def create_user(user_id: str, email: str, name: str = "User"):
    """Create iCloud user account"""
    try:
        result = personal_cloud.create_user_account(user_id, email, name)
        return JSONResponse({
            "status": "success",
            "message": f"iCloud account created for {email}",
            "data": result
        })
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"User creation failed: {e}")
        raise HTTPException(status_code=500, detail=f"User creation failed: {str(e)}")

@app.post("/users/{user_id}/devices")
def register_device(user_id: str, device_id: str, device_name: str, device_type: str = "iPhone"):
    """Register device for iCloud"""
    try:
        result = personal_cloud.register_device(user_id, device_id, device_name, device_type)
        return JSONResponse({
            "status": "success",
            "message": f"Device {device_name} registered for {user_id}",
            "data": result
        })
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Device registration failed: {e}")
        raise HTTPException(status_code=500, detail=f"Device registration failed: {str(e)}")

@app.put("/users/{user_id}/files")
async def upload_file(
    user_id: str,
    file_path: str,
    category: str = "Documents",
    file: UploadFile = File(...)
):
    """Upload file to personal cloud"""
    try:
        file_data = await file.read()
        result = personal_cloud.upload_file(user_id, file_path, file_data, category)
        return JSONResponse({
            "status": "success",
            "message": f"File uploaded to {user_id}'s {category}",
            "data": result
        })
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"File upload failed: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@app.get("/users/{user_id}/files")
def list_files(user_id: str, category: str = None):
    """List user's files"""
    try:
        files = personal_cloud.list_files(user_id, category)
        return JSONResponse({
            "user_id": user_id,
            "files": files,
            "total": len(files)
        })
    except Exception as e:
        logger.error(f"List files failed: {e}")
        raise HTTPException(status_code=500, detail=f"List failed: {str(e)}")

@app.get("/users/{user_id}/files/download")
def download_file(user_id: str, file_path: str):
    """Download file from personal cloud"""
    try:
        file_data = personal_cloud.download_file(user_id, file_path)
        if file_data is None:
            raise HTTPException(status_code=404, detail="File not found")

        file_name = Path(file_path).name
        return StreamingResponse(
            iter([file_data]),
            media_type="application/octet-stream",
            headers={"Content-Disposition": f"attachment; filename={file_name}"}
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"File download failed: {e}")
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")

@app.get("/users/{user_id}/storage")
def get_user_storage(user_id: str):
    """Get user's storage statistics"""
    try:
        stats = personal_cloud.get_user_storage_stats(user_id)
        if stats is None:
            raise HTTPException(status_code=404, detail="User not found")

        return JSONResponse(stats)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Storage stats failed: {e}")
        raise HTTPException(status_code=500, detail=f"Storage stats failed: {str(e)}")

@app.post("/users/{user_id}/devices/{device_id}/backup")
def create_backup(user_id: str, device_id: str):
    """Create device backup"""
    try:
        result = personal_cloud.create_backup(user_id, device_id)
        return JSONResponse({
            "status": "success",
            "message": f"Backup created for device {device_id}",
            "data": result
        })
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Backup creation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Backup failed: {str(e)}")

@app.get("/users")
def list_users():
    """List all iCloud users"""
    return JSONResponse({
        "users": list(personal_cloud.users.values()),
        "total": len(personal_cloud.users)
    })

@app.get("/stats")
def get_personal_stats():
    """Get personal cloud statistics"""
    return JSONResponse(personal_cloud.get_personal_stats())

@app.get("/health")
def health_check():
    """Health check endpoint"""
    stats = personal_cloud.get_personal_stats()
    return {
        "status": "healthy",
        "service": "DarCloud Personal Cloud",
        "users_count": stats["total_users"],
        "devices_count": stats["total_devices"],
        "files_count": stats["total_files"],
        "storage_used_gb": stats["total_storage_gb"],
        "blockchain_backend": "QuranChain",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

def main():
    """Start DarCloud Personal Cloud Service"""
    logger.info("☁️ Starting DarCloud Personal Cloud Service on port 8086")
    uvicorn.run(app, host="0.0.0.0", port=8091)

if __name__ == "__main__":
    main()