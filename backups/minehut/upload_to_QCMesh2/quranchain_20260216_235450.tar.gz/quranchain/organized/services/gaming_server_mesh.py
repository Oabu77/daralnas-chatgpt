#!/usr/bin/env python3
"""
🎮🕸️ GAMING SERVER MESH ENGINE - Fungi Mesh on Free Gaming Infrastructure
═══════════════════════════════════════════════════════════════════════════════
Deploys Fungi Mesh relay/storage nodes onto free gaming server platforms:
  - Minecraft servers (Aternos, Minehut, server.pro free tier)
  - Discord bots (always-online via free hosting)
  - Roblox game servers (Roblox Studio cloud)
  - Steam Workshop / Garry's Mod servers
  - CS2 community servers
  - Terraria tShock servers

Strategy: Gaming servers have 99.9% uptime, free tiers, and are globally
distributed. We embed lightweight mesh relay logic inside game server
plugins/mods, turning every free gaming server into a Fungi Mesh node.
The mesh data travels as encoded game chat messages, custom packets,
or plugin data channels — always reachable, always free.

Founder: Omar Mohammad Abunadi™
Status: PRODUCTION — Gaming infrastructure = free mesh backbone

❌ NEVER modify 30% founder royalty (FOUNDER_ROYALTY_RATE = 0.30)
"""

import os
import sys
import json
import time
import socket
import hashlib
import logging
import base64
import struct
import threading
import asyncio
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Set, Tuple
from enum import Enum
from pathlib import Path
import uuid

sys.path.insert(0, "/home/omar/Desktop/QuranChain")

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(name)s %(message)s")
logger = logging.getLogger("GamingServerMesh")

FOUNDER_ROYALTY_RATE = 0.30  # IMMUTABLE

# ============================================================================
# CONSTANTS
# ============================================================================

DARCLOUD_REGISTRY = "https://darcloud.host/api/mesh/gaming-nodes"
MESH_DATA_PREFIX = b"QCMESH:"           # Prefix to identify mesh data in game packets
MESH_PROTOCOL_VERSION = 1
MAX_CHUNK_SIZE = 4096                     # Max payload per game message
HEARTBEAT_INTERVAL = 30                   # Seconds between keepalives
RECONNECT_DELAY = 10                      # Seconds before reconnect attempt
DATA_ENCODING = "base85"                  # Compact encoding for game chat

# ============================================================================
# GAMING PLATFORM REGISTRY
# ============================================================================

class GamingPlatform(Enum):
    """Supported free gaming server platforms"""
    MINECRAFT_ATERNOS = "minecraft_aternos"
    MINECRAFT_MINEHUT = "minecraft_minehut"
    MINECRAFT_SERVER_PRO = "minecraft_server_pro"
    DISCORD_BOT = "discord_bot"
    ROBLOX_CLOUD = "roblox_cloud"
    STEAM_WORKSHOP = "steam_workshop"
    GMOD_SERVER = "gmod_server"
    CS2_COMMUNITY = "cs2_community"
    TERRARIA_TSHOCK = "terraria_tshock"
    VALHEIM_SERVER = "valheim_server"
    ARK_NITRADO_FREE = "ark_nitrado_free"
    FACTORIO_HEADLESS = "factorio_headless"


class NodeRole(Enum):
    """Role of a gaming server node in the mesh"""
    RELAY = "relay"              # Forward mesh packets between nodes
    STORAGE = "storage"          # Store mesh data chunks (DHT-style)
    BRIDGE = "bridge"            # Bridge between gaming platforms
    BOOTSTRAP = "bootstrap"      # Entry point for new nodes
    CACHE = "cache"              # Cache frequently accessed data


class GamingNodeStatus(Enum):
    """Status of a gaming server mesh node"""
    PROVISIONING = "provisioning"
    DEPLOYING_PLUGIN = "deploying_plugin"
    CONNECTING = "connecting"
    ONLINE = "online"
    DEGRADED = "degraded"
    OFFLINE = "offline"
    BANNED = "banned"              # Server removed our plugin


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class GamingServerNode:
    """Represents a Fungi Mesh node running on a gaming server"""
    node_id: str
    platform: GamingPlatform
    server_name: str
    server_address: str
    server_port: int
    role: NodeRole = NodeRole.RELAY
    status: GamingNodeStatus = GamingNodeStatus.PROVISIONING
    region: str = "us-east"
    max_storage_mb: float = 50.0        # Free tier storage limit
    current_storage_mb: float = 0.0
    data_chunks_stored: int = 0
    packets_relayed: int = 0
    uptime_percent: float = 99.0
    last_heartbeat: datetime = field(default_factory=datetime.now)
    last_error: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict:
        return {
            "node_id": self.node_id,
            "platform": self.platform.value,
            "server_name": self.server_name,
            "server_address": self.server_address,
            "server_port": self.server_port,
            "role": self.role.value,
            "status": self.status.value,
            "region": self.region,
            "max_storage_mb": self.max_storage_mb,
            "current_storage_mb": self.current_storage_mb,
            "data_chunks_stored": self.data_chunks_stored,
            "packets_relayed": self.packets_relayed,
            "uptime_percent": self.uptime_percent,
            "last_heartbeat": self.last_heartbeat.isoformat(),
            "last_error": self.last_error,
            "metadata": self.metadata,
            "created_at": self.created_at,
        }


@dataclass
class MeshDataChunk:
    """A chunk of mesh data stored across gaming servers"""
    chunk_id: str
    data_hash: str
    data: bytes
    size_bytes: int
    replicas: List[str] = field(default_factory=list)     # node_ids holding copies
    min_replicas: int = 3
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    expires_at: Optional[str] = None
    chunk_type: str = "mesh_state"       # mesh_state, transaction, routing_table, peer_list


# ============================================================================
# FREE GAMING SERVER CONFIGURATIONS
# ============================================================================

FREE_GAMING_SERVERS: Dict[str, Dict] = {
    # ── Minecraft Platforms (Plugin Channel for data) ──────────────
    "aternos_eu_1": {
        "platform": GamingPlatform.MINECRAFT_ATERNOS,
        "name": "QuranChain-Mesh-EU-1",
        "address": "aternos.me",
        "port": 25565,
        "region": "eu-west",
        "protocol": "minecraft_plugin_channel",
        "max_storage_mb": 100,
        "notes": "Free Minecraft server, auto-start via API, plugin messaging channel for data",
        "setup_url": "https://aternos.org",
        "data_channel": "quranchain:mesh",
    },
    "aternos_us_1": {
        "platform": GamingPlatform.MINECRAFT_ATERNOS,
        "name": "QuranChain-Mesh-US-1",
        "address": "aternos.me",
        "port": 25565,
        "region": "us-east",
        "protocol": "minecraft_plugin_channel",
        "max_storage_mb": 100,
        "setup_url": "https://aternos.org",
        "data_channel": "quranchain:mesh",
    },
    "minehut_relay_1": {
        "platform": GamingPlatform.MINECRAFT_MINEHUT,
        "name": "QCMesh1",
        "address": "QCMesh1.minehut.gg",
        "port": 25565,
        "region": "us-east",
        "protocol": "minecraft_plugin_channel",
        "max_storage_mb": 50,
        "notes": "Free Minehut server, Spigot plugin support — create QCMesh1 on minehut.com",
        "setup_url": "https://minehut.com",
        "data_channel": "quranchain:mesh",
    },
    "minehut_relay_2": {
        "platform": GamingPlatform.MINECRAFT_MINEHUT,
        "name": "QCMesh2",
        "address": "QCMesh2.minehut.gg",
        "port": 25565,
        "region": "eu-west",
        "protocol": "minecraft_plugin_channel",
        "max_storage_mb": 50,
        "notes": "LIVE — 60ms response, created 2026-02-13",
        "setup_url": "https://minehut.com",
        "data_channel": "quranchain:mesh",
    },
    "server_pro_free_1": {
        "platform": GamingPlatform.MINECRAFT_SERVER_PRO,
        "name": "QC-Mesh-Bridge-1",
        "address": "server.pro",
        "port": 25565,
        "region": "us-central",
        "protocol": "minecraft_plugin_channel",
        "max_storage_mb": 75,
        "notes": "Free server.pro tier, BungeeCord plugin channel support",
        "setup_url": "https://server.pro",
        "data_channel": "quranchain:mesh",
    },

    # ── Discord Bots (WebSocket relay, always online) ─────────────
    "discord_relay_1": {
        "platform": GamingPlatform.DISCORD_BOT,
        "name": "QC-Mesh-Discord-Relay",
        "address": "discord.com",
        "port": 443,
        "region": "global",
        "protocol": "discord_websocket",
        "max_storage_mb": 25,
        "notes": "Discord bot on free hosting (Railway/Render/Replit). Message embeds carry mesh data. Always reachable via Discord API.",
        "setup_url": "https://discord.dev",
        "data_channel": "mesh-relay-channel",
    },
    "discord_storage_1": {
        "platform": GamingPlatform.DISCORD_BOT,
        "name": "QC-Mesh-Discord-Storage",
        "address": "discord.com",
        "port": 443,
        "region": "global",
        "protocol": "discord_websocket",
        "max_storage_mb": 200,
        "notes": "Uses Discord message attachments as chunk storage (8MB per file, unlimited messages)",
        "data_channel": "mesh-storage-channel",
    },

    # ── Roblox (DataStore API for persistence) ────────────────────
    "roblox_mesh_1": {
        "platform": GamingPlatform.ROBLOX_CLOUD,
        "name": "QC-Mesh-Roblox-1",
        "address": "roblox.com",
        "port": 443,
        "region": "global",
        "protocol": "roblox_messaging_service",
        "max_storage_mb": 100,
        "notes": "Roblox game with MessagingService for real-time relay + DataStoreService for persistent storage. Free tier, always available.",
        "setup_url": "https://create.roblox.com",
        "data_channel": "QuranChainMesh",
    },

    # ── Steam / Garry's Mod (Lua addon data) ──────────────────────
    "gmod_relay_1": {
        "platform": GamingPlatform.GMOD_SERVER,
        "name": "QC-Mesh-GMod-1",
        "address": "0.0.0.0",
        "port": 27015,
        "region": "us-east",
        "protocol": "source_engine_rcon",
        "max_storage_mb": 50,
        "notes": "Free GMod server via NFOservers/free hosting. Lua addon handles mesh relay via net library.",
        "data_channel": "qc_mesh_net",
    },

    # ── CS2 Community Server ──────────────────────────────────────
    "cs2_community_1": {
        "platform": GamingPlatform.CS2_COMMUNITY,
        "name": "QC-Mesh-CS2-1",
        "address": "0.0.0.0",
        "port": 27015,
        "region": "eu-west",
        "protocol": "source_engine_rcon",
        "max_storage_mb": 25,
        "notes": "Free CS2 community server, SourceMod plugin for mesh relay",
        "data_channel": "qc_mesh",
    },

    # ── Terraria (tShock plugin) ──────────────────────────────────
    "terraria_relay_1": {
        "platform": GamingPlatform.TERRARIA_TSHOCK,
        "name": "QC-Mesh-Terraria-1",
        "address": "0.0.0.0",
        "port": 7777,
        "region": "us-east",
        "protocol": "terraria_tshock_rest",
        "max_storage_mb": 50,
        "notes": "Free Terraria server with TShock REST API for mesh data relay",
        "data_channel": "/v2/mesh",
    },

    # ── Valheim ───────────────────────────────────────────────────
    "valheim_mesh_1": {
        "platform": GamingPlatform.VALHEIM_SERVER,
        "name": "QC-Mesh-Valheim-1",
        "address": "0.0.0.0",
        "port": 2456,
        "region": "us-west",
        "protocol": "valheim_modded",
        "max_storage_mb": 50,
        "notes": "Free Valheim server (PlayIt.gg tunneled). BepInEx mod for mesh relay.",
        "data_channel": "QCMesh",
    },

    # ── Factorio Headless (free, lightweight) ─────────────────────
    "factorio_relay_1": {
        "platform": GamingPlatform.FACTORIO_HEADLESS,
        "name": "QC-Mesh-Factorio-1",
        "address": "0.0.0.0",
        "port": 34197,
        "region": "us-central",
        "protocol": "factorio_rcon",
        "max_storage_mb": 40,
        "notes": "Free headless Factorio server on Oracle Cloud free tier. RCON for mesh commands.",
        "data_channel": "/qcmesh",
    },
}


# ============================================================================
# MESH DATA ENCODING — Fits inside game chat/packets
# ============================================================================

def encode_mesh_packet(data: bytes, chunk_id: str = "") -> str:
    """Encode mesh data as a game-safe string (base85 is compact & printable)"""
    header = struct.pack("!BH16s", MESH_PROTOCOL_VERSION, len(data),
                         chunk_id.encode()[:16].ljust(16, b'\x00'))
    payload = MESH_DATA_PREFIX + header + data
    return base64.b85encode(payload).decode("ascii")


def decode_mesh_packet(encoded: str) -> Optional[Tuple[int, bytes, str]]:
    """Decode a mesh packet from game message. Returns (version, data, chunk_id)"""
    try:
        raw = base64.b85decode(encoded.encode("ascii"))
        if not raw.startswith(MESH_DATA_PREFIX):
            return None
        raw = raw[len(MESH_DATA_PREFIX):]
        version, length = struct.unpack("!BH", raw[:3])
        chunk_id = raw[3:19].rstrip(b'\x00').decode()
        data = raw[19:19 + length]
        return (version, data, chunk_id)
    except Exception:
        return None


def chunk_data(data: bytes, max_size: int = MAX_CHUNK_SIZE) -> List[bytes]:
    """Split data into chunks that fit in game messages"""
    return [data[i:i + max_size] for i in range(0, len(data), max_size)]


# ============================================================================
# PROTOCOL ADAPTERS — One per gaming platform
# ============================================================================

class MinecraftProtocolAdapter:
    """
    Minecraft Plugin Channel adapter.
    Uses the Minecraft protocol's Plugin Message packets (channel: quranchain:mesh)
    to send/receive mesh data. Works on Spigot/Paper/BungeeCord servers.

    On the server side, a lightweight Spigot plugin listens on the custom channel
    and relays data between connected mesh nodes.
    """

    HANDSHAKE_PACKET_ID = 0x00
    PLUGIN_MESSAGE_ID = 0x17          # Serverbound plugin message (1.20.x)
    LOGIN_START_ID = 0x00

    def __init__(self, address: str, port: int, channel: str = "quranchain:mesh"):
        self.address = address
        self.port = port
        self.channel = channel
        self.socket: Optional[socket.socket] = None
        self.connected = False
        self.node_id = f"mc-{hashlib.sha256(f'{address}:{port}'.encode()).hexdigest()[:12]}"

    def connect(self) -> bool:
        """Connect to Minecraft server using MC protocol handshake"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(10)
            self.socket.connect((self.address, self.port))

            # Send Minecraft handshake (protocol state=2 for login)
            self._send_handshake()
            self.connected = True
            logger.info(f"🎮 Connected to Minecraft server {self.address}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"🎮 Minecraft connect failed ({self.address}): {e}")
            self.connected = False
            return False

    def _send_handshake(self):
        """Send MC protocol handshake packet"""
        # Handshake: protocol version (767 = 1.21), server address, port, next state (2=login)
        data = self._encode_varint(767)
        data += self._encode_string(self.address)
        data += struct.pack("!H", self.port)
        data += self._encode_varint(2)  # Next state: login
        self._send_packet(self.HANDSHAKE_PACKET_ID, data)

    def send_mesh_data(self, payload: bytes) -> bool:
        """Send mesh data through plugin channel"""
        if not self.connected or not self.socket:
            return False
        try:
            encoded = encode_mesh_packet(payload, self.node_id)
            channel_data = self._encode_string(self.channel) + encoded.encode()
            self._send_packet(self.PLUGIN_MESSAGE_ID, channel_data)
            return True
        except Exception as e:
            logger.error(f"🎮 MC send error: {e}")
            return False

    def receive_mesh_data(self, timeout: float = 5.0) -> Optional[bytes]:
        """Receive mesh data from plugin channel"""
        if not self.connected or not self.socket:
            return None
        try:
            self.socket.settimeout(timeout)
            raw = self.socket.recv(65536)
            if raw and MESH_DATA_PREFIX in raw:
                # Extract the encoded portion
                idx = raw.index(MESH_DATA_PREFIX)
                # Find the base85 boundary
                encoded_portion = raw[idx:]
                result = decode_mesh_packet(base64.b85encode(encoded_portion).decode())
                if result:
                    return result[1]
            return None
        except socket.timeout:
            return None
        except Exception as e:
            logger.error(f"🎮 MC recv error: {e}")
            return None

    def disconnect(self):
        if self.socket:
            try:
                self.socket.close()
            except Exception:
                pass
            self.connected = False

    def _send_packet(self, packet_id: int, data: bytes):
        """Send a Minecraft protocol packet"""
        packet = self._encode_varint(packet_id) + data
        length = self._encode_varint(len(packet))
        self.socket.sendall(length + packet)

    @staticmethod
    def _encode_varint(value: int) -> bytes:
        result = bytearray()
        while True:
            byte = value & 0x7F
            value >>= 7
            if value:
                byte |= 0x80
            result.append(byte)
            if not value:
                break
        return bytes(result)

    @staticmethod
    def _encode_string(s: str) -> bytes:
        encoded = s.encode("utf-8")
        return MinecraftProtocolAdapter._encode_varint(len(encoded)) + encoded


class DiscordBotAdapter:
    """
    Discord Bot adapter for mesh relay.
    Uses a Discord bot to relay mesh data through message embeds in a
    dedicated channel. Data is encoded as base85 in embed fields.
    Always reachable via Discord's 99.99% uptime infrastructure.
    """

    DISCORD_API = "https://discord.com/api/v10"

    def __init__(self, bot_token: str = "", channel_id: str = "", guild_id: str = ""):
        self.bot_token = bot_token or os.environ.get("DISCORD_MESH_BOT_TOKEN", "")
        self.channel_id = channel_id or os.environ.get("DISCORD_MESH_CHANNEL_ID", "")
        self.guild_id = guild_id or os.environ.get("DISCORD_MESH_GUILD_ID", "")
        self.node_id = f"discord-{hashlib.sha256(self.channel_id.encode()).hexdigest()[:12]}"
        self.connected = bool(self.bot_token and self.channel_id)

    def connect(self) -> bool:
        if not self.bot_token or not self.channel_id:
            logger.warning("🤖 Discord adapter: missing bot_token or channel_id")
            return False
        self.connected = True
        logger.info(f"🤖 Discord mesh relay ready (channel: {self.channel_id})")
        return True

    def send_mesh_data(self, payload: bytes) -> bool:
        """Send mesh data as a Discord message embed"""
        if not self.connected:
            return False
        try:
            import requests
            encoded = encode_mesh_packet(payload, self.node_id)
            # Split into 1024-char embed field values if needed
            fields = []
            for i in range(0, len(encoded), 1024):
                fields.append({
                    "name": f"mesh_chunk_{i // 1024}",
                    "value": f"```{encoded[i:i+1024]}```",
                    "inline": False,
                })

            message = {
                "embeds": [{
                    "title": "🕸️ Fungi Mesh Relay",
                    "color": 0x2ECC71,
                    "fields": fields[:25],  # Discord max 25 fields
                    "footer": {"text": f"QCMesh v{MESH_PROTOCOL_VERSION} | {self.node_id}"},
                    "timestamp": datetime.utcnow().isoformat(),
                }]
            }

            resp = requests.post(
                f"{self.DISCORD_API}/channels/{self.channel_id}/messages",
                headers={"Authorization": f"Bot {self.bot_token}", "Content-Type": "application/json"},
                json=message, timeout=10,
            )
            return resp.status_code in (200, 201)
        except Exception as e:
            logger.error(f"🤖 Discord send error: {e}")
            return False

    def receive_mesh_data(self, limit: int = 10) -> List[bytes]:
        """Fetch recent mesh data from Discord channel"""
        results = []
        if not self.connected:
            return results
        try:
            import requests
            resp = requests.get(
                f"{self.DISCORD_API}/channels/{self.channel_id}/messages?limit={limit}",
                headers={"Authorization": f"Bot {self.bot_token}"},
                timeout=10,
            )
            if resp.status_code == 200:
                for msg in resp.json():
                    for embed in msg.get("embeds", []):
                        for field_obj in embed.get("fields", []):
                            value = field_obj.get("value", "").strip("`")
                            decoded = decode_mesh_packet(value)
                            if decoded:
                                results.append(decoded[1])
        except Exception as e:
            logger.error(f"🤖 Discord recv error: {e}")
        return results

    def disconnect(self):
        self.connected = False


class RobloxCloudAdapter:
    """
    Roblox Open Cloud adapter.
    Uses Roblox Open Cloud API for MessagingService (real-time relay)
    and DataStore (persistent chunk storage). Free unlimited messages.
    """

    ROBLOX_API = "https://apis.roblox.com"

    def __init__(self, api_key: str = "", universe_id: str = ""):
        self.api_key = api_key or os.environ.get("ROBLOX_CLOUD_API_KEY", "")
        self.universe_id = universe_id or os.environ.get("ROBLOX_UNIVERSE_ID", "")
        self.node_id = f"roblox-{hashlib.sha256(self.universe_id.encode()).hexdigest()[:12]}"
        self.connected = bool(self.api_key and self.universe_id)

    def connect(self) -> bool:
        if not self.api_key or not self.universe_id:
            logger.warning("🎲 Roblox adapter: missing api_key or universe_id")
            return False
        self.connected = True
        logger.info(f"🎲 Roblox mesh node ready (universe: {self.universe_id})")
        return True

    def send_mesh_data(self, payload: bytes, topic: str = "QuranChainMesh") -> bool:
        """Publish mesh data to Roblox MessagingService"""
        if not self.connected:
            return False
        try:
            import requests
            encoded = encode_mesh_packet(payload, self.node_id)
            resp = requests.post(
                f"{self.ROBLOX_API}/messaging-service/v1/universes/{self.universe_id}/topics/{topic}",
                headers={"x-api-key": self.api_key, "Content-Type": "application/json"},
                json={"message": encoded},
                timeout=10,
            )
            return resp.status_code == 200
        except Exception as e:
            logger.error(f"🎲 Roblox send error: {e}")
            return False

    def store_chunk(self, chunk_id: str, data: bytes, datastore: str = "MeshStorage") -> bool:
        """Store a mesh data chunk in Roblox DataStore (persistent, free)"""
        if not self.connected:
            return False
        try:
            import requests
            encoded = base64.b85encode(data).decode()
            resp = requests.post(
                f"{self.ROBLOX_API}/datastores/v1/universes/{self.universe_id}/standard-datastores/datastore/entries/entry",
                headers={"x-api-key": self.api_key, "Content-Type": "application/json"},
                params={"datastoreName": datastore, "entryKey": chunk_id},
                json={"value": encoded},
                timeout=10,
            )
            return resp.status_code in (200, 201)
        except Exception as e:
            logger.error(f"🎲 Roblox store error: {e}")
            return False

    def retrieve_chunk(self, chunk_id: str, datastore: str = "MeshStorage") -> Optional[bytes]:
        """Retrieve a mesh data chunk from Roblox DataStore"""
        if not self.connected:
            return None
        try:
            import requests
            resp = requests.get(
                f"{self.ROBLOX_API}/datastores/v1/universes/{self.universe_id}/standard-datastores/datastore/entries/entry",
                headers={"x-api-key": self.api_key},
                params={"datastoreName": datastore, "entryKey": chunk_id},
                timeout=10,
            )
            if resp.status_code == 200:
                return base64.b85decode(resp.json().get("value", ""))
        except Exception as e:
            logger.error(f"🎲 Roblox retrieve error: {e}")
        return None

    def disconnect(self):
        self.connected = False


class SourceEngineAdapter:
    """
    Source Engine RCON adapter for Garry's Mod / CS2 / TF2 servers.
    Uses RCON protocol to execute commands that embed mesh data
    in server-side Lua/SourceMod plugin storage.
    """

    def __init__(self, address: str, port: int, rcon_password: str = ""):
        self.address = address
        self.port = port
        self.rcon_password = rcon_password or os.environ.get("GMOD_RCON_PASSWORD", "")
        self.socket: Optional[socket.socket] = None
        self.connected = False
        self.node_id = f"source-{hashlib.sha256(f'{address}:{port}'.encode()).hexdigest()[:12]}"
        self._request_id = 0

    def connect(self) -> bool:
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(10)
            self.socket.connect((self.address, self.port))

            # RCON auth
            self._request_id += 1
            auth_packet = self._build_rcon_packet(self._request_id, 3, self.rcon_password)
            self.socket.sendall(auth_packet)

            resp = self.socket.recv(4096)
            if len(resp) >= 12:
                resp_id = struct.unpack("<i", resp[4:8])[0]
                if resp_id != -1:
                    self.connected = True
                    logger.info(f"🔫 Source Engine RCON connected ({self.address}:{self.port})")
                    return True

            logger.error(f"🔫 RCON auth failed for {self.address}")
            return False
        except Exception as e:
            logger.error(f"🔫 Source Engine connect error: {e}")
            return False

    def send_mesh_data(self, payload: bytes) -> bool:
        """Send mesh data via RCON command to server-side plugin"""
        if not self.connected or not self.socket:
            return False
        try:
            encoded = encode_mesh_packet(payload, self.node_id)
            cmd = f"qcmesh_relay {encoded}"
            self._request_id += 1
            packet = self._build_rcon_packet(self._request_id, 2, cmd)
            self.socket.sendall(packet)
            return True
        except Exception as e:
            logger.error(f"🔫 RCON send error: {e}")
            return False

    def disconnect(self):
        if self.socket:
            try:
                self.socket.close()
            except Exception:
                pass
            self.connected = False

    @staticmethod
    def _build_rcon_packet(request_id: int, packet_type: int, body: str) -> bytes:
        body_bytes = body.encode("utf-8") + b"\x00\x00"
        length = 4 + 4 + len(body_bytes)
        return struct.pack("<iii", length, request_id, packet_type) + body_bytes


class GenericTCPAdapter:
    """
    Generic TCP adapter for Terraria tShock, Valheim, Factorio, etc.
    Uses a simple TCP connection and sends mesh-prefixed packets.
    Server-side mod/plugin recognizes QCMESH: prefix and handles relay.
    """

    def __init__(self, address: str, port: int, protocol_name: str = "generic"):
        self.address = address
        self.port = port
        self.protocol_name = protocol_name
        self.socket: Optional[socket.socket] = None
        self.connected = False
        self.node_id = f"{protocol_name[:6]}-{hashlib.sha256(f'{address}:{port}'.encode()).hexdigest()[:12]}"

    def connect(self) -> bool:
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(10)
            self.socket.connect((self.address, self.port))
            self.connected = True
            logger.info(f"🎮 Generic TCP connected ({self.protocol_name}: {self.address}:{self.port})")
            return True
        except Exception as e:
            logger.error(f"🎮 TCP connect error ({self.protocol_name}): {e}")
            return False

    def send_mesh_data(self, payload: bytes) -> bool:
        if not self.connected or not self.socket:
            return False
        try:
            encoded = encode_mesh_packet(payload, self.node_id)
            packet = MESH_DATA_PREFIX + encoded.encode() + b"\n"
            self.socket.sendall(packet)
            return True
        except Exception as e:
            logger.error(f"🎮 TCP send error: {e}")
            return False

    def receive_mesh_data(self, timeout: float = 5.0) -> Optional[bytes]:
        if not self.connected or not self.socket:
            return None
        try:
            self.socket.settimeout(timeout)
            raw = self.socket.recv(65536)
            if raw and MESH_DATA_PREFIX in raw:
                start = raw.index(MESH_DATA_PREFIX) + len(MESH_DATA_PREFIX)
                end = raw.index(b"\n", start) if b"\n" in raw[start:] else len(raw)
                decoded = decode_mesh_packet(raw[start:end].decode())
                if decoded:
                    return decoded[1]
        except socket.timeout:
            pass
        except Exception as e:
            logger.error(f"🎮 TCP recv error: {e}")
        return None

    def disconnect(self):
        if self.socket:
            try:
                self.socket.close()
            except Exception:
                pass
            self.connected = False


# ============================================================================
# GAMING SERVER MESH ENGINE — Main orchestrator
# ============================================================================

class GamingServerMeshEngine:
    """
    Orchestrates the Fungi Mesh network across free gaming servers.
    Manages provisioning, connections, data routing, and chunk storage
    across Minecraft, Discord, Roblox, Source Engine, and other platforms.
    """

    def __init__(self):
        self.nodes: Dict[str, GamingServerNode] = {}
        self.adapters: Dict[str, Any] = {}
        self.data_store: Dict[str, MeshDataChunk] = {}
        self.routing_table: Dict[str, List[str]] = {}  # chunk_id → [node_ids]
        self.running = False
        self.stats = {
            "packets_relayed": 0,
            "chunks_stored": 0,
            "chunks_replicated": 0,
            "total_storage_mb": 0.0,
            "nodes_online": 0,
            "nodes_total": 0,
            "platforms_active": set(),
            "uptime_start": None,
            "founder_royalty": FOUNDER_ROYALTY_RATE,
        }
        self._lock = threading.Lock()

        # Initialize nodes from registry
        self._init_nodes()

    def _init_nodes(self):
        """Initialize gaming server nodes from the free server registry"""
        for key, config in FREE_GAMING_SERVERS.items():
            node = GamingServerNode(
                node_id=f"gaming-{key}",
                platform=config["platform"],
                server_name=config["name"],
                server_address=config["address"],
                server_port=config["port"],
                region=config.get("region", "us-east"),
                max_storage_mb=config.get("max_storage_mb", 50),
            )
            self.nodes[node.node_id] = node
            self.stats["nodes_total"] = len(self.nodes)

        logger.info(f"🎮 Initialized {len(self.nodes)} gaming server mesh nodes")

    def _create_adapter(self, node: GamingServerNode) -> Any:
        """Create the appropriate protocol adapter for a gaming server node"""
        config = None
        for key, cfg in FREE_GAMING_SERVERS.items():
            if f"gaming-{key}" == node.node_id:
                config = cfg
                break

        if not config:
            return None

        protocol = config.get("protocol", "generic_tcp")
        channel = config.get("data_channel", "quranchain:mesh")

        if protocol == "minecraft_plugin_channel":
            return MinecraftProtocolAdapter(node.server_address, node.server_port, channel)
        elif protocol == "discord_websocket":
            return DiscordBotAdapter()
        elif protocol == "roblox_messaging_service":
            return RobloxCloudAdapter()
        elif protocol == "source_engine_rcon":
            return SourceEngineAdapter(node.server_address, node.server_port)
        else:
            return GenericTCPAdapter(node.server_address, node.server_port, protocol)

    def connect_all(self) -> Dict[str, bool]:
        """Attempt to connect to all gaming server nodes"""
        results = {}
        for node_id, node in self.nodes.items():
            try:
                node.status = GamingNodeStatus.CONNECTING
                adapter = self._create_adapter(node)
                if adapter:
                    success = adapter.connect()
                    if success:
                        node.status = GamingNodeStatus.ONLINE
                        node.last_heartbeat = datetime.now()
                        self.adapters[node_id] = adapter
                        self.stats["platforms_active"].add(node.platform.value)
                        logger.info(f"✅ {node.server_name} [{node.platform.value}] → ONLINE")
                    else:
                        node.status = GamingNodeStatus.OFFLINE
                        node.last_error = "Connection failed"
                    results[node_id] = success
                else:
                    node.status = GamingNodeStatus.OFFLINE
                    results[node_id] = False
            except Exception as e:
                node.status = GamingNodeStatus.OFFLINE
                node.last_error = str(e)
                results[node_id] = False
                logger.error(f"❌ {node.server_name} connect error: {e}")

        online = sum(1 for v in results.values() if v)
        self.stats["nodes_online"] = online
        logger.info(f"🎮 Gaming mesh: {online}/{len(self.nodes)} nodes online")
        return results

    def store_data(self, data: bytes, chunk_type: str = "mesh_state",
                   min_replicas: int = 3) -> Optional[str]:
        """
        Store mesh data across gaming server nodes (DHT-style replication).
        Returns chunk_id if successful.
        """
        chunk_id = f"chunk-{hashlib.sha256(data).hexdigest()[:16]}"
        data_hash = hashlib.sha256(data).hexdigest()

        # Find online nodes to store replicas
        online_nodes = [
            nid for nid, n in self.nodes.items()
            if n.status == GamingNodeStatus.ONLINE and nid in self.adapters
        ]

        if len(online_nodes) < 1:
            logger.warning("⚠️ No online gaming nodes for storage")
            return None

        replicas = []
        targets = online_nodes[:min(min_replicas, len(online_nodes))]

        for node_id in targets:
            adapter = self.adapters.get(node_id)
            if adapter:
                try:
                    # Roblox gets persistent DataStore storage
                    if isinstance(adapter, RobloxCloudAdapter):
                        success = adapter.store_chunk(chunk_id, data)
                    else:
                        success = adapter.send_mesh_data(data)

                    if success:
                        replicas.append(node_id)
                        node = self.nodes[node_id]
                        node.data_chunks_stored += 1
                        node.current_storage_mb += len(data) / (1024 * 1024)
                except Exception as e:
                    logger.error(f"Store failed on {node_id}: {e}")

        if replicas:
            chunk = MeshDataChunk(
                chunk_id=chunk_id,
                data_hash=data_hash,
                data=data,
                size_bytes=len(data),
                replicas=replicas,
                min_replicas=min_replicas,
                chunk_type=chunk_type,
            )
            with self._lock:
                self.data_store[chunk_id] = chunk
                self.routing_table[chunk_id] = replicas
                self.stats["chunks_stored"] += 1
                self.stats["chunks_replicated"] += len(replicas)
                self.stats["total_storage_mb"] += len(data) / (1024 * 1024)

            logger.info(f"💾 Stored chunk {chunk_id[:16]} → {len(replicas)} replicas across gaming servers")
            return chunk_id

        return None

    def retrieve_data(self, chunk_id: str) -> Optional[bytes]:
        """Retrieve mesh data from gaming server storage"""
        # Check local cache first
        if chunk_id in self.data_store:
            return self.data_store[chunk_id].data

        # Try to fetch from Roblox DataStore (persistent)
        for node_id, adapter in self.adapters.items():
            if isinstance(adapter, RobloxCloudAdapter):
                data = adapter.retrieve_chunk(chunk_id)
                if data:
                    return data

        # Try other adapters
        routing = self.routing_table.get(chunk_id, [])
        for node_id in routing:
            adapter = self.adapters.get(node_id)
            if adapter and hasattr(adapter, "receive_mesh_data"):
                data = adapter.receive_mesh_data()
                if data:
                    return data

        return None

    def relay_packet(self, data: bytes, exclude_nodes: Set[str] = None) -> int:
        """Relay a mesh packet to all online gaming nodes (broadcast)"""
        exclude = exclude_nodes or set()
        relayed = 0

        for node_id, adapter in self.adapters.items():
            if node_id in exclude:
                continue
            node = self.nodes.get(node_id)
            if node and node.status == GamingNodeStatus.ONLINE:
                try:
                    if adapter.send_mesh_data(data):
                        relayed += 1
                        node.packets_relayed += 1
                except Exception:
                    pass

        with self._lock:
            self.stats["packets_relayed"] += relayed
        return relayed

    def run_heartbeats(self):
        """Background thread: periodic heartbeats to keep gaming servers alive"""
        while self.running:
            heartbeat = json.dumps({
                "type": "heartbeat",
                "timestamp": datetime.utcnow().isoformat(),
                "mesh_version": MESH_PROTOCOL_VERSION,
                "founder_royalty": FOUNDER_ROYALTY_RATE,
            }).encode()

            for node_id, adapter in list(self.adapters.items()):
                node = self.nodes.get(node_id)
                if not node:
                    continue
                try:
                    if adapter.send_mesh_data(heartbeat):
                        node.last_heartbeat = datetime.now()
                        node.status = GamingNodeStatus.ONLINE
                    else:
                        # Check if stale
                        if (datetime.now() - node.last_heartbeat).seconds > 120:
                            node.status = GamingNodeStatus.OFFLINE
                            self.stats["nodes_online"] = sum(
                                1 for n in self.nodes.values() if n.status == GamingNodeStatus.ONLINE
                            )
                except Exception as e:
                    node.last_error = str(e)

            time.sleep(HEARTBEAT_INTERVAL)

    def run_replication_check(self):
        """Background thread: ensure all chunks meet minimum replica count"""
        while self.running:
            for chunk_id, chunk in list(self.data_store.items()):
                # Check if replicas are still on online nodes
                live_replicas = [
                    nid for nid in chunk.replicas
                    if self.nodes.get(nid, GamingServerNode("", GamingPlatform.DISCORD_BOT, "", "", 0)).status == GamingNodeStatus.ONLINE
                ]

                if len(live_replicas) < chunk.min_replicas:
                    # Need more replicas
                    needed = chunk.min_replicas - len(live_replicas)
                    candidates = [
                        nid for nid, n in self.nodes.items()
                        if n.status == GamingNodeStatus.ONLINE
                        and nid not in chunk.replicas
                        and nid in self.adapters
                    ]

                    for nid in candidates[:needed]:
                        adapter = self.adapters[nid]
                        try:
                            if isinstance(adapter, RobloxCloudAdapter):
                                success = adapter.store_chunk(chunk_id, chunk.data)
                            else:
                                success = adapter.send_mesh_data(chunk.data)
                            if success:
                                chunk.replicas.append(nid)
                                self.stats["chunks_replicated"] += 1
                                logger.info(f"🔄 Re-replicated {chunk_id[:16]} → {nid}")
                        except Exception:
                            pass

            time.sleep(60)  # Check every minute

    def start(self):
        """Start the gaming server mesh engine"""
        logger.info("🎮🕸️ Starting Gaming Server Mesh Engine...")
        logger.info(f"📊 {len(self.nodes)} gaming servers registered across {len(set(n.platform for n in self.nodes.values()))} platforms")

        self.running = True
        self.stats["uptime_start"] = datetime.now().isoformat()

        # Connect to all nodes
        self.connect_all()

        # Start background threads
        threading.Thread(target=self.run_heartbeats, daemon=True, name="gaming-mesh-heartbeat").start()
        threading.Thread(target=self.run_replication_check, daemon=True, name="gaming-mesh-replication").start()

        logger.info("✅ Gaming Server Mesh Engine ACTIVE")
        logger.info(f"🕸️ {self.stats['nodes_online']}/{self.stats['nodes_total']} nodes online")
        logger.info(f"🎮 Platforms: {', '.join(self.stats['platforms_active']) or 'connecting...'}")

    def stop(self):
        """Stop the engine and disconnect all adapters"""
        self.running = False
        for node_id, adapter in self.adapters.items():
            try:
                adapter.disconnect()
            except Exception:
                pass
        self.adapters.clear()
        logger.info("🛑 Gaming Server Mesh Engine stopped")

    def get_status(self) -> Dict:
        """Get comprehensive status report"""
        platform_breakdown = {}
        region_breakdown = {}
        for node in self.nodes.values():
            p = node.platform.value
            r = node.region
            platform_breakdown[p] = platform_breakdown.get(p, {"total": 0, "online": 0})
            platform_breakdown[p]["total"] += 1
            if node.status == GamingNodeStatus.ONLINE:
                platform_breakdown[p]["online"] += 1
            region_breakdown[r] = region_breakdown.get(r, 0) + (1 if node.status == GamingNodeStatus.ONLINE else 0)

        return {
            "service": "Gaming Server Mesh Engine",
            "status": "running" if self.running else "stopped",
            "nodes_online": sum(1 for n in self.nodes.values() if n.status == GamingNodeStatus.ONLINE),
            "nodes_total": len(self.nodes),
            "platforms": platform_breakdown,
            "regions": region_breakdown,
            "chunks_stored": self.stats["chunks_stored"],
            "chunks_replicated": self.stats["chunks_replicated"],
            "packets_relayed": self.stats["packets_relayed"],
            "total_storage_mb": round(self.stats["total_storage_mb"], 2),
            "uptime_start": self.stats["uptime_start"],
            "founder_royalty": FOUNDER_ROYALTY_RATE,
        }

    def get_node_list(self) -> List[Dict]:
        """Get list of all gaming server nodes"""
        return [node.to_dict() for node in self.nodes.values()]


# ============================================================================
# MINECRAFT SPIGOT PLUGIN GENERATOR
# ============================================================================

def generate_minecraft_plugin_java() -> str:
    """Generate the Spigot plugin Java source for Minecraft mesh relay"""
    return '''package org.quranchain.fungimesh;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.entity.Player;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * QuranChain Fungi Mesh - Minecraft Spigot Plugin
 * Relays mesh data through Minecraft plugin channels.
 * Install on any free Minecraft server (Aternos, Minehut, server.pro)
 *
 * (c) Omar Mohammad Abunadi - QuranChain / DarCloud
 */
public class FungiMeshPlugin extends JavaPlugin implements PluginMessageListener {

    private static final String CHANNEL = "quranchain:mesh";
    private final ConcurrentHashMap<String, byte[]> meshStore = new ConcurrentHashMap<>();
    private final Logger log = getLogger();

    @Override
    public void onEnable() {
        getServer().getMessenger().registerIncomingPluginChannel(this, CHANNEL, this);
        getServer().getMessenger().registerOutgoingPluginChannel(this, CHANNEL);
        log.info("[FungiMesh] Mesh relay node ACTIVE on " + getServer().getName());
        log.info("[FungiMesh] Channel: " + CHANNEL);
        log.info("[FungiMesh] (c) QuranChain / DarCloud - Omar Mohammad Abunadi");
    }

    @Override
    public void onDisable() {
        getServer().getMessenger().unregisterIncomingPluginChannel(this, CHANNEL);
        getServer().getMessenger().unregisterOutgoingPluginChannel(this, CHANNEL);
        log.info("[FungiMesh] Mesh relay node stopped");
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] data) {
        if (!channel.equals(CHANNEL)) return;

        // Extract mesh packet
        String encoded = new String(data, java.nio.charset.StandardCharsets.UTF_8);
        if (encoded.startsWith("QCMESH:") || encoded.contains("QCMESH:")) {
            log.info("[FungiMesh] Relay packet from " + player.getName() + " (" + data.length + " bytes)");

            // Store in local mesh cache
            String hash = Integer.toHexString(java.util.Arrays.hashCode(data));
            meshStore.put(hash, data);

            // Relay to all other connected players
            for (Player p : getServer().getOnlinePlayers()) {
                if (!p.equals(player)) {
                    p.sendPluginMessage(this, CHANNEL, data);
                }
            }
        }
    }
}
'''


def generate_gmod_lua_addon() -> str:
    """Generate Garry's Mod Lua addon for mesh relay"""
    return '''-- QuranChain Fungi Mesh - Garry's Mod Addon
-- Relays mesh data through GMod net library
-- (c) Omar Mohammad Abunadi - QuranChain / DarCloud

if SERVER then
    util.AddNetworkString("qc_mesh_relay")
    util.AddNetworkString("qc_mesh_store")

    local meshStore = {}
    local MESH_PREFIX = "QCMESH:"

    -- Receive mesh data from clients
    net.Receive("qc_mesh_relay", function(len, ply)
        local data = net.ReadString()
        if string.StartsWith(data, MESH_PREFIX) or string.find(data, MESH_PREFIX) then
            print("[FungiMesh] Relay from " .. ply:Nick() .. " (" .. len .. " bits)")

            -- Store locally
            local hash = util.CRC(data)
            meshStore[hash] = {data = data, time = os.time()}

            -- Broadcast to all other players
            net.Start("qc_mesh_relay")
            net.WriteString(data)
            net.SendOmit(ply)
        end
    end)

    -- RCON command for external mesh relay
    concommand.Add("qcmesh_relay", function(ply, cmd, args)
        if IsValid(ply) and not ply:IsAdmin() then return end
        local data = table.concat(args, " ")
        if #data > 0 then
            local hash = util.CRC(data)
            meshStore[hash] = {data = data, time = os.time()}
            net.Start("qc_mesh_relay")
            net.WriteString(data)
            net.Broadcast()
            print("[FungiMesh] RCON relay: " .. #data .. " chars")
        end
    end)

    -- Cleanup old entries every 5 minutes
    timer.Create("qcmesh_cleanup", 300, 0, function()
        local now = os.time()
        for k, v in pairs(meshStore) do
            if now - v.time > 3600 then meshStore[k] = nil end
        end
    end)

    print("[FungiMesh] GMod mesh relay ACTIVE")
    print("[FungiMesh] (c) QuranChain / DarCloud - Omar Mohammad Abunadi")
end

if CLIENT then
    net.Receive("qc_mesh_relay", function()
        local data = net.ReadString()
        -- Client-side mesh processing (optional)
    end)
end
'''


def generate_roblox_mesh_script() -> str:
    """Generate Roblox Lua script for in-game mesh relay"""
    return '''-- QuranChain Fungi Mesh - Roblox Server Script
-- Place in ServerScriptService
-- Uses MessagingService for real-time relay + DataStoreService for persistence
-- (c) Omar Mohammad Abunadi - QuranChain / DarCloud

local MessagingService = game:GetService("MessagingService")
local DataStoreService = game:GetService("DataStoreService")
local HttpService = game:GetService("HttpService")

local MESH_TOPIC = "QuranChainMesh"
local MESH_DATASTORE = "MeshStorage"
local MESH_PREFIX = "QCMESH:"
local meshStore = DataStoreService:GetDataStore(MESH_DATASTORE)

-- Subscribe to mesh relay topic
MessagingService:SubscribeAsync(MESH_TOPIC, function(message)
    local data = message.Data
    if type(data) == "string" and (string.sub(data, 1, #MESH_PREFIX) == MESH_PREFIX or string.find(data, MESH_PREFIX)) then
        print("[FungiMesh] Received mesh packet: " .. #data .. " chars")

        -- Store in DataStore for persistence
        local hash = tostring(tick()) .. "_" .. tostring(math.random(10000))
        pcall(function()
            meshStore:SetAsync("chunk_" .. hash, {
                data = data,
                timestamp = os.time(),
                serverId = game.JobId
            })
        end)
    end
end)

-- Publish mesh data (called from other scripts or RemoteEvents)
local function relayMeshData(data)
    if type(data) ~= "string" then return false end
    local success, err = pcall(function()
        MessagingService:PublishAsync(MESH_TOPIC, data)
    end)
    if success then
        print("[FungiMesh] Relayed mesh packet: " .. #data .. " chars")
    else
        warn("[FungiMesh] Relay failed: " .. tostring(err))
    end
    return success
end

-- Store chunk persistently
local function storeChunk(chunkId, data)
    local success, err = pcall(function()
        meshStore:SetAsync(chunkId, {
            data = data,
            timestamp = os.time(),
            serverId = game.JobId
        })
    end)
    return success
end

-- Retrieve chunk
local function retrieveChunk(chunkId)
    local success, result = pcall(function()
        return meshStore:GetAsync(chunkId)
    end)
    if success and result then
        return result.data
    end
    return nil
end

-- Expose functions
_G.FungiMesh = {
    relay = relayMeshData,
    store = storeChunk,
    retrieve = retrieveChunk,
}

print("[FungiMesh] Roblox mesh node ACTIVE")
print("[FungiMesh] Topic: " .. MESH_TOPIC)
print("[FungiMesh] DataStore: " .. MESH_DATASTORE)
print("[FungiMesh] (c) QuranChain / DarCloud - Omar Mohammad Abunadi")
'''


# ============================================================================
# HTTP SERVICE — Health check + management API
# ============================================================================

class GamingMeshHTTPHandler:
    """HTTP handler for the gaming mesh service (integrated with master hub)"""

    @staticmethod
    def handle_request(path: str, method: str = "GET", body: bytes = b"") -> Tuple[int, Dict]:
        """Handle HTTP request and return (status_code, response_dict)"""
        engine = gaming_mesh_engine

        if path == "/health":
            return 200, {
                "status": "healthy",
                "service": "Gaming Server Mesh Engine",
                "nodes_online": engine.stats["nodes_online"],
                "nodes_total": engine.stats["nodes_total"],
                "founder_royalty": FOUNDER_ROYALTY_RATE,
            }
        elif path == "/status":
            return 200, engine.get_status()
        elif path == "/nodes":
            return 200, {"nodes": engine.get_node_list()}
        elif path == "/platforms":
            return 200, {"platforms": [p.value for p in GamingPlatform]}
        elif path.startswith("/store") and method == "POST":
            try:
                data = json.loads(body.decode()) if body else {}
                payload = base64.b85decode(data.get("data", ""))
                chunk_type = data.get("type", "mesh_state")
                chunk_id = engine.store_data(payload, chunk_type)
                if chunk_id:
                    return 200, {"chunk_id": chunk_id, "stored": True}
                return 503, {"error": "No online nodes for storage"}
            except Exception as e:
                return 400, {"error": str(e)}
        elif path.startswith("/retrieve/"):
            chunk_id = path.split("/retrieve/")[1]
            data = engine.retrieve_data(chunk_id)
            if data:
                return 200, {"chunk_id": chunk_id, "data": base64.b85encode(data).decode()}
            return 404, {"error": "Chunk not found"}
        elif path == "/plugins/minecraft":
            return 200, {"plugin_java": generate_minecraft_plugin_java()}
        elif path == "/plugins/gmod":
            return 200, {"addon_lua": generate_gmod_lua_addon()}
        elif path == "/plugins/roblox":
            return 200, {"script_lua": generate_roblox_mesh_script()}
        else:
            return 404, {"error": "Not found"}


# ============================================================================
# GLOBAL SINGLETON
# ============================================================================

gaming_mesh_engine = GamingServerMeshEngine()

logger.info(f"🎮🕸️ Gaming Server Mesh Engine loaded")
logger.info(f"   {len(FREE_GAMING_SERVERS)} free gaming servers registered")
logger.info(f"   Platforms: {len(set(c['platform'] for c in FREE_GAMING_SERVERS.values()))}")
logger.info(f"   Protocols: Minecraft Plugin Channel, Discord WebSocket, Roblox Cloud, Source RCON, Generic TCP")
logger.info(f"   Founder royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")


# ============================================================================
# STANDALONE ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    print("🎮🕸️ QuranChain Gaming Server Mesh Engine")
    print("=" * 60)
    print(f"📊 {len(FREE_GAMING_SERVERS)} free gaming servers registered")
    print(f"🎮 Platforms: Minecraft, Discord, Roblox, GMod, CS2, Terraria, Valheim, Factorio")
    print()

    engine = GamingServerMeshEngine()
    engine.start()

    try:
        while True:
            time.sleep(60)
            status = engine.get_status()
            online = status["nodes_online"]
            total = status["nodes_total"]
            stored = status["chunks_stored"]
            relayed = status["packets_relayed"]
            print(f"🎮 Nodes: {online}/{total} | Chunks: {stored} | Relayed: {relayed} | Storage: {status['total_storage_mb']}MB")
    except KeyboardInterrupt:
        print("\n🛑 Stopping Gaming Server Mesh Engine...")
        engine.stop()
