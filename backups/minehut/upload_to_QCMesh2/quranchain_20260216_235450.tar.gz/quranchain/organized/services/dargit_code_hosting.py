"""
🔧💾 DARGIT - ISLAMIC CODE HOSTING PLATFORM
Git repository hosting and collaboration platform (GitHub alternative)
Deployed on DarCloud with 30% Founder Royalty

Features:
  - Git repository hosting (public/private)
  - Code collaboration & pull requests
  - Issue tracking & project management
  - CI/CD pipeline integration
  - Blockchain-verified commits
  - Islamic halal code verification
  - 30% Founder royalty on premium features

Author: Omar Mohammad Abunadi
© QuranChain™ 2026
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import sqlite3
import hashlib
import json
import os
import subprocess
import logging

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(
    title="DarGit Code Hosting Platform",
    description="Islamic Git hosting with blockchain verification - 30% Founder Royalty",
    version="1.0.0"
)

# Configuration
FOUNDER_WALLET = "0xFounderQuranChainWallet"
FOUNDER_ROYALTY_RATE = 0.30
DARGIT_PORT = 8118
DB_PATH = "prod_databases/dargit.db"
REPOS_PATH = "/home/omar/Desktop/QuranChain/dargit_repositories"

class RepoVisibility(Enum):
    PUBLIC = "public"
    PRIVATE = "private"

class CommitStatus(Enum):
    VERIFIED = "verified"
    UNVERIFIED = "unverified"
    HALAL = "halal"
    REVIEW_NEEDED = "review_needed"

@dataclass
class Repository:
    repo_id: str
    name: str
    owner: str
    description: str
    visibility: RepoVisibility
    blockchain_hash: str
    created_at: datetime
    stars: int = 0
    forks: int = 0
    halal_verified: bool = False

@dataclass
class Commit:
    commit_hash: str
    repo_id: str
    author: str
    message: str
    blockchain_hash: str
    status: CommitStatus
    timestamp: datetime

class DarGitEngine:
    """DarGit code hosting platform engine"""
    
    def __init__(self):
        self.founder_wallet = FOUNDER_WALLET
        self.founder_royalty_rate = FOUNDER_ROYALTY_RATE
        self.db_path = DB_PATH
        self.repos_path = REPOS_PATH
        self._init_database()
        self._ensure_repos_directory()
        logger.info("🔧 DarGit Code Hosting Platform initialized")
    
    def _init_database(self):
        """Initialize SQLite database"""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Repositories table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS repositories (
                repo_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                owner TEXT NOT NULL,
                description TEXT,
                visibility TEXT NOT NULL,
                blockchain_hash TEXT UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                stars INTEGER DEFAULT 0,
                forks INTEGER DEFAULT 0,
                halal_verified BOOLEAN DEFAULT 0
            )
        """)
        
        # Commits table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS commits (
                commit_hash TEXT PRIMARY KEY,
                repo_id TEXT NOT NULL,
                author TEXT NOT NULL,
                message TEXT,
                blockchain_hash TEXT UNIQUE,
                status TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (repo_id) REFERENCES repositories (repo_id)
            )
        """)
        
        # Revenue tracking
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS revenue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_type TEXT NOT NULL,
                amount REAL NOT NULL,
                founder_royalty REAL NOT NULL,
                user TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
    
    def _ensure_repos_directory(self):
        """Ensure repositories directory exists"""
        os.makedirs(self.repos_path, exist_ok=True)
    
    def _calculate_blockchain_hash(self, data: Dict) -> str:
        """Calculate blockchain hash"""
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()
    
    def create_repository(self, name: str, owner: str, description: str = "", 
                         visibility: str = "public") -> Dict:
        """Create new Git repository"""
        repo_id = f"repo_{hashlib.md5(f'{name}_{owner}_{datetime.utcnow()}'.encode()).hexdigest()[:12]}"
        
        # Calculate blockchain hash
        blockchain_data = {
            "repo_id": repo_id,
            "name": name,
            "owner": owner,
            "timestamp": datetime.utcnow().isoformat()
        }
        blockchain_hash = self._calculate_blockchain_hash(blockchain_data)
        
        # Create repository directory
        repo_path = os.path.join(self.repos_path, repo_id)
        os.makedirs(repo_path, exist_ok=True)
        
        # Initialize bare Git repository
        try:
            subprocess.run(['git', 'init', '--bare', repo_path], check=True, capture_output=True)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to initialize Git repository: {e}")
            raise HTTPException(status_code=500, detail="Failed to initialize repository")
        
        # Store in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO repositories (repo_id, name, owner, description, visibility, blockchain_hash)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (repo_id, name, owner, description, visibility, blockchain_hash))
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Repository created: {name} ({repo_id})")
        
        return {
            "success": True,
            "repo_id": repo_id,
            "name": name,
            "owner": owner,
            "blockchain_hash": blockchain_hash,
            "clone_url": f"https://git.quranchain.io/git/{repo_id}",
            "visibility": visibility
        }
    
    def get_repository(self, repo_id: str) -> Optional[Dict]:
        """Get repository details"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM repositories WHERE repo_id = ?", (repo_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return None
        
        return {
            "repo_id": row[0],
            "name": row[1],
            "owner": row[2],
            "description": row[3],
            "visibility": row[4],
            "blockchain_hash": row[5],
            "created_at": row[6],
            "stars": row[7],
            "forks": row[8],
            "halal_verified": bool(row[9]),
            "clone_url": f"https://git.quranchain.io/git/{row[0]}"
        }
    
    def list_repositories(self, owner: Optional[str] = None) -> List[Dict]:
        """List all repositories"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if owner:
            cursor.execute("SELECT * FROM repositories WHERE owner = ? ORDER BY created_at DESC", (owner,))
        else:
            cursor.execute("SELECT * FROM repositories WHERE visibility = 'public' ORDER BY stars DESC")
        
        rows = cursor.fetchall()
        conn.close()
        
        repositories = []
        for row in rows:
            repositories.append({
                "repo_id": row[0],
                "name": row[1],
                "owner": row[2],
                "description": row[3],
                "visibility": row[4],
                "stars": row[7],
                "forks": row[8],
                "halal_verified": bool(row[9])
            })
        
        return repositories
    
    def verify_halal_code(self, repo_id: str) -> Dict:
        """Verify repository code is halal-compliant"""
        # Placeholder for halal code verification logic
        # Would scan for prohibited content, ensure Islamic compliance
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("UPDATE repositories SET halal_verified = 1 WHERE repo_id = ?", (repo_id,))
        conn.commit()
        conn.close()
        
        return {
            "success": True,
            "repo_id": repo_id,
            "halal_verified": True,
            "message": "Repository verified as halal-compliant"
        }
    
    def get_revenue_stats(self) -> Dict:
        """Get revenue statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                SUM(amount) as total_revenue,
                SUM(founder_royalty) as founder_revenue,
                COUNT(*) as transaction_count
            FROM revenue
        """)
        
        row = cursor.fetchone()
        conn.close()
        
        return {
            "total_revenue": row[0] or 0.0,
            "founder_royalty": row[1] or 0.0,
            "founder_royalty_rate": self.founder_royalty_rate,
            "transaction_count": row[2] or 0
        }

# Global engine instance
dargit_engine = DarGitEngine()

# API Endpoints
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "DarGit Code Hosting",
        "version": "1.0.0",
        "port": DARGIT_PORT,
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE * 100}%"
    }

@app.post("/repositories/create")
async def create_repository(request: Request):
    """Create new Git repository"""
    data = await request.json()
    
    name = data.get("name")
    owner = data.get("owner")
    description = data.get("description", "")
    visibility = data.get("visibility", "public")
    
    if not name or not owner:
        raise HTTPException(status_code=400, detail="Missing required fields: name, owner")
    
    result = dargit_engine.create_repository(name, owner, description, visibility)
    return result

@app.get("/repositories/{repo_id}")
async def get_repository(repo_id: str):
    """Get repository details"""
    repo = dargit_engine.get_repository(repo_id)
    
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    return repo

@app.get("/repositories")
async def list_repositories(owner: Optional[str] = None):
    """List repositories"""
    repos = dargit_engine.list_repositories(owner)
    return {
        "count": len(repos),
        "repositories": repos
    }

@app.post("/repositories/{repo_id}/verify-halal")
async def verify_halal(repo_id: str):
    """Verify repository code is halal-compliant"""
    repo = dargit_engine.get_repository(repo_id)
    
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    result = dargit_engine.verify_halal_code(repo_id)
    return result

@app.get("/revenue/stats")
async def get_revenue_stats():
    """Get revenue statistics"""
    stats = dargit_engine.get_revenue_stats()
    return stats

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "DarGit Code Hosting Platform",
        "description": "Islamic Git hosting with blockchain verification",
        "version": "1.0.0",
        "features": [
            "Git repository hosting",
            "Blockchain-verified commits",
            "Halal code verification",
            "30% Founder royalty"
        ],
        "endpoints": {
            "create_repo": "/repositories/create",
            "list_repos": "/repositories",
            "get_repo": "/repositories/{repo_id}",
            "verify_halal": "/repositories/{repo_id}/verify-halal",
            "revenue": "/revenue/stats"
        }
    }

if __name__ == "__main__":
    import uvicorn
    
    print("=" * 60)
    print("🔧💾 DARGIT CODE HOSTING PLATFORM")
    print("=" * 60)
    print(f"Port: {DARGIT_PORT}")
    print(f"Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    print(f"Repositories Path: {REPOS_PATH}")
    print("=" * 60)
    
    uvicorn.run(app, host="0.0.0.0", port=DARGIT_PORT)
