"""
$1 Apartment Option Takeover - Configuration & Deployment
Default parameters and market profiles for different geographies.
"""

# ============================================================================
# DEAL SCORING WEIGHTS
# ============================================================================

SCORING_WEIGHTS = {
    "property_financials": 0.35,      # Cap rate, vacancy, below-market rents
    "seller_motivation": 0.30,        # Seller type and distress signals
    "market_opportunity": 0.20,       # Market tier, growth, fundamentals
    "deal_structuring": 0.15,         # Option terms, assignability, feasibility
}

# ============================================================================
# MARKET TIER PROFILES
# ============================================================================

MARKET_PROFILES = {
    "USA_TIER_2": {
        "name": "USA Secondary Markets",
        "description": "Mid-size cities with growth, lower costs",
        "examples": [
            "Memphis, TN",
            "Nashville, TN", 
            "Austin, TX",
            "Phoenix, AZ",
            "Charlotte, NC",
            "Raleigh, NC",
            "Denver, CO",
            "Portland, OR",
        ],
        "target_population_growth": 0.025,     # 2.5% annual
        "target_job_growth": 0.020,           # 2.0% annual
        "target_rent_growth": 0.035,          # 3.5% annual
        "typical_cap_rate_range": (0.05, 0.08),
        "typical_below_market_rent_range": (0.10, 0.25),
        "competitive_intensity": "medium",
        "refinance_lender_availability": "strong",
        "investor_interest": "high",
    },
    
    "USA_TIER_3": {
        "name": "USA Tertiary Markets",
        "description": "Smaller cities, emerging growth areas",
        "examples": [
            "Boise, ID",
            "Fargo, ND",
            "Sioux Falls, SD",
            "Wichita, KS",
            "Greenville, SC",
            "Fort Wayne, IN",
            "Tulsa, OK",
            "Little Rock, AR",
        ],
        "target_population_growth": 0.030,     # 3.0% annual
        "target_job_growth": 0.025,           # 2.5% annual
        "target_rent_growth": 0.040,          # 4.0% annual
        "typical_cap_rate_range": (0.06, 0.09),
        "typical_below_market_rent_range": (0.15, 0.30),
        "competitive_intensity": "low",
        "refinance_lender_availability": "moderate",
        "investor_interest": "medium",
    },
    
    "JORDAN": {
        "name": "Jordan",
        "description": "Middle East opportunity, Amman focus",
        "currency": "JOD",
        "examples": ["Amman", "Zarqa", "Irbid"],
        "target_population_growth": 0.020,
        "target_job_growth": 0.015,
        "typical_cap_rate_range": (0.07, 0.10),
        "typical_below_market_rent_range": (0.12, 0.28),
        "competitive_intensity": "low",
        "refinance_lender_availability": "limited",
        "investor_interest": "growing",
        "special_notes": "Islamic finance preferred, QuranChain integration key",
    },
    
    "KSA": {
        "name": "Kingdom of Saudi Arabia",
        "description": "GCC powerhouse, Vision 2030 growth",
        "currency": "SAR",
        "examples": ["Riyadh", "Jeddah", "Dammam"],
        "target_population_growth": 0.025,
        "target_job_growth": 0.020,
        "typical_cap_rate_range": (0.05, 0.08),
        "typical_below_market_rent_range": (0.10, 0.20),
        "competitive_intensity": "high",
        "refinance_lender_availability": "strong",
        "investor_interest": "very_high",
        "special_notes": "Strong capital, Islamic finance standard, Vision 2030 tailwinds",
    },
    
    "GCC": {
        "name": "Gulf Cooperation Council (UAE, Qatar, etc)",
        "description": "High-capital Gulf markets",
        "currency": "AED/QAR",
        "examples": ["Dubai", "Abu Dhabi", "Doha", "Muscat"],
        "target_population_growth": 0.020,
        "target_job_growth": 0.018,
        "typical_cap_rate_range": (0.04, 0.07),
        "typical_below_market_rent_range": (0.08, 0.18),
        "competitive_intensity": "very_high",
        "refinance_lender_availability": "strong",
        "investor_interest": "extreme",
        "special_notes": "Wealthy capital pools, Islamic finance, premium markets",
    },
    
    "MEXICO": {
        "name": "Mexico",
        "description": "Latin America expansion",
        "currency": "MXN",
        "examples": ["Mexico City", "Monterrey", "Cancun", "Guadalajara"],
        "target_population_growth": 0.015,
        "target_job_growth": 0.012,
        "typical_cap_rate_range": (0.07, 0.11),
        "typical_below_market_rent_range": (0.15, 0.30),
        "competitive_intensity": "low",
        "refinance_lender_availability": "moderate",
        "investor_interest": "growing",
        "special_notes": "Language/cultural considerations, emerging market opportunity",
    },
}

# ============================================================================
# SELLER TYPE PROFILES
# ============================================================================

SELLER_TYPE_PROFILES = {
    "MOM_AND_POP": {
        "description": "Individual owners or small family partnerships",
        "characteristics": [
            "Often tired of management",
            "Typically hold 1-5 properties",
            "May lack sophisticated exit strategies",
            "Responsive to personal touch",
            "Appreciate consultative approach",
        ],
        "option_acceptance_likelihood": 0.20,
        "ideal_approach": "Personal relationships, local credibility, problem-solving focus",
        "typical_asking_price_deviation": -0.10,  # Often 10% below market
    },
    
    "SMALL_PARTNERS": {
        "description": "2-3 person investment partnerships",
        "characteristics": [
            "Often fractious decision-making",
            "One partner may want out",
            "Motivated by partnership conflicts",
            "More sophisticated than mom-and-pop",
            "Appreciate creative structures",
        ],
        "option_acceptance_likelihood": 0.15,
        "ideal_approach": "Individual partner meetings, creative deal structures, exit strategy",
        "typical_asking_price_deviation": -0.08,
    },
    
    "ESTATE_HEIRS": {
        "description": "Inherited properties, non-operator heirs",
        "characteristics": [
            "Usually motivated for liquidity",
            "No management experience",
            "Often geographically distant",
            "Appreciate simplicity",
            "Time-pressured (estate settlements)",
        ],
        "option_acceptance_likelihood": 0.30,
        "ideal_approach": "Professional presentation, fast decisions, certainty of close",
        "typical_asking_price_deviation": -0.15,  # Often 15% below market
    },
    
    "INSTITUTIONAL": {
        "description": "REITs, funds, professional operators",
        "characteristics": [
            "Sophisticated and disciplined",
            "Less motivated by below-market deals",
            "Strong negotiating positions",
            "Rarely accept options",
            "Focus on cap rate and cashflow",
        ],
        "option_acceptance_likelihood": 0.02,
        "ideal_approach": "Avoid - rarely receptive to creative structures",
        "typical_asking_price_deviation": 0.0,
    },
}

# ============================================================================
# SELLER MOTIVATION SIGNALS
# ============================================================================

MOTIVATION_SIGNALS = {
    "BURNOUT": {
        "score_weight": 30,
        "indicators": [
            "Negative Glassdoor/review site comments",
            "Multiple leasing issues",
            "Maintenance complaints",
            "Tenant turnover >35%",
        ],
        "messaging": "We have systems to eliminate management headaches",
    },
    
    "RELOCATION": {
        "score_weight": 25,
        "indicators": [
            "Listing says 'owner relocating'",
            "Moving for job or family",
            "Time pressure evident",
            "Long hold period indicated",
        ],
        "messaging": "Quick solution for your relocation",
    },
    
    "PARTNERSHIP_BREAKUP": {
        "score_weight": 25,
        "indicators": [
            "Listings mention 'partnership dissolved'",
            "Recent legal filings",
            "Fractious management visible",
            "Deferred maintenance",
        ],
        "messaging": "Exit solution for partnership conflicts",
    },
    
    "DIVORCE": {
        "score_weight": 25,
        "indicators": [
            "Sudden listings from one party",
            "Property court records",
            "Forced sale pressure",
        ],
        "messaging": "Fair, quick resolution for all parties",
    },
    
    "TIME_PRESSURE": {
        "score_weight": 20,
        "indicators": [
            "Days on market >90",
            "Multiple price reductions",
            "Auction approaching",
        ],
        "messaging": "Certainty and closure",
    },
    
    "TAX_PRESSURE": {
        "score_weight": 15,
        "indicators": [
            "Large accumulated depreciation",
            "Recent passive activity loss limitations",
            "Year-end motivation",
        ],
        "messaging": "1031 exchange opportunity or portfolio optimization",
    },
}

# ============================================================================
# PROPERTY CONDITION PROFILES
# ============================================================================

CONDITION_PROFILES = {
    "STRUCTURALLY_SOUND_NEEDS_MANAGEMENT": {
        "description": "Good building, under-managed operations",
        "key_opportunities": [
            "Below-market rents (primary)",
            "High vacancy (due to neglect)",
            "Deferred marketing",
            "Inefficient collections",
        ],
        "typical_value_add": 0.20,  # 20% upside typical
        "capex_requirement": 0.05,  # 5% of purchase price
        "time_to_stabilize": 6,  # months
        "ideal_buyer": "Operators, value-add investors",
    },
    
    "COSMETIC_REHAB": {
        "description": "Minor cosmetic improvements needed",
        "key_opportunities": [
            "Below-market rents due to appearance",
            "Unit turnover delays",
            "Curb appeal improvements",
        ],
        "typical_value_add": 0.15,
        "capex_requirement": 0.08,
        "time_to_stabilize": 4,
        "ideal_buyer": "Cosmetic-focused operators, flipper mentality",
    },
    
    "FAIR": {
        "description": "Average condition, some unit/systems upgrades needed",
        "key_opportunities": [
            "Moderate value-add",
            "Systems upgrades (HVAC, plumbing)",
        ],
        "typical_value_add": 0.12,
        "capex_requirement": 0.12,
        "time_to_stabilize": 8,
        "ideal_buyer": "Value-add investors with capital",
    },
}

# ============================================================================
# OPTION AGREEMENT TEMPLATES
# ============================================================================

OPTION_AGREEMENT_TERMS = {
    "standard": {
        "option_price": 1.00,  # $1
        "consideration": "One Dollar ($1.00) and good and valuable consideration",
        "good_valuable_consideration": [
            "Professional market analysis and due diligence",
            "Property business plan development",
            "Capital sourcing and refinance structuring",
            "Operator referrals and management solutions",
        ],
        "strike_price_type": "fixed",
        "option_term_default_days": 90,
        "option_term_min_days": 60,
        "option_term_max_days": 180,
        "assignable": True,
        "data_access_rights": "Full due diligence access",
        "early_termination": "Option holder may terminate anytime",
        "extension_option": "Seller can grant 30-day extension (negotiable)",
    },
    
    "seller_favorable": {
        "option_price": 5000.00,  # $5k (for high-motivation sellers)
        "option_term_default_days": 60,
        "option_term_max_days": 120,
        "assignable": False,  # Non-assignable
        "early_termination": "Option holder loses fee if terminates early",
    },
    
    "aggressive_option": {
        "option_price": 0.01,  # 1 penny (legal minimum)
        "consideration": "One cent and services",
        "option_term_default_days": 120,
        "option_term_max_days": 180,
        "assignable": True,
        "data_access_rights": "Full access including confidential tenant information",
        "early_termination": "Can extend 30/60 days by mutual agreement",
        "extension_option": "Automatic 30-day extension if notice given",
    },
}

# ============================================================================
# DUE DILIGENCE CHECKLIST
# ============================================================================

DUE_DILIGENCE_TASKS = {
    "financial": {
        "priority": 1,
        "timeline_days": 14,
        "tasks": [
            "Obtain 3 years of P&L statements",
            "Obtain 3 years of balance sheets",
            "Verify rent roll vs. actual collections",
            "Calculate true NOI (owner-reported vs. audited)",
            "Identify below-market rents (% above current)",
            "Calculate DSCR and debt service requirements",
            "Analyze operating expense ratios (utilities, maintenance, mgmt)",
            "Identify any deferred maintenance costs",
            "Review current financing terms and maturity dates",
            "Analyze cash reserves and debt service coverage",
        ]
    },
    
    "physical": {
        "priority": 1,
        "timeline_days": 21,
        "tasks": [
            "Walk every occupied unit (10% minimum sample)",
            "Walk 3-5 vacant units",
            "Exterior inspection (roof, siding, foundation)",
            "Systems walkthrough (HVAC, plumbing, electrical)",
            "Safety systems review (fire suppression, exits)",
            "Common areas assessment (lobby, hallways, amenities)",
            "Parking area condition and capacity",
            "Document all deficiencies and capex needs",
            "Obtain professional property inspection report",
            "Estimate capex budget for 5-year hold",
        ]
    },
    
    "legal": {
        "priority": 2,
        "timeline_days": 14,
        "tasks": [
            "Verify property deed and title (title insurance review)",
            "Review lease terms and default provisions",
            "Check for code violations or non-compliance",
            "Review property tax records and appeals",
            "Verify landlord insurance adequacy",
            "Check for any litigation or liens",
            "Verify zoning compliance",
            "Review HOA documents (if applicable)",
            "Verify operating licenses and permits",
        ]
    },
    
    "operational": {
        "priority": 2,
        "timeline_days": 21,
        "tasks": [
            "Analyze lease terms and renewal timeline",
            "Review tenant screening and credit quality",
            "Evaluate property management quality",
            "Benchmark rent rates vs. comparable properties",
            "Calculate tenant turnover and reasons",
            "Analyze amenities and competitive positioning",
            "Review maintenance and repair spending",
            "Evaluate market rental rate growth potential",
            "Identify operational improvement opportunities",
            "Develop 90-day operational plan",
        ]
    },
    
    "tokenization": {
        "priority": 3,
        "timeline_days": 14,
        "tasks": [
            "Design property token structure",
            "Define investor share classes (Class A, Class B, etc)",
            "Structure founder royalty smart contract (10%)",
            "Define cash flow distribution waterfall",
            "Calculate token valuation model",
            "Plan quarterly distribution mechanics",
            "Establish QuranChain™ settlement logic",
            "Create transparent reporting framework",
            "Plan holder distribution platform",
        ]
    },
    
    "refinance": {
        "priority": 3,
        "timeline_days": 21,
        "tasks": [
            "Contact 3-5 commercial lenders (pre-qualification)",
            "Analyze current financing terms and prepayment penalties",
            "Model stabilization refinance scenarios",
            "Model cash-out refinance scenarios",
            "Calculate refinance capacity post-stabilization",
            "Obtain rate quotes for refinance assumptions",
            "Estimate closing costs and timeline",
            "Identify potential capital sources",
            "Calculate cash-on-cash returns post-refinance",
            "Obtain preliminary lender commitment letters",
        ]
    },
    
    "investor_lineup": {
        "priority": 3,
        "timeline_days": 30,
        "tasks": [
            "Identify 10-15 qualified investors",
            "Create investment package and proforma",
            "Schedule investor presentations",
            "Obtain interest commitments",
            "Negotiate terms and return expectations",
            "Prepare syndication or joint venture agreements",
            "Establish investor communication process",
            "Identify lead investor/capital partner",
            "Prepare for investor due diligence",
            "Develop exit strategy communication",
        ]
    },
}

# ============================================================================
# EXIT STRATEGY TEMPLATES
# ============================================================================

EXIT_STRATEGIES = {
    "ASSIGN_OPTION": {
        "name": "Assign Option for Fee",
        "capital_required": 0,
        "timeline_days": 30,
        "typical_fee_pct": 0.02,  # 2% of purchase price
        "pros": [
            "Quick capital deployment",
            "Zero execution risk",
            "Can exit if better opportunity",
            "Immediate liquidity",
        ],
        "cons": [
            "One-time revenue only",
            "Limited upside participation",
            "Requires qualified buyer",
        ],
        "ideal_for": "Quick wins, capital constraints",
    },
    
    "CLOSE_AND_HOLD": {
        "name": "Close & Hold in Portfolio",
        "capital_required": 0.27,  # 27.5% down payment typical
        "timeline_days": 90,
        "ongoing_revenue": "10% Founder Royalty annual on NOI",
        "pros": [
            "Long-term income stream",
            "Founder Royalty forever",
            "Participate in value growth",
            "Refinance upside",
        ],
        "cons": [
            "Significant capital required",
            "Operational complexity",
            "Management overhead",
            "Long-term commitment",
        ],
        "ideal_for": "Capital-rich operators, long-term hold mentality",
    },
    
    "JOINT_VENTURE": {
        "name": "Joint Venture with Seller",
        "capital_required": 0.15,  # 15% down payment (seller co-invests)
        "timeline_days": 120,
        "ongoing_revenue": "Founder Royalty + promote on returns",
        "pros": [
            "Seller alignment and motivation",
            "Lower capital requirement",
            "Shared risk and upside",
            "Smoother operations",
        ],
        "cons": [
            "Management complexity",
            "Shared control dilution",
            "Complex waterfall",
        ],
        "ideal_for": "Motivated sellers, shared expertise model",
    },
    
    "SYNDICATION": {
        "name": "Syndicate to Investors",
        "capital_required": 0,
        "timeline_days": 120,
        "ongoing_revenue": "Promote (20% of surplus) + 10% Founder Royalty",
        "pros": [
            "Zero capital requirement",
            "Portfolio scale",
            "Founder Royalty forever",
            "Investor capital deployment",
        ],
        "cons": [
            "Syndication timeline",
            "SEC/state compliance",
            "Investor reporting burden",
            "Promote only on exit",
        ],
        "ideal_for": "Portfolio scale, capital-light model",
    },
}

# ============================================================================
# FOUNDER ROYALTY CONFIGURATION
# ============================================================================

FOUNDER_ROYALTY_CONFIG = {
    "founder_name": "Omar Mohammad Abunadi",
    "founder_signature": "OMAR-QURANCHAIN-SOVEREIGN-FOUNDER-10PCT-ROYALTY",
    "royalty_rate_pct": 10.0,
    "royalty_basis": "net_project_income_or_net_revenue",
    "settlement_method": "QuranChain™ Smart Contracts",
    "distribution_frequency": "quarterly",
    "applies_to": [
        "Annual NOI distributions",
        "Refinance proceeds",
        "Sale/exit proceeds",
        "Syndication promote",
        "Option assignment fees",
    ],
    "exceptions": [
        "Return of capital (not profit)",
        "Loan repayment (not income)",
    ],
    "smart_contract": {
        "enabled": True,
        "transparent_audit": True,
        "immutable_waterfall": True,
        "automatic_distribution": True,
    },
}

if __name__ == "__main__":
    print("✅ $1 Option Strategy Configuration Loaded")
    print(f"   - {len(MARKET_PROFILES)} market profiles defined")
    print(f"   - {len(SELLER_TYPE_PROFILES)} seller type profiles")
    print(f"   - {len(MOTIVATION_SIGNALS)} motivation signals")
    print(f"   - Founder Royalty: 10% via QuranChain™")
