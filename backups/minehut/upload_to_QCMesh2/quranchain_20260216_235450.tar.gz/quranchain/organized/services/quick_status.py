#!/usr/bin/env python3
import sys, requests
sys.path.insert(0, "crm")
from database import CRMDatabase
from kraken_auto_cashout import KrakenAutoSeller

print("\n" + "="*80)
print("💰 QURANCHAIN REVENUE STATUS")
print("="*80 + "\n")

# CRM
crm = CRMDatabase()
stats = crm.get_revenue_summary(30)
print(f"📊 CRM Revenue:           ${stats['total_revenue']:,.2f}")
print(f"   Founder (30%):         ${stats['founder_royalty']:,.2f}")

# Crypto
try:
    resp = requests.get("http://localhost:7500/check-balances", timeout=2)
    print(f"\n💳 Crypto System:         ✅ ONLINE")
    print(f"   Wallet:                0x1FDF...45A9")
except:
    print(f"\n💳 Crypto System:         ⚠️ Offline")

# Kraken
kraken = KrakenAutoSeller()
bal = kraken.get_balance()
if 'result' in bal:
    print(f"\n🏦 Kraken Auto-Sell:      ✅ CONNECTED")
    print(f"   Ready for cashouts:    YES")
else:
    print(f"\n🏦 Kraken Auto-Sell:      ❌ {bal.get('error')}")

print("\n" + "="*80)
print("🎯 SYSTEM STATUS: FULLY OPERATIONAL")
print("="*80)
print("\n✅ Accept crypto payments (BTC, ETH, USDC)")
print("✅ Auto-convert to USD via Kraken")  
print("✅ Track all revenue with 30% founder royalty")
print("\n© QuranChain™ | Omar Mohammad Abunadi™\n")
