#!/usr/bin/env python3
"""
QuranChain Multi-Chain Bridge Interface - PRODUCTION
Allows users to bridge assets between 47 chains
Collects 0.5% gas toll on all transactions
30% founder royalty enforced

Production Endpoint: https://bridge.quranchain.com
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os
import logging
import requests
from datetime import datetime
sys.path.insert(0, '/home/omar/Desktop/QuranChain')
from organized.ai_agents.blockchain_gas_toll_system import blockchain_gas_toll_system
from blockchain_logging_handler import setup_blockchain_logging

# Gas Toll Highway Integration
GAS_TOLL_HIGHWAY_API = os.getenv('GAS_TOLL_HIGHWAY_API', 'http://localhost:7777')
HIGHWAY_ENABLED = os.getenv('ENABLE_GAS_TOLL_HIGHWAY', 'true').lower() == 'true'

# Production logging
setup_blockchain_logging()
logger = logging.getLogger("QuranChainBridge")

app = Flask(__name__)
CORS(app)  # Enable CORS for production API access

# Production Configuration
PRODUCTION_DOMAIN = os.getenv('BRIDGE_DOMAIN', 'bridge.quranchain.com')
PRODUCTION_MODE = os.getenv('PRODUCTION_MODE', 'true').lower() == 'true'

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    highway_status = 'disabled'
    if HIGHWAY_ENABLED:
        try:
            resp = requests.get(f"{GAS_TOLL_HIGHWAY_API}/health", timeout=2)
            highway_status = 'connected' if resp.status_code == 200 else 'unavailable'
        except:
            highway_status = 'unavailable'
    
    return jsonify({
        'status': 'live',
        'service': 'QuranChain Bridge Interface',
        'mode': 'PRODUCTION' if PRODUCTION_MODE else 'development',
        'endpoint': f'https://{PRODUCTION_DOMAIN}' if PRODUCTION_MODE else 'http://localhost:6600',
        'networks_monitored': 47,
        'gas_toll_rate': '0.5%',
        'founder_royalty': '30%',
        'gas_toll_highway': highway_status,
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/v1/networks', methods=['GET'])
def get_supported_networks():
    """Get list of all supported blockchain networks"""
    networks = blockchain_gas_toll_system.get_supported_networks()
    return jsonify({
        'total_networks': len(networks),
        'networks': networks,
        'bridge_fee': '0.5%',
        'founder_royalty': '30%'
    })

@app.route('/api/v1/bridge/quote', methods=['POST'])
def get_bridge_quote():
    """Get quote for bridging assets between chains"""
    try:
        data = request.json
        
        source_chain = data.get('source_chain')
        dest_chain = data.get('dest_chain')
        amount = float(data.get('amount', 0))
        token = data.get('token', 'USDC')
        
        # Validate inputs
        if not source_chain or not dest_chain:
            return jsonify({'error': 'source_chain and dest_chain required'}), 400
        
        if amount <= 0:
            return jsonify({'error': 'amount must be greater than 0'}), 400
        
        # Calculate gas toll (0.5%)
        gas_toll = amount * 0.005
        founder_share = gas_toll * 0.30
        
        logger.info(f"Bridge quote: {amount} {token} from {source_chain} to {dest_chain}")
        
        return jsonify({
            'success': True,
            'quote_id': f"QC-{datetime.utcnow().timestamp()}",
            'source_chain': source_chain,
            'destination_chain': dest_chain,
            'amount': amount,
            'token': token,
            'gas_toll': round(gas_toll, 6),
            'founder_royalty': round(founder_share, 6),
            'you_receive': round(amount - gas_toll, 6),
            'estimated_time': '3-5 minutes',
            'expires_at': (datetime.utcnow().timestamp() + 300)  # 5 min expiry
        })
    except Exception as e:
        logger.error(f"Quote error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/bridge/execute', methods=['POST'])
def execute_bridge():
    """Execute bridge transaction and collect gas toll"""
    try:
        data = request.json
        
        # Validate required fields
        required = ['source_chain', 'dest_chain', 'amount', 'wallet_address']
        for field in required:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        logger.info(f"Executing bridge: {data.get('amount')} from {data.get('source_chain')} to {data.get('dest_chain')}")
        
        # Route through Gas Toll Highway if enabled
        if HIGHWAY_ENABLED:
            try:
                highway_response = requests.post(
                    f"{GAS_TOLL_HIGHWAY_API}/api/v1/route",
                    json={
                        'source_chain': data.get('source_chain'),
                        'dest_chain': data.get('dest_chain'),
                        'token': data.get('token', 'USDC'),
                        'amount': str(data.get('amount')),
                        'user_address': data.get('wallet_address'),
                        'quote_id': data.get('quote_id')
                    },
                    timeout=10
                )
                
                if highway_response.status_code == 200:
                    highway_result = highway_response.json()
                    logger.info(f"Gas Toll Highway executed: {highway_result.get('tx_hash')}")
                    
                    return jsonify({
                        'success': True,
                        'via': 'gas_toll_highway',
                        'result': highway_result,
                        'fees': {
                            'gas_toll': highway_result.get('fees', {}).get('total_fee'),
                            'founder_royalty': highway_result.get('fees', {}).get('founder_share'),
                            'highway_enabled': True
                        }
                    })
            except Exception as highway_error:
                logger.warning(f"Gas Toll Highway unavailable, falling back: {highway_error}")
        
        # Fallback to blockchain gas toll system
        result = blockchain_gas_toll_system.process_bridge_transaction(
            source_chain=data.get('source_chain'),
            dest_chain=data.get('dest_chain'),
            amount=float(data.get('amount')),
            token=data.get('token', 'USDC'),
            user_wallet=data.get('wallet_address'),
            quote_id=data.get('quote_id')
        )
        
        logger.info(f"Bridge executed: {result.get('transaction_id')}")
        
        return jsonify({
            'success': True,
            'via': 'blockchain_gas_toll_system',
            'result': result
        })
    except Exception as e:
        logger.error(f"Bridge execution error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/revenue/summary', methods=['GET'])
def get_revenue_summary():
    """Get current revenue summary from gas toll collection"""
    try:
        stats = blockchain_gas_toll_system.get_collection_stats()
        return jsonify({
            'success': True,
            'data': stats,
            'timestamp': datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"Revenue summary error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/stats', methods=['GET'])
def get_bridge_stats():
    """Get bridge statistics"""
    return jsonify({
        'total_networks': 47,
        'gas_toll_rate': '0.5%',
        'founder_royalty_rate': '30%',
        'production_endpoint': f'https://{PRODUCTION_DOMAIN}',
        'status': 'operational'
    })

@app.route('/v1/bridge/stats', methods=['GET'])
def get_v1_bridge_stats():
    """V1 API: Get bridge statistics"""
    return jsonify({
        'success': True,
        'total_networks': 47,
        'gas_toll_rate': '0.5%',
        'founder_royalty_rate': '30%',
        'production_endpoint': f'https://{PRODUCTION_DOMAIN}',
        'status': 'operational',
        'mode': 'PRODUCTION' if PRODUCTION_MODE else 'development',
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/v1/bridge/quote', methods=['POST'])
def get_v1_bridge_quote():
    """V1 API: Get quote for bridging assets"""
    return get_bridge_quote()

@app.route('/v1/bridge/execute', methods=['POST'])
def execute_v1_bridge():
    """V1 API: Execute bridge transaction"""
    return execute_bridge()

if __name__ == '__main__':
    # Production configuration
    PORT = int(os.getenv('BRIDGE_PORT', 6600))
    
    print("\n" + "="*80)
    print("🌉 QURANCHAIN BRIDGE INTERFACE - PRODUCTION MODE")
    print("="*80)
    print(f"📊 Monitoring: 47 blockchain networks")
    print(f"💰 Gas Toll: 0.5% (30% founder royalty)")
    print(f"🔗 Production Endpoint: https://{PRODUCTION_DOMAIN}")
    print(f"🔗 Local Endpoint: http://0.0.0.0:{PORT}")
    print(f"📈 API Version: v1")
    print(f"🔒 CORS: Enabled for production")
    print("="*80 + "\n")
    
    logger.info(f"Starting QuranChain Bridge on port {PORT}")
    
    # Production-grade server
    app.run(
        host='0.0.0.0',
        port=PORT,
        debug=False,
        threaded=True,
        use_reloader=False
    )
