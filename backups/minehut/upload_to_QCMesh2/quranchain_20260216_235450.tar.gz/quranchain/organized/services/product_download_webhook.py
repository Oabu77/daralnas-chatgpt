#!/usr/bin/env python3
"""
🕸️ PRODUCT DOWNLOAD WEBHOOK SERVICE
Stripe webhook endpoint that delivers product download links
when a customer completes a purchase.

Every purchase → download link → Fungi Mesh node → network expansion

Founder: Omar Mohammad Abunadi™
Port: 9095
Status: PRODUCTION

❌ NEVER modify 30% founder royalty (FOUNDER_ROYALTY_RATE = 0.30)
"""

import sys
import os
import json
import hmac
import hashlib
import logging
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Optional

sys.path.insert(0, "/home/omar/Desktop/QuranChain")

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(name)s %(message)s")
logger = logging.getLogger("DownloadWebhook")

FOUNDER_ROYALTY_RATE = 0.30  # IMMUTABLE
WEBHOOK_PORT = 9095
SERVICE_NAME = "Product Download Webhook"

# Load Stripe config
try:
    from dotenv import load_dotenv
    load_dotenv("/home/omar/Desktop/QuranChain/.env")
except ImportError:
    pass

STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
STRIPE_LIVE_KEY = os.environ.get(
    "STRIPE_SECRET_KEY",
    "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"
)

# Import download system
try:
    from organized.services.product_download_system import (
        DOWNLOAD_PACKAGES,
        get_download_url,
        handle_stripe_purchase_completed,
        get_download_catalog_summary,
        build_all_download_packages,
    )
    DOWNLOADS_LOADED = True
    if not DOWNLOAD_PACKAGES:
        build_all_download_packages()
except ImportError as e:
    logger.warning(f"⚠️ Download system not available: {e}")
    DOWNLOADS_LOADED = False
    DOWNLOAD_PACKAGES = {}

# Import email system for delivery
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


# ============================================================================
# DOWNLOAD DELIVERY
# ============================================================================

def deliver_download(product_id: str, customer_email: str, customer_name: str = "") -> Dict:
    """Deliver download link to customer after purchase"""
    if not DOWNLOADS_LOADED:
        return {"error": "Download system not loaded", "delivered": False}

    download_info = handle_stripe_purchase_completed(product_id, customer_email)
    if not download_info:
        return {"error": f"No download package for product: {product_id}", "delivered": False}

    # Log the delivery
    logger.info(
        f"🛒 DOWNLOAD DELIVERY: {download_info['product_name']} → {customer_email} "
        f"(tier={download_info['node_tier']}, caps={download_info['mesh_capabilities']})"
    )

    # Record delivery for CRM
    delivery_record = {
        "timestamp": datetime.now().isoformat(),
        "customer_email": customer_email,
        "customer_name": customer_name,
        "product_key": download_info["product_key"],
        "product_name": download_info["product_name"],
        "download_url": download_info["download_url"],
        "node_tier": download_info["node_tier"],
        "mesh_capabilities": download_info["mesh_capabilities"],
        "delivered": True,
        "founder_royalty": FOUNDER_ROYALTY_RATE,
    }

    # Persist delivery log
    log_dir = "/home/omar/Desktop/QuranChain/monitoring_logs"
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "download_deliveries.jsonl")
    try:
        with open(log_file, "a") as f:
            f.write(json.dumps(delivery_record) + "\n")
    except Exception as e:
        logger.error(f"Failed to log delivery: {e}")

    return delivery_record


def send_download_email(customer_email: str, download_info: Dict) -> bool:
    """Send download link via email (SendGrid if available)"""
    sendgrid_key = os.environ.get("SENDGRID_API_KEY", "")
    if not sendgrid_key or not REQUESTS_AVAILABLE:
        logger.info(f"📧 Email delivery skipped (no SendGrid key) — URL logged for: {customer_email}")
        return False

    try:
        payload = {
            "personalizations": [{
                "to": [{"email": customer_email}],
                "subject": f"🕸️ Your {download_info['product_name']} Download — QuranChain™"
            }],
            "from": {"email": "downloads@darcloud.host", "name": "QuranChain Downloads"},
            "content": [{
                "type": "text/html",
                "value": f"""
                <h2>Your Download is Ready!</h2>
                <p>Thank you for your purchase of <strong>{download_info['product_name']}</strong>.</p>
                <p><a href="{download_info['download_url']}" style="background:#4CAF50;color:white;padding:12px 24px;text-decoration:none;border-radius:4px;">
                    Download Package
                </a></p>
                <h3>What's Included:</h3>
                <ul>
                    <li>Product software and tools</li>
                    <li>Fungi Mesh Node Installer (Tier: {download_info['node_tier'].upper()})</li>
                    <li>Docker + Kubernetes deployment files</li>
                    <li>Documentation</li>
                </ul>
                <p><strong>Mesh Capabilities:</strong> {', '.join(download_info['mesh_capabilities'])}</p>
                <p>By installing this software, your hardware joins the QuranChain decentralized mesh network.
                As a hardware host, you earn <strong>10% of all revenue</strong> processed through your node.</p>
                <p>© {datetime.now().year} Omar Mohammad Abunadi™ — QuranChain™ / DarCloud™</p>
                """
            }]
        }

        resp = requests.post(
            "https://api.sendgrid.com/v3/mail/send",
            headers={"Authorization": f"Bearer {sendgrid_key}", "Content-Type": "application/json"},
            json=payload,
            timeout=10
        )
        if resp.status_code in (200, 202):
            logger.info(f"📧 Download email sent to {customer_email}")
            return True
        else:
            logger.warning(f"📧 Email send failed: {resp.status_code}")
            return False
    except Exception as e:
        logger.error(f"📧 Email error: {e}")
        return False


# ============================================================================
# STRIPE WEBHOOK HANDLER
# ============================================================================

def verify_stripe_signature(payload: bytes, sig_header: str) -> bool:
    """Verify Stripe webhook signature"""
    if not STRIPE_WEBHOOK_SECRET:
        logger.warning("⚠️ No webhook secret configured — skipping verification")
        return True  # Allow in dev mode

    try:
        elements = dict(item.split("=", 1) for item in sig_header.split(","))
        timestamp = elements.get("t", "")
        signature = elements.get("v1", "")

        signed_payload = f"{timestamp}.{payload.decode()}"
        expected = hmac.new(
            STRIPE_WEBHOOK_SECRET.encode(),
            signed_payload.encode(),
            hashlib.sha256
        ).hexdigest()

        return hmac.compare_digest(signature, expected)
    except Exception as e:
        logger.error(f"Signature verification error: {e}")
        return False


class DownloadWebhookHandler(BaseHTTPRequestHandler):
    """HTTP handler for Stripe webhooks and download delivery API"""

    def do_GET(self):
        if self.path == "/health":
            self._respond(200, {
                "status": "healthy",
                "service": SERVICE_NAME,
                "port": WEBHOOK_PORT,
                "downloads_loaded": DOWNLOADS_LOADED,
                "total_packages": len(DOWNLOAD_PACKAGES),
                "founder_royalty": FOUNDER_ROYALTY_RATE,
                "timestamp": datetime.now().isoformat(),
            })
        elif self.path == "/downloads/catalog":
            if DOWNLOADS_LOADED:
                self._respond(200, get_download_catalog_summary())
            else:
                self._respond(503, {"error": "Download system not loaded"})
        elif self.path.startswith("/downloads/product/"):
            product_key = self.path.split("/downloads/product/")[1].strip("/")
            download = get_download_url(product_key) if DOWNLOADS_LOADED else None
            if download:
                self._respond(200, download)
            else:
                self._respond(404, {"error": f"No download for: {product_key}"})
        elif self.path == "/downloads/stats":
            self._respond(200, {
                "total_packages": len(DOWNLOAD_PACKAGES),
                "downloads_loaded": DOWNLOADS_LOADED,
                "service_uptime": datetime.now().isoformat(),
            })
        else:
            self._respond(404, {"error": "Not found"})

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        if self.path == "/webhook/stripe":
            self._handle_stripe_webhook(body)
        elif self.path == "/downloads/deliver":
            self._handle_manual_delivery(body)
        else:
            self._respond(404, {"error": "Not found"})

    def _handle_stripe_webhook(self, body: bytes):
        """Process Stripe webhook event"""
        sig = self.headers.get("Stripe-Signature", "")

        if STRIPE_WEBHOOK_SECRET and not verify_stripe_signature(body, sig):
            self._respond(401, {"error": "Invalid signature"})
            return

        try:
            event = json.loads(body.decode())
            event_type = event.get("type", "")

            if event_type == "checkout.session.completed":
                session = event.get("data", {}).get("object", {})
                customer_email = session.get("customer_email", session.get("customer_details", {}).get("email", ""))
                customer_name = session.get("customer_details", {}).get("name", "")

                # Extract product from line items
                line_items = session.get("line_items", {}).get("data", [])
                if not line_items:
                    # Try metadata
                    product_id = session.get("metadata", {}).get("product_id", "")
                else:
                    product_id = line_items[0].get("price", {}).get("product", "")

                if product_id and customer_email:
                    result = deliver_download(product_id, customer_email, customer_name)
                    if result.get("delivered"):
                        # Also try to send email
                        send_download_email(customer_email, result)
                    self._respond(200, result)
                else:
                    self._respond(200, {"status": "ok", "note": "No product_id or email in event"})

            elif event_type == "payment_intent.succeeded":
                logger.info(f"💰 Payment succeeded: {event.get('data', {}).get('object', {}).get('id', 'unknown')}")
                self._respond(200, {"status": "ok", "event": event_type})

            else:
                logger.info(f"📬 Webhook event: {event_type}")
                self._respond(200, {"status": "ok", "event": event_type})

        except json.JSONDecodeError:
            self._respond(400, {"error": "Invalid JSON"})
        except Exception as e:
            logger.error(f"Webhook error: {e}")
            self._respond(500, {"error": str(e)})

    def _handle_manual_delivery(self, body: bytes):
        """Handle manual download delivery request"""
        try:
            data = json.loads(body.decode())
            product_key = data.get("product_key", "")
            customer_email = data.get("customer_email", "")

            if not product_key or not customer_email:
                self._respond(400, {"error": "Missing product_key or customer_email"})
                return

            # Look up product_id from key
            pkg = DOWNLOAD_PACKAGES.get(product_key)
            if not pkg:
                self._respond(404, {"error": f"Unknown product: {product_key}"})
                return

            result = deliver_download(pkg.product_id, customer_email, data.get("customer_name", ""))
            if result.get("delivered"):
                send_download_email(customer_email, result)
            self._respond(200, result)

        except json.JSONDecodeError:
            self._respond(400, {"error": "Invalid JSON"})
        except Exception as e:
            self._respond(500, {"error": str(e)})

    def _respond(self, code: int, data: dict):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode())

    def log_message(self, format, *args):
        logger.info(f"📬 {args[0]}")


# ============================================================================
# SERVER STARTUP
# ============================================================================

def start_webhook_server(port: int = WEBHOOK_PORT):
    """Start the download webhook server"""
    server = HTTPServer(("0.0.0.0", port), DownloadWebhookHandler)
    logger.info(f"🕸️ Product Download Webhook Service started on port {port}")
    logger.info(f"📦 Serving downloads for {len(DOWNLOAD_PACKAGES)} products")
    logger.info(f"🌐 Health: http://localhost:{port}/health")
    logger.info(f"📬 Webhook: POST http://localhost:{port}/webhook/stripe")
    logger.info(f"📋 Catalog: http://localhost:{port}/downloads/catalog")
    logger.info(f"💳 Founder royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("🛑 Webhook server shutting down")
        server.shutdown()


if __name__ == "__main__":
    start_webhook_server()
