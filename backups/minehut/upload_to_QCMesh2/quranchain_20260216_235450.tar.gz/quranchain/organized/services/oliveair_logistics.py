#!/usr/bin/env python3
"""
OliveAir Logistics - Integrated Supply Chain Management
Port: 9312
Founder: Omar Mohammad Abunadi
30% Immutable Founder Royalty
"""

from flask import Flask, jsonify, request
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Dict
import hashlib
import json
import sqlite3
import os

app = Flask(__name__)

# IMMUTABLE FOUNDER ROYALTY
FOUNDER_ROYALTY_RATE = 0.30  # 30% - NEVER CHANGE THIS
FOUNDER_WALLET = "QRC-FOUNDER-OMAR-ABUNADI"

# Revenue Distribution
REVENUE_DISTRIBUTION = {
    "founder": 0.30,      # Omar Mohammad Abunadi - IMMUTABLE
    "ai_validators": 0.40,  # Omar AI™ & QuranChain AI™
    "hardware_hosts": 0.10,
    "ecosystem": 0.18,
    "zakat": 0.02
}

# Database
DB_PATH = "prod_databases/oliveair_logistics.db"

@dataclass
class LogisticsOrder:
    """Multi-modal logistics order"""
    order_id: str
    customer_id: str
    service_type: str  # air-only, air-sea, air-land, multimodal
    origin: str
    destination: str
    cargo_details: str
    total_weight_kg: float
    estimated_delivery: str
    logistics_fee: float
    status: str
    blockchain_hash: str
    timestamp: str

@dataclass
class Warehouse:
    """Warehouse facility"""
    warehouse_id: str
    location: str
    capacity_sqm: int
    current_utilization: float
    services: List[str]

class OliveAirLogistics:
    """OliveAir Logistics Management System"""
    
    def __init__(self):
        self.init_database()
        self.init_warehouses()
        
    def init_database(self):
        """Initialize SQLite database"""
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Orders table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                customer_id TEXT,
                service_type TEXT,
                origin TEXT,
                destination TEXT,
                cargo_details TEXT,
                total_weight_kg REAL,
                estimated_delivery TEXT,
                logistics_fee REAL,
                founder_royalty REAL,
                status TEXT,
                blockchain_hash TEXT,
                timestamp TEXT
            )
        """)
        
        # Warehouses table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS warehouses (
                warehouse_id TEXT PRIMARY KEY,
                location TEXT,
                capacity_sqm INTEGER,
                current_utilization REAL,
                services TEXT
            )
        """)
        
        conn.commit()
        conn.close()
        
    def init_warehouses(self):
        """Initialize warehouse network"""
        warehouses = [
            Warehouse("WH-DXB-001", "Dubai Logistics City", 50000, 0.65, 
                     ["storage", "cross-docking", "customs", "packaging"]),
            Warehouse("WH-RUH-001", "Riyadh Dry Port", 30000, 0.50,
                     ["storage", "distribution", "customs"]),
            Warehouse("WH-JED-001", "Jeddah Islamic Port", 40000, 0.70,
                     ["storage", "sea-air", "customs", "halal-certified"]),
            Warehouse("WH-IST-001", "Istanbul Logistics Hub", 35000, 0.60,
                     ["storage", "distribution", "europe-gateway"]),
        ]
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        for wh in warehouses:
            cursor.execute("""
                INSERT OR IGNORE INTO warehouses
                (warehouse_id, location, capacity_sqm, current_utilization, services)
                VALUES (?, ?, ?, ?, ?)
            """, (wh.warehouse_id, wh.location, wh.capacity_sqm,
                  wh.current_utilization, json.dumps(wh.services)))
        
        conn.commit()
        conn.close()
        
    def create_logistics_order(self, customer_id: str, service_type: str,
                              origin: str, destination: str, cargo_details: str,
                              total_weight_kg: float, logistics_fee: float) -> LogisticsOrder:
        """Create new logistics order"""
        
        # Calculate founder royalty
        founder_royalty = logistics_fee * FOUNDER_ROYALTY_RATE
        
        # Generate order ID and blockchain hash
        order_id = f"OAL-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        blockchain_data = f"{order_id}:{customer_id}:{service_type}:{logistics_fee}:{founder_royalty}"
        blockchain_hash = hashlib.sha256(blockchain_data.encode()).hexdigest()
        
        # Estimate delivery based on service type
        delivery_estimates = {
            "air-only": "2-3 days",
            "air-sea": "7-10 days",
            "air-land": "5-7 days",
            "multimodal": "10-14 days"
        }
        estimated_delivery = delivery_estimates.get(service_type, "TBD")
        
        order = LogisticsOrder(
            order_id=order_id,
            customer_id=customer_id,
            service_type=service_type,
            origin=origin,
            destination=destination,
            cargo_details=cargo_details,
            total_weight_kg=total_weight_kg,
            estimated_delivery=estimated_delivery,
            logistics_fee=logistics_fee,
            status="confirmed",
            blockchain_hash=blockchain_hash,
            timestamp=datetime.now().isoformat()
        )
        
        # Store in database
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO orders
            (order_id, customer_id, service_type, origin, destination,
             cargo_details, total_weight_kg, estimated_delivery, logistics_fee,
             founder_royalty, status, blockchain_hash, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (order.order_id, order.customer_id, order.service_type,
              order.origin, order.destination, order.cargo_details,
              order.total_weight_kg, order.estimated_delivery, order.logistics_fee,
              founder_royalty, order.status, order.blockchain_hash, order.timestamp))
        
        conn.commit()
        conn.close()
        
        return order
    
    def get_warehouses(self) -> List[Dict]:
        """Get warehouse network"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM warehouses")
        warehouses = cursor.fetchall()
        
        conn.close()
        
        return [
            {
                "warehouse_id": w[0],
                "location": w[1],
                "capacity_sqm": w[2],
                "utilization": f"{w[3] * 100:.0f}%",
                "services": json.loads(w[4])
            }
            for w in warehouses
        ]
    
    def get_order_status(self, order_id: str) -> Dict:
        """Get order status"""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,))
        order = cursor.fetchone()
        
        conn.close()
        
        if not order:
            return {"error": "Order not found"}
        
        return {
            "order_id": order[0],
            "status": order[10],
            "service_type": order[2],
            "origin": order[3],
            "destination": order[4],
            "estimated_delivery": order[7],
            "blockchain_hash": order[11]
        }

# Initialize service
logistics = OliveAirLogistics()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "OliveAir Logistics",
        "port": 9312,
        "founder": "Omar Mohammad Abunadi",
        "founder_royalty": f"{FOUNDER_ROYALTY_RATE * 100}%",
        "network_integrations": {
            "quranchain": "Connected",
            "fungi_mesh": "Connected",
            "meshtalk": "Connected",
            "darcloud": "Connected",
            "oliveair_airlines": "Integrated",
            "oliveair_express": "Integrated",
            "olivesea_maritime": "Integrated"
        }
    })

@app.route('/warehouses', methods=['GET'])
def get_warehouses():
    """Get warehouse network"""
    warehouses = logistics.get_warehouses()
    return jsonify({
        "warehouses": warehouses,
        "total_warehouses": len(warehouses),
        "total_capacity_sqm": sum(w['capacity_sqm'] for w in warehouses)
    })

@app.route('/order/create', methods=['POST'])
def create_order():
    """Create new logistics order"""
    data = request.json
    
    try:
        order = logistics.create_logistics_order(
            customer_id=data['customer_id'],
            service_type=data['service_type'],
            origin=data['origin'],
            destination=data['destination'],
            cargo_details=data['cargo_details'],
            total_weight_kg=data['total_weight_kg'],
            logistics_fee=data['logistics_fee']
        )
        
        return jsonify({
            "success": True,
            "order": asdict(order),
            "logistics_fee": f"${order.logistics_fee:.2f}",
            "founder_royalty": f"${order.logistics_fee * FOUNDER_ROYALTY_RATE:.2f}",
            "blockchain_hash": order.blockchain_hash
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/order/<order_id>', methods=['GET'])
def get_order(order_id):
    """Get order status"""
    return jsonify(logistics.get_order_status(order_id))

@app.route('/stats', methods=['GET'])
def get_stats():
    """Get logistics statistics"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*), SUM(logistics_fee), SUM(total_weight_kg) FROM orders")
    stats = cursor.fetchone()
    
    total_orders = stats[0] or 0
    total_revenue = stats[1] or 0
    total_weight = stats[2] or 0
    
    conn.close()
    
    warehouses = logistics.get_warehouses()
    
    return jsonify({
        "total_orders": total_orders,
        "total_revenue": f"${total_revenue:,.2f}",
        "total_weight_kg": f"{total_weight:,.2f}",
        "founder_royalty_collected": f"${total_revenue * FOUNDER_ROYALTY_RATE:,.2f}",
        "warehouses": len(warehouses),
        "total_warehouse_capacity": sum(w['capacity_sqm'] for w in warehouses)
    })

if __name__ == '__main__':
    print("="*80)
    print("🚚 OLIVEAIR LOGISTICS - STARTING")
    print("="*80)
    print(f"Founder: Omar Mohammad Abunadi")
    print(f"Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print(f"Port: 9312")
    print(f"Warehouses: {len(logistics.get_warehouses())} facilities")
    print("="*80)
    
    app.run(host='0.0.0.0', port=9312, debug=False)
