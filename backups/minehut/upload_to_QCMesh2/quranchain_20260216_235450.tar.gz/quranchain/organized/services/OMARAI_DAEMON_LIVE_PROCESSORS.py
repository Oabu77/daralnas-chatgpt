#!/usr/bin/env python3
"""
QuranChain Multi-Chain Bridge Interface
Allows users to bridge assets between 47 chains
Collects 0.5% gas toll on all transactions
30% founder royalty enforced
"""

from flask import Flask, request, jsonify
import sys
sys.path.insert(0, '/home/omar/Desktop/QuranChain')
from organized.ai_agents.blockchain_gas_toll_system import blockchain_gas_toll_system

app = Flask(__name__)

@app.route('/api/bridge/quote', methods=['POST'])
def get_bridge_quote():
    """Get quote for bridging assets between chains"""
    data = request.json
    
    source_chain = data.get('source_chain')
    dest_chain = data.get('dest_chain')
    amount = float(data.get('amount', 0))
    token = data.get('token', 'USDC')
    
    # Calculate gas toll (0.5%)
    gas_toll = amount * 0.005
    founder_share = gas_toll * 0.30
    
    return jsonify({
        'source_chain': source_chain,
        'destination_chain': dest_chain,
        'amount': amount,
        'token': token,
        'gas_toll': gas_toll,
        'founder_royalty': founder_share,
        'you_receive': amount - gas_toll,
        'estimated_time': '3-5 minutes'
    })

@app.route('/api/bridge/execute', methods=['POST'])
def execute_bridge():
    """Execute bridge transaction and collect gas toll"""
    data = request.json
    
    # Process through gas toll system
    result = blockchain_gas_toll_system.process_bridge_transaction(
        source_chain=data.get('source_chain'),
        dest_chain=data.get('dest_chain'),
        amount=float(data.get('amount')),
        token=data.get('token'),
        user_wallet=data.get('wallet_address')
    )
    
    return jsonify(result)

if __name__ == '__main__':
    print("🌉 QuranChain Bridge Interface Started")
    print("📊 Monitoring 47 blockchain networks")
    print("💰 Collecting 0.5% gas toll (30% founder royalty)")
    app.run(host='0.0.0.0', port=6500)
