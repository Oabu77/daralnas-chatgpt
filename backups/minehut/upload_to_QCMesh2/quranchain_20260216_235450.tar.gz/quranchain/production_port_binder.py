#!/usr/bin/env python3
"""
🔒 QURANCHAIN PRODUCTION PORT BINDER & SERVICE MANAGER
Persistent port binding with auto-restart and health monitoring
© QuranChain™ | Omar Mohammad Abunadi™
"""

import os
import sys
import time
import socket
import subprocess
import requests
import signal
import json
from datetime import datetime
from typing import Dict, List, Tuple
from pathlib import Path

# QuranChain Ecosystem - All 103+ Services with Port Assignments
PRODUCTION_SERVICES = {
    # Core Blockchain & Infrastructure (9999-9990)
    "quranchain_blockchain_host.py": {"port": 9999, "critical": True, "category": "Core"},
    "quranchain_v5.py": {"port": 9998, "critical": True, "category": "Core"},
    "ai_agent_orchestrator.py": {"port": 9090, "critical": True, "category": "AI"},
    
    # Core AI (8080-8082)
    "organized/ai_agents/omar_ai.py": {"port": 8080, "critical": True, "category": "AI"},
    "organized/ai_agents/quranchain_ai.py": {"port": 8081, "critical": True, "category": "AI"},
    
    # AI Workforce Agents (7300-7310, 9000-9020)
    "ai_workforce/marketing_ai_agent.py": {"port": 7300, "critical": True, "category": "AI"},
    "ai_workforce/sales_ai_agent.py": {"port": 7301, "critical": True, "category": "AI"},
    "ai_workforce/optimization_ai_agent.py": {"port": 9004, "critical": True, "category": "AI"},
    "ai_workforce/it_operations_ai_agent.py": {"port": 9005, "critical": True, "category": "AI"},
    "ai_workforce/security_ai_agent.py": {"port": 9006, "critical": True, "category": "AI"},
    
    # Gas Toll Network (9503-9515)
    "ai_workforce/gas_toll_agents/polygon_gas_toll_agent.py": {"port": 9503, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/avalanche_gas_toll_agent.py": {"port": 9504, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/arbitrum_gas_toll_agent.py": {"port": 9505, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/solana_gas_toll_agent.py": {"port": 9506, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/defi_gas_toll_agent.py": {"port": 9507, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/nft_gas_toll_agent.py": {"port": 9508, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/bridge_gas_toll_agent.py": {"port": 9509, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/staking_gas_toll_agent.py": {"port": 9510, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/network_congestion_gas_toll_agent.py": {"port": 9511, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/dynamic_pricing_gas_toll_agent.py": {"port": 9512, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/fraud_detection_gas_toll_agent.py": {"port": 9513, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/revenue_optimization_gas_toll_agent.py": {"port": 9514, "critical": True, "category": "Revenue"},
    "ai_workforce/gas_toll_agents/governance_gas_toll_agent.py": {"port": 9515, "critical": True, "category": "Revenue"},
    
    # Revenue Services (8082)
    "organized/revenue/muslim_wallet_core.py": {"port": 8082, "critical": True, "category": "Revenue"},
    
    # Dar Al-Nas Companies (7000-7099)
    "dar_al_nas_host.py": {"port": 7080, "critical": True, "category": "Company"},
    
    # Financial Services (6000-6099, 8100-8199)
    "dar_payments_service.py": {"port": 6000, "critical": True, "category": "Finance"},
    "dar_real_estate_service.py": {"port": 8102, "critical": True, "category": "Finance"},
    "financial_general_service.py": {"port": 8101, "critical": True, "category": "Finance"},
    
    # Telecommunications (5000-5099, 9001, 8083)
    "meshtalk_global_customer_portal.py": {"port": 5000, "critical": True, "category": "Telecom"},
    "meshtalk_os_host.py": {"port": 9001, "critical": True, "category": "Telecom"},
    "fungi_network_service.py": {"port": 5006, "critical": True, "category": "Telecom"},
    "organized/services/meshtalk_telecom_service.py": {"port": 8083, "critical": True, "category": "Telecom"},
    
    # Aviation & Maritime Services (8086-8089)
    "organized/services/oliveair_express_freight.py": {"port": 8086, "critical": True, "category": "Aviation"},
    "organized/services/oliveair_logistics.py": {"port": 8087, "critical": True, "category": "Aviation"},
    "organized/services/olivesea_maritime_shipping.py": {"port": 8088, "critical": True, "category": "Maritime"},
    "organized/services/olivesea_cargo_freight.py": {"port": 8089, "critical": True, "category": "Maritime"},
    
    # Cloud Services (8084-8085, 8200)
    "organized/services/darcloud_ai_agent_school.py": {"port": 8084, "critical": True, "category": "Cloud"},
    "organized/services/darcloud_web_hosting_production.py": {"port": 8085, "critical": True, "category": "Cloud"},
    "organized/services/darcloud_autonomous_server.py": {"port": 8200, "critical": True, "category": "Cloud"},
    
    # Bridge & Revenue Generation (6600)
    "organized/services/quranchain_bridge_interface.py": {"port": 6600, "critical": True, "category": "Revenue"},
    
    # Customer & CRM Services (5001-5010)
    "crm_api_service.py": {"port": 5001, "critical": True, "category": "Customer"},
    "live_dashboard.py": {"port": 5002, "critical": True, "category": "Monitoring"},
    
    # Service Stubs (8300-8399)
    "stub_service_cloud.py": {"port": 8300, "critical": False, "category": "Stub"},
    "stub_service_healthcare.py": {"port": 8301, "critical": False, "category": "Stub"},
    "stub_service_education.py": {"port": 8302, "critical": False, "category": "Stub"},
    "stub_service_realestate.py": {"port": 8303, "critical": False, "category": "Stub"},
    "stub_service_commerce.py": {"port": 8304, "critical": False, "category": "Stub"},
    "stub_service_media.py": {"port": 8305, "critical": False, "category": "Stub"},
    "stub_service_travel.py": {"port": 8306, "critical": False, "category": "Stub"},
    "stub_service_professional.py": {"port": 8307, "critical": False, "category": "Stub"},
    "stub_service_finance.py": {"port": 8308, "critical": False, "category": "Stub"},
    "stub_service_manufacturing.py": {"port": 8309, "critical": False, "category": "Stub"},
    "stub_service_agriculture.py": {"port": 8310, "critical": False, "category": "Stub"},
    "stub_service_energy.py": {"port": 8311, "critical": False, "category": "Stub"},
    "stub_service_transportation.py": {"port": 8312, "critical": False, "category": "Stub"},
    "stub_service_construction.py": {"port": 8313, "critical": False, "category": "Stub"},
    "stub_service_retail.py": {"port": 8314, "critical": False, "category": "Stub"},
    "stub_service_hospitality.py": {"port": 8315, "critical": False, "category": "Stub"},
}

class ProductionPortBinder:
    """Production-grade port binder with persistence and auto-restart"""
    
    def __init__(self):
        self.base_path = Path("/home/omar/Desktop/QuranChain")
        self.processes = {}  # Port -> subprocess.Popen
        self.port_locks = {}  # Port -> socket
        self.restart_counts = {}  # Service -> count
        self.max_restarts = 5
        self.health_check_interval = 30
        self.status_file = self.base_path / "production_services_status.json"
        
    def bind_port(self, port: int) -> bool:
        """Bind and lock a port to prevent conflicts"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('0.0.0.0', port))
            sock.listen(1)
            self.port_locks[port] = sock
            return True
        except Exception as e:
            print(f"❌ Failed to bind port {port}: {e}")
            return False
    
    def release_port(self, port: int):
        """Release a locked port"""
        if port in self.port_locks:
            try:
                self.port_locks[port].close()
                del self.port_locks[port]
            except:
                pass
    
    def start_service(self, filepath: str, port: int, critical: bool, category: str) -> bool:
        """Start a service and bind its port"""
        full_path = self.base_path / filepath
        
        if not full_path.exists():
            print(f"⚠️  Service file not found: {filepath}")
            return False
        
        try:
            # Create log file
            log_file = self.base_path / f"monitoring_logs/service_{port}.log"
            log_file.parent.mkdir(exist_ok=True)
            
            # Launch service
            with open(log_file, 'w') as log:
                process = subprocess.Popen(
                    ["python3", str(full_path)],
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    cwd=str(self.base_path)
                )
            
            self.processes[port] = {
                'process': process,
                'filepath': filepath,
                'critical': critical,
                'category': category,
                'started': datetime.now().isoformat(),
                'restarts': self.restart_counts.get(filepath, 0)
            }
            
            print(f"✅ Started: Port {port:4d} | {filepath:50} | PID {process.pid}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to start {filepath}: {e}")
            return False
    
    def check_service_health(self, port: int) -> bool:
        """Check if service is responding on its health endpoint"""
        try:
            response = requests.get(f"http://localhost:{port}/health", timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def restart_service(self, filepath: str, port: int, critical: bool, category: str) -> bool:
        """Restart a failed service"""
        restart_count = self.restart_counts.get(filepath, 0)
        
        if restart_count >= self.max_restarts:
            print(f"🛑 Service {filepath} exceeded max restarts ({self.max_restarts})")
            return False
        
        print(f"🔄 Restarting: {filepath} (attempt {restart_count + 1})")
        
        # Kill existing process if any
        if port in self.processes:
            try:
                self.processes[port]['process'].kill()
            except:
                pass
        
        # Increment restart counter
        self.restart_counts[filepath] = restart_count + 1
        
        # Wait before restart
        time.sleep(2)
        
        # Restart
        return self.start_service(filepath, port, critical, category)
    
    def monitor_and_maintain(self):
        """Continuous monitoring and auto-restart loop"""
        print("\n" + "="*120)
        print("🔒 PRODUCTION PORT BINDER - CONTINUOUS MONITORING ACTIVE")
        print("="*120)
        
        while True:
            try:
                current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                print(f"\n[{current_time}] 🔍 Health Check Cycle")
                
                for filepath, config in PRODUCTION_SERVICES.items():
                    port = config['port']
                    critical = config['critical']
                    category = config['category']
                    
                    # Check if process is running
                    if port in self.processes:
                        process = self.processes[port]['process']
                        
                        # Check if process died
                        if process.poll() is not None:
                            print(f"💀 Process died: Port {port} | {filepath}")
                            if critical:
                                self.restart_service(filepath, port, critical, category)
                        else:
                            # Process running, check health endpoint
                            if not self.check_service_health(port):
                                print(f"⚠️  Unhealthy: Port {port} | {filepath}")
                                # Don't restart on every failed health check, just warn
                    else:
                        # Service not started, start it
                        print(f"🚀 Starting: Port {port} | {filepath}")
                        self.start_service(filepath, port, critical, category)
                
                # Save status
                self.save_status()
                
                # Sleep until next check
                time.sleep(self.health_check_interval)
                
            except KeyboardInterrupt:
                print("\n\n🛑 Shutting down port binder...")
                self.cleanup()
                break
            except Exception as e:
                print(f"❌ Monitor error: {e}")
                time.sleep(5)
    
    def save_status(self):
        """Save current status to file"""
        try:
            status = {
                'timestamp': datetime.now().isoformat(),
                'total_services': len(PRODUCTION_SERVICES),
                'running_services': len(self.processes),
                'services': {}
            }
            
            for port, data in self.processes.items():
                status['services'][str(port)] = {
                    'filepath': data['filepath'],
                    'pid': data['process'].pid,
                    'critical': data['critical'],
                    'category': data['category'],
                    'started': data['started'],
                    'restarts': data['restarts'],
                    'healthy': self.check_service_health(port)
                }
            
            with open(self.status_file, 'w') as f:
                json.dump(status, f, indent=2)
                
        except Exception as e:
            print(f"⚠️  Failed to save status: {e}")
    
    def cleanup(self):
        """Clean shutdown of all services"""
        print("🧹 Cleaning up...")
        
        for port, data in self.processes.items():
            try:
                data['process'].terminate()
                print(f"🛑 Stopped port {port}")
            except:
                pass
        
        for port in list(self.port_locks.keys()):
            self.release_port(port)
        
        print("✅ Cleanup complete")
    
    def deploy_all_services(self):
        """Deploy all production services with port binding"""
        print("\n" + "="*120)
        print("🚀 DEPLOYING ALL QURANCHAIN PRODUCTION SERVICES")
        print("="*120)
        
        # Group services by category
        categories = {}
        for filepath, config in PRODUCTION_SERVICES.items():
            cat = config['category']
            if cat not in categories:
                categories[cat] = []
            categories[cat].append((filepath, config))
        
        # Deploy by category
        for category, services in sorted(categories.items()):
            print(f"\n📁 {category} Services ({len(services)} services)")
            
            for filepath, config in sorted(services, key=lambda x: x[1]['port']):
                port = config['port']
                critical = config['critical']
                
                self.start_service(filepath, port, critical, category)
                time.sleep(0.5)  # Small delay between starts
        
        print("\n" + "="*120)
        print(f"✅ Deployment complete: {len(self.processes)}/{len(PRODUCTION_SERVICES)} services started")
        print("="*120)
        
        # Start continuous monitoring
        self.monitor_and_maintain()

def main():
    """Main entry point"""
    print("="*120)
    print("🔒 QURANCHAIN PRODUCTION PORT BINDER")
    print("="*120)
    print(f"📊 Total Services: {len(PRODUCTION_SERVICES)}")
    print(f"⚙️  Health Check Interval: 30 seconds")
    print(f"🔄 Max Auto-Restarts: 5 per service")
    print("="*120)
    
    binder = ProductionPortBinder()
    binder.deploy_all_services()

if __name__ == "__main__":
    main()
