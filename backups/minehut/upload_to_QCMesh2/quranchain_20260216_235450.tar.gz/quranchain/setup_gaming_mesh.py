#!/usr/bin/env python3
"""
🎮🕸️ GAMING MESH SETUP WIZARD
Interactive setup for all gaming server failsafe nodes.
Validates credentials, deploys plugins, connects nodes.

Usage:
  python3 setup_gaming_mesh.py              # Interactive setup
  python3 setup_gaming_mesh.py --verify     # Verify all connections
  python3 setup_gaming_mesh.py --status     # Show node status

© Omar Mohammad Abunadi™ — QuranChain™ / DarCloud™
"""
import sys
import os
import json
import socket
import time
import struct
import hashlib
from pathlib import Path
from datetime import datetime

sys.path.insert(0, "/home/omar/Desktop/QuranChain")
os.chdir("/home/omar/Desktop/QuranChain")

# Load .env
ENV_FILE = Path("/home/omar/Desktop/QuranChain/.env")
env_vars = {}
if ENV_FILE.exists():
    for line in ENV_FILE.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env_vars[k.strip()] = v.strip()
            os.environ.setdefault(k.strip(), v.strip())


def print_header():
    print()
    print("=" * 60)
    print("  🎮🕸️ QuranChain™ Gaming Server Mesh Setup Wizard")
    print("  Hidden failsafe nodes on free gaming infrastructure")
    print("  © Omar Mohammad Abunadi™")
    print("=" * 60)
    print()


def check_minecraft_server(address, port=25565, timeout=10):
    """Test Minecraft server connectivity using MC protocol handshake"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((address, port))

        # Send MC handshake (protocol 767 = 1.21, state=1 for status)
        def encode_varint(val):
            r = bytearray()
            while True:
                b = val & 0x7F
                val >>= 7
                if val:
                    b |= 0x80
                r.append(b)
                if not val:
                    break
            return bytes(r)

        def encode_string(s):
            e = s.encode("utf-8")
            return encode_varint(len(e)) + e

        # Handshake packet
        data = encode_varint(767) + encode_string(address) + struct.pack("!H", port) + encode_varint(1)
        packet = encode_varint(0x00) + data
        sock.sendall(encode_varint(len(packet)) + packet)

        # Status request
        status_req = encode_varint(0x00)
        sock.sendall(encode_varint(len(status_req)) + status_req)

        # Read response
        resp = sock.recv(4096)
        sock.close()

        if len(resp) > 5:
            # Try to extract JSON status
            try:
                # Skip varint length + packet id, find JSON
                json_start = resp.index(b"{")
                json_end = resp.rindex(b"}") + 1
                status_json = json.loads(resp[json_start:json_end].decode("utf-8", errors="replace"))
                return True, status_json
            except (ValueError, json.JSONDecodeError):
                return True, {"raw_response": len(resp)}
        return True, {"connected": True}
    except socket.timeout:
        return False, "Connection timed out"
    except ConnectionRefusedError:
        return False, "Connection refused"
    except Exception as e:
        return False, str(e)


def check_discord_bot(token):
    """Verify Discord bot token is valid"""
    try:
        import requests
        resp = requests.get(
            "https://discord.com/api/v10/users/@me",
            headers={"Authorization": "Bot " + token},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            return True, data.get("username", "unknown")
        return False, "HTTP %d" % resp.status_code
    except ImportError:
        return False, "requests module not installed"
    except Exception as e:
        return False, str(e)


def check_roblox_api(api_key, universe_id):
    """Verify Roblox Open Cloud credentials"""
    try:
        import requests
        resp = requests.get(
            "https://apis.roblox.com/datastores/v1/universes/%s/standard-datastores" % universe_id,
            headers={"x-api-key": api_key},
            timeout=10,
        )
        if resp.status_code == 200:
            return True, "API key valid"
        return False, "HTTP %d" % resp.status_code
    except ImportError:
        return False, "requests module not installed"
    except Exception as e:
        return False, str(e)


def check_tcp_server(address, port, timeout=5):
    """Test basic TCP connectivity"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((address, port))
        sock.close()
        return True, "Connected"
    except Exception as e:
        return False, str(e)


def verify_all():
    """Verify all gaming mesh node connections"""
    print_header()
    print("  🔍 Verifying all gaming server mesh nodes...\n")

    results = []

    # Minecraft nodes
    mc_servers = [
        ("Aternos EU-1", "aternos.me", 25565),
        ("Aternos US-1", "aternos.me", 25565),
        ("QCMesh1", "QCMesh1.minehut.gg", 25565),
        ("QCMesh2", "QCMesh2.minehut.gg", 25565),
        ("server.pro Bridge-1", "server.pro", 25565),
    ]

    print("  🎮 MINECRAFT SERVERS")
    print("  " + "-" * 50)
    for name, addr, port in mc_servers:
        ok, info = check_minecraft_server(addr, port, timeout=8)
        status = "✅ ONLINE" if ok else "❌ OFFLINE"
        print("  %s  %-25s  %s" % (status, name, info if not ok else ""))
        results.append((name, "minecraft", ok))

    # Discord bot
    print("\n  🤖 DISCORD BOT")
    print("  " + "-" * 50)
    token = env_vars.get("DISCORD_MESH_BOT_TOKEN", "")
    if token:
        ok, info = check_discord_bot(token)
        status = "✅ ONLINE" if ok else "❌ OFFLINE"
        print("  %s  Discord Relay Bot       %s" % (status, ("(bot: %s)" % info) if ok else info))
        results.append(("Discord Relay", "discord", ok))
        results.append(("Discord Storage", "discord", ok))
    else:
        print("  ⚠️  No DISCORD_MESH_BOT_TOKEN in .env")
        results.append(("Discord Relay", "discord", False))
        results.append(("Discord Storage", "discord", False))

    # Roblox
    print("\n  🎲 ROBLOX CLOUD")
    print("  " + "-" * 50)
    roblox_key = env_vars.get("ROBLOX_CLOUD_API_KEY", "")
    roblox_uid = env_vars.get("ROBLOX_UNIVERSE_ID", "")
    if roblox_key and roblox_uid:
        ok, info = check_roblox_api(roblox_key, roblox_uid)
        status = "✅ ONLINE" if ok else "❌ OFFLINE"
        print("  %s  Roblox Mesh-1           %s" % (status, info))
        results.append(("Roblox Mesh-1", "roblox", ok))
    else:
        print("  ⚠️  No ROBLOX_CLOUD_API_KEY in .env")
        results.append(("Roblox Mesh-1", "roblox", False))

    # Source engine servers
    print("\n  🔫 SOURCE ENGINE / OTHER")
    print("  " + "-" * 50)
    other_servers = [
        ("GMod Relay-1", "0.0.0.0", 27015),
        ("CS2 Community-1", "0.0.0.0", 27015),
        ("Terraria Relay-1", "0.0.0.0", 7777),
        ("Valheim Mesh-1", "0.0.0.0", 2456),
        ("Factorio Relay-1", "0.0.0.0", 34197),
    ]
    for name, addr, port in other_servers:
        if addr == "0.0.0.0":
            print("  ⚠️  %-25s  Needs server address in config" % name)
            results.append((name, "other", False))
        else:
            ok, info = check_tcp_server(addr, port)
            status = "✅ ONLINE" if ok else "❌ OFFLINE"
            print("  %s  %-25s  %s" % (status, name, "" if ok else info))
            results.append((name, "other", ok))

    # Summary
    online = sum(1 for _, _, ok in results if ok)
    total = len(results)
    print()
    print("  " + "=" * 50)
    print("  📊 SUMMARY: %d / %d nodes verified" % (online, total))
    print("  🎮 Platforms checked: Minecraft, Discord, Roblox, Source Engine")
    print("  💰 Founder royalty: 30%% (IMMUTABLE)")
    print("  " + "=" * 50)

    return results


def show_status():
    """Show current gaming mesh engine status"""
    print_header()
    try:
        from organized.services.gaming_server_mesh import gaming_mesh_engine
        status = gaming_mesh_engine.get_status()
        print("  Engine:     %s" % status["status"])
        print("  Nodes:      %d / %d online" % (status["nodes_online"], status["nodes_total"]))
        print("  Chunks:     %d stored, %d replicated" % (status["chunks_stored"], status["chunks_replicated"]))
        print("  Relayed:    %d packets" % status["packets_relayed"])
        print("  Storage:    %.2f MB" % status["total_storage_mb"])
        print("  Uptime:     %s" % (status["uptime_start"] or "not started"))
        print()
        print("  Platforms:")
        for platform, info in status.get("platforms", {}).items():
            print("    %-25s %d/%d online" % (platform, info["online"], info["total"]))
    except Exception as e:
        print("  ❌ Engine not running: %s" % e)


def interactive_setup():
    """Interactive setup wizard"""
    print_header()
    print("  This wizard helps you set up all gaming server mesh nodes.\n")

    updates = {}

    # Discord
    print("  📌 STEP 1: Discord Bot")
    print("  " + "-" * 40)
    token = env_vars.get("DISCORD_MESH_BOT_TOKEN", "")
    if token:
        print("  ✅ Discord bot token already configured")
    else:
        print("  Go to: https://discord.com/developers/applications")
        print("  1. Click 'New Application' → Name: 'QuranChain Mesh Relay'")
        print("  2. Go to 'Bot' tab → Click 'Reset Token' → Copy it")
        print("  3. Enable: Message Content Intent")
        t = input("  Paste bot token (or press Enter to skip): ").strip()
        if t:
            updates["DISCORD_MESH_BOT_TOKEN"] = t

    # Discord channel
    channel = env_vars.get("DISCORD_MESH_CHANNEL_ID", "")
    if not channel and (token or "DISCORD_MESH_BOT_TOKEN" in updates):
        print("\n  Create a Discord server with a #mesh-relay channel")
        c = input("  Paste channel ID (or press Enter to skip): ").strip()
        if c:
            updates["DISCORD_MESH_CHANNEL_ID"] = c

    # Roblox
    print("\n  📌 STEP 2: Roblox Open Cloud")
    print("  " + "-" * 40)
    rk = env_vars.get("ROBLOX_CLOUD_API_KEY", "")
    if rk:
        print("  ✅ Roblox API key already configured")
    else:
        print("  Go to: https://create.roblox.com/dashboard/credentials")
        print("  1. Create API Key → Name: 'QuranChain Mesh'")
        print("  2. Add: MessagingService (Write), DataStore (Read+Write)")
        k = input("  Paste API key (or press Enter to skip): ").strip()
        if k:
            updates["ROBLOX_CLOUD_API_KEY"] = k
        u = input("  Paste Universe ID (or press Enter to skip): ").strip()
        if u:
            updates["ROBLOX_UNIVERSE_ID"] = u

    # Minecraft
    print("\n  📌 STEP 3: Minecraft Servers")
    print("  " + "-" * 40)
    print("  Aternos: already connected (2 nodes)")
    print("  server.pro: signed up")
    print("  Minehut: https://minehut.com — create 2 free servers")
    print("  Upload plugin from: product_downloads/gaming_plugins/minecraft/")
    input("  Press Enter when done (or to skip)...")

    # Write updates to .env
    if updates:
        print("\n  💾 Updating .env with %d new values..." % len(updates))
        content = ENV_FILE.read_text()
        for key, value in updates.items():
            if key + "=" in content:
                lines = content.split("\n")
                for i, line in enumerate(lines):
                    if line.startswith(key + "="):
                        lines[i] = "%s=%s" % (key, value)
                        break
                content = "\n".join(lines)
            else:
                content += "\n%s=%s" % (key, value)
        ENV_FILE.write_text(content)
        print("  ✅ .env updated")

    # Verify
    print("\n  🔍 Running verification...\n")
    verify_all()


if __name__ == "__main__":
    if "--verify" in sys.argv:
        verify_all()
    elif "--status" in sys.argv:
        show_status()
    else:
        interactive_setup()
