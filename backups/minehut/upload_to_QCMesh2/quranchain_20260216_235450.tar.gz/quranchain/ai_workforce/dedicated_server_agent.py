#!/usr/bin/env python3
"""
🖥️🔒 DEDICATED SERVER AGENT - INFRASTRUCTURE MANAGEMENT SPECIALIST
═══════════════════════════════════════════════════════════════════════════════
Specialized AI agent for dedicated server management, monitoring, maintenance,
security hardening, and performance optimization across the QuranChain ecosystem.

Capabilities:
  🖥️ Server Provisioning & Configuration
  📊 Performance Monitoring & Analytics
  🔒 Security Hardening & Compliance
  💾 Backup & Disaster Recovery
  🔄 Automated Maintenance Tasks
  📈 Resource Optimization
  🚨 Alert Management & Incident Response
  📋 Compliance Reporting

Author: QuranChain AI Agent Team
Date: 2026-01-15
"""

import asyncio
import json
import logging
import os
import platform
import psutil
import shutil
import subprocess
import threading
import time
from blockchain_logging_handler import setup_blockchain_logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Any, Optional, Set, Tuple
import uuid
import socket
import hashlib

# Add project root to path
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import QuranChain dependencies
try:
    from cosmos_blockchain_integration import cosmos_blockchain_client, COSMOS_CONFIG
    COSMOS_ENABLED = True
except ImportError:
    COSMOS_ENABLED = False
    cosmos_blockchain_client = None

# Configure logging
setup_blockchain_logging()
logger = logging.getLogger(__name__)

class ServerStatus(Enum):
    """Enumeration of server states"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    MAINTENANCE = "maintenance"
    OFFLINE = "offline"

class BackupStatus(Enum):
    """Enumeration of backup states"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class ServerMetrics:
    """Server performance metrics"""
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    disk_usage: Dict[str, float] = field(default_factory=dict)
    network_io: Dict[str, int] = field(default_factory=dict)
    load_average: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    uptime_seconds: int = 0
    temperature_celsius: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class BackupJob:
    """Backup job information"""
    backup_id: str
    name: str
    source_paths: List[str]
    destination: str
    status: BackupStatus
    start_time: datetime
    end_time: Optional[datetime] = None
    size_bytes: int = 0
    compression_ratio: float = 1.0

@dataclass
class SecurityScan:
    """Security scan results"""
    scan_id: str
    scan_type: str
    start_time: datetime
    end_time: Optional[datetime] = None
    vulnerabilities_found: int = 0
    critical_issues: int = 0
    warnings: int = 0
    results: Dict[str, Any] = field(default_factory=dict)

class DedicatedServerAgent:
    """
    Dedicated Server Agent - Specialized AI for server infrastructure management
    """

    def __init__(self):
        self.node_id = str(uuid.uuid4())
        self.server_id = socket.gethostname()
        self.server_status = ServerStatus.HEALTHY
        self.metrics_history: List[ServerMetrics] = []
        self.backup_jobs: Dict[str, BackupJob] = {}
        self.security_scans: Dict[str, SecurityScan] = {}
        self.monitoring_active = False
        self.maintenance_active = False
        self.monitoring_thread: Optional[threading.Thread] = None
        self.maintenance_thread: Optional[threading.Thread] = None

        # Server configuration
        self.config = {
            "backup_schedule": "daily",
            "security_scan_schedule": "weekly",
            "maintenance_window": "02:00-04:00",
            "alert_thresholds": {
                "cpu_warning": 70.0,
                "cpu_critical": 90.0,
                "memory_warning": 80.0,
                "memory_critical": 95.0,
                "disk_warning": 85.0,
                "disk_critical": 95.0
            }
        }

        logger.info(f"🖥️ Dedicated Server Agent initialized for {self.server_id}")

    def start_server_monitoring(self):
        """Start comprehensive server monitoring"""
        if self.monitoring_active:
            logger.warning("⚠️ Server monitoring already active")
            return

        logger.info("📊 Starting server monitoring...")
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

    def stop_server_monitoring(self):
        """Stop server monitoring"""
        logger.info("🛑 Stopping server monitoring...")
        self.monitoring_active = False
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)

    def start_maintenance_mode(self):
        """Start automated maintenance mode"""
        if self.maintenance_active:
            logger.warning("⚠️ Maintenance mode already active")
            return

        logger.info("🔧 Starting maintenance mode...")
        self.maintenance_active = True
        self.server_status = ServerStatus.MAINTENANCE
        self.maintenance_thread = threading.Thread(target=self._maintenance_loop, daemon=True)
        self.maintenance_thread.start()

    def stop_maintenance_mode(self):
        """Stop maintenance mode"""
        logger.info("🔧 Stopping maintenance mode...")
        self.maintenance_active = False
        self.server_status = ServerStatus.HEALTHY
        if self.maintenance_thread and self.maintenance_thread.is_alive():
            self.maintenance_thread.join(timeout=5)

    def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.monitoring_active:
            try:
                metrics = self._collect_server_metrics()
                self.metrics_history.append(metrics)

                # Keep only last 1000 metrics
                if len(self.metrics_history) > 1000:
                    self.metrics_history = self.metrics_history[-1000:]

                # Check alerts
                self._check_server_alerts(metrics)

                # Update server status
                self._update_server_status(metrics)

                time.sleep(60)  # Monitor every minute

            except Exception as e:
                logger.error(f"❌ Monitoring error: {e}")
                time.sleep(10)

    def _maintenance_loop(self):
        """Maintenance tasks loop"""
        while self.maintenance_active:
            try:
                self._perform_maintenance_tasks()
                time.sleep(3600)  # Run maintenance tasks hourly
            except Exception as e:
                logger.error(f"❌ Maintenance error: {e}")
                time.sleep(60)

    def _collect_server_metrics(self) -> ServerMetrics:
        """Collect comprehensive server metrics"""
        cpu_usage = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()

        disk_usage = {}
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disk_usage[partition.mountpoint] = usage.percent
            except Exception:
                continue

        network_io = {}
        net_io = psutil.net_io_counters()
        network_io = {
            "bytes_sent": net_io.bytes_sent,
            "bytes_recv": net_io.bytes_recv,
            "packets_sent": net_io.packets_sent,
            "packets_recv": net_io.packets_recv
        }

        load_average = (0.0, 0.0, 0.0)
        try:
            load_average = os.getloadavg()
        except AttributeError:
            pass

        # Try to get temperature (Linux only)
        temperature = None
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                # Get CPU temperature
                for sensor_name, sensors in temps.items():
                    if 'cpu' in sensor_name.lower() or 'core' in sensor_name.lower():
                        temperature = sensors[0].current
                        break
        except Exception:
            pass

        return ServerMetrics(
            cpu_usage=cpu_usage,
            memory_usage=memory.percent,
            disk_usage=disk_usage,
            network_io=network_io,
            load_average=load_average,
            uptime_seconds=int(time.time() - psutil.boot_time()),
            temperature_celsius=temperature
        )

    def _check_server_alerts(self, metrics: ServerMetrics):
        """Check for server alerts based on metrics"""
        alerts = []

        thresholds = self.config["alert_thresholds"]

        if metrics.cpu_usage > thresholds["cpu_critical"]:
            alerts.append(f"🚨 CRITICAL: CPU usage {metrics.cpu_usage}% (threshold: {thresholds['cpu_critical']}%)")
        elif metrics.cpu_usage > thresholds["cpu_warning"]:
            alerts.append(f"⚠️ WARNING: CPU usage {metrics.cpu_usage}% (threshold: {thresholds['cpu_warning']}%)")

        if metrics.memory_usage > thresholds["memory_critical"]:
            alerts.append(f"🚨 CRITICAL: Memory usage {metrics.memory_usage}% (threshold: {thresholds['memory_critical']}%)")
        elif metrics.memory_usage > thresholds["memory_warning"]:
            alerts.append(f"⚠️ WARNING: Memory usage {metrics.memory_usage}% (threshold: {thresholds['memory_warning']}%)")

        for mount_point, usage in metrics.disk_usage.items():
            if usage > thresholds["disk_critical"]:
                alerts.append(f"🚨 CRITICAL: Disk usage on {mount_point}: {usage}% (threshold: {thresholds['disk_critical']}%)")
            elif usage > thresholds["disk_warning"]:
                alerts.append(f"⚠️ WARNING: Disk usage on {mount_point}: {usage}% (threshold: {thresholds['disk_warning']}%)")

        for alert in alerts:
            logger.warning(alert)

    def _update_server_status(self, metrics: ServerMetrics):
        """Update server status based on metrics"""
        thresholds = self.config["alert_thresholds"]

        if (metrics.cpu_usage > thresholds["cpu_critical"] or
            metrics.memory_usage > thresholds["memory_critical"] or
            any(usage > thresholds["disk_critical"] for usage in metrics.disk_usage.values())):
            self.server_status = ServerStatus.CRITICAL
        elif (metrics.cpu_usage > thresholds["cpu_warning"] or
              metrics.memory_usage > thresholds["memory_warning"] or
              any(usage > thresholds["disk_warning"] for usage in metrics.disk_usage.values())):
            self.server_status = ServerStatus.WARNING
        else:
            self.server_status = ServerStatus.HEALTHY

    def _perform_maintenance_tasks(self):
        """Perform automated maintenance tasks"""
        logger.info("🔧 Running maintenance tasks...")

        tasks = []

        # Clean package cache
        if platform.system() == "Linux":
            if os.path.exists("/usr/bin/apt"):
                result = self._execute_command("sudo apt autoremove -y && sudo apt autoclean")
                tasks.append(f"Package cleanup: {'success' if result['success'] else 'failed'}")

            # Clean journal logs
            result = self._execute_command("sudo journalctl --vacuum-time=7d")
            tasks.append(f"Journal cleanup: {'success' if result['success'] else 'failed'}")

        # Clean temporary files
        temp_dirs = ["/tmp", "/var/tmp"]
        for temp_dir in temp_dirs:
            if os.path.exists(temp_dir):
                try:
                    result = self._execute_command(f"find {temp_dir} -type f -mtime +7 -delete")
                    tasks.append(f"Temp file cleanup in {temp_dir}: success")
                except Exception as e:
                    tasks.append(f"Temp file cleanup in {temp_dir}: failed - {e}")

        # Update system if in maintenance window
        if self._is_maintenance_window():
            if platform.system() == "Linux":
                if os.path.exists("/usr/bin/apt"):
                    result = self._execute_command("sudo apt update && sudo apt upgrade -y")
                    tasks.append(f"System update: {'success' if result['success'] else 'failed'}")

        logger.info(f"🔧 Maintenance tasks completed: {tasks}")

    def _is_maintenance_window(self) -> bool:
        """Check if current time is within maintenance window"""
        try:
            window = self.config["maintenance_window"]
            start_str, end_str = window.split("-")

            now = datetime.now().time()
            start = datetime.strptime(start_str, "%H:%M").time()
            end = datetime.strptime(end_str, "%H:%M").time()

            if start <= end:
                return start <= now <= end
            else:  # Window crosses midnight
                return now >= start or now <= end

        except Exception:
            return False

    def _execute_command(self, command: str, timeout: int = 300) -> Dict[str, Any]:
        """Execute a system command safely"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )

            return {
                "success": result.returncode == 0,
                "return_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr
            }

        except subprocess.TimeoutExpired:
            return {"success": False, "error": f"Command timed out after {timeout} seconds"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def create_backup(self, name: str, source_paths: List[str], destination: str,
                     compression: bool = True) -> Dict[str, Any]:
        """Create a backup job"""
        backup_id = str(uuid.uuid4())

        backup = BackupJob(
            backup_id=backup_id,
            name=name,
            source_paths=source_paths,
            destination=destination,
            status=BackupStatus.PENDING,
            start_time=datetime.now()
        )

        self.backup_jobs[backup_id] = backup

        # Start backup in background thread
        threading.Thread(
            target=self._execute_backup,
            args=(backup, compression),
            daemon=True
        ).start()

        logger.info(f"💾 Backup job {backup_id} created: {name}")

        return {
            "success": True,
            "backup_id": backup_id,
            "status": "started"
        }

    def _execute_backup(self, backup: BackupJob, compression: bool):
        """Execute backup operation"""
        try:
            backup.status = BackupStatus.RUNNING
            logger.info(f"💾 Starting backup: {backup.name}")

            # Calculate total size
            total_size = 0
            for source_path in backup.source_paths:
                if os.path.exists(source_path):
                    if os.path.isfile(source_path):
                        total_size += os.path.getsize(source_path)
                    else:
                        for dirpath, dirnames, filenames in os.walk(source_path):
                            for filename in filenames:
                                filepath = os.path.join(dirpath, filename)
                                try:
                                    total_size += os.path.getsize(filepath)
                                except OSError:
                                    continue

            backup.size_bytes = total_size

            # Create backup archive
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            archive_name = f"{backup.name}_{timestamp}.tar"
            if compression:
                archive_name += ".gz"

            archive_path = os.path.join(backup.destination, archive_name)

            # Ensure destination exists
            os.makedirs(backup.destination, exist_ok=True)

            # Create tar command
            cmd = ["tar"]
            if compression:
                cmd.append("-czf")
            else:
                cmd.append("-cf")

            cmd.append(archive_path)
            cmd.extend(backup.source_paths)

            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                # Calculate compression ratio
                if compression:
                    archive_size = os.path.getsize(archive_path)
                    backup.compression_ratio = total_size / archive_size if archive_size > 0 else 1.0

                backup.status = BackupStatus.COMPLETED
                logger.info(f"✅ Backup completed: {backup.name} ({archive_path})")
            else:
                backup.status = BackupStatus.FAILED
                logger.error(f"❌ Backup failed: {backup.name} - {result.stderr}")

        except Exception as e:
            backup.status = BackupStatus.FAILED
            logger.error(f"❌ Backup error: {backup.name} - {e}")

        backup.end_time = datetime.now()

    def run_security_scan(self, scan_type: str = "full") -> Dict[str, Any]:
        """Run a security scan"""
        scan_id = str(uuid.uuid4())

        scan = SecurityScan(
            scan_id=scan_id,
            scan_type=scan_type,
            start_time=datetime.now()
        )

        self.security_scans[scan_id] = scan

        # Start scan in background thread
        threading.Thread(
            target=self._execute_security_scan,
            args=(scan,),
            daemon=True
        ).start()

        logger.info(f"🔒 Security scan {scan_id} started: {scan_type}")

        return {
            "success": True,
            "scan_id": scan_id,
            "status": "started"
        }

    def _execute_security_scan(self, scan: SecurityScan):
        """Execute security scan"""
        try:
            logger.info(f"🔒 Running security scan: {scan.scan_type}")

            results = {
                "vulnerabilities": [],
                "warnings": [],
                "recommendations": []
            }

            if scan.scan_type == "full" or scan.scan_type == "system":
                # Check file permissions
                results["file_permissions"] = self._check_file_permissions()

                # Check running services
                results["running_services"] = self._check_running_services()

                # Check network security
                results["network_security"] = self._check_network_security()

            if scan.scan_type == "full" or scan.scan_type == "packages":
                # Check for outdated packages
                results["package_updates"] = self._check_package_updates()

            # Analyze results
            scan.vulnerabilities_found = len(results.get("vulnerabilities", []))
            scan.warnings = len(results.get("warnings", []))
            scan.critical_issues = len([v for v in results.get("vulnerabilities", []) if v.get("severity") == "critical"])
            scan.results = results

            logger.info(f"✅ Security scan completed: {scan.vulnerabilities_found} vulnerabilities, {scan.warnings} warnings")

        except Exception as e:
            logger.error(f"❌ Security scan error: {e}")
            scan.results = {"error": str(e)}

        scan.end_time = datetime.now()

    def _check_file_permissions(self) -> List[Dict[str, Any]]:
        """Check file permissions for security issues"""
        issues = []

        # Check critical system files
        critical_files = [
            "/etc/passwd",
            "/etc/shadow",
            "/etc/sudoers"
        ]

        for file_path in critical_files:
            if os.path.exists(file_path):
                stat = os.stat(file_path)
                if stat.st_mode & 0o777 > 0o644:  # Too permissive
                    issues.append({
                        "type": "file_permissions",
                        "file": file_path,
                        "severity": "high",
                        "description": f"File has overly permissive permissions: {oct(stat.st_mode)}"
                    })

        return issues

    def _check_running_services(self) -> List[Dict[str, Any]]:
        """Check running services for security issues"""
        issues = []

        # This would check for services that shouldn't be running
        # Implementation depends on the system (systemd, init.d, etc.)

        return issues

    def _check_network_security(self) -> List[Dict[str, Any]]:
        """Check network security configuration"""
        issues = []

        # Check open ports
        try:
            import socket
            open_ports = []
            for port in range(1, 1025):
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.1)
                result = sock.connect_ex(('127.0.0.1', port))
                if result == 0:
                    open_ports.append(port)
                sock.close()

            # Flag suspicious open ports
            suspicious_ports = [21, 23, 25, 53, 139, 445]  # FTP, Telnet, SMTP, DNS, Samba
            for port in open_ports:
                if port in suspicious_ports:
                    issues.append({
                        "type": "network_security",
                        "port": port,
                        "severity": "medium",
                        "description": f"Potentially insecure service running on port {port}"
                    })

        except Exception as e:
            logger.warning(f"Could not check network security: {e}")

        return issues

    def _check_package_updates(self) -> List[Dict[str, Any]]:
        """Check for available package updates"""
        updates = []

        if platform.system() == "Linux":
            if os.path.exists("/usr/bin/apt"):
                result = self._execute_command("apt list --upgradable 2>/dev/null | grep -v 'Listing' | wc -l")
                if result["success"]:
                    try:
                        count = int(result["stdout"].strip())
                        if count > 0:
                            updates.append({
                                "type": "package_updates",
                                "count": count,
                                "severity": "low",
                                "description": f"{count} packages available for update"
                            })
                    except ValueError:
                        pass

        return updates

    def get_server_status(self) -> Dict[str, Any]:
        """Get comprehensive server status"""
        current_metrics = self.metrics_history[-1] if self.metrics_history else None

        return {
            "server_id": self.server_id,
            "node_id": self.node_id,
            "status": self.server_status.value,
            "system_info": {
                "os": platform.system(),
                "version": platform.version(),
                "architecture": platform.machine(),
                "cpu_count": psutil.cpu_count(),
                "memory_total_gb": round(psutil.virtual_memory().total / (1024**3), 2)
            },
            "current_metrics": {
                "cpu_usage": current_metrics.cpu_usage if current_metrics else 0,
                "memory_usage": current_metrics.memory_usage if current_metrics else 0,
                "disk_usage": current_metrics.disk_usage if current_metrics else {},
                "network_io": current_metrics.network_io if current_metrics else {},
                "load_average": current_metrics.load_average if current_metrics else (0, 0, 0),
                "uptime_seconds": current_metrics.uptime_seconds if current_metrics else 0,
                "temperature_celsius": current_metrics.temperature_celsius if current_metrics else None
            } if current_metrics else {},
            "active_backups": len([b for b in self.backup_jobs.values() if b.status == BackupStatus.RUNNING]),
            "active_scans": len([s for s in self.security_scans.values() if not s.end_time]),
            "monitoring_active": self.monitoring_active,
            "maintenance_active": self.maintenance_active,
            "metrics_history_count": len(self.metrics_history),
            "timestamp": datetime.now().isoformat()
        }

    def get_backup_status(self, backup_id: str = None) -> Dict[str, Any]:
        """Get backup status"""
        if backup_id:
            backup = self.backup_jobs.get(backup_id)
            if not backup:
                return {"error": "Backup not found"}

            return {
                "backup_id": backup.backup_id,
                "name": backup.name,
                "status": backup.status.value,
                "start_time": backup.start_time.isoformat(),
                "end_time": backup.end_time.isoformat() if backup.end_time else None,
                "size_bytes": backup.size_bytes,
                "compression_ratio": backup.compression_ratio,
                "source_paths": backup.source_paths,
                "destination": backup.destination
            }

        # Return all backups
        return {
            "backups": [
                {
                    "backup_id": backup.backup_id,
                    "name": backup.name,
                    "status": backup.status.value,
                    "start_time": backup.start_time.isoformat(),
                    "end_time": backup.end_time.isoformat() if backup.end_time else None
                }
                for backup in self.backup_jobs.values()
            ]
        }

    def get_security_status(self, scan_id: str = None) -> Dict[str, Any]:
        """Get security scan status"""
        if scan_id:
            scan = self.security_scans.get(scan_id)
            if not scan:
                return {"error": "Scan not found"}

            return {
                "scan_id": scan.scan_id,
                "scan_type": scan.scan_type,
                "start_time": scan.start_time.isoformat(),
                "end_time": scan.end_time.isoformat() if scan.end_time else None,
                "vulnerabilities_found": scan.vulnerabilities_found,
                "critical_issues": scan.critical_issues,
                "warnings": scan.warnings,
                "results": scan.results
            }

        # Return all scans
        return {
            "scans": [
                {
                    "scan_id": scan.scan_id,
                    "scan_type": scan.scan_type,
                    "start_time": scan.start_time.isoformat(),
                    "end_time": scan.end_time.isoformat() if scan.end_time else None,
                    "vulnerabilities_found": scan.vulnerabilities_found,
                    "status": "completed" if scan.end_time else "running"
                }
                for scan in self.security_scans.values()
            ]
        }

# ═══════════════════════════════════════════════════════════════════════════════
# SINGLETON INSTANCE
# ═══════════════════════════════════════════════════════════════════════════════

dedicated_server_agent = DedicatedServerAgent()

# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("🖥️🔒 Dedicated Server Agent Test")
    print("=" * 50)

    agent = DedicatedServerAgent()

    try:
        # Start monitoring
        agent.start_server_monitoring()

        # Get initial status
        status = agent.get_server_status()
        print(json.dumps(status, indent=2, default=str))

        # Create a test backup
        backup_result = agent.create_backup(
            name="test_backup",
            source_paths=["/tmp"],
            destination="/tmp/backups"
        )
        print(f"Backup created: {backup_result}")

        # Run a security scan
        scan_result = agent.run_security_scan("system")
        print(f"Security scan started: {scan_result}")

        # Keep running for a bit
        time.sleep(10)

        # Check backup status
        if backup_result["success"]:
            backup_status = agent.get_backup_status(backup_result["backup_id"])
            print(f"Backup status: {json.dumps(backup_status, indent=2, default=str)}")

        # Check scan status
        if scan_result["success"]:
            scan_status = agent.get_security_status(scan_result["scan_id"])
            print(f"Scan status: {json.dumps(scan_status, indent=2, default=str)}")

    except KeyboardInterrupt:
        print("\n🛑 Shutting down Dedicated Server Agent...")
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        agent.stop_server_monitoring()