#!/usr/bin/env python3
"""
Data Science/ML Tools Expert AI Agent
Master of QuranChain Data Operations: pandas, numpy, scikit-learn, matplotlib
Specializes in: Data analysis, machine learning, visualization, statistical modeling
"""

from flask import Flask, jsonify, request
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
try:
    import seaborn as sns
except ImportError:
    sns = None  # Make seaborn optional
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.metrics import accuracy_score, mean_squared_error
import json
import time
import threading
from datetime import datetime
import os
import logging
import base64
import io

app = Flask(__name__)
PORT = 9022

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty

class DataScienceMLToolsExpert:
    def __init__(self):
        self.agent_name = "data-science-ml-tools-expert"
        self.expertise = [
            "pandas_data_manipulation",
            "numpy_array_operations",
            "scikit_learn_ml_models",
            "matplotlib_visualization",
            "data_preprocessing",
            "feature_engineering",
            "model_training_evaluation",
            "statistical_analysis",
            "data_visualization",
            "predictive_modeling",
            "clustering_analysis",
            "dimensionality_reduction",
            "time_series_analysis",
            "natural_language_processing",
            "computer_vision_tasks"
        ]

        # Data Science/ML Tools Knowledge
        self.ml_tools = {
            "pandas": {
                "name": "Pandas",
                "type": "Data Manipulation Library",
                "version": "2.3+",
                "features": [
                    "DataFrame Operations",
                    "Data Cleaning",
                    "Time Series Analysis",
                    "Group Operations",
                    "Merging/Joining",
                    "I/O Operations"
                ],
                "use_cases": ["Data Analysis", "ETL Processes", "Data Preparation"],
                "performance": "Efficient for structured data operations"
            },
            "numpy": {
                "name": "NumPy",
                "type": "Numerical Computing Library",
                "version": "1.26+",
                "features": [
                    "N-dimensional Arrays",
                    "Mathematical Functions",
                    "Linear Algebra",
                    "Random Number Generation",
                    "Broadcasting",
                    "Memory Efficiency"
                ],
                "use_cases": ["Scientific Computing", "Matrix Operations", "Statistical Analysis"],
                "performance": "High performance numerical computations"
            },
            "scikit-learn": {
                "name": "Scikit-learn",
                "type": "Machine Learning Library",
                "version": "1.7+",
                "features": [
                    "Classification Algorithms",
                    "Regression Models",
                    "Clustering Methods",
                    "Dimensionality Reduction",
                    "Model Selection",
                    "Preprocessing Tools"
                ],
                "use_cases": ["Predictive Modeling", "Classification", "Clustering"],
                "performance": "Optimized ML algorithms"
            },
            "matplotlib": {
                "name": "Matplotlib",
                "type": "Visualization Library",
                "version": "3.10+",
                "features": [
                    "2D/3D Plotting",
                    "Publication Quality",
                    "Interactive Plots",
                    "Multiple Backends",
                    "Customization",
                    "Export Formats"
                ],
                "use_cases": ["Data Visualization", "Scientific Plots", "Reports"],
                "performance": "Flexible plotting library"
            }
        }

        self.revenue_stats = {
            "total_operations": 0,
            "datasets_processed": 0,
            "models_trained": 0,
            "visualizations_created": 0,
            "predictions_made": 0,
            "data_analyzed_gb": 0,
            "accuracy_achieved": 0,
            "founder_royalty_paid": 0
        }

        self.service_status = {}
        self.last_health_check = None
        self.crm_db = "crm/crm.db"

        # Trained models cache
        self.trained_models = {}

        self.setup_logging()

    def setup_logging(self):
        """Setup logging for data science operations"""
        logging.basicConfig(
            filename='logs/ai_workforce/data_science_ml_tools_expert.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def log_to_crm(self, action, data):
        """Log data science operations to CRM for attribution tracking"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT INTO agent_activities
                (agent_name, action, data, timestamp, revenue_impact)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                self.agent_name,
                action,
                json.dumps(data),
                datetime.now().isoformat(),
                data.get('revenue', 0)
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error(f"CRM logging error: {e}")

    def check_data_science_service_status(self):
        """Check status of data science/ML services"""
        status = {
            "timestamp": datetime.now().isoformat(),
            "service": "data_science_ml_tools_expert",
            "port": PORT,
            "status": "unknown",
            "pandas_available": False,
            "numpy_available": False,
            "scikit_learn_available": False,
            "matplotlib_available": False
        }

        # Check pandas
        try:
            import pandas as pd
            status["pandas_available"] = True
        except:
            pass

        # Check numpy
        try:
            import numpy as np
            status["numpy_available"] = True
        except:
            pass

        # Check scikit-learn
        try:
            import sklearn
            status["scikit_learn_available"] = True
        except:
            pass

        # Check matplotlib
        try:
            import matplotlib
            status["matplotlib_available"] = True
        except:
            pass

        # Determine overall status
        available_count = sum([
            status["pandas_available"],
            status["numpy_available"],
            status["scikit_learn_available"],
            status["matplotlib_available"]
        ])

        if available_count >= 3:
            status["status"] = "healthy"
        elif available_count >= 2:
            status["status"] = "degraded"
        else:
            status["status"] = "offline"

        self.service_status = status
        self.last_health_check = datetime.now().isoformat()
        return status

    def process_pandas_data(self, data, operations):
        """Process data using pandas operations"""
        try:
            df = pd.DataFrame(data)

            results = {"original_shape": df.shape}

            for op in operations:
                if op["type"] == "filter":
                    condition = op["condition"]
                    df = df.query(condition)
                elif op["type"] == "groupby":
                    group_cols = op["columns"]
                    agg_func = op["aggregation"]
                    df = df.groupby(group_cols).agg(agg_func).reset_index()
                elif op["type"] == "sort":
                    sort_cols = op["columns"]
                    ascending = op.get("ascending", True)
                    df = df.sort_values(sort_cols, ascending=ascending)
                elif op["type"] == "fillna":
                    value = op["value"]
                    df = df.fillna(value)

            results["processed_shape"] = df.shape
            results["columns"] = list(df.columns)
            results["sample_data"] = df.head(5).to_dict('records')

            return results

        except Exception as e:
            return {"error": str(e)}

    def perform_numpy_operations(self, array_data, operations):
        """Perform numpy array operations"""
        try:
            arr = np.array(array_data)

            results = {"original_shape": arr.shape, "dtype": str(arr.dtype)}

            for op in operations:
                if op["type"] == "reshape":
                    new_shape = op["shape"]
                    arr = arr.reshape(new_shape)
                elif op["type"] == "transpose":
                    arr = arr.T
                elif op["type"] == "matmul":
                    matrix_b = np.array(op["matrix_b"])
                    arr = np.matmul(arr, matrix_b)
                elif op["type"] == "mean":
                    axis = op.get("axis")
                    arr = np.mean(arr, axis=axis)
                elif op["type"] == "sum":
                    axis = op.get("axis")
                    arr = np.sum(arr, axis=axis)

            results["final_shape"] = arr.shape
            results["result"] = arr.tolist() if arr.size <= 100 else "Result too large to display"

            return results

        except Exception as e:
            return {"error": str(e)}

    def train_ml_model(self, data, target_column, model_type="classification", test_size=0.2):
        """Train a machine learning model"""
        try:
            df = pd.DataFrame(data)

            # Prepare features and target
            X = df.drop(columns=[target_column])
            y = df[target_column]

            # Handle categorical variables
            for col in X.select_dtypes(include=['object']).columns:
                le = LabelEncoder()
                X[col] = le.fit_transform(X[col])

            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

            # Scale features
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)

            # Train model
            if model_type == "classification":
                model = RandomForestClassifier(n_estimators=100, random_state=42)
                model.fit(X_train_scaled, y_train)
                predictions = model.predict(X_test_scaled)
                accuracy = accuracy_score(y_test, predictions)
                metric_name = "accuracy"
                metric_value = accuracy
            else:  # regression
                model = LinearRegression()
                model.fit(X_train_scaled, y_train)
                predictions = model.predict(X_test_scaled)
                mse = mean_squared_error(y_test, predictions)
                metric_name = "mse"
                metric_value = mse

            # Store model
            model_id = f"model_{len(self.trained_models)}"
            self.trained_models[model_id] = {
                "model": model,
                "scaler": scaler,
                "features": list(X.columns),
                "model_type": model_type,
                "metric_name": metric_name,
                "metric_value": metric_value
            }

            results = {
                "model_id": model_id,
                "model_type": model_type,
                "training_samples": len(X_train),
                "test_samples": len(X_test),
                "features_used": list(X.columns),
                metric_name: metric_value,
                "feature_importance": dict(zip(X.columns, model.feature_importances_)) if hasattr(model, 'feature_importances_') else None
            }

            self.revenue_stats["models_trained"] += 1
            return results

        except Exception as e:
            return {"error": str(e)}

    def create_visualization(self, data, plot_type, x_column=None, y_column=None, title="Data Visualization"):
        """Create data visualization"""
        try:
            df = pd.DataFrame(data)

            plt.figure(figsize=(10, 6))

            if plot_type == "scatter":
                plt.scatter(df[x_column], df[y_column])
                plt.xlabel(x_column)
                plt.ylabel(y_column)
            elif plot_type == "bar":
                df.plot(kind='bar', x=x_column, y=y_column)
            elif plot_type == "line":
                df.plot(kind='line', x=x_column, y=y_column)
            elif plot_type == "histogram":
                plt.hist(df[x_column], bins=30, alpha=0.7)
                plt.xlabel(x_column)
            elif plot_type == "boxplot":
                df.boxplot(column=y_column, by=x_column)
            elif plot_type == "heatmap":
                numeric_df = df.select_dtypes(include=[np.number])
                sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm')

            plt.title(title)
            plt.tight_layout()

            # Save plot to base64
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=100)
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()

            plt.close()

            results = {
                "plot_type": plot_type,
                "title": title,
                "image_base64": image_base64,
                "data_points": len(df)
            }

            self.revenue_stats["visualizations_created"] += 1
            return results

        except Exception as e:
            return {"error": str(e)}

    def make_predictions(self, model_id, new_data):
        """Make predictions using trained model"""
        try:
            if model_id not in self.trained_models:
                return {"error": "Model not found"}

            model_info = self.trained_models[model_id]
            model = model_info["model"]
            scaler = model_info["scaler"]

            df = pd.DataFrame(new_data)

            # Handle categorical variables
            for col in df.select_dtypes(include=['object']).columns:
                le = LabelEncoder()
                df[col] = le.fit_transform(df[col])

            # Scale features
            X_scaled = scaler.transform(df)

            # Make predictions
            predictions = model.predict(X_scaled)

            results = {
                "model_id": model_id,
                "predictions": predictions.tolist(),
                "samples_predicted": len(predictions),
                "model_type": model_info["model_type"]
            }

            self.revenue_stats["predictions_made"] += len(predictions)
            return results

        except Exception as e:
            return {"error": str(e)}

    def perform_statistical_analysis(self, data, analysis_type):
        """Perform statistical analysis on data"""
        try:
            df = pd.DataFrame(data)
            numeric_df = df.select_dtypes(include=[np.number])

            results = {}

            if analysis_type == "descriptive":
                results = {
                    "mean": numeric_df.mean().to_dict(),
                    "median": numeric_df.median().to_dict(),
                    "std": numeric_df.std().to_dict(),
                    "min": numeric_df.min().to_dict(),
                    "max": numeric_df.max().to_dict(),
                    "quartiles": numeric_df.quantile([0.25, 0.75]).to_dict()
                }
            elif analysis_type == "correlation":
                results = {
                    "correlation_matrix": numeric_df.corr().to_dict(),
                    "highly_correlated": []
                }
                corr_matrix = numeric_df.corr()
                for i in range(len(corr_matrix.columns)):
                    for j in range(i+1, len(corr_matrix.columns)):
                        if abs(corr_matrix.iloc[i, j]) > 0.7:
                            results["highly_correlated"].append({
                                "var1": corr_matrix.columns[i],
                                "var2": corr_matrix.columns[j],
                                "correlation": corr_matrix.iloc[i, j]
                            })

            return results

        except Exception as e:
            return {"error": str(e)}

    def get_data_science_analytics(self):
        """Get data science performance analytics"""
        analytics = {
            "timestamp": datetime.now().isoformat(),
            "total_operations": self.revenue_stats["total_operations"],
            "datasets_processed": self.revenue_stats["datasets_processed"],
            "models_trained": self.revenue_stats["models_trained"],
            "visualizations_created": self.revenue_stats["visualizations_created"],
            "predictions_made": self.revenue_stats["predictions_made"],
            "data_analyzed_gb": self.revenue_stats["data_analyzed_gb"],
            "models_cached": len(self.trained_models),
            "supported_tools": list(self.ml_tools.keys())
        }

        return analytics

    def get_revenue_attribution(self):
        """Get revenue attribution for this agent"""
        return {
            "agent": self.agent_name,
            "total_operations": self.revenue_stats["total_operations"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "revenue_generated": self.revenue_stats["total_operations"] * 0.005,  # $0.005 per operation
            "attribution_percentage": 0.25  # 25% of data science operations revenue
        }

# Initialize the expert
data_science_expert = DataScienceMLToolsExpert()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    status = data_science_expert.check_data_science_service_status()
    return jsonify(status)

@app.route('/pandas/process', methods=['POST'])
def pandas_process():
    """Process data with pandas operations"""
    data = request.json
    dataset = data.get('data', [])
    operations = data.get('operations', [])

    result = data_science_expert.process_pandas_data(dataset, operations)
    data_science_expert.revenue_stats["datasets_processed"] += 1
    data_science_expert.revenue_stats["total_operations"] += 1

    data_science_expert.log_to_crm("pandas_processing", {"operations": len(operations), "revenue": 0.005})
    return jsonify(result)

@app.route('/numpy/operations', methods=['POST'])
def numpy_operations():
    """Perform numpy array operations"""
    data = request.json
    array_data = data.get('array', [])
    operations = data.get('operations', [])

    result = data_science_expert.perform_numpy_operations(array_data, operations)
    data_science_expert.revenue_stats["total_operations"] += 1

    data_science_expert.log_to_crm("numpy_operations", {"operations": len(operations), "revenue": 0.005})
    return jsonify(result)

@app.route('/ml/train', methods=['POST'])
def train_model():
    """Train a machine learning model"""
    data = request.json
    dataset = data.get('data', [])
    target_column = data.get('target_column', '')
    model_type = data.get('model_type', 'classification')
    test_size = data.get('test_size', 0.2)

    result = data_science_expert.train_ml_model(dataset, target_column, model_type, test_size)
    data_science_expert.revenue_stats["total_operations"] += 1

    data_science_expert.log_to_crm("ml_training", {"model_type": model_type, "revenue": 0.005})
    return jsonify(result)

@app.route('/visualize', methods=['POST'])
def create_visualization():
    """Create data visualization"""
    data = request.json
    dataset = data.get('data', [])
    plot_type = data.get('plot_type', 'scatter')
    x_column = data.get('x_column')
    y_column = data.get('y_column')
    title = data.get('title', 'Data Visualization')

    result = data_science_expert.create_visualization(dataset, plot_type, x_column, y_column, title)
    data_science_expert.revenue_stats["total_operations"] += 1

    data_science_expert.log_to_crm("visualization", {"plot_type": plot_type, "revenue": 0.005})
    return jsonify(result)

@app.route('/ml/predict/<model_id>', methods=['POST'])
def make_predictions(model_id):
    """Make predictions with trained model"""
    data = request.json
    new_data = data.get('data', [])

    result = data_science_expert.make_predictions(model_id, new_data)
    data_science_expert.revenue_stats["total_operations"] += 1

    data_science_expert.log_to_crm("predictions", {"model_id": model_id, "samples": len(new_data), "revenue": 0.005})
    return jsonify(result)

@app.route('/stats/analyze', methods=['POST'])
def statistical_analysis():
    """Perform statistical analysis"""
    data = request.json
    dataset = data.get('data', [])
    analysis_type = data.get('analysis_type', 'descriptive')

    result = data_science_expert.perform_statistical_analysis(dataset, analysis_type)
    data_science_expert.revenue_stats["total_operations"] += 1

    data_science_expert.log_to_crm("statistical_analysis", {"type": analysis_type, "revenue": 0.005})
    return jsonify(result)

@app.route('/analytics', methods=['GET'])
def analytics():
    """Get data science analytics"""
    analytics = data_science_expert.get_data_science_analytics()
    data_science_expert.log_to_crm("analytics_request", analytics)
    return jsonify(analytics)

@app.route('/tools', methods=['GET'])
def tools():
    """Get supported data science tools"""
    return jsonify(data_science_expert.ml_tools)

@app.route('/models', methods=['GET'])
def list_models():
    """List trained models"""
    models_info = {}
    for model_id, info in data_science_expert.trained_models.items():
        models_info[model_id] = {
            "model_type": info["model_type"],
            "features": info["features"],
            "metric_name": info["metric_name"],
            "metric_value": info["metric_value"]
        }
    return jsonify(models_info)

@app.route('/attribution', methods=['GET'])
def attribution():
    """Get revenue attribution"""
    return jsonify(data_science_expert.get_revenue_attribution())

@app.route('/metrics', methods=['GET'])
def metrics():
    """Get agent metrics"""
    return jsonify({
        "agent": "data-science-ml-tools-expert",
        "supported_tools": len(data_science_expert.ml_tools),
        "models_cached": len(data_science_expert.trained_models),
        "last_health_check": data_science_expert.last_health_check,
        "total_operations": data_science_expert.revenue_stats["total_operations"],
        "datasets_processed": data_science_expert.revenue_stats["datasets_processed"],
        "models_trained": data_science_expert.revenue_stats["models_trained"],
        "visualizations_created": data_science_expert.revenue_stats["visualizations_created"],
        "predictions_made": data_science_expert.revenue_stats["predictions_made"],
        "founder_royalty_paid": data_science_expert.revenue_stats["founder_royalty_paid"],
        "timestamp": datetime.now().isoformat()
    })

def continuous_monitoring():
    """Background thread for continuous monitoring"""
    while True:
        try:
            # Check service health every 30 seconds
            data_science_expert.check_data_science_service_status()
            time.sleep(30)
        except Exception as e:
            print(f"Monitoring error: {e}")
            time.sleep(30)

if __name__ == '__main__':
    print(f"📊 Data Science/ML Tools Expert Agent starting on port {PORT}")
    print(f"💰 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    print(f"\n📊 Data Science Tools Configured:")
    for name, info in data_science_expert.ml_tools.items():
        print(f"   • {info['name']} - {info['type']}")
    print(f"\n🔍 Expertise Areas: {len(data_science_expert.expertise)}")

    # Initial service check
    status = data_science_expert.check_data_science_service_status()
    print(f"\n📈 Initial Status: {status['status']}")

    # Start background monitoring
    monitor_thread = threading.Thread(target=continuous_monitoring, daemon=True)
    monitor_thread.start()

    # Register with master hub
    try:
        import requests
        requests.post("http://localhost:9999/register_agent", json={
            "agent": "data-science-ml-tools-expert",
            "port": PORT,
            "capabilities": data_science_expert.expertise
        }, timeout=2)
        print("✅ Registered with quantum blockchain hub")
    except:
        print("⚠️ Hub registration pending (will retry)")

    app.run(host='0.0.0.0', port=PORT, debug=False)
