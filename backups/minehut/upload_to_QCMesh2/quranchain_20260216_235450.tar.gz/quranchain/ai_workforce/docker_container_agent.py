#!/usr/bin/env python3
"""
🐳📦 DOCKER CONTAINER AGENT - CONTAINERIZATION SPECIALIST
═══════════════════════════════════════════════════════════════════════════════
Specialized AI agent for Docker container management, orchestration,
image building, deployment automation, and microservices architecture.

Capabilities:
  🐳 Docker Container Lifecycle Management
  🖼️ Image Building & Registry Operations
  📋 Docker Compose Orchestration
  ⚖️ Load Balancing & Service Discovery
  🔒 Container Security Scanning
  📊 Resource Monitoring & Scaling
  🌐 Multi-Container Networking
  🔄 CI/CD Pipeline Integration

Author: QuranChain AI Agent Team
Date: 2026-01-15
"""

import asyncio
import docker
import json
import logging
import os
import subprocess
import threading
import time
from blockchain_logging_handler import setup_blockchain_logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Any, Optional, Set, Tuple
import uuid
import yaml

# Add project root to path
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import QuranChain dependencies
try:
    from cosmos_blockchain_integration import cosmos_blockchain_client, COSMOS_CONFIG
    COSMOS_ENABLED = True
except ImportError:
    COSMOS_ENABLED = False
    cosmos_blockchain_client = None

# Configure logging
setup_blockchain_logging()
logger = logging.getLogger(__name__)

class ContainerStatus(Enum):
    """Enumeration of container states"""
    CREATED = "created"
    RUNNING = "running"
    PAUSED = "paused"
    RESTARTING = "restarting"
    EXITED = "exited"
    DEAD = "dead"

class ImageStatus(Enum):
    """Enumeration of image states"""
    AVAILABLE = "available"
    BUILDING = "building"
    FAILED = "failed"
    PUSHING = "pushing"

@dataclass
class DockerContainer:
    """Docker container information"""
    container_id: str
    name: str
    image: str
    status: ContainerStatus
    ports: Dict[str, Any] = field(default_factory=dict)
    networks: List[str] = field(default_factory=list)
    volumes: Dict[str, str] = field(default_factory=dict)
    environment: Dict[str, str] = field(default_factory=dict)
    created: datetime = field(default_factory=datetime.now)
    cpu_percent: float = 0.0
    memory_usage: int = 0
    memory_limit: int = 0

@dataclass
class DockerImage:
    """Docker image information"""
    image_id: str
    repository: str
    tag: str
    size: int
    created: datetime
    status: ImageStatus = ImageStatus.AVAILABLE

@dataclass
class DockerNetwork:
    """Docker network information"""
    network_id: str
    name: str
    driver: str
    scope: str
    containers: Dict[str, str] = field(default_factory=dict)

class DockerContainerAgent:
    """
    Docker Container Agent - Specialized AI for container operations
    """

    def __init__(self):
        self.node_id = str(uuid.uuid4())
        self.docker_client = None
        self.containers: Dict[str, DockerContainer] = {}
        self.images: Dict[str, DockerImage] = {}
        self.networks: Dict[str, DockerNetwork] = {}
        self.monitoring_active = False
        self.monitoring_thread: Optional[threading.Thread] = None

        self._initialize_docker_client()
        logger.info("🐳 Docker Container Agent initialized")

    def _initialize_docker_client(self):
        """Initialize Docker client"""
        try:
            self.docker_client = docker.from_env()
            logger.info("✅ Docker client connected")
        except Exception as e:
            logger.error(f"❌ Failed to connect to Docker: {e}")
            self.docker_client = None

    def scan_containers(self):
        """Scan all Docker containers"""
        if not self.docker_client:
            logger.error("❌ Docker client not available")
            return

        logger.info("🔍 Scanning Docker containers...")

        try:
            containers = self.docker_client.containers.list(all=True)
            self.containers.clear()

            for container in containers:
                # Get detailed stats
                stats = container.stats(stream=False)

                docker_container = DockerContainer(
                    container_id=container.id,
                    name=container.name,
                    image=container.image.tags[0] if container.image.tags else container.image.id,
                    status=ContainerStatus(container.status.lower()),
                    ports=container.ports,
                    networks=list(container.attrs['NetworkSettings']['Networks'].keys()),
                    volumes={},  # Would need more complex parsing
                    environment={},  # Would need more complex parsing
                    cpu_percent=self._calculate_cpu_percent(stats),
                    memory_usage=stats['memory_stats'].get('usage', 0),
                    memory_limit=stats['memory_stats'].get('limit', 0)
                )

                self.containers[container.id] = docker_container

            logger.info(f"📦 Found {len(self.containers)} containers")

        except Exception as e:
            logger.error(f"❌ Error scanning containers: {e}")

    def scan_images(self):
        """Scan all Docker images"""
        if not self.docker_client:
            logger.error("❌ Docker client not available")
            return

        logger.info("🔍 Scanning Docker images...")

        try:
            images = self.docker_client.images.list()
            self.images.clear()

            for image in images:
                for tag in image.tags:
                    repo, tag_name = tag.split(':') if ':' in tag else (tag, 'latest')

                    docker_image = DockerImage(
                        image_id=image.id,
                        repository=repo,
                        tag=tag_name,
                        size=image.attrs['Size'],
                        created=datetime.fromtimestamp(image.attrs['Created'])
                    )

                    self.images[image.id] = docker_image

            logger.info(f"🖼️ Found {len(self.images)} images")

        except Exception as e:
            logger.error(f"❌ Error scanning images: {e}")

    def scan_networks(self):
        """Scan Docker networks"""
        if not self.docker_client:
            logger.error("❌ Docker client not available")
            return

        logger.info("🔍 Scanning Docker networks...")

        try:
            networks = self.docker_client.networks.list()
            self.networks.clear()

            for network in networks:
                docker_network = DockerNetwork(
                    network_id=network.id,
                    name=network.name,
                    driver=network.attrs['Driver'],
                    scope=network.attrs.get('Scope', 'local'),
                    containers=network.attrs.get('Containers', {})
                )

                self.networks[network.id] = docker_network

            logger.info(f"🌐 Found {len(self.networks)} networks")

        except Exception as e:
            logger.error(f"❌ Error scanning networks: {e}")

    def start_container_monitoring(self):
        """Start container monitoring"""
        if self.monitoring_active:
            logger.warning("⚠️ Container monitoring already active")
            return

        logger.info("📊 Starting container monitoring...")
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

    def stop_container_monitoring(self):
        """Stop container monitoring"""
        logger.info("🛑 Stopping container monitoring...")
        self.monitoring_active = False
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)

    def _monitoring_loop(self):
        """Container monitoring loop"""
        while self.monitoring_active:
            try:
                self.scan_containers()
                self._check_container_alerts()
                time.sleep(30)  # Monitor every 30 seconds
            except Exception as e:
                logger.error(f"❌ Monitoring error: {e}")
                time.sleep(5)

    def _check_container_alerts(self):
        """Check for container alerts"""
        for container in self.containers.values():
            if container.status != ContainerStatus.RUNNING:
                logger.warning(f"⚠️ Container {container.name} is {container.status.value}")

            if container.memory_usage > 0 and container.memory_limit > 0:
                memory_percent = (container.memory_usage / container.memory_limit) * 100
                if memory_percent > 90:
                    logger.warning(f"⚠️ Container {container.name} high memory usage: {memory_percent:.1f}%")

    def _calculate_cpu_percent(self, stats: Dict[str, Any]) -> float:
        """Calculate CPU percentage from Docker stats"""
        try:
            cpu_stats = stats.get('cpu_stats', {})
            precpu_stats = stats.get('precpu_stats', {})

            if not cpu_stats or not precpu_stats:
                return 0.0

            cpu_delta = cpu_stats['cpu_usage']['total_usage'] - precpu_stats['cpu_usage']['total_usage']
            system_delta = cpu_stats['system_cpu_usage'] - precpu_stats.get('system_cpu_usage', 0)

            if system_delta > 0 and cpu_delta > 0:
                cpu_percent = (cpu_delta / system_delta) * len(cpu_stats['cpu_usage']['percpu_usage']) * 100
                return round(cpu_percent, 2)

        except Exception:
            pass

        return 0.0

    def build_image(self, dockerfile_path: str, image_name: str, tag: str = "latest", build_args: Dict[str, str] = None) -> Dict[str, Any]:
        """Build a Docker image"""
        if not self.docker_client:
            return {"success": False, "error": "Docker client not available"}

        logger.info(f"🔨 Building image {image_name}:{tag} from {dockerfile_path}")

        try:
            # Update image status
            image_key = f"{image_name}:{tag}"
            if image_key not in [f"{img.repository}:{img.tag}" for img in self.images.values()]:
                new_image = DockerImage(
                    image_id="building",
                    repository=image_name,
                    tag=tag,
                    size=0,
                    created=datetime.now(),
                    status=ImageStatus.BUILDING
                )
                self.images[f"building_{image_key}"] = new_image

            # Build the image
            build_result = self.docker_client.api.build(
                path=os.path.dirname(dockerfile_path),
                dockerfile=os.path.basename(dockerfile_path),
                tag=f"{image_name}:{tag}",
                buildargs=build_args or {},
                decode=True
            )

            # Monitor build progress
            for line in build_result:
                if 'stream' in line:
                    logger.info(f"📝 Build: {line['stream'].strip()}")
                elif 'error' in line:
                    logger.error(f"❌ Build error: {line['error']}")
                    return {"success": False, "error": line['error']}

            # Update image status
            self.scan_images()

            return {
                "success": True,
                "image_name": image_name,
                "tag": tag,
                "message": f"Successfully built {image_name}:{tag}"
            }

        except Exception as e:
            logger.error(f"❌ Build failed: {e}")
            return {"success": False, "error": str(e)}

    def run_container(self, image: str, name: str, ports: Dict[str, Any] = None,
                     environment: Dict[str, str] = None, volumes: Dict[str, str] = None,
                     network: str = None, detach: bool = True) -> Dict[str, Any]:
        """Run a Docker container"""
        if not self.docker_client:
            return {"success": False, "error": "Docker client not available"}

        logger.info(f"🚀 Running container {name} from image {image}")

        try:
            container = self.docker_client.containers.run(
                image=image,
                name=name,
                ports=ports or {},
                environment=environment or {},
                volumes=volumes or {},
                network=network,
                detach=detach
            )

            # Refresh container list
            self.scan_containers()

            return {
                "success": True,
                "container_id": container.id,
                "container_name": name,
                "status": "running"
            }

        except Exception as e:
            logger.error(f"❌ Failed to run container: {e}")
            return {"success": False, "error": str(e)}

    def stop_container(self, container_id: str) -> Dict[str, Any]:
        """Stop a Docker container"""
        if not self.docker_client:
            return {"success": False, "error": "Docker client not available"}

        logger.info(f"🛑 Stopping container {container_id}")

        try:
            container = self.docker_client.containers.get(container_id)
            container.stop(timeout=30)

            # Refresh container list
            self.scan_containers()

            return {"success": True, "container_id": container_id, "status": "stopped"}

        except Exception as e:
            logger.error(f"❌ Failed to stop container: {e}")
            return {"success": False, "error": str(e)}

    def remove_container(self, container_id: str, force: bool = False) -> Dict[str, Any]:
        """Remove a Docker container"""
        if not self.docker_client:
            return {"success": False, "error": "Docker client not available"}

        logger.info(f"🗑️ Removing container {container_id}")

        try:
            container = self.docker_client.containers.get(container_id)
            container.remove(force=force)

            # Refresh container list
            self.scan_containers()

            return {"success": True, "container_id": container_id, "status": "removed"}

        except Exception as e:
            logger.error(f"❌ Failed to remove container: {e}")
            return {"success": False, "error": str(e)}

    def deploy_compose_stack(self, compose_file: str, project_name: str = None) -> Dict[str, Any]:
        """Deploy a Docker Compose stack"""
        logger.info(f"📋 Deploying compose stack from {compose_file}")

        try:
            # Use docker-compose command
            cmd = ["docker-compose", "-f", compose_file, "up", "-d"]
            if project_name:
                cmd.extend(["-p", project_name])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=os.path.dirname(compose_file)
            )

            if result.returncode == 0:
                # Refresh all resources
                self.scan_containers()
                self.scan_networks()

                return {
                    "success": True,
                    "compose_file": compose_file,
                    "project_name": project_name,
                    "output": result.stdout
                }
            else:
                return {
                    "success": False,
                    "error": result.stderr,
                    "compose_file": compose_file
                }

        except Exception as e:
            logger.error(f"❌ Compose deployment failed: {e}")
            return {"success": False, "error": str(e)}

    def get_docker_status(self) -> Dict[str, Any]:
        """Get comprehensive Docker status"""
        return {
            "docker_available": self.docker_client is not None,
            "containers": {
                container_id: {
                    "name": container.name,
                    "image": container.image,
                    "status": container.status.value,
                    "ports": container.ports,
                    "networks": container.networks,
                    "cpu_percent": container.cpu_percent,
                    "memory_usage_mb": round(container.memory_usage / (1024**2), 2) if container.memory_usage else 0
                }
                for container_id, container in self.containers.items()
            },
            "images": {
                image_id: {
                    "repository": image.repository,
                    "tag": image.tag,
                    "size_mb": round(image.size / (1024**2), 2),
                    "created": image.created.isoformat(),
                    "status": image.status.value
                }
                for image_id, image in self.images.items()
            },
            "networks": {
                network_id: {
                    "name": network.name,
                    "driver": network.driver,
                    "scope": network.scope,
                    "containers": len(network.containers)
                }
                for network_id, network in self.networks.items()
            },
            "monitoring_active": self.monitoring_active,
            "timestamp": datetime.now().isoformat()
        }

    def cleanup_docker(self) -> Dict[str, Any]:
        """Clean up unused Docker resources"""
        logger.info("🧹 Cleaning up Docker resources...")

        cleanup_results = {
            "containers_removed": 0,
            "images_removed": 0,
            "networks_removed": 0,
            "errors": []
        }

        try:
            # Remove stopped containers
            containers_removed = self.docker_client.containers.prune()
            cleanup_results["containers_removed"] = len(containers_removed.get("ContainersDeleted", []))

            # Remove unused images
            images_removed = self.docker_client.images.prune()
            cleanup_results["images_removed"] = len(images_removed.get("ImagesDeleted", []))

            # Remove unused networks
            networks_removed = self.docker_client.networks.prune()
            cleanup_results["networks_removed"] = len(networks_removed.get("NetworksDeleted", []))

            logger.info(f"🧹 Cleanup complete: {cleanup_results}")

        except Exception as e:
            cleanup_results["errors"].append(str(e))
            logger.error(f"❌ Cleanup failed: {e}")

        return cleanup_results

# ═══════════════════════════════════════════════════════════════════════════════
# SINGLETON INSTANCE
# ═══════════════════════════════════════════════════════════════════════════════

docker_container_agent = DockerContainerAgent()

# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("🐳📦 Docker Container Agent Test")
    print("=" * 50)

    agent = DockerContainerAgent()

    try:
        # Scan Docker resources
        agent.scan_containers()
        agent.scan_images()
        agent.scan_networks()

        # Get status
        status = agent.get_docker_status()
        print(json.dumps(status, indent=2, default=str))

        # Start monitoring
        agent.start_container_monitoring()

        # Keep running for a bit
        time.sleep(10)

    except KeyboardInterrupt:
        print("\n🛑 Shutting down Docker Agent...")
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        agent.stop_container_monitoring()