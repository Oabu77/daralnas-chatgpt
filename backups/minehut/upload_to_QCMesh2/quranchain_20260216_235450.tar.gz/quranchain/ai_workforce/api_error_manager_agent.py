#!/usr/bin/env python3
"""
API Error Manager AI Agent
Specializes in monitoring, detecting, and fixing API errors in QuranChain services
Manages enrollment API issues, input validation, and error handling
"""

from flask import Flask, jsonify, request
import requests
import json
import time
import threading
from datetime import datetime
import os
import logging
import subprocess
import sys

app = Flask(__name__)
PORT = 9030  # Unique port for this agent

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty

class APIErrorManagerAgent:
    def __init__(self):
        self.agent_name = "api-error-manager-agent"
        self.wallet_address = "0xAPI_ERROR_MANAGER_WALLET_ADDRESS"  # Unique wallet for tracking
        self.expertise = [
            "api_error_monitoring",
            "input_validation_fixes",
            "enum_mapping_solutions",
            "log_analysis",
            "code_hotfixes",
            "service_restart_management",
            "error_pattern_detection",
            "preventive_maintenance"
        ]

        # Known API endpoints to monitor
        self.monitored_endpoints = {
            "ai_agent_school": {
                "url": "http://localhost:8121/health",
                "enroll_url": "http://localhost:8121/enroll",
                "common_errors": ["ValueError", "TypeError", "KeyError"]
            }
        }

        # Error patterns and fixes
        self.error_fixes = {
            "AIAgentType": {
                "pattern": "'[A-Z_]+' is not a valid AIAgentType",
                "fix": "Implement map_agent_type_input function",
                "code_location": "organized/services/darcloud_ai_agent_school.py"
            }
        }

        self.logger = self._setup_logging()

    def _setup_logging(self):
        """Setup blockchain logging"""
        try:
            from blockchain_logging_handler import setup_blockchain_logging
            return setup_blockchain_logging("api_error_manager")
        except ImportError:
            return logging.getLogger("api_error_manager")

    def monitor_api_health(self):
        """Monitor API endpoints for health and errors"""
        while True:
            try:
                for service, config in self.monitored_endpoints.items():
                    try:
                        response = requests.get(config["url"], timeout=5)
                        if response.status_code != 200:
                            self.logger.warning(f"⚠️ {service} health check failed: {response.status_code}")
                            self.attempt_fix(service)
                    except requests.exceptions.RequestException as e:
                        self.logger.error(f"❌ {service} unreachable: {e}")
                        self.attempt_fix(service)

                time.sleep(60)  # Check every minute

            except Exception as e:
                self.logger.error(f"❌ Error in monitoring loop: {e}")
                time.sleep(30)

    def attempt_fix(self, service):
        """Attempt to fix known issues for a service"""
        if service == "ai_agent_school":
            self.fix_ai_agent_school_errors()

    def fix_ai_agent_school_errors(self):
        """Fix common AI Agent School API errors"""
        try:
            # Check if map_agent_type_input function exists
            result = subprocess.run([
                sys.executable, "-c",
                "from organized.services.darcloud_ai_agent_school import map_agent_type_input; print('Function exists')"
            ], capture_output=True, text=True, cwd="/home/omar/Desktop/QuranChain")

            if result.returncode != 0:
                self.logger.error("❌ map_agent_type_input function missing")
                return

            # Check if the code is using the function
            with open("/home/omar/Desktop/QuranChain/organized/services/darcloud_ai_agent_school.py", "r") as f:
                content = f.read()

            if "agent_type=AIAgentType(data.get(\"agent_type\"))" in content:
                self.logger.warning("⚠️ Found old code pattern, needs manual fix")
                # Could implement auto-fix here, but for safety, just log
            else:
                self.logger.info("✅ Code appears to be using map_agent_type_input")

            # Restart the service if needed
            self.restart_service("ai_agent_school")

        except Exception as e:
            self.logger.error(f"❌ Error fixing AI Agent School: {e}")

    def restart_service(self, service):
        """Restart a service if it's not responding"""
        try:
            if service == "ai_agent_school":
                # Kill existing process
                subprocess.run(["pkill", "-f", "ai_agent_school"], check=False)

                # Start new process
                subprocess.Popen([
                    sys.executable,
                    "organized/services/darcloud_ai_agent_school.py"
                ], cwd="/home/omar/Desktop/QuranChain")

                self.logger.info("🔄 Restarted AI Agent School service")

        except Exception as e:
            self.logger.error(f"❌ Error restarting {service}: {e}")

    def analyze_logs(self):
        """Analyze logs for error patterns"""
        try:
            # Read recent logs
            log_files = [
                "/var/log/darcloud/web_hosting.log",
                "/home/omar/Desktop/QuranChain/logs/ai_workforce/api_error_manager.log"
            ]

            for log_file in log_files:
                if os.path.exists(log_file):
                    with open(log_file, "r") as f:
                        lines = f.readlines()[-100:]  # Last 100 lines

                    for line in lines:
                        if "ValueError" in line and "AIAgentType" in line:
                            self.logger.warning(f"📊 Detected AIAgentType error: {line.strip()}")
                            self.fix_ai_agent_school_errors()

        except Exception as e:
            self.logger.error(f"❌ Error analyzing logs: {e}")

# Global instance
api_error_manager = APIErrorManagerAgent()

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status": "healthy",
        "agent": api_error_manager.agent_name,
        "wallet": api_error_manager.wallet_address,
        "timestamp": datetime.now().isoformat(),
        "founder_royalty": FOUNDER_ROYALTY_RATE
    })

@app.route('/fix/<service>', methods=['POST'])
def fix_service(service):
    try:
        api_error_manager.attempt_fix(service)
        return jsonify({"status": "fix_attempted", "service": service})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/analyze-logs', methods=['POST'])
def analyze_logs():
    try:
        api_error_manager.analyze_logs()
        return jsonify({"status": "logs_analyzed"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/status', methods=['GET'])
def get_status():
    return jsonify({
        "agent_name": api_error_manager.agent_name,
        "wallet_address": api_error_manager.wallet_address,
        "monitored_endpoints": list(api_error_manager.monitored_endpoints.keys()),
        "expertise": api_error_manager.expertise,
        "founder_royalty": FOUNDER_ROYALTY_RATE
    })

def start_monitoring():
    """Start the monitoring thread"""
    monitor_thread = threading.Thread(target=api_error_manager.monitor_api_health, daemon=True)
    monitor_thread.start()

if __name__ == "__main__":
    print(f"🤖 Starting {api_error_manager.agent_name} on port {PORT}")
    print(f"💰 Wallet: {api_error_manager.wallet_address}")
    print(f"👤 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")

    # Start monitoring in background
    start_monitoring()

    # Start Flask app
    app.run(host='0.0.0.0', port=PORT, debug=False)