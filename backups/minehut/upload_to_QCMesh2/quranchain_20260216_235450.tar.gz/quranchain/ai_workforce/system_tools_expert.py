#!/usr/bin/env python3
"""
System Tools Expert AI Agent
Master of QuranChain System Operations: psutil, system monitoring, resource management
Specializes in: System monitoring, performance analysis, resource optimization, diagnostics
"""

from flask import Flask, jsonify, request
import json
import time
import threading
from datetime import datetime
import os
import logging
import secrets
import hashlib
import platform
import subprocess

app = Flask(__name__)
PORT = 9029

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty

class SystemToolsExpert:
    def __init__(self):
        self.agent_name = "system-tools-expert"
        self.expertise = [
            "system_monitoring",
            "performance_analysis",
            "resource_management",
            "process_monitoring",
            "memory_analysis",
            "cpu_utilization",
            "disk_usage",
            "network_monitoring",
            "system_diagnostics",
            "resource_optimization",
            "load_balancing",
            "system_health_checks",
            "log_analysis",
            "alert_management",
            "capacity_planning",
            "system_automation"
        ]

        # System Tools Knowledge
        self.system_tools = {
            "psutil": {
                "name": "psutil System Monitoring",
                "type": "System Information Library",
                "version": "5.9+",
                "features": [
                    "CPU Usage Monitoring",
                    "Memory Usage Statistics",
                    "Disk I/O Operations",
                    "Network Interface Stats",
                    "Process Management",
                    "System Load Average",
                    "Battery Information",
                    "Temperature Sensors"
                ],
                "platforms": ["Windows", "Linux", "macOS", "FreeBSD"],
                "use_cases": ["System Monitoring", "Performance Analysis", "Resource Management"]
            },
            "performance_monitor": {
                "name": "Performance Monitoring Suite",
                "type": "System Diagnostics",
                "features": [
                    "Real-time Metrics",
                    "Historical Analysis",
                    "Threshold Alerts",
                    "Performance Baselines",
                    "Resource Forecasting",
                    "Bottleneck Detection",
                    "Optimization Recommendations",
                    "Automated Reporting"
                ],
                "metrics_tracked": ["CPU", "Memory", "Disk", "Network", "Processes"],
                "use_cases": ["Capacity Planning", "Troubleshooting", "Performance Tuning"]
            },
            "resource_optimizer": {
                "name": "Resource Optimization Engine",
                "type": "System Optimization",
                "features": [
                    "Memory Optimization",
                    "CPU Scheduling",
                    "Disk Defragmentation",
                    "Cache Management",
                    "Process Prioritization",
                    "Resource Allocation",
                    "Load Balancing",
                    "Energy Management"
                ],
                "optimization_types": ["memory", "cpu", "disk", "network", "power"],
                "use_cases": ["Performance Improvement", "Cost Reduction", "System Stability"]
            },
            "diagnostic_analyzer": {
                "name": "System Diagnostic Analyzer",
                "type": "Troubleshooting Tool",
                "features": [
                    "System Health Checks",
                    "Error Detection",
                    "Log Analysis",
                    "Configuration Validation",
                    "Dependency Checking",
                    "Security Assessment",
                    "Performance Benchmarking",
                    "Automated Diagnostics"
                ],
                "diagnostic_types": ["hardware", "software", "network", "security", "performance"],
                "use_cases": ["Problem Diagnosis", "System Validation", "Maintenance Planning"]
            }
        }

        self.revenue_stats = {
            "total_operations": 0,
            "system_scans": 0,
            "performance_analyses": 0,
            "resource_optimizations": 0,
            "diagnostic_reports": 0,
            "alerts_generated": 0,
            "processes_monitored": 0,
            "logs_analyzed": 0,
            "founder_royalty_paid": 0
        }

        self.service_status = {}
        self.last_health_check = None
        self.crm_db = "crm/crm.db"

        # System monitoring data
        self.system_metrics = {}
        self.process_cache = {}
        self.alert_history = []

        self.setup_logging()

    def setup_logging(self):
        """Setup logging for system operations"""
        logging.basicConfig(
            filename='logs/ai_workforce/system_tools_expert.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def log_to_crm(self, action, data):
        """Log system operations to CRM for attribution tracking"""
        try:
            import sqlite3
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT INTO agent_activities
                (agent_name, action, data, timestamp, revenue_impact)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                self.agent_name,
                action,
                json.dumps(data),
                datetime.now().isoformat(),
                data.get('revenue', 0)
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error(f"CRM logging error: {e}")

    def check_system_service_status(self):
        """Check status of system services"""
        status = {
            "timestamp": datetime.now().isoformat(),
            "service": "system-tools-expert",
            "port": PORT,
            "status": "unknown",
            "psutil_available": False,
            "system_access": True,
            "database_connection": False,
            "monitoring_active": True
        }

        # Check psutil
        try:
            import psutil
            status["psutil_available"] = True
        except:
            pass

        # Check system access
        try:
            # Try to get basic system info
            platform.system()
            status["system_access"] = True
        except:
            status["system_access"] = False

        # Check database connection
        try:
            import sqlite3
            conn = sqlite3.connect(self.crm_db)
            conn.close()
            status["database_connection"] = True
        except:
            pass

        # Determine overall status
        available_count = sum([
            status["psutil_available"],
            status["system_access"],
            status["database_connection"],
            status["monitoring_active"]
        ])

        if available_count >= 3:
            status["status"] = "healthy"
        elif available_count >= 2:
            status["status"] = "degraded"
        else:
            status["status"] = "offline"

        self.service_status = status
        self.last_health_check = datetime.now().isoformat()
        return status

    def get_system_metrics(self):
        """Get comprehensive system metrics"""
        try:
            import psutil

            # CPU metrics
            cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
            cpu_freq = psutil.cpu_freq()
            load_avg = psutil.getloadavg() if hasattr(psutil, 'getloadavg') else None

            # Memory metrics
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()

            # Disk metrics
            disk_usage = psutil.disk_usage('/')
            disk_io = psutil.disk_io_counters()

            # Network metrics
            network = psutil.net_io_counters()
            network_interfaces = psutil.net_if_stats()

            # Process metrics
            process_count = len(psutil.pids())

            metrics = {
                "timestamp": datetime.now().isoformat(),
                "cpu": {
                    "percent_per_core": cpu_percent,
                    "percent_total": sum(cpu_percent) / len(cpu_percent),
                    "frequency_current": cpu_freq.current if cpu_freq else None,
                    "frequency_max": cpu_freq.max if cpu_freq else None,
                    "load_average": load_avg
                },
                "memory": {
                    "total": memory.total,
                    "available": memory.available,
                    "percent": memory.percent,
                    "used": memory.used,
                    "free": memory.free
                },
                "swap": {
                    "total": swap.total,
                    "used": swap.used,
                    "free": swap.free,
                    "percent": swap.percent
                },
                "disk": {
                    "total": disk_usage.total,
                    "used": disk_usage.used,
                    "free": disk_usage.free,
                    "percent": disk_usage.percent,
                    "io_read_count": disk_io.read_count if disk_io else None,
                    "io_write_count": disk_io.write_count if disk_io else None
                },
                "network": {
                    "bytes_sent": network.bytes_sent,
                    "bytes_recv": network.bytes_recv,
                    "packets_sent": network.packets_sent,
                    "packets_recv": network.packets_recv,
                    "errin": network.errin,
                    "errout": network.errout
                },
                "system": {
                    "process_count": process_count,
                    "boot_time": psutil.boot_time(),
                    "uptime_seconds": time.time() - psutil.boot_time(),
                    "platform": platform.platform(),
                    "processor": platform.processor(),
                    "architecture": platform.architecture()[0]
                }
            }

            self.system_metrics = metrics
            return metrics

        except Exception as e:
            return {"error": str(e)}

    def monitor_processes(self, filters=None):
        """Monitor system processes"""
        try:
            import psutil

            processes = []
            filters = filters or {}

            for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent', 'status']):
                try:
                    proc_info = proc.info

                    # Apply filters
                    if filters.get('name') and filters['name'].lower() not in proc_info['name'].lower():
                        continue
                    if filters.get('username') and proc_info['username'] != filters['username']:
                        continue
                    if filters.get('min_cpu') and (proc_info['cpu_percent'] or 0) < filters['min_cpu']:
                        continue
                    if filters.get('min_memory') and (proc_info['memory_percent'] or 0) < filters['min_memory']:
                        continue

                    # Get additional process info
                    try:
                        proc_obj = psutil.Process(proc_info['pid'])
                        proc_info['cmdline'] = proc_obj.cmdline()
                        proc_info['create_time'] = proc_obj.create_time()
                        proc_info['num_threads'] = proc_obj.num_threads()
                    except:
                        pass

                    processes.append(proc_info)

                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Sort by CPU usage (highest first)
            processes.sort(key=lambda x: x.get('cpu_percent', 0), reverse=True)

            result = {
                "total_processes": len(processes),
                "filters_applied": filters,
                "processes": processes[:50],  # Limit to top 50
                "monitored_at": datetime.now().isoformat()
            }

            self.revenue_stats["processes_monitored"] += len(processes)
            return result

        except Exception as e:
            return {"error": str(e)}

    def analyze_performance_bottlenecks(self, metrics_data=None):
        """Analyze system performance bottlenecks"""
        try:
            if not metrics_data:
                metrics_data = self.get_system_metrics()

            if "error" in metrics_data:
                return metrics_data

            bottlenecks = []
            recommendations = []

            # CPU analysis
            cpu_percent = metrics_data["cpu"]["percent_total"]
            if cpu_percent > 90:
                bottlenecks.append({
                    "component": "CPU",
                    "severity": "critical",
                    "current_usage": cpu_percent,
                    "threshold": 90,
                    "description": "CPU usage is critically high"
                })
                recommendations.append("Consider optimizing CPU-intensive processes or adding more CPU cores")
            elif cpu_percent > 70:
                bottlenecks.append({
                    "component": "CPU",
                    "severity": "high",
                    "current_usage": cpu_percent,
                    "threshold": 70,
                    "description": "CPU usage is high"
                })
                recommendations.append("Monitor CPU usage and consider process optimization")

            # Memory analysis
            memory_percent = metrics_data["memory"]["percent"]
            if memory_percent > 90:
                bottlenecks.append({
                    "component": "Memory",
                    "severity": "critical",
                    "current_usage": memory_percent,
                    "threshold": 90,
                    "description": "Memory usage is critically high"
                })
                recommendations.append("Add more RAM or optimize memory usage")
            elif memory_percent > 80:
                bottlenecks.append({
                    "component": "Memory",
                    "severity": "high",
                    "current_usage": memory_percent,
                    "threshold": 80,
                    "description": "Memory usage is high"
                })
                recommendations.append("Monitor memory usage and consider cleanup")

            # Disk analysis
            disk_percent = metrics_data["disk"]["percent"]
            if disk_percent > 95:
                bottlenecks.append({
                    "component": "Disk",
                    "severity": "critical",
                    "current_usage": disk_percent,
                    "threshold": 95,
                    "description": "Disk usage is critically high"
                })
                recommendations.append("Free up disk space immediately")
            elif disk_percent > 85:
                bottlenecks.append({
                    "component": "Disk",
                    "severity": "high",
                    "current_usage": disk_percent,
                    "threshold": 85,
                    "description": "Disk usage is high"
                })
                recommendations.append("Consider disk cleanup or expansion")

            analysis = {
                "analysis_timestamp": datetime.now().isoformat(),
                "bottlenecks_found": len(bottlenecks),
                "bottlenecks": bottlenecks,
                "recommendations": recommendations,
                "overall_health": "critical" if any(b["severity"] == "critical" for b in bottlenecks) else "warning" if bottlenecks else "good",
                "metrics_analyzed": ["cpu", "memory", "disk"]
            }

            self.revenue_stats["performance_analyses"] += 1
            return analysis

        except Exception as e:
            return {"error": str(e)}

    def optimize_system_resources(self, optimization_type="memory"):
        """Optimize system resources"""
        try:
            import psutil

            optimizations = []

            if optimization_type == "memory":
                # Memory optimization
                memory = psutil.virtual_memory()
                if memory.percent > 80:
                    # Try to free memory (simplified)
                    optimizations.append({
                        "type": "memory_cleanup",
                        "action": "Clear page cache",
                        "command": "echo 3 > /proc/sys/vm/drop_caches",
                        "expected_impact": "Free cached memory",
                        "status": "recommended"
                    })

                # Kill high memory processes if critical
                if memory.percent > 95:
                    high_mem_processes = []
                    for proc in psutil.process_iter(['pid', 'name', 'memory_percent']):
                        if proc.info['memory_percent'] and proc.info['memory_percent'] > 10:
                            high_mem_processes.append(proc.info)

                    if high_mem_processes:
                        optimizations.append({
                            "type": "memory_optimization",
                            "action": "High memory processes identified",
                            "processes": high_mem_processes[:5],
                            "status": "requires_attention"
                        })

            elif optimization_type == "cpu":
                # CPU optimization
                cpu_percent = psutil.cpu_percent(interval=1)
                if cpu_percent > 80:
                    optimizations.append({
                        "type": "cpu_optimization",
                        "action": "Identify CPU-intensive processes",
                        "recommendation": "Consider process prioritization or load balancing",
                        "status": "recommended"
                    })

            elif optimization_type == "disk":
                # Disk optimization
                disk = psutil.disk_usage('/')
                if disk.percent > 85:
                    optimizations.append({
                        "type": "disk_optimization",
                        "action": "Disk cleanup",
                        "commands": [
                            "Find large files: find / -type f -size +100M",
                            "Check disk usage: du -h --max-depth=1 /",
                            "Clear package cache: apt clean" if os.path.exists('/etc/debian_version') else "yum clean all"
                        ],
                        "status": "recommended"
                    })

            result = {
                "optimization_type": optimization_type,
                "optimizations_found": len(optimizations),
                "optimizations": optimizations,
                "executed_at": datetime.now().isoformat()
            }

            self.revenue_stats["resource_optimizations"] += 1
            return result

        except Exception as e:
            return {"error": str(e)}

    def run_system_diagnostics(self, diagnostic_type="full"):
        """Run comprehensive system diagnostics"""
        try:
            diagnostics = {
                "diagnostic_type": diagnostic_type,
                "started_at": datetime.now().isoformat(),
                "checks": []
            }

            # System information
            diagnostics["checks"].append({
                "check": "system_info",
                "status": "passed",
                "details": {
                    "platform": platform.platform(),
                    "processor": platform.processor(),
                    "architecture": platform.architecture()[0],
                    "python_version": platform.python_version()
                }
            })

            # Service availability
            try:
                import psutil
                diagnostics["checks"].append({
                    "check": "psutil_availability",
                    "status": "passed",
                    "details": f"psutil version {psutil.__version__} available"
                })
            except:
                diagnostics["checks"].append({
                    "check": "psutil_availability",
                    "status": "failed",
                    "details": "psutil not available"
                })

            # Disk space check
            try:
                import psutil
                disk = psutil.disk_usage('/')
                status = "passed" if disk.percent < 90 else "warning" if disk.percent < 95 else "failed"
                diagnostics["checks"].append({
                    "check": "disk_space",
                    "status": status,
                    "details": f"Disk usage: {disk.percent}%"
                })
            except:
                diagnostics["checks"].append({
                    "check": "disk_space",
                    "status": "error",
                    "details": "Could not check disk space"
                })

            # Memory check
            try:
                import psutil
                memory = psutil.virtual_memory()
                status = "passed" if memory.percent < 90 else "warning" if memory.percent < 95 else "failed"
                diagnostics["checks"].append({
                    "check": "memory_usage",
                    "status": status,
                    "details": f"Memory usage: {memory.percent}%"
                })
            except:
                diagnostics["checks"].append({
                    "check": "memory_usage",
                    "status": "error",
                    "details": "Could not check memory usage"
                })

            # Network connectivity
            try:
                import socket
                socket.create_connection(("8.8.8.8", 53), timeout=3)
                diagnostics["checks"].append({
                    "check": "network_connectivity",
                    "status": "passed",
                    "details": "Internet connectivity available"
                })
            except:
                diagnostics["checks"].append({
                    "check": "network_connectivity",
                    "status": "warning",
                    "details": "No internet connectivity detected"
                })

            # Overall assessment
            failed_checks = len([c for c in diagnostics["checks"] if c["status"] in ["failed", "error"]])
            warning_checks = len([c for c in diagnostics["checks"] if c["status"] == "warning"])

            if failed_checks > 0:
                overall_status = "failed"
            elif warning_checks > 0:
                overall_status = "warning"
            else:
                overall_status = "passed"

            diagnostics["completed_at"] = datetime.now().isoformat()
            diagnostics["overall_status"] = overall_status
            diagnostics["summary"] = f"{len(diagnostics['checks'])} checks run, {failed_checks} failed, {warning_checks} warnings"

            self.revenue_stats["diagnostic_reports"] += 1
            return diagnostics

        except Exception as e:
            return {"error": str(e)}

    def analyze_system_logs(self, log_files=None, time_range_hours=24):
        """Analyze system logs for issues"""
        try:
            log_analysis = {
                "analysis_timestamp": datetime.now().isoformat(),
                "time_range_hours": time_range_hours,
                "log_files_analyzed": [],
                "issues_found": [],
                "patterns_detected": [],
                "recommendations": []
            }

            # Default log files to check
            if not log_files:
                log_files = [
                    "/var/log/syslog",
                    "/var/log/messages",
                    "/var/log/kern.log",
                    "/var/log/auth.log"
                ]

            for log_file in log_files:
                if os.path.exists(log_file):
                    try:
                        # Read recent log entries
                        result = subprocess.run(
                            ["tail", "-n", "1000", log_file],
                            capture_output=True,
                            text=True,
                            timeout=10
                        )

                        if result.returncode == 0:
                            log_content = result.stdout
                            log_analysis["log_files_analyzed"].append(log_file)

                            # Analyze for common issues
                            error_patterns = [
                                (r"error|Error|ERROR", "General errors"),
                                (r"failed|Failed|FAILED", "Failed operations"),
                                (r"warning|Warning|WARNING", "Warnings"),
                                (r"critical|Critical|CRITICAL", "Critical issues"),
                                (r"denied|Denied|DENIED", "Access denied"),
                                (r"timeout|Timeout|TIMEOUT", "Timeouts")
                            ]

                            for pattern, description in error_patterns:
                                matches = len(re.findall(pattern, log_content, re.IGNORECASE))
                                if matches > 0:
                                    log_analysis["issues_found"].append({
                                        "log_file": log_file,
                                        "pattern": pattern,
                                        "description": description,
                                        "occurrences": matches
                                    })

                    except Exception as e:
                        log_analysis["issues_found"].append({
                            "log_file": log_file,
                            "error": str(e)
                        })

            # Generate recommendations
            if log_analysis["issues_found"]:
                log_analysis["recommendations"].append("Review system logs for detailed error information")
                log_analysis["recommendations"].append("Consider log rotation if logs are too large")
                log_analysis["recommendations"].append("Monitor for recurring error patterns")

            self.revenue_stats["logs_analyzed"] += len(log_analysis["log_files_analyzed"])
            return log_analysis

        except Exception as e:
            return {"error": str(e)}

    def generate_performance_report(self, time_range_hours=24):
        """Generate comprehensive performance report"""
        try:
            # Get current metrics
            current_metrics = self.get_system_metrics()

            # Analyze bottlenecks
            bottleneck_analysis = self.analyze_performance_bottlenecks(current_metrics)

            # Get process information
            process_info = self.monitor_processes()

            report = {
                "report_title": "QuranChain System Performance Report",
                "generated_at": datetime.now().isoformat(),
                "time_range_hours": time_range_hours,
                "system_overview": {
                    "platform": platform.platform(),
                    "uptime_hours": current_metrics.get("system", {}).get("uptime_seconds", 0) / 3600,
                    "total_processes": process_info.get("total_processes", 0)
                },
                "current_metrics": current_metrics,
                "bottleneck_analysis": bottleneck_analysis,
                "top_processes": process_info.get("processes", [])[:10],
                "recommendations": bottleneck_analysis.get("recommendations", []),
                "alerts": self.alert_history[-10:] if self.alert_history else []
            }

            return report

        except Exception as e:
            return {"error": str(e)}

    def get_system_analytics(self):
        """Get system performance analytics"""
        analytics = {
            "timestamp": datetime.now().isoformat(),
            "total_operations": self.revenue_stats["total_operations"],
            "system_scans": self.revenue_stats["system_scans"],
            "performance_analyses": self.revenue_stats["performance_analyses"],
            "resource_optimizations": self.revenue_stats["resource_optimizations"],
            "diagnostic_reports": self.revenue_stats["diagnostic_reports"],
            "alerts_generated": self.revenue_stats["alerts_generated"],
            "processes_monitored": self.revenue_stats["processes_monitored"],
            "logs_analyzed": self.revenue_stats["logs_analyzed"],
            "active_alerts": len(self.alert_history),
            "cached_processes": len(self.process_cache),
            "supported_platforms": ["Linux", "Windows", "macOS", "FreeBSD"],
            "monitoring_uptime": time.time() - (self.system_metrics.get("timestamp_epoch", time.time()) if self.system_metrics else time.time())
        }

        return analytics

    def get_revenue_attribution(self):
        """Get revenue attribution for this agent"""
        return {
            "agent": self.agent_name,
            "total_operations": self.revenue_stats["total_operations"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "revenue_generated": self.revenue_stats["total_operations"] * 0.014,  # $0.014 per operation
            "attribution_percentage": 0.15  # 15% of system operations revenue
        }

# Initialize the expert
system_expert = SystemToolsExpert()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    status = system_expert.check_system_service_status()
    return jsonify(status)

@app.route('/metrics', methods=['GET'])
def get_metrics():
    """Get system metrics"""
    metrics = system_expert.get_system_metrics()
    system_expert.revenue_stats["total_operations"] += 1

    system_expert.log_to_crm("metrics_request", {"metrics_collected": len(metrics) if "error" not in metrics else 0, "revenue": 0.014})
    return jsonify(metrics)

@app.route('/processes/monitor', methods=['POST'])
def monitor_processes():
    """Monitor system processes"""
    data = request.json
    filters = data.get('filters', {})

    result = system_expert.monitor_processes(filters)
    system_expert.revenue_stats["total_operations"] += 1

    system_expert.log_to_crm("process_monitoring", {"processes_found": result["total_processes"], "revenue": 0.014})
    return jsonify(result)

@app.route('/performance/analyze', methods=['GET'])
def analyze_performance():
    """Analyze performance bottlenecks"""
    result = system_expert.analyze_performance_bottlenecks()
    system_expert.revenue_stats["total_operations"] += 1

    system_expert.log_to_crm("performance_analysis", {"bottlenecks": result.get("bottlenecks_found", 0), "revenue": 0.014})
    return jsonify(result)

@app.route('/resources/optimize', methods=['POST'])
def optimize_resources():
    """Optimize system resources"""
    data = request.json
    optimization_type = data.get('optimization_type', 'memory')

    result = system_expert.optimize_system_resources(optimization_type)
    system_expert.revenue_stats["total_operations"] += 1

    system_expert.log_to_crm("resource_optimization", {"type": optimization_type, "optimizations": result["optimizations_found"], "revenue": 0.014})
    return jsonify(result)

@app.route('/diagnostics/run', methods=['POST'])
def run_diagnostics():
    """Run system diagnostics"""
    data = request.json
    diagnostic_type = data.get('diagnostic_type', 'full')

    result = system_expert.run_system_diagnostics(diagnostic_type)
    system_expert.revenue_stats["total_operations"] += 1

    system_expert.log_to_crm("system_diagnostics", {"type": diagnostic_type, "checks_run": len(result.get("checks", [])), "revenue": 0.014})
    return jsonify(result)

@app.route('/logs/analyze', methods=['POST'])
def analyze_logs():
    """Analyze system logs"""
    data = request.json
    log_files = data.get('log_files')
    time_range_hours = data.get('time_range_hours', 24)

    result = system_expert.analyze_system_logs(log_files, time_range_hours)
    system_expert.revenue_stats["total_operations"] += 1

    system_expert.log_to_crm("log_analysis", {"files_analyzed": len(result["log_files_analyzed"]), "issues_found": len(result["issues_found"]), "revenue": 0.014})
    return jsonify(result)

@app.route('/report/performance', methods=['POST'])
def generate_report():
    """Generate performance report"""
    data = request.json
    time_range_hours = data.get('time_range_hours', 24)

    result = system_expert.generate_performance_report(time_range_hours)
    system_expert.revenue_stats["total_operations"] += 1

    system_expert.log_to_crm("performance_report", {"time_range": time_range_hours, "revenue": 0.014})
    return jsonify(result)

@app.route('/analytics', methods=['GET'])
def analytics():
    """Get system analytics"""
    analytics = system_expert.get_system_analytics()
    system_expert.log_to_crm("analytics_request", analytics)
    return jsonify(analytics)

@app.route('/tools', methods=['GET'])
def tools():
    """Get supported system tools"""
    return jsonify(system_expert.system_tools)

@app.route('/alerts', methods=['GET'])
def get_alerts():
    """Get recent alerts"""
    return jsonify({
        "active_alerts": len(system_expert.alert_history),
        "recent_alerts": system_expert.alert_history[-10:],
        "timestamp": datetime.now().isoformat()
    })

@app.route('/attribution', methods=['GET'])
def attribution():
    """Get revenue attribution"""
    return jsonify(system_expert.get_revenue_attribution())

@app.route('/agent/metrics', methods=['GET'])
def agent_metrics():
    """Get agent metrics"""
    return jsonify({
        "agent": "system-tools-expert",
        "supported_tools": len(system_expert.system_tools),
        "active_alerts": len(system_expert.alert_history),
        "cached_processes": len(system_expert.process_cache),
        "last_health_check": system_expert.last_health_check,
        "total_operations": system_expert.revenue_stats["total_operations"],
        "system_scans": system_expert.revenue_stats["system_scans"],
        "performance_analyses": system_expert.revenue_stats["performance_analyses"],
        "resource_optimizations": system_expert.revenue_stats["resource_optimizations"],
        "diagnostic_reports": system_expert.revenue_stats["diagnostic_reports"],
        "founder_royalty_paid": system_expert.revenue_stats["founder_royalty_paid"],
        "timestamp": datetime.now().isoformat()
    })

def continuous_monitoring():
    """Background thread for continuous monitoring"""
    while True:
        try:
            # Check service health every 30 seconds
            system_expert.check_system_service_status()

            # Get system metrics every 60 seconds
            if int(time.time()) % 60 == 0:
                system_expert.get_system_metrics()

            time.sleep(30)
        except Exception as e:
            print(f"Monitoring error: {e}")
            time.sleep(30)

if __name__ == '__main__':
    print(f"🖥️ System Tools Expert Agent starting on port {PORT}")
    print(f"💰 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    print(f"\n📊 System Tools Configured:")
    for name, info in system_expert.system_tools.items():
        print(f"   • {info['name']} - {info['type']}")
    print(f"\n🔍 Expertise Areas: {len(system_expert.expertise)}")

    # Initial service check
    status = system_expert.check_system_service_status()
    print(f"\n📈 Initial Status: {status['status']}")

    # Start background monitoring
    monitor_thread = threading.Thread(target=continuous_monitoring, daemon=True)
    monitor_thread.start()

    # Register with master hub
    try:
        import requests
        requests.post("http://localhost:9999/register_agent", json={
            "agent": "system-tools-expert",
            "port": PORT,
            "capabilities": system_expert.expertise
        }, timeout=2)
        print("✅ Registered with quantum blockchain hub")
    except:
        print("⚠️ Hub registration pending (will retry)")

    app.run(host='0.0.0.0', port=PORT, debug=False)