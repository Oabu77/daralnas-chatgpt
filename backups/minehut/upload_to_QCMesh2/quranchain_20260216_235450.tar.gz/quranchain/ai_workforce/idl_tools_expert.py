#!/usr/bin/env python3
"""
IDL Tools Expert AI Agent
Master of QuranChain IDL Operations: IDL operators, scientific data analysis, visualization
Specializes in: IDL programming, astronomical data processing, image analysis, scientific computing
"""

from flask import Flask, jsonify, request
import json
import time
import threading
from datetime import datetime
import os
import logging
import secrets
import hashlib
import numpy as np

app = Flask(__name__)
PORT = 9028

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty

class IDLToolsExpert:
    def __init__(self):
        self.agent_name = "idl-tools-expert"
        self.expertise = [
            "idl_programming",
            "astronomical_data_analysis",
            "image_processing",
            "scientific_visualization",
            "data_manipulation",
            "statistical_analysis",
            "array_operations",
            "file_i_o_operations",
            "plotting_graphics",
            "signal_processing",
            "remote_sensing",
            "geospatial_analysis",
            "spectroscopy",
            "time_series_analysis",
            "numerical_computing",
            "scientific_workflows"
        ]

        # IDL Tools Knowledge
        self.idl_tools = {
            "idl_core": {
                "name": "IDL Core Language",
                "type": "Scientific Programming Language",
                "version": "8.8+",
                "features": [
                    "Array-oriented Programming",
                    "Built-in Mathematical Functions",
                    "Data Visualization",
                    "File I/O Operations",
                    "Object-oriented Programming",
                    "Cross-platform Compatibility",
                    "Integration with Python",
                    "High-performance Computing"
                ],
                "data_types": ["integers", "floats", "complex", "strings", "structures", "pointers"],
                "use_cases": ["Data Analysis", "Scientific Computing", "Image Processing", "Visualization"]
            },
            "astronomical_library": {
                "name": "Astronomical Library (AstroLib)",
                "type": "Astronomy-specific Functions",
                "features": [
                    "Coordinate Transformations",
                    "Celestial Mechanics",
                    "Photometric Analysis",
                    "Spectral Analysis",
                    "Telescope Data Reduction",
                    "Astrometry",
                    "Light Curve Analysis",
                    "Exoplanet Detection"
                ],
                "supported_missions": ["Hubble", "JWST", "TESS", "Kepler", "GAIA"],
                "use_cases": ["Astronomical Research", "Space Mission Data", "Stellar Analysis"]
            },
            "image_processing": {
                "name": "IDL Image Processing",
                "type": "Computer Vision Library",
                "features": [
                    "Image Filtering",
                    "Morphological Operations",
                    "Fourier Transforms",
                    "Wavelet Analysis",
                    "Edge Detection",
                    "Segmentation",
                    "Registration",
                    "Restoration"
                ],
                "supported_formats": ["FITS", "JPEG", "TIFF", "PNG", "DICOM"],
                "use_cases": ["Medical Imaging", "Remote Sensing", "Quality Control", "Research"]
            },
            "scientific_visualization": {
                "name": "IDL Visualization Tools",
                "type": "Graphics and Plotting",
                "features": [
                    "2D/3D Plotting",
                    "Surface Plots",
                    "Contour Plots",
                    "Volume Rendering",
                    "Animation",
                    "Interactive Graphics",
                    "Publication Quality",
                    "Custom Styling"
                ],
                "output_formats": ["PNG", "JPEG", "PDF", "PostScript", "SVG"],
                "use_cases": ["Data Visualization", "Scientific Publishing", "Presentations"]
            }
        }

        self.revenue_stats = {
            "total_operations": 0,
            "idl_programs_executed": 0,
            "data_analyses_performed": 0,
            "images_processed": 0,
            "visualizations_created": 0,
            "astronomical_calculations": 0,
            "signal_processing_operations": 0,
            "geospatial_analyses": 0,
            "founder_royalty_paid": 0
        }

        self.service_status = {}
        self.last_health_check = None
        self.crm_db = "crm/crm.db"

        # Mock IDL data structures
        self.idl_variables = {}
        self.idl_procedures = {}
        self.data_arrays = {}

        self.setup_logging()

    def setup_logging(self):
        """Setup logging for IDL operations"""
        logging.basicConfig(
            filename='logs/ai_workforce/idl_tools_expert.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def log_to_crm(self, action, data):
        """Log IDL operations to CRM for attribution tracking"""
        try:
            import sqlite3
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT INTO agent_activities
                (agent_name, action, data, timestamp, revenue_impact)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                self.agent_name,
                action,
                json.dumps(data),
                datetime.now().isoformat(),
                data.get('revenue', 0)
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error(f"CRM logging error: {e}")

    def check_idl_service_status(self):
        """Check status of IDL services"""
        status = {
            "timestamp": datetime.now().isoformat(),
            "service": "idl-tools-expert",
            "port": PORT,
            "status": "unknown",
            "numpy_available": False,
            "scipy_available": False,
            "matplotlib_available": False,
            "astropy_available": False,
            "database_connection": False
        }

        # Check NumPy (IDL-like array operations)
        try:
            import numpy as np
            status["numpy_available"] = True
        except:
            pass

        # Check SciPy (scientific computing)
        try:
            import scipy
            status["scipy_available"] = True
        except:
            pass

        # Check Matplotlib (plotting)
        try:
            import matplotlib
            status["matplotlib_available"] = True
        except:
            pass

        # Check AstroPy (astronomical computations)
        try:
            import astropy
            status["astropy_available"] = True
        except:
            pass

        # Check database connection
        try:
            import sqlite3
            conn = sqlite3.connect(self.crm_db)
            conn.close()
            status["database_connection"] = True
        except:
            pass

        # Determine overall status
        available_count = sum([
            status["numpy_available"],
            status["scipy_available"],
            status["matplotlib_available"],
            status["astropy_available"],
            status["database_connection"]
        ])

        if available_count >= 4:
            status["status"] = "healthy"
        elif available_count >= 3:
            status["status"] = "degraded"
        else:
            status["status"] = "offline"

        self.service_status = status
        self.last_health_check = datetime.now().isoformat()
        return status

    def execute_idl_array_operation(self, operation, array1, array2=None, parameters=None):
        """Execute IDL-style array operations"""
        try:
            # Convert to numpy arrays
            arr1 = np.array(array1)

            if operation == "findgen":
                # Create array from 0 to n-1
                n = parameters.get("n", 10)
                result = np.arange(n, dtype=float)
            elif operation == "indgen":
                # Create integer array from 0 to n-1
                n = parameters.get("n", 10)
                result = np.arange(n, dtype=int)
            elif operation == "dindgen":
                # Create double array from 0 to n-1
                n = parameters.get("n", 10)
                result = np.arange(n, dtype=float)
            elif operation == "fltarr":
                # Create float array filled with zeros
                dimensions = parameters.get("dimensions", [10])
                result = np.zeros(dimensions, dtype=float)
            elif operation == "intarr":
                # Create integer array filled with zeros
                dimensions = parameters.get("dimensions", [10])
                result = np.zeros(dimensions, dtype=int)
            elif operation == "dblarr":
                # Create double array filled with zeros
                dimensions = parameters.get("dimensions", [10])
                result = np.zeros(dimensions, dtype=float)
            elif operation == "reform":
                # Reshape array
                new_shape = parameters.get("shape", arr1.shape)
                result = arr1.reshape(new_shape)
            elif operation == "transpose":
                # Transpose array
                result = arr1.T
            elif operation == "reverse":
                # Reverse array
                result = np.flip(arr1)
            elif operation == "sort":
                # Sort array
                result = np.sort(arr1)
            elif operation == "total":
                # Sum array elements
                result = np.sum(arr1)
            elif operation == "mean":
                # Mean of array
                result = np.mean(arr1)
            elif operation == "stddev":
                # Standard deviation
                result = np.std(arr1)
            elif operation == "min":
                # Minimum value
                result = np.min(arr1)
            elif operation == "max":
                # Maximum value
                result = np.max(arr1)
            else:
                return {"error": f"Unsupported operation: {operation}"}

            result_data = {
                "operation": operation,
                "input_shape": arr1.shape,
                "output_shape": result.shape,
                "result": result.tolist() if hasattr(result, 'tolist') else result,
                "data_type": str(result.dtype),
                "executed_at": datetime.now().isoformat()
            }

            self.revenue_stats["idl_programs_executed"] += 1
            return result_data

        except Exception as e:
            return {"error": str(e)}

    def perform_astronomical_calculation(self, calculation_type, parameters):
        """Perform astronomical calculations"""
        try:
            if calculation_type == "coordinate_conversion":
                # Convert between coordinate systems
                ra = parameters.get("ra", 0)  # Right Ascension in degrees
                dec = parameters.get("dec", 0)  # Declination in degrees
                from_system = parameters.get("from", "equatorial")
                to_system = parameters.get("to", "galactic")

                # Mock coordinate conversion (in production, use astropy)
                if from_system == "equatorial" and to_system == "galactic":
                    # Simplified conversion
                    l = (ra - 32.93) * np.cos(np.radians(dec))  # Galactic longitude
                    b = dec - 28.94  # Galactic latitude
                    result = {"l": l, "b": b}
                else:
                    result = {"error": "Unsupported coordinate conversion"}

            elif calculation_type == "distance_modulus":
                # Calculate distance from apparent magnitude and absolute magnitude
                m = parameters.get("apparent_magnitude", 0)
                M = parameters.get("absolute_magnitude", 0)
                distance_modulus = m - M
                distance_parsecs = 10 ** ((distance_modulus + 5) / 5)
                result = {
                    "distance_modulus": distance_modulus,
                    "distance_parsecs": distance_parsecs,
                    "distance_light_years": distance_parsecs * 3.08568e13 / 9.461e15
                }

            elif calculation_type == "blackbody_flux":
                # Calculate blackbody flux
                temperature = parameters.get("temperature", 5772)  # Kelvin
                wavelength = parameters.get("wavelength", 500e-9)  # meters

                # Planck's law (simplified)
                h = 6.626e-34  # Planck constant
                c = 3e8  # Speed of light
                k = 1.381e-23  # Boltzmann constant

                flux = (2 * h * c**2 / wavelength**5) / (np.exp(h * c / (wavelength * k * temperature)) - 1)
                result = {
                    "flux": flux,
                    "temperature": temperature,
                    "wavelength": wavelength
                }

            else:
                return {"error": f"Unsupported calculation: {calculation_type}"}

            result_data = {
                "calculation_type": calculation_type,
                "parameters": parameters,
                "result": result,
                "calculated_at": datetime.now().isoformat()
            }

            self.revenue_stats["astronomical_calculations"] += 1
            return result_data

        except Exception as e:
            return {"error": str(e)}

    def process_scientific_image(self, image_data, operation, parameters=None):
        """Process scientific images (IDL-style)"""
        try:
            # Convert to numpy array
            image = np.array(image_data)

            if operation == "smooth":
                # Apply smoothing filter
                from scipy.ndimage import gaussian_filter
                sigma = parameters.get("sigma", 1.0)
                smoothed = gaussian_filter(image, sigma=sigma)
                result = smoothed.tolist()

            elif operation == "convol":
                # Convolution with kernel
                from scipy.signal import convolve2d
                kernel = np.array(parameters.get("kernel", [[1, 1, 1], [1, 1, 1], [1, 1, 1]]))
                kernel = kernel / np.sum(kernel)  # Normalize
                convolved = convolve2d(image, kernel, mode='same')
                result = convolved.tolist()

            elif operation == "histogram":
                # Create histogram
                bins = parameters.get("bins", 256)
                range_min = parameters.get("min", np.min(image))
                range_max = parameters.get("max", np.max(image))

                hist, bin_edges = np.histogram(image.flatten(), bins=bins, range=(range_min, range_max))
                result = {
                    "histogram": hist.tolist(),
                    "bin_edges": bin_edges.tolist(),
                    "bins": bins
                }

            elif operation == "statistics":
                # Calculate image statistics
                stats = {
                    "mean": float(np.mean(image)),
                    "median": float(np.median(image)),
                    "stddev": float(np.std(image)),
                    "min": float(np.min(image)),
                    "max": float(np.max(image)),
                    "total_pixels": int(np.prod(image.shape))
                }
                result = stats

            else:
                return {"error": f"Unsupported image operation: {operation}"}

            result_data = {
                "operation": operation,
                "input_shape": image.shape,
                "parameters": parameters or {},
                "result": result,
                "processed_at": datetime.now().isoformat()
            }

            self.revenue_stats["images_processed"] += 1
            return result_data

        except Exception as e:
            return {"error": str(e)}

    def create_scientific_visualization(self, data, plot_type, parameters=None):
        """Create scientific visualizations (IDL-style)"""
        try:
            import matplotlib.pyplot as plt

            plt.figure(figsize=(10, 6))

            if plot_type == "plot":
                # Line plot
                x = parameters.get("x", list(range(len(data))))
                plt.plot(x, data, 'b-', linewidth=2)
                plt.xlabel(parameters.get("xlabel", "X"))
                plt.ylabel(parameters.get("ylabel", "Y"))
                plt.title(parameters.get("title", "Scientific Plot"))

            elif plot_type == "contour":
                # Contour plot
                data_array = np.array(data)
                if len(data_array.shape) == 2:
                    plt.contour(data_array, levels=parameters.get("levels", 10))
                    plt.colorbar()
                    plt.title(parameters.get("title", "Contour Plot"))

            elif plot_type == "surface":
                # Surface plot
                from mpl_toolkits.mplot3d import Axes3D
                data_array = np.array(data)
                if len(data_array.shape) == 2:
                    x, y = np.meshgrid(np.arange(data_array.shape[1]), np.arange(data_array.shape[0]))
                    ax = plt.gca(projection='3d')
                    ax.plot_surface(x, y, data_array, cmap='viridis')
                    plt.title(parameters.get("title", "Surface Plot"))

            elif plot_type == "histogram":
                # Histogram
                plt.hist(data, bins=parameters.get("bins", 50), alpha=0.7, edgecolor='black')
                plt.xlabel(parameters.get("xlabel", "Value"))
                plt.ylabel(parameters.get("ylabel", "Frequency"))
                plt.title(parameters.get("title", "Histogram"))

            else:
                plt.close()
                return {"error": f"Unsupported plot type: {plot_type}"}

            # Save plot to base64 string (simplified - in production, save to file)
            import io
            import base64
            buf = io.BytesIO()
            plt.savefig(buf, format='png', dpi=100, bbox_inches='tight')
            buf.seek(0)
            image_base64 = base64.b64encode(buf.read()).decode('utf-8')
            plt.close()

            result_data = {
                "plot_type": plot_type,
                "data_points": len(data) if isinstance(data, list) else "array",
                "parameters": parameters or {},
                "image_base64": image_base64,
                "image_format": "png",
                "created_at": datetime.now().isoformat()
            }

            self.revenue_stats["visualizations_created"] += 1
            return result_data

        except Exception as e:
            return {"error": str(e)}

    def perform_signal_processing(self, signal_data, operation, parameters=None):
        """Perform signal processing operations"""
        try:
            signal = np.array(signal_data)

            if operation == "fft":
                # Fast Fourier Transform
                fft_result = np.fft.fft(signal)
                frequencies = np.fft.fftfreq(len(signal))
                result = {
                    "fft_real": fft_result.real.tolist(),
                    "fft_imag": fft_result.imag.tolist(),
                    "frequencies": frequencies.tolist(),
                    "magnitude": np.abs(fft_result).tolist()
                }

            elif operation == "filter":
                # Apply filter
                from scipy.signal import butter, filtfilt
                filter_type = parameters.get("type", "lowpass")
                cutoff = parameters.get("cutoff", 0.1)
                order = parameters.get("order", 4)

                # Design filter
                b, a = butter(order, cutoff, btype=filter_type)
                filtered_signal = filtfilt(b, a, signal)
                result = filtered_signal.tolist()

            elif operation == "convolve":
                # Convolution
                kernel = np.array(parameters.get("kernel", [1, 1, 1]))
                convolved = np.convolve(signal, kernel, mode='same')
                result = convolved.tolist()

            elif operation == "correlation":
                # Auto-correlation
                correlation = np.correlate(signal, signal, mode='full')
                result = correlation.tolist()

            else:
                return {"error": f"Unsupported signal operation: {operation}"}

            result_data = {
                "operation": operation,
                "input_length": len(signal),
                "parameters": parameters or {},
                "result": result,
                "processed_at": datetime.now().isoformat()
            }

            self.revenue_stats["signal_processing_operations"] += 1
            return result_data

        except Exception as e:
            return {"error": str(e)}

    def analyze_geospatial_data(self, data, analysis_type, parameters=None):
        """Analyze geospatial data"""
        try:
            if analysis_type == "distance":
                # Calculate distances between points
                points = np.array(data)
                from scipy.spatial.distance import pdist, squareform
                distances = squareform(pdist(points))
                result = distances.tolist()

            elif analysis_type == "area":
                # Calculate area (simplified for polygons)
                # Assuming data is list of (x,y) coordinates
                from shapely.geometry import Polygon
                polygon = Polygon(data)
                area = polygon.area
                result = {"area": area, "perimeter": polygon.length}

            elif analysis_type == "centroid":
                # Calculate centroid
                points = np.array(data)
                centroid = np.mean(points, axis=0)
                result = {"centroid_x": centroid[0], "centroid_y": centroid[1]}

            elif analysis_type == "buffer":
                # Create buffer around points
                from shapely.geometry import Point
                points = [Point(p) for p in data]
                buffer_distance = parameters.get("distance", 1.0)
                buffered = [point.buffer(buffer_distance) for point in points]
                result = [{"x": list(poly.exterior.xy[0]), "y": list(poly.exterior.xy[1])} for poly in buffered]

            else:
                return {"error": f"Unsupported geospatial analysis: {analysis_type}"}

            result_data = {
                "analysis_type": analysis_type,
                "input_points": len(data),
                "parameters": parameters or {},
                "result": result,
                "analyzed_at": datetime.now().isoformat()
            }

            self.revenue_stats["geospatial_analyses"] += 1
            return result_data

        except Exception as e:
            return {"error": str(e)}

    def execute_idl_procedure(self, procedure_name, parameters):
        """Execute IDL-style procedures"""
        try:
            # Mock IDL procedures
            if procedure_name == "read_fits":
                # Simulate reading FITS file
                result = {
                    "header": {"NAXIS": 2, "NAXIS1": 1024, "NAXIS2": 1024},
                    "data_shape": [1024, 1024],
                    "data_type": "float32",
                    "file_info": "Simulated FITS file read"
                }

            elif procedure_name == "write_fits":
                # Simulate writing FITS file
                filename = parameters.get("filename", "output.fits")
                result = {
                    "filename": filename,
                    "status": "written",
                    "bytes_written": 1024 * 1024 * 4,  # 4MB for float32
                    "file_info": f"FITS file {filename} written successfully"
                }

            elif procedure_name == "plot":
                # Simulate plotting
                result = {
                    "plot_type": "line",
                    "data_points": len(parameters.get("data", [])),
                    "output_format": "png",
                    "status": "created"
                }

            elif procedure_name == "tv":
                # Simulate image display (tv procedure)
                result = {
                    "display_type": "image",
                    "dimensions": parameters.get("dimensions", [512, 512]),
                    "colormap": parameters.get("colormap", "greyscale"),
                    "status": "displayed"
                }

            else:
                return {"error": f"Unknown IDL procedure: {procedure_name}"}

            result_data = {
                "procedure": procedure_name,
                "parameters": parameters,
                "result": result,
                "executed_at": datetime.now().isoformat()
            }

            self.revenue_stats["idl_programs_executed"] += 1
            return result_data

        except Exception as e:
            return {"error": str(e)}

    def get_idl_analytics(self):
        """Get IDL operations analytics"""
        analytics = {
            "timestamp": datetime.now().isoformat(),
            "total_operations": self.revenue_stats["total_operations"],
            "idl_programs_executed": self.revenue_stats["idl_programs_executed"],
            "data_analyses_performed": self.revenue_stats["data_analyses_performed"],
            "images_processed": self.revenue_stats["images_processed"],
            "visualizations_created": self.revenue_stats["visualizations_created"],
            "astronomical_calculations": self.revenue_stats["astronomical_calculations"],
            "signal_processing_operations": self.revenue_stats["signal_processing_operations"],
            "geospatial_analyses": self.revenue_stats["geospatial_analyses"],
            "active_variables": len(self.idl_variables),
            "stored_procedures": len(self.idl_procedures),
            "data_arrays": len(self.data_arrays),
            "supported_operations": ["array_ops", "astronomy", "image_proc", "visualization", "signal_proc", "geospatial"],
            "data_types_supported": ["int", "float", "double", "complex", "string", "structure"]
        }

        return analytics

    def get_revenue_attribution(self):
        """Get revenue attribution for this agent"""
        return {
            "agent": self.agent_name,
            "total_operations": self.revenue_stats["total_operations"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "revenue_generated": self.revenue_stats["total_operations"] * 0.016,  # $0.016 per operation
            "attribution_percentage": 0.20  # 20% of IDL operations revenue
        }

# Initialize the expert
idl_expert = IDLToolsExpert()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    status = idl_expert.check_idl_service_status()
    return jsonify(status)

@app.route('/array/operation', methods=['POST'])
def execute_array_operation():
    """Execute IDL array operation"""
    data = request.json
    operation = data.get('operation', '')
    array1 = data.get('array1', [])
    array2 = data.get('array2')
    parameters = data.get('parameters', {})

    result = idl_expert.execute_idl_array_operation(operation, array1, array2, parameters)
    idl_expert.revenue_stats["total_operations"] += 1

    idl_expert.log_to_crm("array_operation", {"operation": operation, "array_size": len(array1), "revenue": 0.016})
    return jsonify(result)

@app.route('/astronomy/calculate', methods=['POST'])
def astronomical_calculation():
    """Perform astronomical calculation"""
    data = request.json
    calculation_type = data.get('calculation_type', '')
    parameters = data.get('parameters', {})

    result = idl_expert.perform_astronomical_calculation(calculation_type, parameters)
    idl_expert.revenue_stats["total_operations"] += 1

    idl_expert.log_to_crm("astronomical_calculation", {"type": calculation_type, "revenue": 0.016})
    return jsonify(result)

@app.route('/image/process', methods=['POST'])
def process_image():
    """Process scientific image"""
    data = request.json
    image_data = data.get('image_data', [])
    operation = data.get('operation', '')
    parameters = data.get('parameters', {})

    result = idl_expert.process_scientific_image(image_data, operation, parameters)
    idl_expert.revenue_stats["total_operations"] += 1

    idl_expert.log_to_crm("image_processing", {"operation": operation, "revenue": 0.016})
    return jsonify(result)

@app.route('/visualization/create', methods=['POST'])
def create_visualization():
    """Create scientific visualization"""
    data = request.json
    plot_data = data.get('data', [])
    plot_type = data.get('plot_type', '')
    parameters = data.get('parameters', {})

    result = idl_expert.create_scientific_visualization(plot_data, plot_type, parameters)
    idl_expert.revenue_stats["total_operations"] += 1

    idl_expert.log_to_crm("visualization_creation", {"plot_type": plot_type, "revenue": 0.016})
    return jsonify(result)

@app.route('/signal/process', methods=['POST'])
def process_signal():
    """Process signal"""
    data = request.json
    signal_data = data.get('signal_data', [])
    operation = data.get('operation', '')
    parameters = data.get('parameters', {})

    result = idl_expert.perform_signal_processing(signal_data, operation, parameters)
    idl_expert.revenue_stats["total_operations"] += 1

    idl_expert.log_to_crm("signal_processing", {"operation": operation, "signal_length": len(signal_data), "revenue": 0.016})
    return jsonify(result)

@app.route('/geospatial/analyze', methods=['POST'])
def analyze_geospatial():
    """Analyze geospatial data"""
    data = request.json
    geospatial_data = data.get('data', [])
    analysis_type = data.get('analysis_type', '')
    parameters = data.get('parameters', {})

    result = idl_expert.analyze_geospatial_data(geospatial_data, analysis_type, parameters)
    idl_expert.revenue_stats["total_operations"] += 1

    idl_expert.log_to_crm("geospatial_analysis", {"type": analysis_type, "points": len(geospatial_data), "revenue": 0.016})
    return jsonify(result)

@app.route('/procedure/execute', methods=['POST'])
def execute_procedure():
    """Execute IDL procedure"""
    data = request.json
    procedure_name = data.get('procedure_name', '')
    parameters = data.get('parameters', {})

    result = idl_expert.execute_idl_procedure(procedure_name, parameters)
    idl_expert.revenue_stats["total_operations"] += 1

    idl_expert.log_to_crm("procedure_execution", {"procedure": procedure_name, "revenue": 0.016})
    return jsonify(result)

@app.route('/analytics', methods=['GET'])
def analytics():
    """Get IDL analytics"""
    analytics = idl_expert.get_idl_analytics()
    idl_expert.log_to_crm("analytics_request", analytics)
    return jsonify(analytics)

@app.route('/tools', methods=['GET'])
def tools():
    """Get supported IDL tools"""
    return jsonify(idl_expert.idl_tools)

@app.route('/variables', methods=['GET'])
def list_variables():
    """List IDL variables"""
    return jsonify(idl_expert.idl_variables)

@app.route('/procedures', methods=['GET'])
def list_procedures():
    """List IDL procedures"""
    return jsonify(idl_expert.idl_procedures)

@app.route('/attribution', methods=['GET'])
def attribution():
    """Get revenue attribution"""
    return jsonify(idl_expert.get_revenue_attribution())

@app.route('/metrics', methods=['GET'])
def metrics():
    """Get agent metrics"""
    return jsonify({
        "agent": "idl-tools-expert",
        "supported_tools": len(idl_expert.idl_tools),
        "active_variables": len(idl_expert.idl_variables),
        "stored_procedures": len(idl_expert.idl_procedures),
        "data_arrays": len(idl_expert.data_arrays),
        "last_health_check": idl_expert.last_health_check,
        "total_operations": idl_expert.revenue_stats["total_operations"],
        "idl_programs_executed": idl_expert.revenue_stats["idl_programs_executed"],
        "images_processed": idl_expert.revenue_stats["images_processed"],
        "visualizations_created": idl_expert.revenue_stats["visualizations_created"],
        "astronomical_calculations": idl_expert.revenue_stats["astronomical_calculations"],
        "founder_royalty_paid": idl_expert.revenue_stats["founder_royalty_paid"],
        "timestamp": datetime.now().isoformat()
    })

def continuous_monitoring():
    """Background thread for continuous monitoring"""
    while True:
        try:
            # Check service health every 30 seconds
            idl_expert.check_idl_service_status()
            time.sleep(30)
        except Exception as e:
            print(f"Monitoring error: {e}")
            time.sleep(30)

if __name__ == '__main__':
    print(f"🔭 IDL Tools Expert Agent starting on port {PORT}")
    print(f"💰 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    print(f"\n📊 IDL Tools Configured:")
    for name, info in idl_expert.idl_tools.items():
        print(f"   • {info['name']} - {info['type']}")
    print(f"\n🔍 Expertise Areas: {len(idl_expert.expertise)}")

    # Initial service check
    status = idl_expert.check_idl_service_status()
    print(f"\n📈 Initial Status: {status['status']}")

    # Start background monitoring
    monitor_thread = threading.Thread(target=continuous_monitoring, daemon=True)
    monitor_thread.start()

    # Register with master hub
    try:
        import requests
        requests.post("http://localhost:9999/register_agent", json={
            "agent": "idl-tools-expert",
            "port": PORT,
            "capabilities": idl_expert.expertise
        }, timeout=2)
        print("✅ Registered with quantum blockchain hub")
    except:
        print("⚠️ Hub registration pending (will retry)")

    app.run(host='0.0.0.0', port=PORT, debug=False)