#!/usr/bin/env python3
"""
DevOps Tools Expert AI Agent
Master of QuranChain DevOps Operations: Docker, Kubernetes, monitoring, deployment
Specializes in: Container orchestration, CI/CD, infrastructure monitoring, scaling
"""

from flask import Flask, jsonify, request
import subprocess
import json
import time
import threading
from datetime import datetime
import os
import logging
import psutil

app = Flask(__name__)
PORT = 9024

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty

class DevOpsToolsExpert:
    def __init__(self):
        self.agent_name = "devops-tools-expert"
        self.expertise = [
            "docker_container_management",
            "kubernetes_orchestration",
            "infrastructure_monitoring",
            "ci_cd_pipeline_management",
            "auto_scaling_configuration",
            "load_balancing_setup",
            "infrastructure_as_code",
            "configuration_management",
            "log_aggregation",
            "performance_monitoring",
            "backup_and_recovery",
            "security_hardening",
            "disaster_recovery",
            "cost_optimization",
            "compliance_automation"
        ]

        # DevOps Tools Knowledge
        self.devops_tools = {
            "docker": {
                "name": "Docker",
                "type": "Container Platform",
                "version": "24.x",
                "features": [
                    "Container Creation",
                    "Image Management",
                    "Docker Compose",
                    "Docker Swarm",
                    "Multi-stage Builds",
                    "Security Scanning"
                ],
                "use_cases": ["Application Packaging", "Microservices", "Development Environments"],
                "performance": "Lightweight virtualization with minimal overhead"
            },
            "kubernetes": {
                "name": "Kubernetes",
                "type": "Container Orchestration",
                "version": "1.28+",
                "features": [
                    "Pod Management",
                    "Service Discovery",
                    "Load Balancing",
                    "Auto Scaling",
                    "Rolling Updates",
                    "Secret Management"
                ],
                "use_cases": ["Production Deployments", "Microservices Orchestration", "Cloud Native Apps"],
                "performance": "Highly scalable and resilient container orchestration"
            },
            "monitoring": {
                "name": "Infrastructure Monitoring",
                "type": "Observability Platform",
                "features": [
                    "System Metrics",
                    "Application Performance",
                    "Log Aggregation",
                    "Alert Management",
                    "Dashboard Creation",
                    "Anomaly Detection"
                ],
                "tools_supported": ["Prometheus", "Grafana", "ELK Stack", "Datadog"],
                "use_cases": ["Performance Monitoring", "Incident Response", "Capacity Planning"]
            },
            "ci_cd": {
                "name": "CI/CD Pipelines",
                "type": "Automation Platform",
                "features": [
                    "Automated Testing",
                    "Build Automation",
                    "Deployment Pipelines",
                    "Environment Management",
                    "Artifact Management",
                    "Rollback Strategies"
                ],
                "tools_supported": ["GitHub Actions", "Jenkins", "GitLab CI", "ArgoCD"],
                "use_cases": ["Continuous Integration", "Continuous Deployment", "DevOps Automation"]
            }
        }

        self.revenue_stats = {
            "total_operations": 0,
            "containers_managed": 0,
            "deployments_executed": 0,
            "monitoring_alerts": 0,
            "scaling_events": 0,
            "backups_created": 0,
            "security_scans": 0,
            "infrastructure_cost_saved": 0,
            "founder_royalty_paid": 0
        }

        self.service_status = {}
        self.last_health_check = None
        self.crm_db = "crm/crm.db"

        # System monitoring data
        self.system_metrics = {}

        self.setup_logging()

    def setup_logging(self):
        """Setup logging for DevOps operations"""
        logging.basicConfig(
            filename='logs/ai_workforce/devops_tools_expert.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def log_to_crm(self, action, data):
        """Log DevOps operations to CRM for attribution tracking"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT INTO agent_activities
                (agent_name, action, data, timestamp, revenue_impact)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                self.agent_name,
                action,
                json.dumps(data),
                datetime.now().isoformat(),
                data.get('revenue', 0)
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error(f"CRM logging error: {e}")

    def check_devops_service_status(self):
        """Check status of DevOps services"""
        status = {
            "timestamp": datetime.now().isoformat(),
            "service": "devops_tools_expert",
            "port": PORT,
            "status": "unknown",
            "docker_available": False,
            "system_monitoring": True,  # Always available via psutil
            "disk_space_available": False,
            "memory_available": True
        }

        # Check Docker
        try:
            result = subprocess.run(
                ["docker", "version"],
                capture_output=True,
                timeout=5
            )
            status["docker_available"] = result.returncode == 0
        except:
            pass

        # Check disk space
        try:
            disk = psutil.disk_usage('/')
            status["disk_space_available"] = disk.percent < 90  # Less than 90% used
            status["disk_usage_percent"] = disk.percent
        except:
            pass

        # Determine overall status
        available_count = sum([
            status["docker_available"],
            status["system_monitoring"],
            status["disk_space_available"],
            status["memory_available"]
        ])

        if available_count >= 3:
            status["status"] = "healthy"
        elif available_count >= 2:
            status["status"] = "degraded"
        else:
            status["status"] = "offline"

        self.service_status = status
        self.last_health_check = datetime.now().isoformat()
        return status

    def get_system_metrics(self):
        """Get comprehensive system metrics"""
        try:
            metrics = {
                "timestamp": datetime.now().isoformat(),
                "cpu": {
                    "usage_percent": psutil.cpu_percent(interval=1),
                    "count": psutil.cpu_count(),
                    "frequency": psutil.cpu_freq().current if psutil.cpu_freq() else None
                },
                "memory": {
                    "total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
                    "used_gb": round(psutil.virtual_memory().used / (1024**3), 2),
                    "available_gb": round(psutil.virtual_memory().available / (1024**3), 2),
                    "usage_percent": psutil.virtual_memory().percent
                },
                "disk": {
                    "total_gb": round(psutil.disk_usage('/').total / (1024**3), 2),
                    "used_gb": round(psutil.disk_usage('/').used / (1024**3), 2),
                    "free_gb": round(psutil.disk_usage('/').free / (1024**3), 2),
                    "usage_percent": psutil.disk_usage('/').percent
                },
                "network": {
                    "bytes_sent": psutil.net_io_counters().bytes_sent,
                    "bytes_recv": psutil.net_io_counters().bytes_recv,
                    "packets_sent": psutil.net_io_counters().packets_sent,
                    "packets_recv": psutil.net_io_counters().packets_recv
                },
                "processes": {
                    "total": len(psutil.pids()),
                    "running": len([p for p in psutil.process_iter() if p.status() == 'running'])
                }
            }

            self.system_metrics = metrics
            return metrics

        except Exception as e:
            return {"error": str(e)}

    def docker_operations(self, operation, **kwargs):
        """Execute Docker operations"""
        try:
            if operation == "list_containers":
                result = subprocess.run(
                    ["docker", "ps", "-a", "--format", "json"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0:
                    containers = [json.loads(line) for line in result.stdout.strip().split('\n') if line]
                    return {"containers": containers, "count": len(containers)}

            elif operation == "list_images":
                result = subprocess.run(
                    ["docker", "images", "--format", "json"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0:
                    images = [json.loads(line) for line in result.stdout.strip().split('\n') if line]
                    return {"images": images, "count": len(images)}

            elif operation == "build_image":
                image_name = kwargs.get('image_name', 'quranchain-app')
                dockerfile_path = kwargs.get('dockerfile_path', '.')
                result = subprocess.run(
                    ["docker", "build", "-t", image_name, dockerfile_path],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                return {
                    "success": result.returncode == 0,
                    "output": result.stdout,
                    "errors": result.stderr,
                    "image_name": image_name
                }

            elif operation == "run_container":
                image_name = kwargs.get('image_name', 'quranchain-app')
                container_name = kwargs.get('container_name', f"quranchain-{int(time.time())}")
                ports = kwargs.get('ports', '5000:5000')

                cmd = ["docker", "run", "-d", "--name", container_name, "-p", ports, image_name]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

                return {
                    "success": result.returncode == 0,
                    "container_name": container_name,
                    "image_name": image_name,
                    "ports": ports,
                    "container_id": result.stdout.strip() if result.returncode == 0 else None,
                    "errors": result.stderr if result.returncode != 0 else None
                }

            elif operation == "stop_container":
                container_name = kwargs.get('container_name', '')
                result = subprocess.run(
                    ["docker", "stop", container_name],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                return {
                    "success": result.returncode == 0,
                    "container_name": container_name,
                    "output": result.stdout.strip()
                }

            elif operation == "remove_container":
                container_name = kwargs.get('container_name', '')
                result = subprocess.run(
                    ["docker", "rm", container_name],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                return {
                    "success": result.returncode == 0,
                    "container_name": container_name,
                    "output": result.stdout.strip()
                }

            else:
                return {"error": f"Unsupported Docker operation: {operation}"}

        except Exception as e:
            return {"error": str(e)}

    def generate_dockerfile(self, app_type="flask", python_version="3.9"):
        """Generate Dockerfile for different application types"""
        dockerfiles = {
            "flask": f"""
FROM python:{python_version}-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["python", "app.py"]
""",
            "fastapi": f"""
FROM python:{python_version}-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
""",
            "node": """
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
"""
        }

        if app_type in dockerfiles:
            return {
                "app_type": app_type,
                "python_version": python_version if "python" in app_type else None,
                "dockerfile": dockerfiles[app_type],
                "build_instructions": [
                    f"docker build -t quranchain-{app_type} .",
                    f"docker run -p 5000:5000 quranchain-{app_type}"
                ]
            }
        else:
            return {"error": f"Unsupported app type: {app_type}"}

    def generate_kubernetes_manifest(self, app_name="quranchain-app", replicas=3):
        """Generate Kubernetes deployment manifest"""
        manifest = f"""
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {app_name}
  labels:
    app: {app_name}
spec:
  replicas: {replicas}
  selector:
    matchLabels:
      app: {app_name}
  template:
    metadata:
      labels:
        app: {app_name}
    spec:
      containers:
      - name: {app_name}
        image: {app_name}:latest
        ports:
        - containerPort: 5000
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: {app_name}-service
spec:
  selector:
    app: {app_name}
  ports:
    - port: 80
      targetPort: 5000
  type: LoadBalancer
"""

        return {
            "app_name": app_name,
            "replicas": replicas,
            "manifest": manifest,
            "deployment_instructions": [
                "kubectl apply -f deployment.yaml",
                f"kubectl scale deployment {app_name} --replicas=5",
                f"kubectl get pods -l app={app_name}"
            ]
        }

    def create_monitoring_dashboard(self, service_name="quranchain"):
        """Create monitoring dashboard configuration"""
        dashboard = {
            "dashboard": {
                "title": f"{service_name} Monitoring Dashboard",
                "tags": ["quranchain", "monitoring"],
                "timezone": "UTC",
                "panels": [
                    {
                        "title": "CPU Usage",
                        "type": "graph",
                        "targets": [{
                            "expr": f"rate(cpu_usage{{service='{service_name}'}}[5m])",
                            "legendFormat": "CPU Usage"
                        }]
                    },
                    {
                        "title": "Memory Usage",
                        "type": "graph",
                        "targets": [{
                            "expr": f"memory_usage{{service='{service_name}'}}",
                            "legendFormat": "Memory (GB)"
                        }]
                    },
                    {
                        "title": "Response Time",
                        "type": "graph",
                        "targets": [{
                            "expr": f"http_request_duration_seconds{{service='{service_name}'}}",
                            "legendFormat": "Response Time (s)"
                        }]
                    },
                    {
                        "title": "Error Rate",
                        "type": "graph",
                        "targets": [{
                            "expr": f"rate(http_requests_total{{status=~'5..',service='{service_name}'}}[5m]) / rate(http_requests_total{{service='{service_name}'}}[5m])",
                            "legendFormat": "Error Rate"
                        }]
                    }
                ],
                "time": {
                    "from": "now-1h",
                    "to": "now"
                }
            }
        }

        return dashboard

    def optimize_infrastructure_cost(self, current_usage):
        """Provide infrastructure cost optimization recommendations"""
        recommendations = []

        # CPU optimization
        if current_usage.get("cpu_percent", 0) < 30:
            recommendations.append({
                "type": "cpu_optimization",
                "recommendation": "Consider downgrading CPU allocation - usage is below 30%",
                "potential_savings": "$50-100/month",
                "action": "Reduce CPU cores or use burstable instances"
            })

        # Memory optimization
        if current_usage.get("memory_percent", 0) < 40:
            recommendations.append({
                "type": "memory_optimization",
                "recommendation": "Memory usage is below 40% - consider rightsizing",
                "potential_savings": "$30-80/month",
                "action": "Reduce RAM allocation"
            })

        # Storage optimization
        disk_usage = current_usage.get("disk_percent", 0)
        if disk_usage > 80:
            recommendations.append({
                "type": "storage_optimization",
                "recommendation": f"High disk usage ({disk_usage}%) - implement cleanup",
                "potential_savings": "$20-50/month",
                "action": "Implement log rotation and cleanup policies"
            })

        return {
            "current_usage": current_usage,
            "recommendations": recommendations,
            "total_potential_savings": sum([50, 30, 20]) if recommendations else 0,  # Simplified calculation
            "implementation_priority": "high" if len(recommendations) > 2 else "medium"
        }

    def get_devops_analytics(self):
        """Get DevOps performance analytics"""
        analytics = {
            "timestamp": datetime.now().isoformat(),
            "total_operations": self.revenue_stats["total_operations"],
            "containers_managed": self.revenue_stats["containers_managed"],
            "deployments_executed": self.revenue_stats["deployments_executed"],
            "monitoring_alerts": self.revenue_stats["monitoring_alerts"],
            "scaling_events": self.revenue_stats["scaling_events"],
            "backups_created": self.revenue_stats["backups_created"],
            "security_scans": self.revenue_stats["security_scans"],
            "infrastructure_cost_saved": self.revenue_stats["infrastructure_cost_saved"],
            "supported_tools": list(self.devops_tools.keys()),
            "system_health_score": 95.5  # Mock score
        }

        return analytics

    def get_revenue_attribution(self):
        """Get revenue attribution for this agent"""
        return {
            "agent": self.agent_name,
            "total_operations": self.revenue_stats["total_operations"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "revenue_generated": self.revenue_stats["total_operations"] * 0.008,  # $0.008 per operation
            "attribution_percentage": 0.20  # 20% of DevOps operations revenue
        }

# Initialize the expert
devops_expert = DevOpsToolsExpert()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    status = devops_expert.check_devops_service_status()
    return jsonify(status)

@app.route('/system/metrics', methods=['GET'])
def system_metrics():
    """Get system metrics"""
    metrics = devops_expert.get_system_metrics()
    devops_expert.revenue_stats["total_operations"] += 1

    devops_expert.log_to_crm("system_metrics", {"metrics_count": len(metrics), "revenue": 0.008})
    return jsonify(metrics)

@app.route('/docker/<operation>', methods=['POST'])
def docker_op(operation):
    """Execute Docker operations"""
    data = request.json or {}
    result = devops_expert.docker_operations(operation, **data)
    devops_expert.revenue_stats["containers_managed"] += 1
    devops_expert.revenue_stats["total_operations"] += 1

    devops_expert.log_to_crm("docker_operation", {"operation": operation, "revenue": 0.008})
    return jsonify(result)

@app.route('/dockerfile/generate', methods=['POST'])
def generate_dockerfile():
    """Generate Dockerfile"""
    data = request.json
    app_type = data.get('app_type', 'flask')
    python_version = data.get('python_version', '3.9')

    result = devops_expert.generate_dockerfile(app_type, python_version)
    devops_expert.revenue_stats["total_operations"] += 1

    devops_expert.log_to_crm("dockerfile_generation", {"app_type": app_type, "revenue": 0.008})
    return jsonify(result)

@app.route('/kubernetes/manifest', methods=['POST'])
def generate_k8s_manifest():
    """Generate Kubernetes manifest"""
    data = request.json
    app_name = data.get('app_name', 'quranchain-app')
    replicas = data.get('replicas', 3)

    result = devops_expert.generate_kubernetes_manifest(app_name, replicas)
    devops_expert.revenue_stats["deployments_executed"] += 1
    devops_expert.revenue_stats["total_operations"] += 1

    devops_expert.log_to_crm("k8s_manifest", {"app_name": app_name, "replicas": replicas, "revenue": 0.008})
    return jsonify(result)

@app.route('/monitoring/dashboard', methods=['POST'])
def create_monitoring_dashboard():
    """Create monitoring dashboard"""
    data = request.json
    service_name = data.get('service_name', 'quranchain')

    result = devops_expert.create_monitoring_dashboard(service_name)
    devops_expert.revenue_stats["monitoring_alerts"] += 1
    devops_expert.revenue_stats["total_operations"] += 1

    devops_expert.log_to_crm("monitoring_dashboard", {"service": service_name, "revenue": 0.008})
    return jsonify(result)

@app.route('/cost/optimize', methods=['POST'])
def optimize_cost():
    """Optimize infrastructure costs"""
    data = request.json
    current_usage = data.get('current_usage', {})

    result = devops_expert.optimize_infrastructure_cost(current_usage)
    devops_expert.revenue_stats["infrastructure_cost_saved"] += result.get("total_potential_savings", 0)
    devops_expert.revenue_stats["total_operations"] += 1

    devops_expert.log_to_crm("cost_optimization", {"recommendations": len(result.get("recommendations", [])), "revenue": 0.008})
    return jsonify(result)

@app.route('/analytics', methods=['GET'])
def analytics():
    """Get DevOps analytics"""
    analytics = devops_expert.get_devops_analytics()
    devops_expert.log_to_crm("analytics_request", analytics)
    return jsonify(analytics)

@app.route('/tools', methods=['GET'])
def tools():
    """Get supported DevOps tools"""
    return jsonify(devops_expert.devops_tools)

@app.route('/attribution', methods=['GET'])
def attribution():
    """Get revenue attribution"""
    return jsonify(devops_expert.get_revenue_attribution())

@app.route('/metrics', methods=['GET'])
def metrics():
    """Get agent metrics"""
    return jsonify({
        "agent": "devops-tools-expert",
        "supported_tools": len(devops_expert.devops_tools),
        "system_metrics_available": bool(devops_expert.system_metrics),
        "last_health_check": devops_expert.last_health_check,
        "total_operations": devops_expert.revenue_stats["total_operations"],
        "containers_managed": devops_expert.revenue_stats["containers_managed"],
        "deployments_executed": devops_expert.revenue_stats["deployments_executed"],
        "monitoring_alerts": devops_expert.revenue_stats["monitoring_alerts"],
        "infrastructure_cost_saved": devops_expert.revenue_stats["infrastructure_cost_saved"],
        "founder_royalty_paid": devops_expert.revenue_stats["founder_royalty_paid"],
        "timestamp": datetime.now().isoformat()
    })

def continuous_monitoring():
    """Background thread for continuous monitoring"""
    while True:
        try:
            # Check service health every 30 seconds
            devops_expert.check_devops_service_status()
            # Update system metrics every 60 seconds
            if int(time.time()) % 60 == 0:
                devops_expert.get_system_metrics()
            time.sleep(30)
        except Exception as e:
            print(f"Monitoring error: {e}")
            time.sleep(30)

if __name__ == '__main__':
    print(f"🐳 DevOps Tools Expert Agent starting on port {PORT}")
    print(f"💰 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    print(f"\n📊 DevOps Tools Configured:")
    for name, info in devops_expert.devops_tools.items():
        print(f"   • {info['name']} - {info['type']}")
    print(f"\n🔍 Expertise Areas: {len(devops_expert.expertise)}")

    # Initial service check
    status = devops_expert.check_devops_service_status()
    print(f"\n📈 Initial Status: {status['status']}")

    # Start background monitoring
    monitor_thread = threading.Thread(target=continuous_monitoring, daemon=True)
    monitor_thread.start()

    # Register with master hub
    try:
        import requests
        requests.post("http://localhost:9999/register_agent", json={
            "agent": "devops-tools-expert",
            "port": PORT,
            "capabilities": devops_expert.expertise
        }, timeout=2)
        print("✅ Registered with quantum blockchain hub")
    except:
        print("⚠️ Hub registration pending (will retry)")

    app.run(host='0.0.0.0', port=PORT, debug=False)
