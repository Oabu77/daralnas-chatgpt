#!/usr/bin/env python3
"""
DarPay™ - QuranChain Fiat-to-QURAN Payment Processing System
============================================================
Converts AI agent fiat earnings into QURAN tokens for smart contract payments.

Revenue Flow:
1. AI agents earn fiat (USD, EUR, etc.) from various revenue streams
2. DarPay collects and tracks fiat earnings
3. Fiat is exchanged for QURAN tokens on QuranChain Exchange (QEX)
4. QURAN tokens deposited into AI agent accounts
5. Smart contracts paid using QURAN tokens

© 2026 QuranChain™ - Omar Mohammad Abunadi™
"""

import json
import logging
import sqlite3
import time
import os
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime
from decimal import Decimal
from flask import Flask, jsonify, request
from typing import Dict, List, Optional, Tuple
import requests
from dotenv import load_dotenv

# Load environment variables from .env.darpay
load_dotenv('.env.darpay')

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        PRODUCTS as STRIPE_CATALOG, DARPAY_PRODUCTS, PAYMENT_PRODUCTS,
        TOKEN_PRODUCTS, EXCHANGE_PRODUCTS,
        create_checkout_session, create_payment_link,
        get_products_by_platform, Platform,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

# Configure logging
setup_blockchain_logging()
logger = logging.getLogger('DarPay')

app = Flask(__name__)

# QuranChain Configuration
QUANTUM_HUB_URL = "http://localhost:9999"
QEX_EXCHANGE_URL = os.getenv('QEX_BASE_URL', "http://localhost:8888")
DARPAY_PORT = 9011

# Revenue Distribution (Immutable)
FOUNDER_ROYALTY_RATE = 0.30  # 30% Founder - NEVER MODIFY
REVENUE_DISTRIBUTION = {
    'founder_royalty': 0.30,    # Omar Mohammad Abunadi™
    'ai_validators': 0.40,       # Omar AI™ + QuranChain AI™
    'hardware_hosts': 0.10,      # Network infrastructure providers
    'ecosystem': 0.18,           # Development & growth
    'zakat': 0.02                # Islamic charity obligation
}

class DarPay:
    """
    DarPay™ Payment Processing System
    
    Handles fiat-to-QURAN conversion and smart contract payments for AI agents.
    """
    
    def __init__(self):
        self.port = DARPAY_PORT
        self.name = "DarPay™"
        self.version = "2.0.0"
        self.start_time = datetime.now()
        
        # Bank Account Configuration (loaded from .env.darpay)
        self.bank_accounts = {
            'founder_royalty': {
                'percentage': 0.30,
                'bank_name': os.getenv('FOUNDER_BANK_NAME', 'Not Configured'),
                'account_name': os.getenv('FOUNDER_ACCOUNT_NAME', 'Not Configured'),
                'account_number': os.getenv('FOUNDER_ACCOUNT_NUMBER', 'XXXXXXXXXX'),
                'routing_number': os.getenv('FOUNDER_ROUTING_NUMBER', 'XXXXXXXXX'),
                'account_type': os.getenv('FOUNDER_ACCOUNT_TYPE', 'checking'),
                'swift_code': os.getenv('FOUNDER_SWIFT_CODE', ''),
                'crypto_usdt': os.getenv('FOUNDER_USDT_ADDRESS', ''),
                'crypto_usdc': os.getenv('FOUNDER_USDC_ADDRESS', ''),
                'crypto_btc': os.getenv('FOUNDER_BTC_ADDRESS', ''),
                'crypto_eth': os.getenv('FOUNDER_ETH_ADDRESS', '')
            },
            'ai_validators': {
                'percentage': 0.40,
                'bank_name': os.getenv('AI_VALIDATORS_BANK_NAME', 'Not Configured'),
                'account_name': os.getenv('AI_VALIDATORS_ACCOUNT_NAME', 'Not Configured'),
                'account_number': os.getenv('AI_VALIDATORS_ACCOUNT_NUMBER', 'XXXXXXXXXX'),
                'routing_number': os.getenv('AI_VALIDATORS_ROUTING_NUMBER', 'XXXXXXXXX'),
                'account_type': os.getenv('AI_VALIDATORS_ACCOUNT_TYPE', 'checking')
            },
            'hardware_hosts': {
                'percentage': 0.10,
                'bank_name': os.getenv('HARDWARE_HOSTS_BANK_NAME', 'Not Configured'),
                'account_name': os.getenv('HARDWARE_HOSTS_ACCOUNT_NAME', 'Not Configured'),
                'account_number': os.getenv('HARDWARE_HOSTS_ACCOUNT_NUMBER', 'XXXXXXXXXX'),
                'routing_number': os.getenv('HARDWARE_HOSTS_ROUTING_NUMBER', 'XXXXXXXXX'),
                'account_type': os.getenv('HARDWARE_HOSTS_ACCOUNT_TYPE', 'checking')
            },
            'ecosystem': {
                'percentage': 0.18,
                'bank_name': os.getenv('ECOSYSTEM_BANK_NAME', 'Not Configured'),
                'account_name': os.getenv('ECOSYSTEM_ACCOUNT_NAME', 'Not Configured'),
                'account_number': os.getenv('ECOSYSTEM_ACCOUNT_NUMBER', 'XXXXXXXXXX'),
                'routing_number': os.getenv('ECOSYSTEM_ROUTING_NUMBER', 'XXXXXXXXX'),
                'account_type': os.getenv('ECOSYSTEM_ACCOUNT_TYPE', 'checking')
            },
            'zakat': {
                'percentage': 0.02,
                'bank_name': os.getenv('ZAKAT_BANK_NAME', 'Not Configured'),
                'account_name': os.getenv('ZAKAT_ACCOUNT_NAME', 'Not Configured'),
                'account_number': os.getenv('ZAKAT_ACCOUNT_NUMBER', 'XXXXXXXXXX'),
                'routing_number': os.getenv('ZAKAT_ROUTING_NUMBER', 'XXXXXXXXX'),
                'account_type': os.getenv('ZAKAT_ACCOUNT_TYPE', 'checking')
            }
        }
        
        # Payment processor configuration
        self.payment_processors = {
            'stripe': {
                'enabled': bool(os.getenv('STRIPE_SECRET_KEY')),
                'auto_transfer': os.getenv('ENABLE_BANK_TRANSFERS', 'false').lower() == 'true'
            },
            'paypal': {
                'enabled': bool(os.getenv('PAYPAL_CLIENT_ID')),
                'auto_transfer': os.getenv('ENABLE_BANK_TRANSFERS', 'false').lower() == 'true'
            }
        }
        
        # Security settings
        self.security = {
            'enable_bank_transfers': os.getenv('ENABLE_BANK_TRANSFERS', 'false').lower() == 'true',
            'require_manual_approval': os.getenv('REQUIRE_MANUAL_APPROVAL', 'true').lower() == 'true',
            'large_transfer_threshold': float(os.getenv('LARGE_TRANSFER_THRESHOLD', '10000'))
        }
        
        # Payment systems understanding (no API integration)
        self.payment_systems = {
            'stripe': {
                'name': 'Stripe',
                'currencies': ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD'],
                'methods': ['Credit Cards', 'Debit Cards', 'ACH', 'Apple Pay', 'Google Pay'],
                'fees': '2.9% + $0.30 per transaction',
                'understanding': 'Stripe payment processing knowledge for fiat collection'
            },
            'paypal': {
                'name': 'PayPal',
                'currencies': ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD'],
                'methods': ['PayPal Checkout', 'PayPal Credit', 'Venmo'],
                'fees': '2.9% + $0.30 per transaction',
                'understanding': 'PayPal payment processing knowledge for fiat collection'
            },
            'traditional_banking': {
                'name': 'Traditional Banking',
                'currencies': ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'All fiat currencies'],
                'methods': ['Wire Transfer', 'Bank Transfer', 'ACH', 'SWIFT', 'SEPA'],
                'understanding': 'Banking system knowledge for fiat collection'
            },
            'cryptocurrency': {
                'name': 'Crypto Payments',
                'currencies': ['BTC', 'ETH', 'USDT', 'USDC'],
                'methods': ['Blockchain transfers', 'DeFi protocols'],
                'understanding': 'Crypto payment knowledge for conversion to fiat'
            }
        }
        
        # QuranChain Exchange (QEX) Integration
        self.qex_config = {
            'name': 'QuranChain Exchange',
            'base_url': QEX_EXCHANGE_URL,
            'supported_pairs': [
                'QURAN/USD', 'QURAN/EUR', 'QURAN/GBP',
                'QURAN/BTC', 'QURAN/ETH', 'QURAN/USDT'
            ],
            'min_trade': 0.01,  # Minimum QURAN amount
            'fee_rate': 0.001   # 0.1% exchange fee
        }
        
        # AI Agent Account Management
        self.ai_agent_accounts = {
            'marketing_agent': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'sales_agent': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'onboarding_agent': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'optimization_agent': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'it_ops_agent': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'security_agent': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'orchestrator': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'network_telecom_expert': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'core_services_expert': {'balance_quran': 0.0, 'fiat_earned': 0.0},
            'darpay': {'balance_quran': 0.0, 'fiat_earned': 0.0}
        }
        
        # Expertise areas
        self.expertise = [
            'fiat_currency_management',
            'fiat_to_quran_conversion',
            'exchange_integration',
            'ai_agent_accounting',
            'smart_contract_payments',
            'revenue_distribution',
            'multi_currency_support',
            'transaction_tracking',
            'account_management',
            'payment_reconciliation',
            'exchange_rate_monitoring',
            'automated_conversions',
            'founder_royalty_enforcement',
            'islamic_finance_compliance',
            'quran_token_economics'
        ]
        
        # Transaction tracking
        self.transactions = []
        self.conversion_history = []
        
        # Statistics
        self.stats = {
            'total_fiat_collected': 0.0,
            'total_quran_converted': 0.0,
            'total_contracts_paid': 0,
            'founder_royalty_paid': 0.0,
            'active_agents': len(self.ai_agent_accounts),
            'exchange_rate': self.get_quran_exchange_rate('USD')
        }
        
        # Initialize database
        self.init_database()
        
        # Register with Quantum Hub
        self.register_with_hub()
        
        logger.info(f"✅ {self.name} v{self.version} initialized on port {self.port}")
        logger.info(f"💱 Exchange integration: {self.qex_config['name']}")
        logger.info(f"🤖 Managing {len(self.ai_agent_accounts)} AI agent accounts")
    
    def init_database(self):
        """Initialize DarPay database for transaction tracking."""
        try:
            conn = sqlite3.connect('crm/crm.db')
            cursor = conn.cursor()
            
            # DarPay transactions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS darpay_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    fiat_amount REAL NOT NULL,
                    fiat_currency TEXT NOT NULL,
                    quran_amount REAL NOT NULL,
                    exchange_rate REAL NOT NULL,
                    transaction_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    founder_royalty REAL NOT NULL,
                    notes TEXT
                )
            ''')
            
            # AI agent accounts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS darpay_agent_accounts (
                    agent_id TEXT PRIMARY KEY,
                    balance_quran REAL NOT NULL DEFAULT 0.0,
                    total_fiat_earned REAL NOT NULL DEFAULT 0.0,
                    total_quran_received REAL NOT NULL DEFAULT 0.0,
                    contracts_paid INTEGER NOT NULL DEFAULT 0,
                    last_updated TEXT NOT NULL
                )
            ''')
            
            # Smart contract payments table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS darpay_contract_payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    contract_address TEXT NOT NULL,
                    quran_amount REAL NOT NULL,
                    purpose TEXT NOT NULL,
                    status TEXT NOT NULL
                )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("✅ DarPay database initialized")
        except Exception as e:
            logger.error(f"❌ Database initialization failed: {e}")
    
    def register_with_hub(self):
        """Register DarPay with Quantum Blockchain Hub."""
        try:
            response = requests.post(
                f"{QUANTUM_HUB_URL}/register_service",
                json={
                    'service_name': self.name,
                    'port': self.port,
                    'type': 'payment_processor',
                    'version': self.version,
                    'capabilities': self.expertise
                },
                timeout=5
            )
            if response.status_code == 200:
                logger.info(f"✅ Registered with Quantum Hub: {QUANTUM_HUB_URL}")
            else:
                logger.warning(f"⚠️ Hub registration returned: {response.status_code}")
        except Exception as e:
            logger.warning(f"⚠️ Could not register with Quantum Hub: {e}")
    
    def get_quran_exchange_rate(self, fiat_currency: str = 'USD') -> float:
        """
        Get current QURAN exchange rate from QuranChain Exchange.
        
        Args:
            fiat_currency: Fiat currency code (USD, EUR, etc.)
        
        Returns:
            Exchange rate (fiat per QURAN)
        """
        try:
            # Try to get live rate from QEX
            response = requests.get(
                f"{self.qex_config['base_url']}/rate/QURAN/{fiat_currency}",
                timeout=2
            )
            if response.status_code == 200:
                rate = response.json().get('rate', 1.0)
                logger.info(f"💱 Live rate: 1 QURAN = {rate} {fiat_currency}")
                return float(rate)
        except:
            pass
        
        # Default rates if exchange unavailable
        default_rates = {
            'USD': 1.00,
            'EUR': 0.92,
            'GBP': 0.79,
            'JPY': 149.50,
            'CAD': 1.35,
            'AUD': 1.52
        }
        
        rate = default_rates.get(fiat_currency.upper(), 1.0)
        logger.info(f"💱 Using default rate: 1 QURAN = {rate} {fiat_currency}")
        return rate
    
    def convert_fiat_to_quran(
        self,
        agent_id: str,
        fiat_amount: float,
        fiat_currency: str = 'USD'
    ) -> Dict:
        """
        Convert fiat earnings to QURAN tokens.
        
        Args:
            agent_id: AI agent identifier
            fiat_amount: Amount in fiat currency
            fiat_currency: Currency code
        
        Returns:
            Conversion details including QURAN amount and founder royalty
        """
        try:
            # Get current exchange rate
            exchange_rate = self.get_quran_exchange_rate(fiat_currency)
            
            # Calculate QURAN amount
            quran_amount = fiat_amount / exchange_rate
            
            # Apply exchange fee
            exchange_fee = quran_amount * self.qex_config['fee_rate']
            quran_net = quran_amount - exchange_fee
            
            # Calculate revenue distribution
            distribution = self.calculate_revenue_distribution(fiat_amount)
            
            # Update agent account
            if agent_id in self.ai_agent_accounts:
                self.ai_agent_accounts[agent_id]['balance_quran'] += quran_net
                self.ai_agent_accounts[agent_id]['fiat_earned'] += fiat_amount
            
            # Record transaction
            transaction = {
                'timestamp': datetime.now().isoformat(),
                'agent_id': agent_id,
                'fiat_amount': fiat_amount,
                'fiat_currency': fiat_currency,
                'quran_gross': quran_amount,
                'exchange_fee': exchange_fee,
                'quran_net': quran_net,
                'exchange_rate': exchange_rate,
                'distribution': distribution,
                'status': 'completed'
            }
            
            self.transactions.append(transaction)
            self.conversion_history.append(transaction)
            
            # Update statistics
            self.stats['total_fiat_collected'] += fiat_amount
            self.stats['total_quran_converted'] += quran_net
            self.stats['founder_royalty_paid'] += distribution['founder_royalty']
            
            # Save to database
            self.save_transaction_to_db(transaction)
            
            logger.info(f"💱 Converted {fiat_amount} {fiat_currency} → {quran_net:.6f} QURAN for {agent_id}")
            
            return {
                'success': True,
                'transaction': transaction,
                'agent_balance': self.ai_agent_accounts[agent_id]['balance_quran']
            }
            
        except Exception as e:
            logger.error(f"❌ Conversion failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def pay_smart_contract(
        self,
        agent_id: str,
        contract_address: str,
        quran_amount: float,
        purpose: str
    ) -> Dict:
        """
        Pay smart contract using QURAN tokens from agent account.
        
        Args:
            agent_id: AI agent making payment
            contract_address: Smart contract address
            quran_amount: Amount in QURAN tokens
            purpose: Payment description
        
        Returns:
            Payment confirmation
        """
        try:
            # Check agent balance
            if agent_id not in self.ai_agent_accounts:
                return {'success': False, 'error': 'Agent not found'}
            
            account = self.ai_agent_accounts[agent_id]
            if account['balance_quran'] < quran_amount:
                return {
                    'success': False,
                    'error': f'Insufficient balance. Has {account["balance_quran"]:.6f} QURAN, needs {quran_amount:.6f}'
                }
            
            # Deduct from agent balance
            account['balance_quran'] -= quran_amount
            
            # Record payment
            payment = {
                'timestamp': datetime.now().isoformat(),
                'agent_id': agent_id,
                'contract_address': contract_address,
                'quran_amount': quran_amount,
                'purpose': purpose,
                'status': 'completed',
                'remaining_balance': account['balance_quran']
            }
            
            # Update stats
            self.stats['total_contracts_paid'] += 1
            
            # Save to database
            self.save_contract_payment_to_db(payment)
            
            logger.info(f"✅ {agent_id} paid {quran_amount:.6f} QURAN to contract {contract_address[:10]}...")
            
            return {'success': True, 'payment': payment}
            
        except Exception as e:
            logger.error(f"❌ Contract payment failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def calculate_revenue_distribution(self, amount: float) -> Dict:
        """
        Calculate revenue distribution according to QuranChain model.
        
        30% Founder Royalty (IMMUTABLE)
        40% AI Validators (Omar AI™ + QuranChain AI™)
        10% Hardware Hosts
        18% Ecosystem Development
        2% Zakat (Islamic Charity)
        """
        distribution = {
            'founder_royalty': amount * REVENUE_DISTRIBUTION['founder_royalty'],
            'ai_validators': amount * REVENUE_DISTRIBUTION['ai_validators'],
            'hardware_hosts': amount * REVENUE_DISTRIBUTION['hardware_hosts'],
            'ecosystem': amount * REVENUE_DISTRIBUTION['ecosystem'],
            'zakat': amount * REVENUE_DISTRIBUTION['zakat']
        }
        
        # Verify total matches input
        total = sum(distribution.values())
        
        return {
            **distribution,
            'total': total,
            'matches_input': abs(total - amount) < 0.01,
            'founder_royalty_protected': distribution['founder_royalty'] == amount * FOUNDER_ROYALTY_RATE
        }
    
    def save_transaction_to_db(self, transaction: Dict):
        """Save conversion transaction to database."""
        try:
            conn = sqlite3.connect('crm/crm.db')
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO darpay_transactions (
                    timestamp, agent_id, fiat_amount, fiat_currency,
                    quran_amount, exchange_rate, transaction_type,
                    status, founder_royalty, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                transaction['timestamp'],
                transaction['agent_id'],
                transaction['fiat_amount'],
                transaction['fiat_currency'],
                transaction['quran_net'],
                transaction['exchange_rate'],
                'fiat_to_quran',
                transaction['status'],
                transaction['distribution']['founder_royalty'],
                f"Exchange fee: {transaction['exchange_fee']:.6f} QURAN"
            ))
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"❌ Failed to save transaction: {e}")
    
    def save_contract_payment_to_db(self, payment: Dict):
        """Save smart contract payment to database."""
        try:
            conn = sqlite3.connect('crm/crm.db')
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO darpay_contract_payments (
                    timestamp, agent_id, contract_address,
                    quran_amount, purpose, status
                ) VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                payment['timestamp'],
                payment['agent_id'],
                payment['contract_address'],
                payment['quran_amount'],
                payment['purpose'],
                payment['status']
            ))
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"❌ Failed to save contract payment: {e}")
    
    def get_agent_account(self, agent_id: str) -> Dict:
        """Get AI agent account details."""
        if agent_id in self.ai_agent_accounts:
            return {
                'agent_id': agent_id,
                **self.ai_agent_accounts[agent_id],
                'exchange_rate': self.get_quran_exchange_rate('USD')
            }
        return {'error': 'Agent not found'}
    
    def get_all_accounts(self) -> Dict:
        """Get all AI agent accounts."""
        return {
            'accounts': self.ai_agent_accounts,
            'total_agents': len(self.ai_agent_accounts),
            'total_balance': sum(acc['balance_quran'] for acc in self.ai_agent_accounts.values()),
            'total_fiat_earned': sum(acc['fiat_earned'] for acc in self.ai_agent_accounts.values())
        }


# Global instance
darpay = DarPay()


# ============================================================================
# Flask API Endpoints
# ============================================================================

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'service': darpay.name,
        'version': darpay.version,
        'port': darpay.port,
        'uptime': str(datetime.now() - darpay.start_time),
        'expertise': darpay.expertise,
        'payment_systems': len(darpay.payment_systems),
        'ai_agents': len(darpay.ai_agent_accounts)
    })

@app.route('/systems', methods=['GET'])
def get_payment_systems():
    """Get payment system knowledge base."""
    return jsonify({
        'payment_systems': darpay.payment_systems,
        'note': 'DarPay understands these systems but converts all fiat to QURAN tokens'
    })

@app.route('/exchange/rate', methods=['GET'])
def get_exchange_rate():
    """Get current QURAN exchange rate."""
    currency = request.args.get('currency', 'USD')
    rate = darpay.get_quran_exchange_rate(currency)
    
    return jsonify({
        'pair': f'QURAN/{currency}',
        'rate': rate,
        'description': f'1 QURAN = {rate} {currency}',
        'exchange': darpay.qex_config['name'],
        'supported_pairs': darpay.qex_config['supported_pairs']
    })

@app.route('/convert', methods=['POST'])
def convert_fiat():
    """Convert fiat to QURAN tokens."""
    data = request.json
    
    agent_id = data.get('agent_id')
    fiat_amount = float(data.get('fiat_amount', 0))
    fiat_currency = data.get('fiat_currency', 'USD')
    
    result = darpay.convert_fiat_to_quran(agent_id, fiat_amount, fiat_currency)
    return jsonify(result)

@app.route('/pay/contract', methods=['POST'])
def pay_contract():
    """Pay smart contract using QURAN tokens."""
    data = request.json
    
    agent_id = data.get('agent_id')
    contract_address = data.get('contract_address')
    quran_amount = float(data.get('quran_amount', 0))
    purpose = data.get('purpose', 'Smart contract payment')
    
    result = darpay.pay_smart_contract(agent_id, contract_address, quran_amount, purpose)
    return jsonify(result)

@app.route('/account/<agent_id>', methods=['GET'])
def get_account(agent_id):
    """Get AI agent account details."""
    account = darpay.get_agent_account(agent_id)
    return jsonify(account)

@app.route('/accounts', methods=['GET'])
def get_accounts():
    """Get all AI agent accounts."""
    accounts = darpay.get_all_accounts()
    return jsonify(accounts)

@app.route('/transactions', methods=['GET'])
def get_transactions():
    """Get transaction history."""
    limit = int(request.args.get('limit', 100))
    
    return jsonify({
        'transactions': darpay.transactions[-limit:],
        'total': len(darpay.transactions),
        'conversions': len(darpay.conversion_history)
    })

@app.route('/stats', methods=['GET'])
def get_stats():
    """Get DarPay statistics."""
    return jsonify({
        'statistics': darpay.stats,
        'revenue_distribution': REVENUE_DISTRIBUTION,
        'founder_royalty_rate': FOUNDER_ROYALTY_RATE,
        'exchange_config': darpay.qex_config
    })

@app.route('/revenue/distribution', methods=['POST'])
def calculate_distribution():
    """Calculate revenue distribution for an amount."""
    data = request.json
    amount = float(data.get('amount', 0))
    
    distribution = darpay.calculate_revenue_distribution(amount)
    return jsonify(distribution)

@app.route('/bank/accounts', methods=['GET'])
def get_bank_accounts():
    """Get configured bank accounts (masked for security)."""
    masked_accounts = {}
    
    for account_type, details in darpay.bank_accounts.items():
        # Mask sensitive information
        masked_accounts[account_type] = {
            'percentage': details['percentage'],
            'bank_name': details['bank_name'],
            'account_name': details['account_name'],
            'account_number': '****' + details['account_number'][-4:] if len(details['account_number']) > 4 else '****',
            'routing_number': '****' + details['routing_number'][-4:] if len(details['routing_number']) > 4 else '****',
            'account_type': details['account_type'],
            'configured': details['account_number'] != 'XXXXXXXXXX'
        }
        
        # Add crypto addresses if present
        if 'crypto_usdt' in details and details['crypto_usdt']:
            masked_accounts[account_type]['crypto_usdt'] = details['crypto_usdt']
            masked_accounts[account_type]['crypto_usdc'] = details.get('crypto_usdc', '')
    
    return jsonify({
        'bank_accounts': masked_accounts,
        'security_enabled': darpay.security['enable_bank_transfers'],
        'manual_approval_required': darpay.security['require_manual_approval']
    })

@app.route('/withdrawal/instructions', methods=['GET'])
def get_withdrawal_instructions():
    """Generate withdrawal instructions for pending fiat earnings."""
    stats = darpay.stats
    
    if stats['total_fiat_collected'] == 0:
        return jsonify({
            'message': 'No fiat earnings to withdraw',
            'total_pending': 0
        })
    
    # Calculate distributions
    total = stats['total_fiat_collected']
    instructions = []
    
    for account_type, details in darpay.bank_accounts.items():
        amount = total * details['percentage']
        
        if amount > 0:
            instruction = {
                'recipient': account_type.replace('_', ' ').title(),
                'amount': f"${amount:,.2f}",
                'percentage': f"{details['percentage']*100}%",
                'bank_name': details['bank_name'],
                'account_name': details['account_name'],
                'account_number': details['account_number'],
                'routing_number': details['routing_number'],
                'account_type': details['account_type'],
                'configured': details['account_number'] != 'XXXXXXXXXX'
            }
            
            # Add crypto alternative if available
            if 'crypto_usdt' in details and details['crypto_usdt']:
                instruction['crypto_alternative'] = {
                    'usdt_address': details['crypto_usdt'],
                    'usdc_address': details.get('crypto_usdc', ''),
                    'note': 'Convert to stablecoin and send to this address'
                }
            
            instructions.append(instruction)
    
    return jsonify({
        'total_pending': f"${total:,.2f}",
        'distribution_count': len(instructions),
        'instructions': instructions,
        'note': 'These are withdrawal instructions. Execute transfers manually or configure auto-transfer.'
    })

@app.route('/deposit/record', methods=['POST'])
def record_deposit():
    """Record a fiat deposit that was made to bank account."""
    data = request.json
    
    account_type = data.get('account_type')  # founder_royalty, ai_validators, etc.
    amount = float(data.get('amount', 0))
    currency = data.get('currency', 'USD')
    transaction_id = data.get('transaction_id', '')
    notes = data.get('notes', '')
    
    # Save deposit record to database
    try:
        conn = sqlite3.connect('crm/crm.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS darpay_deposits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                account_type TEXT NOT NULL,
                amount REAL NOT NULL,
                currency TEXT NOT NULL,
                transaction_id TEXT,
                notes TEXT,
                status TEXT DEFAULT 'completed'
            )
        ''')
        
        cursor.execute('''
            INSERT INTO darpay_deposits (
                timestamp, account_type, amount, currency,
                transaction_id, notes
            ) VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            datetime.now().isoformat(),
            account_type,
            amount,
            currency,
            transaction_id,
            notes
        ))
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Recorded deposit: ${amount} {currency} to {account_type}")
        
        return jsonify({
            'success': True,
            'message': f'Deposit of ${amount} {currency} recorded for {account_type}',
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"❌ Failed to record deposit: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


if __name__ == '__main__':
    logger.info(f"🚀 Starting {darpay.name} v{darpay.version} on port {darpay.port}")
    logger.info(f"💱 Fiat → QURAN conversion engine ready")
    logger.info(f"🤖 Managing {len(darpay.ai_agent_accounts)} AI agent accounts")
    logger.info(f"💰 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    logger.info(f"🏦 Bank accounts configured: {sum(1 for acc in darpay.bank_accounts.values() if acc['account_number'] != 'XXXXXXXXXX')}/5")
    
    app.run(host='0.0.0.0', port=darpay.port, debug=False)
