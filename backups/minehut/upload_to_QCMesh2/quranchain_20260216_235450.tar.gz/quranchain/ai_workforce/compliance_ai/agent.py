import os
import json
import sqlite3
import time
from flask import Flask, jsonify, request

AGENT_NAME = "compliance_ai"
PORT = int(os.environ.get("COMPLIANCE_AI_PORT", "9010"))
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOG_DIR = os.path.join(REPO_ROOT, "logs", "ai_workforce")
CRM_DB = os.path.join(REPO_ROOT, "crm", "crm.db")
LOG_FILE = os.path.join(LOG_DIR, f"{AGENT_NAME}.log")

os.makedirs(LOG_DIR, exist_ok=True)

app = Flask("compliance_ai")

_state = {
    "tasks_received": 0,
    "tasks_success": 0,
    "tasks_failed": 0,
    "last_task_id": None,
}


def log(msg: str):
    stamp = time.strftime('%Y-%m-%d %H:%M:%S')
    with open(LOG_FILE, 'a') as f:
        f.write(f"[{stamp}] {msg}\n")


def record_performance(task_id: str, source: str, status: str):
    try:
        conn = sqlite3.connect(CRM_DB)
        cur = conn.cursor()
        cur.execute("""
        INSERT INTO ai_agent_performance (agent_name, task_id, source, status, timestamp)
        VALUES (?, ?, ?, ?, ?)
        """, (AGENT_NAME, task_id, source, status, int(time.time())))
        conn.commit()
        conn.close()
    except Exception as e:
        log(f"CRM performance insert failed: {e}")


def ensure_tables():
    try:
        conn = sqlite3.connect(CRM_DB)
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS compliance_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                merchant_id TEXT,
                result TEXT,
                reasons TEXT,
                timestamp INTEGER
            )
            """
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log(f"Ensure tables failed: {e}")


def handle_policy_or_kyc(task_id: str, source: str, payload: dict) -> dict:
    merchant_id = str(payload.get('merchant_id') or '')
    documents_ok = bool(payload.get('documents_ok') or False)
    email = str(payload.get('email') or '')
    reasons = []

    if not merchant_id:
        reasons.append('missing_merchant_id')
    if not documents_ok:
        reasons.append('documents_incomplete')
    if email and email.split('@')[-1].lower() in {'tempmail.com','example.com'}:
        reasons.append('email_domain_flagged')

    result = 'approved' if not reasons else 'manual_review'

    try:
        conn = sqlite3.connect(CRM_DB)
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO compliance_events (merchant_id, result, reasons, timestamp) VALUES (?, ?, ?, ?)",
            (merchant_id, result, json.dumps(reasons), int(time.time()))
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log(f"Insert compliance event failed: {e}")

    record_performance(task_id, source, result)
    return {"status": result, "task_id": task_id, "reasons": reasons}


@app.get('/health')
def health():
    return jsonify({
        "agent_id": f"{AGENT_NAME}_{int(time.time())}",
        "agent_type": AGENT_NAME,
        "status": "healthy"
    })


@app.get('/metrics')
def metrics():
    return jsonify({
        "tasks_received": _state["tasks_received"],
        "tasks_success": _state["tasks_success"],
        "tasks_failed": _state["tasks_failed"],
        "last_task_id": _state["last_task_id"],
    })


@app.get('/revenue')
def revenue():
    # Real revenue reporting from CRM database
    try:
        conn = sqlite3.connect(CRM_DB)
        cur = conn.cursor()
        cur.execute("SELECT SUM(amount_usd) FROM trading_trades WHERE status = 'completed'")
        result = cur.fetchone()
        revenue_usd = result[0] if result[0] else 0.0
        conn.close()
    except Exception as e:
        log(f"Revenue calculation error: {e}")
        revenue_usd = 0.0
    founder_share_usd = round(revenue_usd * 0.30, 2)
    return jsonify({
        "revenue_usd": revenue_usd,
        "founder_share_usd": founder_share_usd,
        "agent": AGENT_NAME
    })


@app.post('/tasks')
def tasks():
    payload = request.get_json(force=True, silent=True) or {}
    task_id = str(payload.get('task_id') or f"task_{int(time.time())}")
    source = payload.get('source') or 'unknown'
    _state["tasks_received"] += 1
    _state["last_task_id"] = task_id
    try:
        task_type = str(payload.get('type') or '')
        ensure_tables()
        if task_type in {'policy_check','kyc_check','kyb_check'}:
            result = handle_policy_or_kyc(task_id, source, payload.get('payload') or {})
        else:
            result = {"status": "unknown_task", "task_id": task_id, "type": task_type}
        _state["tasks_success"] += 1
        log(f"Processed task {task_id} from {source}: {result['status']}")
        return jsonify(result)
    except Exception as e:
        _state["tasks_failed"] += 1
        record_performance(task_id, source, 'failed')
        log(f"Task {task_id} failed: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500


if __name__ == '__main__':
    ensure_tables()
    log("Starting Compliance AI service")
    app.run(host='0.0.0.0', port=PORT)
