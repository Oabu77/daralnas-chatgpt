import os
import json
import sqlite3
import time
from flask import Flask, jsonify, request

AGENT_NAME = "fraud_ai"
PORT = int(os.environ.get("FRAUD_AI_PORT", "9011"))
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOG_DIR = os.path.join(REPO_ROOT, "logs", "ai_workforce")
CRM_DB = os.path.join(REPO_ROOT, "crm", "crm.db")
LOG_FILE = os.path.join(LOG_DIR, f"{AGENT_NAME}.log")
PAYMENT_DB = os.path.join(REPO_ROOT, "payment_transactions.db")

os.makedirs(LOG_DIR, exist_ok=True)

app = Flask("fraud_ai")

_state = {
    "tasks_received": 0,
    "tasks_success": 0,
    "tasks_failed": 0,
    "last_task_id": None,
}


def log(msg: str):
    stamp = time.strftime('%Y-%m-%d %H:%M:%S')
    with open(LOG_FILE, 'a') as f:
        f.write(f"[{stamp}] {msg}\n")


def record_performance(task_id: str, source: str, status: str):
    try:
        conn = sqlite3.connect(CRM_DB)
        cur = conn.cursor()
        cur.execute("""
        INSERT INTO ai_agent_performance (agent_name, task_id, source, status, timestamp)
        VALUES (?, ?, ?, ?, ?)
        """, (AGENT_NAME, task_id, source, status, int(time.time())))
        conn.commit()
        conn.close()
    except Exception as e:
        log(f"CRM performance insert failed: {e}")


def ensure_tables():
    try:
        conn = sqlite3.connect(PAYMENT_DB)
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS fraud_assessments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tx_id TEXT,
                risk_score REAL,
                flags TEXT,
                timestamp INTEGER
            )
            """
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log(f"Ensure tables failed: {e}")


def compute_risk(payload: dict) -> (float, list):
    amount = float(payload.get('amount') or 0.0)
    country = str(payload.get('country') or '').upper()
    method = str(payload.get('method') or '').lower()
    flags = []
    score = 10.0
    if amount > 1000:
        score += 25.0; flags.append('high_amount')
    if country in {'NG','RU','UA','CN'}:
        score += 20.0; flags.append('geo_risk')
    if method in {'crypto','wire'}:
        score += 15.0; flags.append('method_risk')
    return min(score, 100.0), flags


@app.get('/health')
def health():
    return jsonify({
        "agent_id": f"{AGENT_NAME}_{int(time.time())}",
        "agent_type": AGENT_NAME,
        "status": "healthy"
    })


@app.get('/metrics')
def metrics():
    return jsonify({
        "tasks_received": _state["tasks_received"],
        "tasks_success": _state["tasks_success"],
        "tasks_failed": _state["tasks_failed"],
        "last_task_id": _state["last_task_id"],
    })


@app.get('/revenue')
def revenue():
    revenue_usd = 0.0
    founder_share_usd = round(revenue_usd * 0.30, 2)
    return jsonify({
        "revenue_usd": revenue_usd,
        "founder_share_usd": founder_share_usd,
        "agent": AGENT_NAME
    })


@app.post('/tasks')
def tasks():
    payload = request.get_json(force=True, silent=True) or {}
    task_id = str(payload.get('task_id') or f"task_{int(time.time())}")
    source = payload.get('source') or 'unknown'
    _state["tasks_received"] += 1
    _state["last_task_id"] = task_id
    try:
        task_type = str(payload.get('type') or '')
        ensure_tables()
        if task_type == 'risk_score':
            inner = payload.get('payload') or {}
            tx_id = str(inner.get('tx_id') or '')
            risk, flags = compute_risk(inner)
            try:
                conn = sqlite3.connect(PAYMENT_DB)
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO fraud_assessments (tx_id, risk_score, flags, timestamp) VALUES (?, ?, ?, ?)",
                    (tx_id, risk, json.dumps(flags), int(time.time()))
                )
                conn.commit()
                conn.close()
            except Exception as e:
                log(f"Insert fraud assessment failed: {e}")
            status = 'review' if risk >= 50 else 'clear'
            record_performance(task_id, source, status)
            result = {"status": status, "task_id": task_id, "risk_score": risk, "flags": flags, "tx_id": tx_id}
        else:
            result = {"status": "unknown_task", "task_id": task_id, "type": task_type}
        _state["tasks_success"] += 1
        log(f"Processed task {task_id} from {source}: {result['status']}")
        return jsonify(result)
    except Exception as e:
        _state["tasks_failed"] += 1
        record_performance(task_id, source, 'failed')
        log(f"Task {task_id} failed: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500


if __name__ == '__main__':
    ensure_tables()
    log("Starting Fraud AI service")
    app.run(host='0.0.0.0', port=PORT)
