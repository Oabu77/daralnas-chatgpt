#!/usr/bin/env python3
"""
🤖🎯 AI AGENT ORCHESTRATOR - COORDINATION & COLLABORATION SPECIALIST
═══════════════════════════════════════════════════════════════════════════════
Central AI agent for coordinating, monitoring, and optimizing the QuranChain
AI workforce. Manages inter-agent communication, task delegation, performance
analytics, and collaborative problem-solving across all specialized agents.

Capabilities:
  🤖 Agent Coordination & Task Delegation
  📊 Performance Monitoring & Analytics
  🔄 Workflow Orchestration & Automation
  💬 Inter-Agent Communication
  📈 Resource Optimization & Load Balancing
  🚨 Conflict Resolution & Error Handling
  📋 Compliance & Audit Trail Management
  🎯 Goal Achievement Tracking

Author: QuranChain AI Agent Team
Date: 2026-01-15
"""

# Add project root to path FIRST
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio
import json
import logging
import threading
import time
import uuid
import hashlib
import queue

from blockchain_logging_handler import setup_blockchain_logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Any, Optional, Set, Tuple

# Import QuranChain dependencies
try:
    from cosmos_blockchain_integration import cosmos_blockchain_client, COSMOS_CONFIG
    COSMOS_ENABLED = True
except ImportError:
    COSMOS_ENABLED = False
    cosmos_blockchain_client = None

# Import specialized agents
try:
    from fungi_mesh_agent import fungi_mesh_agent
    FUNGI_MESH_AVAILABLE = True
except ImportError:
    FUNGI_MESH_AVAILABLE = False
    fungi_mesh_agent = None

try:
    from meshtalk_os_agent import meshtalk_os_agent
    MESHTALK_OS_AVAILABLE = True
except ImportError:
    MESHTALK_OS_AVAILABLE = False
    meshtalk_os_agent = None

try:
    from meshtalk_telecom_ai_agent import meshtalk_telecom_ai_agent
    MESHTALK_TELECOM_AI_AVAILABLE = True
except ImportError:
    MESHTALK_TELECOM_AI_AVAILABLE = False
    meshtalk_telecom_ai_agent = None

try:
    from docker_container_agent import docker_container_agent
    DOCKER_CONTAINER_AVAILABLE = True
except ImportError:
    DOCKER_CONTAINER_AVAILABLE = False
    docker_container_agent = None

try:
    from auto_launch_deploy_agent import auto_launch_deploy_agent
    AUTO_LAUNCH_DEPLOY_AVAILABLE = True
except ImportError:
    AUTO_LAUNCH_DEPLOY_AVAILABLE = False
    auto_launch_deploy_agent = None

try:
    from dedicated_server_agent import dedicated_server_agent
    DEDICATED_SERVER_AVAILABLE = True
except ImportError:
    DEDICATED_SERVER_AVAILABLE = False
    dedicated_server_agent = None

try:
    from database_expert import database_expert
    DATABASE_EXPERT_AVAILABLE = True
except ImportError:
    DATABASE_EXPERT_AVAILABLE = False
    database_expert = None

try:
    from web_api_tools_expert import web_api_tools_expert
    WEB_API_TOOLS_AVAILABLE = True
except ImportError:
    WEB_API_TOOLS_AVAILABLE = False
    web_api_tools_expert = None

try:
    from data_science_ml_tools_expert import data_science_ml_tools_expert
    DATA_SCIENCE_ML_AVAILABLE = True
except ImportError:
    DATA_SCIENCE_ML_AVAILABLE = False
    data_science_ml_tools_expert = None

try:
    from blockchain_tools_expert import blockchain_tools_expert
    BLOCKCHAIN_TOOLS_AVAILABLE = True
except ImportError:
    BLOCKCHAIN_TOOLS_AVAILABLE = False
    blockchain_tools_expert = None

try:
    from devops_tools_expert import devops_tools_expert
    DEVOPS_TOOLS_AVAILABLE = True
except ImportError:
    DEVOPS_TOOLS_AVAILABLE = False
    devops_tools_expert = None

try:
    from security_tools_expert import security_tools_expert
    SECURITY_TOOLS_AVAILABLE = True
except ImportError:
    SECURITY_TOOLS_AVAILABLE = False
    security_tools_expert = None

try:
    from payment_tools_expert import payment_tools_expert
    PAYMENT_TOOLS_AVAILABLE = True
except ImportError:
    PAYMENT_TOOLS_AVAILABLE = False
    payment_tools_expert = None

try:
    from ai_ml_tools_expert import ai_ml_tools_expert
    AI_ML_TOOLS_AVAILABLE = True
except ImportError:
    AI_ML_TOOLS_AVAILABLE = False
    ai_ml_tools_expert = None

try:
    from idl_tools_expert import idl_tools_expert
    IDL_TOOLS_AVAILABLE = True
except ImportError:
    IDL_TOOLS_AVAILABLE = False
    idl_tools_expert = None

try:
    from system_tools_expert import system_tools_expert
    SYSTEM_TOOLS_AVAILABLE = True
except ImportError:
    SYSTEM_TOOLS_AVAILABLE = False
    system_tools_expert = None

# Gas Toll Agent Imports
try:
    from gas_toll_agents.ethereum_gas_toll_agent import EthereumGasTollAgent
    ETHEREUM_GAS_TOLL_AVAILABLE = True
except ImportError:
    ETHEREUM_GAS_TOLL_AVAILABLE = False
    EthereumGasTollAgent = None

try:
    from gas_toll_agents.polygon_gas_toll_agent import PolygonGasTollAgent
    POLYGON_GAS_TOLL_AVAILABLE = True
except ImportError:
    POLYGON_GAS_TOLL_AVAILABLE = False
    PolygonGasTollAgent = None

try:
    from gas_toll_agents.arbitrum_gas_toll_agent import ArbitrumGasTollAgent
    ARBITRUM_GAS_TOLL_AVAILABLE = True
except ImportError:
    ARBITRUM_GAS_TOLL_AVAILABLE = False
    ArbitrumGasTollAgent = None

try:
    from gas_toll_agents.bsc_gas_toll_agent import BSCGasTollAgent
    BSC_GAS_TOLL_AVAILABLE = True
except ImportError:
    BSC_GAS_TOLL_AVAILABLE = False
    BSCGasTollAgent = None

try:
    from gas_toll_agents.avalanche_gas_toll_agent import AvalancheGasTollAgent
    AVALANCHE_GAS_TOLL_AVAILABLE = True
except ImportError:
    AVALANCHE_GAS_TOLL_AVAILABLE = False
    AvalancheGasTollAgent = None

try:
    from gas_toll_agents.solana_gas_toll_agent import SolanaGasTollAgent
    SOLANA_GAS_TOLL_AVAILABLE = True
except ImportError:
    SOLANA_GAS_TOLL_AVAILABLE = False
    SolanaGasTollAgent = None

try:
    from gas_toll_agents.defi_gas_toll_agent import DeFiGasTollAgent
    DEFI_GAS_TOLL_AVAILABLE = True
except ImportError:
    DEFI_GAS_TOLL_AVAILABLE = False
    DeFiGasTollAgent = None

try:
    from gas_toll_agents.nft_gas_toll_agent import NFTGasTollAgent
    NFT_GAS_TOLL_AVAILABLE = True
except ImportError:
    NFT_GAS_TOLL_AVAILABLE = False
    NFTGasTollAgent = None

try:
    from gas_toll_agents.bridge_gas_toll_agent import BridgeGasTollAgent
    BRIDGE_GAS_TOLL_AVAILABLE = True
except ImportError:
    BRIDGE_GAS_TOLL_AVAILABLE = False
    BridgeGasTollAgent = None

try:
    from gas_toll_agents.staking_gas_toll_agent import StakingGasTollAgent
    STAKING_GAS_TOLL_AVAILABLE = True
except ImportError:
    STAKING_GAS_TOLL_AVAILABLE = False
    StakingGasTollAgent = None

try:
    from gas_toll_agents.governance_gas_toll_agent import GovernanceGasTollAgent
    GOVERNANCE_GAS_TOLL_AVAILABLE = True
except ImportError:
    GOVERNANCE_GAS_TOLL_AVAILABLE = False
    GovernanceGasTollAgent = None

try:
    from gas_toll_agents.dynamic_pricing_gas_toll_agent import DynamicPricingGasTollAgent
    DYNAMIC_PRICING_GAS_TOLL_AVAILABLE = True
except ImportError:
    DYNAMIC_PRICING_GAS_TOLL_AVAILABLE = False
    DynamicPricingGasTollAgent = None

try:
    from gas_toll_agents.fraud_detection_gas_toll_agent import FraudDetectionGasTollAgent
    FRAUD_DETECTION_GAS_TOLL_AVAILABLE = True
except ImportError:
    FRAUD_DETECTION_GAS_TOLL_AVAILABLE = False
    FraudDetectionGasTollAgent = None

try:
    from gas_toll_agents.revenue_optimization_gas_toll_agent import RevenueOptimizationGasTollAgent
    REVENUE_OPTIMIZATION_GAS_TOLL_AVAILABLE = True
except ImportError:
    REVENUE_OPTIMIZATION_GAS_TOLL_AVAILABLE = False
    RevenueOptimizationGasTollAgent = None

try:
    from gas_toll_agents.network_congestion_gas_toll_agent import NetworkCongestionGasTollAgent
    NETWORK_CONGESTION_GAS_TOLL_AVAILABLE = True
except ImportError:
    NETWORK_CONGESTION_GAS_TOLL_AVAILABLE = False
    NetworkCongestionGasTollAgent = None

try:
    from api_error_manager_agent import api_error_manager
    API_ERROR_MANAGER_AVAILABLE = True
except ImportError:
    API_ERROR_MANAGER_AVAILABLE = False
    api_error_manager = None

# Configure logging
setup_blockchain_logging()
logger = logging.getLogger(__name__)

class AgentStatus(Enum):
    """Enumeration of agent states"""
    ONLINE = "online"
    OFFLINE = "offline"
    BUSY = "busy"
    MAINTENANCE = "maintenance"
    ERROR = "error"

class TaskStatus(Enum):
    """Enumeration of task states"""
    PENDING = "pending"
    ASSIGNED = "assigned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    """Enumeration of task priorities"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class AgentInfo:
    """Information about a specialized agent"""
    agent_id: str
    name: str
    capabilities: Set[str]
    status: AgentStatus
    last_heartbeat: datetime
    performance_score: float = 100.0
    active_tasks: int = 0
    total_tasks_completed: int = 0
    error_count: int = 0

@dataclass
class Task:
    """Task information"""
    task_id: str
    description: str
    priority: TaskPriority
    required_capabilities: Set[str]
    assigned_agent: Optional[str] = None
    status: TaskStatus = TaskStatus.PENDING
    created_time: datetime = field(default_factory=datetime.now)
    assigned_time: Optional[datetime] = None
    completed_time: Optional[datetime] = None
    result: Optional[Any] = None
    error_message: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)

@dataclass
class Workflow:
    """Workflow definition"""
    workflow_id: str
    name: str
    description: str
    tasks: List[Task]
    status: TaskStatus = TaskStatus.PENDING
    created_time: datetime = field(default_factory=datetime.now)
    completed_time: Optional[datetime] = None

class AIAgentOrchestrator:
    """
    AI Agent Orchestrator - Central coordination and management system
    """

    def __init__(self):
        self.orchestrator_id = str(uuid.uuid4())
        self.agents: Dict[str, AgentInfo] = {}
        self.tasks: Dict[str, Task] = {}
        self.workflows: Dict[str, Workflow] = {}
        self.task_queue = queue.Queue()
        self.message_queue = queue.Queue()
        self.orchestration_active = False
        self.orchestration_thread: Optional[threading.Thread] = None

        # Initialize specialized agents
        self._initialize_agents()

        # Performance metrics
        self.performance_metrics = {
            "tasks_completed": 0,
            "tasks_failed": 0,
            "average_completion_time": 0.0,
            "agent_utilization": {},
            "workflow_success_rate": 0.0
        }

        logger.info(f"🤖 AI Agent Orchestrator initialized with {len(self.agents)} agents")

    def _initialize_agents(self):
        """Initialize all specialized agents"""
        agent_configs = [
            {
                "agent_id": "fungi_mesh_agent",
                "name": "Fungi Mesh Agent",
                "capabilities": {"mesh_networking", "peer_discovery", "message_routing", "network_topology"},
                "instance": fungi_mesh_agent if FUNGI_MESH_AVAILABLE else None
            },
            {
                "agent_id": "meshtalk_os_agent",
                "name": "MeshTalk OS Agent",
                "capabilities": {"system_monitoring", "performance_optimization", "security_assessment", "resource_management"},
                "instance": meshtalk_os_agent if MESHTALK_OS_AVAILABLE else None
            },
            {
                "agent_id": "meshtalk_telecom_ai_agent",
                "name": "MeshTalk Telecom AI Agent",
                "capabilities": {"telecom_operations", "subscriber_management", "network_optimization", "revenue_analytics", "market_expansion", "global_coverage"},
                "instance": meshtalk_telecom_ai_agent if MESHTALK_TELECOM_AI_AVAILABLE else None
            },
            {
                "agent_id": "docker_container_agent",
                "name": "Docker Container Agent",
                "capabilities": {"container_management", "docker_operations", "image_building", "orchestration"},
                "instance": docker_container_agent if DOCKER_CONTAINER_AVAILABLE else None
            },
            {
                "agent_id": "auto_launch_deploy_agent",
                "name": "Auto Launch Deploy Agent",
                "capabilities": {"deployment_automation", "ci_cd", "service_deployment", "health_monitoring"},
                "instance": auto_launch_deploy_agent if AUTO_LAUNCH_DEPLOY_AVAILABLE else None
            },
            {
                "agent_id": "dedicated_server_agent",
                "name": "Dedicated Server Agent",
                "capabilities": {"server_monitoring", "backup_management", "security_scanning", "maintenance"},
                "instance": dedicated_server_agent if DEDICATED_SERVER_AVAILABLE else None
            },
            {
                "agent_id": "database_expert",
                "name": "Database Tools Expert",
                "capabilities": {"database_operations", "sql_queries", "data_modeling", "performance_tuning", "backup_recovery"},
                "instance": database_expert if DATABASE_EXPERT_AVAILABLE else None
            },
            {
                "agent_id": "web_api_tools_expert",
                "name": "Web/API Tools Expert",
                "capabilities": {"api_development", "web_services", "http_requests", "rest_apis", "graphql", "authentication"},
                "instance": web_api_tools_expert if WEB_API_TOOLS_AVAILABLE else None
            },
            {
                "agent_id": "data_science_ml_tools_expert",
                "name": "Data Science/ML Tools Expert",
                "capabilities": {"data_analysis", "machine_learning", "statistical_modeling", "data_visualization", "feature_engineering"},
                "instance": data_science_ml_tools_expert if DATA_SCIENCE_ML_AVAILABLE else None
            },
            {
                "agent_id": "blockchain_tools_expert",
                "name": "Blockchain Tools Expert",
                "capabilities": {"blockchain_operations", "smart_contracts", "wallet_management", "transaction_processing", "defi_protocols"},
                "instance": blockchain_tools_expert if BLOCKCHAIN_TOOLS_AVAILABLE else None
            },
            {
                "agent_id": "devops_tools_expert",
                "name": "DevOps Tools Expert",
                "capabilities": {"infrastructure_automation", "ci_cd", "monitoring", "container_orchestration", "cloud_services"},
                "instance": devops_tools_expert if DEVOPS_TOOLS_AVAILABLE else None
            },
            {
                "agent_id": "security_tools_expert",
                "name": "Security Tools Expert",
                "capabilities": {"security_scanning", "vulnerability_assessment", "encryption", "access_control", "threat_detection"},
                "instance": security_tools_expert if SECURITY_TOOLS_AVAILABLE else None
            },
            {
                "agent_id": "payment_tools_expert",
                "name": "Payment Tools Expert",
                "capabilities": {"payment_processing", "transaction_management", "fraud_detection", "compliance", "financial_operations"},
                "instance": payment_tools_expert if PAYMENT_TOOLS_AVAILABLE else None
            },
            {
                "agent_id": "ai_ml_tools_expert",
                "name": "AI/ML Tools Expert",
                "capabilities": {"ai_modeling", "natural_language_processing", "computer_vision", "deep_learning", "model_deployment"},
                "instance": ai_ml_tools_expert if AI_ML_TOOLS_AVAILABLE else None
            },
            {
                "agent_id": "idl_tools_expert",
                "name": "IDL Tools Expert",
                "capabilities": {"scientific_computing", "data_analysis", "astronomical_data", "image_processing", "signal_processing"},
                "instance": idl_tools_expert if IDL_TOOLS_AVAILABLE else None
            },
            {
                "agent_id": "system_tools_expert",
                "name": "System Tools Expert",
                "capabilities": {"system_monitoring", "performance_analysis", "resource_management", "process_monitoring", "diagnostics"},
                "instance": system_tools_expert if SYSTEM_TOOLS_AVAILABLE else None
            },
            # Gas Toll Agents - Network Specific
            {
                "agent_id": "ethereum_gas_toll_agent",
                "name": "Ethereum Gas Toll Agent",
                "capabilities": {"ethereum_monitoring", "gas_price_optimization", "high_value_tx_detection", "erc20_transfers", "defi_protocols", "nft_monitoring"},
                "instance": EthereumGasTollAgent() if ETHEREUM_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "polygon_gas_toll_agent",
                "name": "Polygon Gas Toll Agent",
                "capabilities": {"polygon_monitoring", "matic_optimization", "defi_transactions", "layer2_scaling", "cross_chain_bridges"},
                "instance": PolygonGasTollAgent() if POLYGON_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "arbitrum_gas_toll_agent",
                "name": "Arbitrum Gas Toll Agent",
                "capabilities": {"arbitrum_monitoring", "layer2_optimization", "arbitrum_nova", "optimistic_rollups", "gas_efficiency"},
                "instance": ArbitrumGasTollAgent() if ARBITRUM_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "bsc_gas_toll_agent",
                "name": "BSC Gas Toll Agent",
                "capabilities": {"bsc_monitoring", "bnb_chain", "dex_transactions", "pancakeswap_monitoring", "fast_transactions"},
                "instance": BSCGasTollAgent() if BSC_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "avalanche_gas_toll_agent",
                "name": "Avalanche Gas Toll Agent",
                "capabilities": {"avalanche_monitoring", "avax_subnets", "cross_chain_bridges", "subnet_operations", "high_throughput"},
                "instance": AvalancheGasTollAgent() if AVALANCHE_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "solana_gas_toll_agent",
                "name": "Solana Gas Toll Agent",
                "capabilities": {"solana_monitoring", "sol_high_throughput", "program_deployments", "validator_operations", "parallel_processing"},
                "instance": SolanaGasTollAgent() if SOLANA_GAS_TOLL_AVAILABLE else None
            },
            # Gas Toll Agents - Function Specific
            {
                "agent_id": "defi_gas_toll_agent",
                "name": "DeFi Gas Toll Agent",
                "capabilities": {"defi_protocols", "yield_farming", "liquidity_pools", "dex_swaps", "lending_protocols", "staking_rewards"},
                "instance": DeFiGasTollAgent() if DEFI_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "nft_gas_toll_agent",
                "name": "NFT Gas Toll Agent",
                "capabilities": {"nft_marketplaces", "erc721_transfers", "erc1155_operations", "opensea_monitoring", "rarible_tracking", "nft_auctions"},
                "instance": NFTGasTollAgent() if NFT_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "bridge_gas_toll_agent",
                "name": "Bridge Gas Toll Agent",
                "capabilities": {"cross_chain_bridges", "asset_transfers", "bridge_protocols", "wrapped_tokens", "interoperability"},
                "instance": BridgeGasTollAgent() if BRIDGE_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "staking_gas_toll_agent",
                "name": "Staking Gas Toll Agent",
                "capabilities": {"validator_staking", "delegation_operations", "reward_distribution", "slashing_protection", "validator_performance"},
                "instance": StakingGasTollAgent() if STAKING_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "governance_gas_toll_agent",
                "name": "Governance Gas Toll Agent",
                "capabilities": {"dao_governance", "proposal_voting", "token_locking", "governance_tokens", "decentralized_decisions"},
                "instance": GovernanceGasTollAgent() if GOVERNANCE_GAS_TOLL_AVAILABLE else None
            },
            # Gas Toll Agents - AI Powered
            {
                "agent_id": "dynamic_pricing_gas_toll_agent",
                "name": "Dynamic Pricing Gas Toll Agent",
                "capabilities": {"ai_pricing", "market_analysis", "congestion_prediction", "dynamic_rates", "revenue_optimization", "ml_models"},
                "instance": DynamicPricingGasTollAgent() if DYNAMIC_PRICING_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "fraud_detection_gas_toll_agent",
                "name": "Fraud Detection Gas Toll Agent",
                "capabilities": {"anomaly_detection", "fraud_prevention", "pattern_analysis", "transaction_monitoring", "risk_assessment", "ai_security"},
                "instance": FraudDetectionGasTollAgent() if FRAUD_DETECTION_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "revenue_optimization_gas_toll_agent",
                "name": "Revenue Optimization Gas Toll Agent",
                "capabilities": {"revenue_prediction", "yield_maximization", "portfolio_optimization", "market_timing", "strategy_adaptation", "performance_analytics"},
                "instance": RevenueOptimizationGasTollAgent() if REVENUE_OPTIMIZATION_GAS_TOLL_AVAILABLE else None
            },
            {
                "agent_id": "network_congestion_gas_toll_agent",
                "name": "Network Congestion Gas Toll Agent",
                "capabilities": {"congestion_monitoring", "network_analysis", "bottleneck_detection", "capacity_planning", "load_balancing", "performance_optimization"},
                "instance": NetworkCongestionGasTollAgent() if NETWORK_CONGESTION_GAS_TOLL_AVAILABLE else None
            }
        ]

        for config in agent_configs:
            agent_info = AgentInfo(
                agent_id=config["agent_id"],
                name=config["name"],
                capabilities=config["capabilities"],
                status=AgentStatus.ONLINE if config["instance"] else AgentStatus.OFFLINE,
                last_heartbeat=datetime.now()
            )
            self.agents[config["agent_id"]] = agent_info

            if config["instance"]:
                logger.info(f"✅ {config['name']} available")
            else:
                logger.warning(f"⚠️ {config['name']} not available")

    def start_orchestration(self):
        """Start the orchestration system"""
        if self.orchestration_active:
            logger.warning("⚠️ Orchestration already active")
            return

        logger.info("🎯 Starting AI Agent Orchestration...")
        self.orchestration_active = True
        self.orchestration_thread = threading.Thread(target=self._orchestration_loop, daemon=True)
        self.orchestration_thread.start()

        # Start heartbeat monitoring
        threading.Thread(target=self._heartbeat_monitor, daemon=True).start()

    def stop_orchestration(self):
        """Stop the orchestration system"""
        logger.info("🛑 Stopping AI Agent Orchestration...")
        self.orchestration_active = False
        if self.orchestration_thread and self.orchestration_thread.is_alive():
            self.orchestration_thread.join(timeout=5)

    def _orchestration_loop(self):
        """Main orchestration loop"""
        while self.orchestration_active:
            try:
                # Process pending tasks
                self._process_pending_tasks()

                # Check for completed tasks
                self._check_completed_tasks()

                # Optimize agent workload
                self._optimize_workload()

                # Process messages
                self._process_messages()

                time.sleep(5)  # Orchestrate every 5 seconds

            except Exception as e:
                logger.error(f"❌ Orchestration error: {e}")
                time.sleep(10)

    def _heartbeat_monitor(self):
        """Monitor agent heartbeats"""
        while self.orchestration_active:
            try:
                current_time = datetime.now()

                for agent_id, agent in self.agents.items():
                    # Check if agent is still responsive
                    if (current_time - agent.last_heartbeat).total_seconds() > 300:  # 5 minutes
                        if agent.status != AgentStatus.OFFLINE:
                            logger.warning(f"⚠️ Agent {agent.name} appears offline")
                            agent.status = AgentStatus.OFFLINE

                time.sleep(60)  # Check every minute

            except Exception as e:
                logger.error(f"❌ Heartbeat monitor error: {e}")
                time.sleep(10)

    def _process_pending_tasks(self):
        """Process tasks waiting for assignment"""
        pending_tasks = [task for task in self.tasks.values() if task.status == TaskStatus.PENDING]

        for task in pending_tasks:
            # Find suitable agent
            suitable_agent = self._find_suitable_agent(task)

            if suitable_agent:
                self._assign_task_to_agent(task, suitable_agent)
            else:
                logger.warning(f"⚠️ No suitable agent found for task: {task.description}")

    def _find_suitable_agent(self, task: Task) -> Optional[str]:
        """Find the most suitable agent for a task"""
        suitable_agents = []

        for agent_id, agent in self.agents.items():
            if (agent.status == AgentStatus.ONLINE and
                task.required_capabilities.issubset(agent.capabilities) and
                agent.active_tasks < 5):  # Max 5 concurrent tasks per agent

                # Calculate suitability score
                score = agent.performance_score - (agent.active_tasks * 10)  # Penalize busy agents
                suitable_agents.append((agent_id, score))

        if suitable_agents:
            # Return agent with highest score
            suitable_agents.sort(key=lambda x: x[1], reverse=True)
            return suitable_agents[0][0]

        return None

    def _assign_task_to_agent(self, task: Task, agent_id: str):
        """Assign a task to an agent"""
        agent = self.agents[agent_id]

        task.assigned_agent = agent_id
        task.status = TaskStatus.ASSIGNED
        task.assigned_time = datetime.now()

        agent.active_tasks += 1

        # Send task to agent (in a real implementation, this would use inter-process communication)
        self._send_task_to_agent(task, agent_id)

        logger.info(f"📋 Task {task.task_id} assigned to {agent.name}")

    def _send_task_to_agent(self, task: Task, agent_id: str):
        """Send task to the specified agent"""
        # This is a simplified implementation
        # In a real system, this would use message queues, HTTP APIs, or other IPC methods

        try:
            if agent_id == "fungi_mesh_agent" and FUNGI_MESH_AVAILABLE:
                # Send to fungi mesh agent
                threading.Thread(
                    target=self._execute_task_on_agent,
                    args=(task, fungi_mesh_agent),
                    daemon=True
                ).start()

            elif agent_id == "meshtalk_os_agent" and MESHTALK_OS_AVAILABLE:
                # Send to meshtalk OS agent
                threading.Thread(
                    target=self._execute_task_on_agent,
                    args=(task, meshtalk_os_agent),
                    daemon=True
                ).start()

            elif agent_id == "docker_container_agent" and DOCKER_CONTAINER_AVAILABLE:
                # Send to docker container agent
                threading.Thread(
                    target=self._execute_task_on_agent,
                    args=(task, docker_container_agent),
                    daemon=True
                ).start()

            elif agent_id == "auto_launch_deploy_agent" and AUTO_LAUNCH_DEPLOY_AVAILABLE:
                # Send to auto launch deploy agent
                threading.Thread(
                    target=self._execute_task_on_agent,
                    args=(task, auto_launch_deploy_agent),
                    daemon=True
                ).start()

            elif agent_id == "dedicated_server_agent" and DEDICATED_SERVER_AVAILABLE:
                # Send to dedicated server agent
                threading.Thread(
                    target=self._execute_task_on_agent,
                    args=(task, dedicated_server_agent),
                    daemon=True
                ).start()

        except Exception as e:
            logger.error(f"❌ Failed to send task to agent {agent_id}: {e}")
            task.status = TaskStatus.FAILED
            task.error_message = str(e)

    def _execute_task_on_agent(self, task: Task, agent_instance):
        """Execute a task on the specified agent instance"""
        try:
            task.status = TaskStatus.RUNNING

            # Parse task description to determine action
            result = self._parse_and_execute_task(task.description, agent_instance)

            task.status = TaskStatus.COMPLETED
            task.result = result
            task.completed_time = datetime.now()

            # Update agent stats
            if task.assigned_agent:
                agent = self.agents[task.assigned_agent]
                agent.active_tasks -= 1
                agent.total_tasks_completed += 1

            logger.info(f"✅ Task {task.task_id} completed successfully")

        except Exception as e:
            logger.error(f"❌ Task {task.task_id} failed: {e}")
            task.status = TaskStatus.FAILED
            task.error_message = str(e)
            task.completed_time = datetime.now()

            # Update agent stats
            if task.assigned_agent:
                agent = self.agents[task.assigned_agent]
                agent.active_tasks -= 1
                agent.error_count += 1

    def _parse_and_execute_task(self, description: str, agent_instance) -> Any:
        """Parse task description and execute on agent"""
        # This is a simplified task execution system
        # In a real implementation, this would have a more sophisticated command parser

        desc_lower = description.lower()

        if "fungi" in desc_lower and "mesh" in desc_lower:
            if hasattr(agent_instance, 'get_mesh_status'):
                return agent_instance.get_mesh_status()
            elif hasattr(agent_instance, 'start_mesh_network'):
                return agent_instance.start_mesh_network()

        elif "docker" in desc_lower or "container" in desc_lower:
            if hasattr(agent_instance, 'list_containers'):
                return agent_instance.list_containers()
            elif hasattr(agent_instance, 'get_docker_status'):
                return agent_instance.get_docker_status()

        elif "deploy" in desc_lower or "launch" in desc_lower:
            if hasattr(agent_instance, 'deploy_service'):
                return agent_instance.deploy_service("test_service")
            elif hasattr(agent_instance, 'get_deployment_status'):
                return agent_instance.get_deployment_status()

        elif "server" in desc_lower or "backup" in desc_lower:
            if hasattr(agent_instance, 'get_server_status'):
                return agent_instance.get_server_status()
            elif hasattr(agent_instance, 'create_backup'):
                return agent_instance.create_backup("auto_backup", ["/tmp"], "/tmp/backups")

        elif "system" in desc_lower or "monitor" in desc_lower:
            if hasattr(agent_instance, 'get_system_status'):
                return agent_instance.get_system_status()

        # Default: try to call a status method
        if hasattr(agent_instance, 'get_status'):
            return agent_instance.get_status()

        return {"message": f"Task executed on {agent_instance.__class__.__name__ if agent_instance else 'unknown agent'}"}

    def _check_completed_tasks(self):
        """Check for completed tasks and update workflows"""
        # This would check task completion status in a real implementation
        pass

    def _optimize_workload(self):
        """Optimize agent workload distribution"""
        # Calculate agent utilization
        total_tasks = sum(agent.active_tasks for agent in self.agents.values())
        if total_tasks > 0:
            for agent in self.agents.values():
                utilization = (agent.active_tasks / total_tasks) * 100
                self.performance_metrics["agent_utilization"][agent.agent_id] = utilization

    def _process_messages(self):
        """Process inter-agent messages"""
        # Process any pending messages
        while not self.message_queue.empty():
            try:
                message = self.message_queue.get_nowait()
                self._handle_message(message)
            except queue.Empty:
                break

    def _handle_message(self, message: Dict[str, Any]):
        """Handle an inter-agent message"""
        message_type = message.get("type", "unknown")

        if message_type == "task_request":
            # Another agent is requesting task assistance
            self.create_task(
                description=message.get("description", "Agent assistance request"),
                priority=TaskPriority.HIGH,
                required_capabilities=set(message.get("capabilities", []))
            )

        elif message_type == "status_update":
            # Agent status update
            agent_id = message.get("agent_id")
            if agent_id in self.agents:
                self.agents[agent_id].last_heartbeat = datetime.now()

        elif message_type == "alert":
            # System alert
            logger.warning(f"🚨 Agent alert: {message.get('message', 'Unknown alert')}")

    def create_task(self, description: str, priority: TaskPriority = TaskPriority.MEDIUM,
                   required_capabilities: Set[str] = None, dependencies: List[str] = None) -> str:
        """Create a new task"""
        task_id = str(uuid.uuid4())

        task = Task(
            task_id=task_id,
            description=description,
            priority=priority,
            required_capabilities=required_capabilities or set(),
            dependencies=dependencies or []
        )

        self.tasks[task_id] = task
        self.task_queue.put(task)

        logger.info(f"📋 Task created: {description} (ID: {task_id})")

        return task_id

    def create_workflow(self, name: str, description: str, tasks: List[Task]) -> str:
        """Create a new workflow"""
        workflow_id = str(uuid.uuid4())

        workflow = Workflow(
            workflow_id=workflow_id,
            name=name,
            description=description,
            tasks=tasks
        )

        self.workflows[workflow_id] = workflow

        logger.info(f"🔄 Workflow created: {name} (ID: {workflow_id})")

        return workflow_id

    def get_orchestrator_status(self) -> Dict[str, Any]:
        """Get comprehensive orchestrator status"""
        agent_status = {}
        for agent_id, agent in self.agents.items():
            agent_status[agent_id] = {
                "name": agent.name,
                "status": agent.status.value,
                "capabilities": list(agent.capabilities),
                "active_tasks": agent.active_tasks,
                "performance_score": agent.performance_score,
                "last_heartbeat": agent.last_heartbeat.isoformat(),
                "total_tasks_completed": agent.total_tasks_completed,
                "error_count": agent.error_count
            }

        task_status = {}
        for task_id, task in self.tasks.items():
            task_status[task_id] = {
                "description": task.description,
                "status": task.status.value,
                "priority": task.priority.value,
                "assigned_agent": task.assigned_agent,
                "created_time": task.created_time.isoformat(),
                "assigned_time": task.assigned_time.isoformat() if task.assigned_time else None,
                "completed_time": task.completed_time.isoformat() if task.completed_time else None
            }

        return {
            "orchestrator_id": self.orchestrator_id,
            "orchestration_active": self.orchestration_active,
            "agents": agent_status,
            "tasks": task_status,
            "workflows": {
                wf_id: {
                    "name": wf.name,
                    "description": wf.description,
                    "status": wf.status.value,
                    "task_count": len(wf.tasks),
                    "created_time": wf.created_time.isoformat()
                }
                for wf_id, wf in self.workflows.items()
            },
            "performance_metrics": self.performance_metrics,
            "timestamp": datetime.now().isoformat()
        }

    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        """Get status of a specific task"""
        task = self.tasks.get(task_id)
        if not task:
            return {"error": "Task not found"}

        return {
            "task_id": task.task_id,
            "description": task.description,
            "status": task.status.value,
            "priority": task.priority.value,
            "required_capabilities": list(task.required_capabilities),
            "assigned_agent": task.assigned_agent,
            "created_time": task.created_time.isoformat(),
            "assigned_time": task.assigned_time.isoformat() if task.assigned_time else None,
            "completed_time": task.completed_time.isoformat() if task.completed_time else None,
            "result": task.result,
            "error_message": task.error_message,
            "dependencies": task.dependencies
        }

    def cancel_task(self, task_id: str) -> bool:
        """Cancel a task"""
        task = self.tasks.get(task_id)
        if not task:
            return False

        if task.status in [TaskStatus.PENDING, TaskStatus.ASSIGNED, TaskStatus.RUNNING]:
            task.status = TaskStatus.CANCELLED
            task.completed_time = datetime.now()

            # Update agent stats if assigned
            if task.assigned_agent:
                agent = self.agents.get(task.assigned_agent)
                if agent:
                    agent.active_tasks = max(0, agent.active_tasks - 1)

            logger.info(f"🚫 Task {task_id} cancelled")
            return True

        return False

    def send_message_to_agent(self, agent_id: str, message: Dict[str, Any]):
        """Send a message to a specific agent"""
        if agent_id not in self.agents:
            logger.error(f"❌ Agent {agent_id} not found")
            return False

        # Add orchestrator info
        message["from_orchestrator"] = self.orchestrator_id
        message["timestamp"] = datetime.now().isoformat()

        # In a real implementation, this would send via message queue or API
        self.message_queue.put(message)

        logger.info(f"💬 Message sent to agent {agent_id}: {message.get('type', 'unknown')}")
        return True

    def broadcast_message(self, message: Dict[str, Any]):
        """Broadcast a message to all agents"""
        message["from_orchestrator"] = self.orchestrator_id
        message["timestamp"] = datetime.now().isoformat()
        message["broadcast"] = True

        for agent_id in self.agents:
            self.message_queue.put(message)

        logger.info(f"📢 Broadcast message sent to all agents: {message.get('type', 'unknown')}")

# ═══════════════════════════════════════════════════════════════════════════════
# SINGLETON INSTANCE
# ═══════════════════════════════════════════════════════════════════════════════

ai_agent_orchestrator = AIAgentOrchestrator()

# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("🤖🎯 AI Agent Orchestrator Test")
    print("=" * 50)

    orchestrator = AIAgentOrchestrator()

    try:
        # Start orchestration
        orchestrator.start_orchestration()

        # Get initial status
        status = orchestrator.get_orchestrator_status()
        print(json.dumps(status, indent=2, default=str))

        # Create some test tasks
        task1_id = orchestrator.create_task(
            description="Monitor mesh network status",
            priority=TaskPriority.HIGH,
            required_capabilities={"mesh_networking"}
        )

        task2_id = orchestrator.create_task(
            description="Check Docker containers",
            priority=TaskPriority.MEDIUM,
            required_capabilities={"container_management"}
        )

        task3_id = orchestrator.create_task(
            description="Deploy test service",
            priority=TaskPriority.LOW,
            required_capabilities={"deployment_automation"}
        )

        print(f"Created tasks: {task1_id}, {task2_id}, {task3_id}")

        # Wait for tasks to be processed
        time.sleep(15)

        # Check task statuses
        for task_id in [task1_id, task2_id, task3_id]:
            task_status = orchestrator.get_task_status(task_id)
            print(f"Task {task_id} status: {json.dumps(task_status, indent=2, default=str)}")

        # Get final orchestrator status
        final_status = orchestrator.get_orchestrator_status()
        print("Final orchestrator status:")
        print(json.dumps(final_status, indent=2, default=str))

    except KeyboardInterrupt:
        print("\n🛑 Shutting down AI Agent Orchestrator...")
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        orchestrator.stop_orchestration()