#!/usr/bin/env python3
"""
Core Services Expert AI Agent
Master of QuranChain Core Services: Quantum Hub, Revenue Engines, AI Workforce
Specializes in: Service health, revenue monitoring, auto-repair, system diagnostics
"""

from flask import Flask, jsonify, request
import sqlite3
import requests
import subprocess
import time
import json
from datetime import datetime
import os
import threading

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        PRODUCTS as STRIPE_CATALOG,
        GAS_TOLL_PRODUCTS, VALIDATOR_PRODUCTS, PAYMENT_PRODUCTS,
        BLOCKCHAIN_SERVICE_PRODUCTS, REVENUE_TRACKING_PRODUCTS,
        create_checkout_session, create_payment_link,
        get_catalog_summary,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

app = Flask(__name__)
PORT = 9010

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty

class CoreServicesExpert:
    def __init__(self):
        self.agent_name = "core-services-expert"
        self.expertise = [
            "quantum_blockchain_hub",
            "gas_toll_revenue_system",
            "fiat_payment_collection",
            "network_provider_revenue",
            "ai_orchestrator",
            "service_health_monitoring",
            "revenue_attribution",
            "auto_repair_systems",
            "log_analysis",
            "founder_royalty_protection"
        ]
        
        # Core Services Configuration
        self.core_services = {
            "quantum_blockchain": {
                "port": 9999,
                "path": "organized/ai_agents/quranchain_quantum_blockchain.py",
                "log": "monitoring_logs/quantum_blockchain.log",
                "health_endpoint": "http://localhost:9999/health",
                "description": "Master integration hub for all QuranChain services"
            },
            "gas_toll": {
                "port": 9020,
                "path": "organized/ai_agents/blockchain_gas_toll_system.py",
                "log": "monitoring_logs/gas_toll_system.log",
                "health_endpoint": "http://localhost:9020/health",
                "description": "Blockchain gas toll collection across 47 networks"
            },
            "fiat_payment": {
                "port": 9021,
                "path": "organized/ai_agents/fiat_payment_collection.py",
                "log": "monitoring_logs/fiat_payment.log",
                "health_endpoint": "http://localhost:9021/health",
                "description": "Fiat payment processing (Stripe, PayPal)"
            },
            "network_provider": {
                "port": 9022,
                "path": "organized/ai_agents/network_provider_revenue.py",
                "log": "monitoring_logs/network_provider.log",
                "health_endpoint": "http://localhost:9022/health",
                "description": "Network provider revenue collection"
            },
            "orchestrator": {
                "port": 9090,
                "path": "organized/ai_agents/ai_workforce/orchestrator.py",
                "log": "logs/ai_workforce/orchestrator.log",
                "health_endpoint": "http://localhost:9090/health",
                "description": "AI workforce coordinator (7 agents)"
            }
        }
        
        self.service_status = {}
        self.last_health_check = None
        self.repair_attempts = {}
        self.crm_db = "crm/crm.db"
        
    def check_service_health(self):
        """Comprehensive health check of all core services"""
        health_report = {
            "timestamp": datetime.now().isoformat(),
            "services": {},
            "summary": {
                "total": len(self.core_services),
                "online": 0,
                "offline": 0,
                "degraded": 0
            }
        }
        
        for service_name, config in self.core_services.items():
            status = {
                "port": config["port"],
                "description": config["description"],
                "port_listening": False,
                "http_responding": False,
                "process_running": False,
                "status": "offline"
            }
            
            # Check if port is listening
            try:
                result = subprocess.run(
                    ["lsof", "-i", f":{config['port']}"],
                    capture_output=True,
                    timeout=2
                )
                status["port_listening"] = result.returncode == 0
            except:
                pass
            
            # Check HTTP endpoint
            try:
                resp = requests.get(config["health_endpoint"], timeout=2)
                status["http_responding"] = resp.status_code == 200
                status["response_data"] = resp.json()
            except:
                pass
            
            # Check if process is running
            try:
                result = subprocess.run(
                    ["pgrep", "-f", config["path"]],
                    capture_output=True,
                    timeout=2
                )
                status["process_running"] = result.returncode == 0
            except:
                pass
            
            # Determine overall status
            if status["http_responding"] and status["port_listening"]:
                status["status"] = "healthy"
                health_report["summary"]["online"] += 1
            elif status["process_running"]:
                status["status"] = "degraded"
                health_report["summary"]["degraded"] += 1
            else:
                status["status"] = "offline"
                health_report["summary"]["offline"] += 1
            
            health_report["services"][service_name] = status
        
        self.service_status = health_report
        self.last_health_check = datetime.now().isoformat()
        return health_report
    
    def analyze_service_logs(self, service_name, lines=50):
        """Analyze service logs for errors and insights"""
        config = self.core_services.get(service_name)
        if not config:
            return {"error": "Service not found"}
        
        log_path = config["log"]
        analysis = {
            "service": service_name,
            "log_path": log_path,
            "timestamp": datetime.now().isoformat(),
            "errors": [],
            "warnings": [],
            "info": [],
            "last_lines": []
        }
        
        try:
            result = subprocess.run(
                ["tail", f"-n{lines}", log_path],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            log_lines = result.stdout.split('\n')
            analysis["last_lines"] = log_lines[-10:]
            
            for line in log_lines:
                if "ERROR" in line or "error" in line.lower():
                    analysis["errors"].append(line.strip())
                elif "WARN" in line or "warning" in line.lower():
                    analysis["warnings"].append(line.strip())
                elif "INFO" in line:
                    analysis["info"].append(line.strip())
                    
        except Exception as e:
            analysis["error"] = str(e)
        
        return analysis
    
    def auto_repair_service(self, service_name):
        """Attempt to auto-repair a failed service"""
        config = self.core_services.get(service_name)
        if not config:
            return {"success": False, "error": "Service not found"}
        
        repair_log = {
            "service": service_name,
            "timestamp": datetime.now().isoformat(),
            "steps": [],
            "success": False
        }
        
        # Step 1: Kill existing process
        repair_log["steps"].append(f"Killing existing {service_name} process")
        try:
            subprocess.run(["pkill", "-f", config["path"]], timeout=5)
            time.sleep(2)
        except:
            pass
        
        # Step 2: Ensure directories exist
        log_dir = os.path.dirname(config["log"])
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
            repair_log["steps"].append(f"Created log directory: {log_dir}")
        
        # Step 3: Restart service
        repair_log["steps"].append(f"Starting {service_name} service")
        try:
            cmd = f"nohup python3 {config['path']} > {config['log']} 2>&1 &"
            subprocess.Popen(cmd, shell=True, cwd="/home/omar/Desktop/QuranChain")
            time.sleep(5)
            
            # Verify restart
            result = subprocess.run(
                ["lsof", "-i", f":{config['port']}"],
                capture_output=True,
                timeout=2
            )
            
            if result.returncode == 0:
                repair_log["success"] = True
                repair_log["steps"].append(f"✅ Service started successfully on port {config['port']}")
            else:
                repair_log["steps"].append(f"⚠️ Service may still be starting...")
                
        except Exception as e:
            repair_log["steps"].append(f"❌ Error: {str(e)}")
        
        # Track repair attempts
        if service_name not in self.repair_attempts:
            self.repair_attempts[service_name] = []
        self.repair_attempts[service_name].append(repair_log)
        
        self.log_to_crm("service_repair", repair_log)
        return repair_log
    
    def get_revenue_status(self):
        """Get revenue collection status across all engines"""
        revenue_report = {
            "timestamp": datetime.now().isoformat(),
            "founder_royalty_rate": FOUNDER_ROYALTY_RATE,
            "engines": {},
            "total_estimated": 0
        }
        
        # Query each revenue engine
        for service in ["gas_toll", "fiat_payment", "network_provider"]:
            config = self.core_services.get(service)
            if not config:
                continue
                
            try:
                # Try to get revenue data
                resp = requests.get(f"{config['health_endpoint'].replace('/health', '/revenue')}", timeout=2)
                if resp.status_code == 200:
                    revenue_report["engines"][service] = resp.json()
            except:
                revenue_report["engines"][service] = {"status": "offline", "revenue": 0}
        
        return revenue_report
    
    def get_system_diagnostics(self):
        """Comprehensive system diagnostics"""
        diagnostics = {
            "timestamp": datetime.now().isoformat(),
            "health_check": self.check_service_health(),
            "revenue_status": self.get_revenue_status(),
            "repair_history": self.repair_attempts,
            "system_info": {
                "founder_royalty_protected": True,
                "royalty_rate": f"{FOUNDER_ROYALTY_RATE * 100}%",
                "total_services": len(self.core_services),
                "ai_workforce_count": 7
            }
        }
        
        return diagnostics
    
    def log_to_crm(self, activity_type, details):
        """Log activity to CRM"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO agent_activity (agent_name, activity_type, details, timestamp)
                VALUES (?, ?, ?, ?)
            """, (self.agent_name, activity_type, json.dumps(details), datetime.now().isoformat()))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"CRM logging error: {e}")
    
    def get_revenue_attribution(self):
        """Calculate revenue attribution for this agent's work"""
        return {
            "agent": self.agent_name,
            "founder_royalty": FOUNDER_ROYALTY_RATE,
            "contribution_areas": [
                "service_health_monitoring",
                "auto_repair_systems",
                "revenue_engine_optimization",
                "system_diagnostics"
            ],
            "revenue_impact": "uptime_maximization_and_revenue_protection"
        }

# Global singleton
core_expert = CoreServicesExpert()

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status": "healthy",
        "agent": "core-services-expert",
        "port": PORT,
        "expertise": core_expert.expertise,
        "services_monitored": len(core_expert.core_services),
        "timestamp": datetime.now().isoformat()
    })

@app.route('/services', methods=['GET'])
def get_services():
    """Get list of all core services"""
    return jsonify({
        "services": core_expert.core_services,
        "total": len(core_expert.core_services)
    })

@app.route('/services/health', methods=['GET'])
def services_health():
    """Comprehensive health check of all services"""
    health_report = core_expert.check_service_health()
    core_expert.log_to_crm("health_check", health_report)
    return jsonify(health_report)

@app.route('/services/<service_name>/logs', methods=['GET'])
def service_logs(service_name):
    """Get and analyze service logs"""
    lines = int(request.args.get('lines', 50))
    analysis = core_expert.analyze_service_logs(service_name, lines)
    return jsonify(analysis)

@app.route('/services/<service_name>/repair', methods=['POST'])
def repair_service(service_name):
    """Attempt to auto-repair a service"""
    result = core_expert.auto_repair_service(service_name)
    return jsonify(result)

@app.route('/services/repair/all', methods=['POST'])
def repair_all_services():
    """Auto-repair all offline services"""
    health = core_expert.check_service_health()
    repairs = []
    
    for service_name, status in health["services"].items():
        if status["status"] != "healthy":
            repair_result = core_expert.auto_repair_service(service_name)
            repairs.append(repair_result)
    
    return jsonify({
        "timestamp": datetime.now().isoformat(),
        "repairs": repairs,
        "total_attempted": len(repairs)
    })

@app.route('/revenue', methods=['GET'])
def revenue_status():
    """Get revenue collection status"""
    return jsonify(core_expert.get_revenue_status())

@app.route('/diagnostics', methods=['GET'])
def diagnostics():
    """Complete system diagnostics"""
    diag = core_expert.get_system_diagnostics()
    core_expert.log_to_crm("diagnostics", diag)
    return jsonify(diag)

@app.route('/attribution', methods=['GET'])
def revenue_attribution():
    """Get revenue attribution for this agent"""
    return jsonify(core_expert.get_revenue_attribution())

@app.route('/metrics', methods=['GET'])
def get_metrics():
    """Get agent metrics"""
    return jsonify({
        "agent": "core-services-expert",
        "services_monitored": len(core_expert.core_services),
        "last_health_check": core_expert.last_health_check,
        "repair_attempts_total": sum(len(v) for v in core_expert.repair_attempts.values()),
        "uptime": "active",
        "timestamp": datetime.now().isoformat()
    })

def continuous_health_monitoring():
    """Background thread for continuous health monitoring"""
    while True:
        try:
            # Check health every 30 seconds
            health = core_expert.check_service_health()
            
            # Auto-repair if enabled and services are down
            offline_count = health["summary"]["offline"]
            if offline_count > 0:
                print(f"⚠️  {offline_count} services offline - monitoring")
                
            time.sleep(30)
        except Exception as e:
            print(f"Monitoring error: {e}")
            time.sleep(30)

if __name__ == '__main__':
    print(f"🔧 Core Services Expert Agent starting on port {PORT}")
    print(f"📊 Monitoring {len(core_expert.core_services)} core services:")
    for name, config in core_expert.core_services.items():
        print(f"   • {name} (port {config['port']})")
    print(f"💰 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    
    # Initial health check
    health = core_expert.check_service_health()
    print(f"\n📈 Initial Status: {health['summary']['online']}/{health['summary']['total']} online")
    
    # Start background monitoring
    monitor_thread = threading.Thread(target=continuous_health_monitoring, daemon=True)
    monitor_thread.start()
    
    # Register with master hub
    try:
        requests.post("http://localhost:9999/register_agent", json={
            "agent": "core-services-expert",
            "port": PORT,
            "capabilities": core_expert.expertise
        }, timeout=2)
        print("✅ Registered with quantum blockchain hub")
    except:
        print("⚠️ Hub registration pending (will retry)")
    
    app.run(host='0.0.0.0', port=PORT, debug=False)
