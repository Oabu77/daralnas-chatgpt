import os
import json
import sqlite3
import time
from flask import Flask, jsonify, request

AGENT_NAME = "customer_support_ai"
PORT = int(os.environ.get("CUSTOMER_SUPPORT_AI_PORT", "9012"))
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOG_DIR = os.path.join(REPO_ROOT, "logs", "ai_workforce")
CRM_DB = os.path.join(REPO_ROOT, "crm", "crm.db")
LOG_FILE = os.path.join(LOG_DIR, f"{AGENT_NAME}.log")

os.makedirs(LOG_DIR, exist_ok=True)

app = Flask("customer_support_ai")

_state = {
    "tasks_received": 0,
    "tasks_success": 0,
    "tasks_failed": 0,
    "last_task_id": None,
}


def log(msg: str):
    stamp = time.strftime('%Y-%m-%d %H:%M:%S')
    with open(LOG_FILE, 'a') as f:
        f.write(f"[{stamp}] {msg}\n")


def record_performance(task_id: str, source: str, status: str):
    try:
        conn = sqlite3.connect(CRM_DB)
        cur = conn.cursor()
        cur.execute("""
        INSERT INTO ai_agent_performance (agent_name, task_id, source, status, timestamp)
        VALUES (?, ?, ?, ?, ?)
        """, (AGENT_NAME, task_id, source, status, int(time.time())))
        conn.commit()
        conn.close()
    except Exception as e:
        log(f"CRM performance insert failed: {e}")


def ensure_tables():
    try:
        conn = sqlite3.connect(CRM_DB)
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS support_tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id TEXT,
                priority TEXT,
                status TEXT,
                summary TEXT,
                timestamp INTEGER
            )
            """
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log(f"Ensure tables failed: {e}")


def triage(summary: str) -> str:
    s = (summary or '').lower()
    if any(k in s for k in ['outage','down','critical','cannot','fail']):
        return 'high'
    if any(k in s for k in ['bug','issue','error','problem']):
        return 'medium'
    return 'low'


@app.get('/health')
def health():
    return jsonify({
        "agent_id": f"{AGENT_NAME}_{int(time.time())}",
        "agent_type": AGENT_NAME,
        "status": "healthy"
    })


@app.get('/metrics')
def metrics():
    return jsonify({
        "tasks_received": _state["tasks_received"],
        "tasks_success": _state["tasks_success"],
        "tasks_failed": _state["tasks_failed"],
        "last_task_id": _state["last_task_id"],
    })


@app.get('/revenue')
def revenue():
    revenue_usd = 0.0
    founder_share_usd = round(revenue_usd * 0.30, 2)
    return jsonify({
        "revenue_usd": revenue_usd,
        "founder_share_usd": founder_share_usd,
        "agent": AGENT_NAME
    })


@app.post('/tasks')
def tasks():
    payload = request.get_json(force=True, silent=True) or {}
    task_id = str(payload.get('task_id') or f"task_{int(time.time())}")
    source = payload.get('source') or 'unknown'
    _state["tasks_received"] += 1
    _state["last_task_id"] = task_id
    try:
        task_type = str(payload.get('type') or '')
        ensure_tables()
        if task_type == 'ticket_triage':
            inner = payload.get('payload') or {}
            ticket_id = str(inner.get('ticket_id') or '')
            summary = str(inner.get('summary') or '')
            priority = triage(summary)
            try:
                conn = sqlite3.connect(CRM_DB)
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO support_tickets (ticket_id, priority, status, summary, timestamp) VALUES (?, ?, ?, ?, ?)",
                    (ticket_id, priority, 'open', summary, int(time.time()))
                )
                conn.commit()
                conn.close()
            except Exception as e:
                log(f"Insert support ticket failed: {e}")
            record_performance(task_id, source, priority)
            result = {"status": "triaged", "task_id": task_id, "priority": priority, "ticket_id": ticket_id}
        else:
            result = {"status": "unknown_task", "task_id": task_id, "type": task_type}
        _state["tasks_success"] += 1
        log(f"Processed task {task_id} from {source}: {result['status']}")
        return jsonify(result)
    except Exception as e:
        _state["tasks_failed"] += 1
        record_performance(task_id, source, 'failed')
        log(f"Task {task_id} failed: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500


if __name__ == '__main__':
    ensure_tables()
    log("Starting Customer Support AI service")
    app.run(host='0.0.0.0', port=PORT)
