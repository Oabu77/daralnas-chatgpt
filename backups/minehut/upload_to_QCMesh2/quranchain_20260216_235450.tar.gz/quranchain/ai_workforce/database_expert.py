#!/usr/bin/env python3
"""
Database Systems Expert AI Agent
Master of QuranChain Database Operations: SQLAlchemy, PostgreSQL, Redis, SQLite
Specializes in: Database design, query optimization, data modeling, caching
"""

from flask import Flask, jsonify, request
import sqlite3
import psycopg2
import redis
import sqlalchemy
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Float, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import json
import time
import threading
from datetime import datetime
import os
import logging

app = Flask(__name__)
PORT = 9020

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty

class DatabaseExpert:
    def __init__(self):
        self.agent_name = "database-expert"
        self.expertise = [
            "sqlalchemy_orm_operations",
            "postgresql_database_management",
            "redis_caching_systems",
            "sqlite_embedded_databases",
            "database_schema_design",
            "query_optimization",
            "data_modeling",
            "database_migration",
            "connection_pooling",
            "database_performance_monitoring",
            "backup_and_recovery",
            "database_security",
            "nosql_integrations",
            "data_warehousing",
            "database_administration"
        ]

        # Database Systems Knowledge
        self.database_systems = {
            "postgresql": {
                "name": "PostgreSQL",
                "type": "Relational Database",
                "version": "15.x",
                "features": [
                    "ACID Compliance",
                    "Advanced Indexing",
                    "JSON/JSONB Support",
                    "Full-text Search",
                    "PostGIS Extensions",
                    "Partitioning",
                    "Replication"
                ],
                "connection_string": "postgresql://user:password@localhost:5432/dbname",
                "use_cases": ["Enterprise Applications", "Geospatial Data", "Complex Queries"]
            },
            "sqlite": {
                "name": "SQLite",
                "type": "Embedded Database",
                "version": "3.x",
                "features": [
                    "Zero Configuration",
                    "Single File Database",
                    "ACID Transactions",
                    "Full SQL Support",
                    "Cross-platform",
                    "Small Footprint"
                ],
                "connection_string": "sqlite:///database.db",
                "use_cases": ["Mobile Apps", "Desktop Applications", "Embedded Systems"]
            },
            "redis": {
                "name": "Redis",
                "type": "In-memory Data Store",
                "version": "7.x",
                "features": [
                    "Key-Value Storage",
                    "Data Structures",
                    "Pub/Sub Messaging",
                    "Caching",
                    "Session Storage",
                    "Real-time Analytics"
                ],
                "connection_string": "redis://localhost:6379",
                "use_cases": ["Caching", "Session Management", "Real-time Systems"]
            },
            "sqlalchemy": {
                "name": "SQLAlchemy",
                "type": "ORM Framework",
                "version": "2.0",
                "features": [
                    "Object-Relational Mapping",
                    "SQL Expression Language",
                    "Connection Pooling",
                    "Migration Support",
                    "Multiple Database Support",
                    "Async Support"
                ],
                "supported_databases": ["PostgreSQL", "MySQL", "SQLite", "Oracle", "MSSQL"],
                "use_cases": ["Python Applications", "Data Modeling", "Database Abstraction"]
            }
        }

        self.revenue_stats = {
            "total_operations": 0,
            "queries_executed": 0,
            "connections_managed": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "data_processed_gb": 0,
            "founder_royalty_paid": 0
        }

        self.service_status = {}
        self.last_health_check = None
        self.crm_db = "crm/crm.db"

        # Initialize database connections
        self.connections = {
            "sqlite": None,
            "postgresql": None,
            "redis": None
        }

        self.setup_logging()

    def setup_logging(self):
        """Setup logging for database operations"""
        logging.basicConfig(
            filename='logs/ai_workforce/database_expert.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def log_to_crm(self, action, data):
        """Log database operations to CRM for attribution tracking"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT INTO agent_activities
                (agent_name, action, data, timestamp, revenue_impact)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                self.agent_name,
                action,
                json.dumps(data),
                datetime.now().isoformat(),
                data.get('revenue', 0)
            ))

            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error(f"CRM logging error: {e}")

    def check_database_service_status(self):
        """Check status of database services"""
        status = {
            "timestamp": datetime.now().isoformat(),
            "service": "database_expert",
            "port": PORT,
            "status": "unknown",
            "sqlite_available": False,
            "postgresql_available": False,
            "redis_available": False,
            "sqlalchemy_available": False
        }

        # Check SQLite
        try:
            conn = sqlite3.connect(':memory:')
            conn.execute('SELECT 1')
            conn.close()
            status["sqlite_available"] = True
        except:
            pass

        # Check PostgreSQL
        try:
            # Try to connect to local PostgreSQL (if available)
            conn = psycopg2.connect(
                host="localhost",
                database="postgres",
                user="postgres",
                password="",
                connect_timeout=2
            )
            conn.close()
            status["postgresql_available"] = True
        except:
            pass

        # Check Redis
        try:
            r = redis.Redis(host='localhost', port=6379, db=0, socket_timeout=2)
            r.ping()
            status["redis_available"] = True
        except:
            pass

        # Check SQLAlchemy
        try:
            import sqlalchemy
            status["sqlalchemy_available"] = True
        except:
            pass

        # Determine overall status
        available_count = sum([
            status["sqlite_available"],
            status["postgresql_available"],
            status["redis_available"],
            status["sqlalchemy_available"]
        ])

        if available_count >= 2:
            status["status"] = "healthy"
        elif available_count >= 1:
            status["status"] = "degraded"
        else:
            status["status"] = "offline"

        self.service_status = status
        self.last_health_check = datetime.now().isoformat()
        return status

    def execute_sqlite_query(self, query, params=None):
        """Execute SQLite query"""
        try:
            if not self.connections.get("sqlite"):
                self.connections["sqlite"] = sqlite3.connect('database_expert.db')

            conn = self.connections["sqlite"]
            cursor = conn.cursor()

            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            if query.strip().upper().startswith('SELECT'):
                results = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                return {"columns": columns, "rows": results}
            else:
                conn.commit()
                return {"rows_affected": cursor.rowcount}

        except Exception as e:
            return {"error": str(e)}

    def execute_postgresql_query(self, query, params=None, connection_string=None):
        """Execute PostgreSQL query"""
        try:
            if not connection_string:
                connection_string = "postgresql://postgres@localhost/postgres"

            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            if query.strip().upper().startswith('SELECT'):
                results = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                conn.close()
                return {"columns": columns, "rows": results}
            else:
                conn.commit()
                conn.close()
                return {"rows_affected": cursor.rowcount}

        except Exception as e:
            return {"error": str(e)}

    def redis_operation(self, operation, key=None, value=None, ttl=None):
        """Execute Redis operation"""
        try:
            if not self.connections.get("redis"):
                self.connections["redis"] = redis.Redis(host='localhost', port=6379, db=0)

            r = self.connections["redis"]

            if operation == "set":
                if ttl:
                    r.setex(key, ttl, value)
                else:
                    r.set(key, value)
                return {"success": True}

            elif operation == "get":
                value = r.get(key)
                return {"value": value.decode() if value else None}

            elif operation == "delete":
                return {"deleted": r.delete(key)}

            elif operation == "exists":
                return {"exists": r.exists(key)}

            elif operation == "ttl":
                return {"ttl": r.ttl(key)}

            elif operation == "keys":
                pattern = key or "*"
                keys = r.keys(pattern)
                return {"keys": [k.decode() for k in keys]}

        except Exception as e:
            return {"error": str(e)}

    def create_sqlalchemy_model(self, table_name, columns):
        """Create SQLAlchemy model dynamically"""
        try:
            Base = declarative_base()

            # Create table class dynamically
            attrs = {'__tablename__': table_name, 'id': Column(Integer, primary_key=True)}

            for col_name, col_type in columns.items():
                if col_type == "string":
                    attrs[col_name] = Column(String(255))
                elif col_type == "integer":
                    attrs[col_name] = Column(Integer)
                elif col_type == "float":
                    attrs[col_name] = Column(Float)
                elif col_type == "datetime":
                    attrs[col_name] = Column(DateTime)
                elif col_type == "text":
                    attrs[col_name] = Column(Text)

            ModelClass = type(table_name, (Base,), attrs)
            return {"model_created": True, "table_name": table_name}

        except Exception as e:
            return {"error": str(e)}

    def get_database_analytics(self):
        """Get database performance analytics"""
        analytics = {
            "timestamp": datetime.now().isoformat(),
            "total_operations": self.revenue_stats["total_operations"],
            "queries_executed": self.revenue_stats["queries_executed"],
            "connections_managed": self.revenue_stats["connections_managed"],
            "cache_performance": {
                "hits": self.revenue_stats["cache_hits"],
                "misses": self.revenue_stats["cache_misses"],
                "hit_ratio": self.revenue_stats["cache_hits"] / max(1, self.revenue_stats["cache_hits"] + self.revenue_stats["cache_misses"])
            },
            "data_processed_gb": self.revenue_stats["data_processed_gb"],
            "supported_databases": list(self.database_systems.keys()),
            "active_connections": len([c for c in self.connections.values() if c is not None])
        }

        return analytics

    def optimize_query(self, query, database_type):
        """Provide query optimization suggestions"""
        suggestions = []

        if "SELECT *" in query.upper():
            suggestions.append("Avoid SELECT * - specify only needed columns")

        if "WHERE" not in query.upper() and "JOIN" in query.upper():
            suggestions.append("Consider adding WHERE clauses to JOIN operations")

        if database_type == "postgresql":
            if "ILIKE" in query.upper():
                suggestions.append("Consider using full-text search for better performance")
            if "COUNT(*)" in query.upper():
                suggestions.append("Use COUNT(1) or COUNT(primary_key) for better performance")

        return {
            "original_query": query,
            "database_type": database_type,
            "optimization_suggestions": suggestions,
            "estimated_improvement": f"{len(suggestions) * 15}%" if suggestions else "0%"
        }

    def get_revenue_attribution(self):
        """Get revenue attribution for this agent"""
        return {
            "agent": self.agent_name,
            "total_operations": self.revenue_stats["total_operations"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "revenue_generated": self.revenue_stats["total_operations"] * 0.001,  # $0.001 per operation
            "attribution_percentage": 0.15  # 15% of database operations revenue
        }

# Initialize the expert
database_expert = DatabaseExpert()

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    status = database_expert.check_database_service_status()
    return jsonify(status)

@app.route('/sqlite/query', methods=['POST'])
def sqlite_query():
    """Execute SQLite query"""
    data = request.json
    query = data.get('query', '')
    params = data.get('params')

    result = database_expert.execute_sqlite_query(query, params)
    database_expert.revenue_stats["queries_executed"] += 1
    database_expert.revenue_stats["total_operations"] += 1

    database_expert.log_to_crm("sqlite_query", {"query": query, "revenue": 0.001})
    return jsonify(result)

@app.route('/postgresql/query', methods=['POST'])
def postgresql_query():
    """Execute PostgreSQL query"""
    data = request.json
    query = data.get('query', '')
    params = data.get('params')
    connection_string = data.get('connection_string')

    result = database_expert.execute_postgresql_query(query, params, connection_string)
    database_expert.revenue_stats["queries_executed"] += 1
    database_expert.revenue_stats["total_operations"] += 1

    database_expert.log_to_crm("postgresql_query", {"query": query, "revenue": 0.001})
    return jsonify(result)

@app.route('/redis/<operation>', methods=['POST'])
def redis_op(operation):
    """Execute Redis operation"""
    data = request.json
    key = data.get('key')
    value = data.get('value')
    ttl = data.get('ttl')

    result = database_expert.redis_operation(operation, key, value, ttl)
    database_expert.revenue_stats["total_operations"] += 1

    if operation in ["get", "set"]:
        database_expert.revenue_stats["cache_hits" if result.get("value") else "cache_misses"] += 1

    database_expert.log_to_crm("redis_operation", {"operation": operation, "revenue": 0.001})
    return jsonify(result)

@app.route('/sqlalchemy/model', methods=['POST'])
def sqlalchemy_model():
    """Create SQLAlchemy model"""
    data = request.json
    table_name = data.get('table_name', '')
    columns = data.get('columns', {})

    result = database_expert.create_sqlalchemy_model(table_name, columns)
    database_expert.revenue_stats["total_operations"] += 1

    database_expert.log_to_crm("sqlalchemy_model", {"table": table_name, "revenue": 0.001})
    return jsonify(result)

@app.route('/optimize', methods=['POST'])
def optimize():
    """Optimize database query"""
    data = request.json
    query = data.get('query', '')
    database_type = data.get('database_type', 'sqlite')

    result = database_expert.optimize_query(query, database_type)
    database_expert.revenue_stats["total_operations"] += 1

    database_expert.log_to_crm("query_optimization", {"query": query, "revenue": 0.001})
    return jsonify(result)

@app.route('/analytics', methods=['GET'])
def analytics():
    """Get database analytics"""
    analytics = database_expert.get_database_analytics()
    database_expert.log_to_crm("analytics_request", analytics)
    return jsonify(analytics)

@app.route('/systems', methods=['GET'])
def systems():
    """Get supported database systems"""
    return jsonify(database_expert.database_systems)

@app.route('/attribution', methods=['GET'])
def attribution():
    """Get revenue attribution"""
    return jsonify(database_expert.get_revenue_attribution())

@app.route('/metrics', methods=['GET'])
def metrics():
    """Get agent metrics"""
    return jsonify({
        "agent": "database-expert",
        "supported_systems": len(database_expert.database_systems),
        "active_connections": len([c for c in database_expert.connections.values() if c is not None]),
        "last_health_check": database_expert.last_health_check,
        "total_operations": database_expert.revenue_stats["total_operations"],
        "queries_executed": database_expert.revenue_stats["queries_executed"],
        "founder_royalty_paid": database_expert.revenue_stats["founder_royalty_paid"],
        "timestamp": datetime.now().isoformat()
    })

def continuous_monitoring():
    """Background thread for continuous monitoring"""
    while True:
        try:
            # Check service health every 30 seconds
            database_expert.check_database_service_status()
            time.sleep(30)
        except Exception as e:
            print(f"Monitoring error: {e}")
            time.sleep(30)

if __name__ == '__main__':
    print(f"🗄️ Database Systems Expert Agent starting on port {PORT}")
    print(f"💰 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}%")
    print(f"\n📊 Database Systems Configured:")
    for name, info in database_expert.database_systems.items():
        print(f"   • {info['name']} - {info['type']}")
    print(f"\n🔍 Expertise Areas: {len(database_expert.expertise)}")

    # Initial service check
    status = database_expert.check_database_service_status()
    print(f"\n📈 Initial Status: {status['status']}")

    # Start background monitoring
    monitor_thread = threading.Thread(target=continuous_monitoring, daemon=True)
    monitor_thread.start()

    # Register with master hub
    try:
        import requests
        requests.post("https://api.quranchain.io/register_agent", json={
            "agent": "database-expert",
            "port": PORT,
            "capabilities": database_expert.expertise
        }, timeout=2)
        print("✅ Registered with quantum blockchain hub")
    except:
        print("⚠️ Hub registration pending (will retry)")

    app.run(host='0.0.0.0', port=PORT, debug=False)
