#!/usr/bin/env python3
"""
DarPay™ Crypto - QuranChain Cryptocurrency Payment Processing System
===================================================================
Crypto-only payment processor for AI agent earnings.
Accepts USDT, USDC, BTC, ETH, DAI - NO FIAT.

Payment Flow:
1. AI agent creates crypto invoice
2. Customer receives payment page with QR codes
3. Customer sends crypto to specified address
4. DarPay monitors blockchain and detects payment
5. Payment auto-confirmed and attributed to agent
6. Revenue distributed (30% founder, 40% validators, 10% hardware, 18% ecosystem, 2% zakat)
7. Crypto converted to QURAN tokens via QEX

© 2026 QuranChain™ - Omar Mohammad Abunadi™
"""

import json
import logging
import sqlite3
import time
import os
import hashlib
import qrcode
import io
import base64
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime, timedelta
from decimal import Decimal
from flask import Flask, jsonify, request, render_template_string
from typing import Dict, List, Optional, Tuple
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv('.env.darpay')

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        PRODUCTS as STRIPE_CATALOG, DARPAY_PRODUCTS, PAYMENT_PRODUCTS,
        TOKEN_PRODUCTS, EXCHANGE_PRODUCTS,
        create_checkout_session, create_payment_link,
        get_products_by_platform, Platform,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

# Configure logging
os.makedirs('logs/ai_workforce', exist_ok=True)
setup_blockchain_logging()
logger = logging.getLogger('DarPayCrypto')

app = Flask(__name__)

# QuranChain Configuration
QUANTUM_HUB_URL = "http://localhost:9999"
QEX_EXCHANGE_URL = os.getenv('QEX_BASE_URL', "http://localhost:8888")
DARPAY_PORT = 9011

# Revenue Distribution (Immutable)
FOUNDER_ROYALTY_RATE = 0.30  # 30% Founder - NEVER MODIFY
REVENUE_DISTRIBUTION = {
    'founder_royalty': 0.30,    # Omar Mohammad Abunadi™
    'ai_validators': 0.40,       # Omar AI™ + QuranChain AI™
    'hardware_hosts': 0.10,      # Network infrastructure providers
    'ecosystem': 0.18,           # Development & growth
    'zakat': 0.02                # Islamic charity obligation
}

# Crypto Wallet Addresses (from environment)
CRYPTO_WALLETS = {
    'USDT_ETH': os.getenv('FOUNDER_USDT_ADDRESS', '0x4e90944C093f7727ff89a30AF96A556deB95cCB8'),
    'USDT_POLYGON': os.getenv('FOUNDER_USDT_ADDRESS', '0x4e90944C093f7727ff89a30AF96A556deB95cCB8'),
    'USDT_BSC': os.getenv('FOUNDER_USDT_ADDRESS', '0x4e90944C093f7727ff89a30AF96A556deB95cCB8'),
    'USDT_TRON': os.getenv('FOUNDER_USDT_TRON_ADDRESS', 'TBA'),
    'USDC_ETH': os.getenv('FOUNDER_USDC_ADDRESS', '0x4e90944C093f7727ff89a30AF96A556deB95cCB8'),
    'USDC_POLYGON': os.getenv('FOUNDER_USDC_ADDRESS', '0x4e90944C093f7727ff89a30AF96A556deB95cCB8'),
    'USDC_SOLANA': os.getenv('FOUNDER_USDC_SOLANA_ADDRESS', 'TBA'),
    'BTC': os.getenv('FOUNDER_BTC_ADDRESS', '3NaWi32bU27P6Dbo6FQTauyBWghmEnApix'),
    'ETH': os.getenv('FOUNDER_ETH_ADDRESS', '0x4e90944C093f7727ff89a30AF96A556deB95cCB8'),
    'DAI': os.getenv('FOUNDER_DAI_ADDRESS', '0x4e90944C093f7727ff89a30AF96A556deB95cCB8')
}

# Database setup
DB_PATH = 'crm/crm.db'


class DarPayCrypto:
    """
    DarPay™ Cryptocurrency Payment Processor
    
    100% crypto-native payment system - NO FIAT
    """
    
    def __init__(self):
        self.port = DARPAY_PORT
        self.name = "DarPay™ Crypto"
        self.version = "3.0.0"
        self.start_time = datetime.now()
        self.invoice_counter = 0
        
        # Initialize database
        self._init_database()
        
        logger.info(f"🚀 {self.name} v{self.version} initialized - CRYPTO ONLY")
        logger.info(f"💎 Supported: USDT, USDC, BTC, ETH, DAI")
        logger.info(f"❌ NO FIAT - Pure crypto economy")
    
    def _init_database(self):
        """Initialize database schema for crypto payments"""
        os.makedirs('crm', exist_ok=True)
        
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            
            # Crypto invoices table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS crypto_invoices (
                    invoice_id TEXT PRIMARY KEY,
                    agent_name TEXT NOT NULL,
                    customer_email TEXT,
                    customer_name TEXT,
                    amount_usd REAL NOT NULL,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP,
                    status TEXT DEFAULT 'pending',
                    payment_url TEXT,
                    accepted_coins TEXT
                )
            ''')
            
            # Crypto transactions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS crypto_transactions (
                    tx_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    invoice_id TEXT NOT NULL,
                    coin_type TEXT NOT NULL,
                    network TEXT,
                    amount_crypto TEXT NOT NULL,
                    amount_usd REAL NOT NULL,
                    wallet_address TEXT NOT NULL,
                    tx_hash TEXT,
                    block_number INTEGER,
                    confirmations INTEGER DEFAULT 0,
                    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    confirmed_at TIMESTAMP,
                    status TEXT DEFAULT 'pending',
                    FOREIGN KEY (invoice_id) REFERENCES crypto_invoices(invoice_id)
                )
            ''')
            
            # Revenue distributions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS crypto_revenue_distributions (
                    distribution_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    invoice_id TEXT NOT NULL,
                    total_amount_usd REAL NOT NULL,
                    founder_amount REAL NOT NULL,
                    validators_amount REAL NOT NULL,
                    hardware_amount REAL NOT NULL,
                    ecosystem_amount REAL NOT NULL,
                    zakat_amount REAL NOT NULL,
                    distributed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (invoice_id) REFERENCES crypto_invoices(invoice_id)
                )
            ''')
            
            conn.commit()
            logger.info("✅ Database initialized with crypto tables")
    
    def get_crypto_price(self, coin: str) -> float:
        """Get live cryptocurrency price in USD"""
        try:
            # CoinGecko API (free, no key needed)
            coin_ids = {
                'BTC': 'bitcoin',
                'ETH': 'ethereum',
                'USDT': 'tether',
                'USDC': 'usd-coin',
                'DAI': 'dai'
            }
            
            coin_id = coin_ids.get(coin.upper())
            if not coin_id:
                return 1.0  # Default for stablecoins
            
            url = f"https://api.coingecko.com/api/v3/simple/price?ids={coin_id}&vs_currencies=usd"
            response = requests.get(url, timeout=5)
            data = response.json()
            
            price = data[coin_id]['usd']
            logger.info(f"💰 {coin} price: ${price}")
            return float(price)
            
        except Exception as e:
            logger.warning(f"⚠️ Failed to fetch {coin} price, using defaults: {e}")
            # Fallback prices
            defaults = {'USDT': 1.0, 'USDC': 1.0, 'DAI': 1.0, 'BTC': 42000, 'ETH': 3200}
            return defaults.get(coin.upper(), 1.0)
    
    def generate_qr_code(self, data: str) -> str:
        """Generate QR code and return as base64 data URL"""
        try:
            qr = qrcode.QRCode(version=1, box_size=10, border=4)
            qr.add_data(data)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            
            # Convert to base64
            buffer = io.BytesIO()
            img.save(buffer, format='PNG')
            buffer.seek(0)
            img_base64 = base64.b64encode(buffer.getvalue()).decode()
            
            return f"data:image/png;base64,{img_base64}"
            
        except Exception as e:
            logger.error(f"❌ QR code generation failed: {e}")
            return ""
    
    def create_invoice(self, agent_name: str, amount_usd: float, 
                      customer_email: str = None, customer_name: str = None,
                      description: str = None, 
                      accepted_coins: List[str] = None) -> Dict:
        """
        Create crypto payment invoice
        
        Args:
            agent_name: Name of AI agent creating invoice
            amount_usd: Amount in USD
            customer_email: Customer's email
            customer_name: Customer's name
            description: Payment description
            accepted_coins: List of accepted coins (default: all)
        
        Returns:
            Invoice details with payment URLs and QR codes
        """
        try:
            if accepted_coins is None:
                accepted_coins = ['USDT', 'USDC', 'BTC', 'ETH', 'DAI']
            
            # Generate invoice ID
            self.invoice_counter += 1
            timestamp = datetime.now().strftime('%Y%m%d')
            invoice_id = f"INV-CRYPTO-{timestamp}-{self.invoice_counter:03d}"
            
            # Calculate expiration (5 days)
            expires_at = datetime.now() + timedelta(days=5)
            
            # Generate payment URL
            payment_url = f"http://localhost:{self.port}/pay/crypto/{invoice_id}"
            
            # Calculate crypto amounts and generate QR codes
            addresses = {}
            amounts = {}
            qr_codes = {}
            
            for coin in accepted_coins:
                coin = coin.upper()
                
                # Get crypto price
                price = self.get_crypto_price(coin)
                amount_crypto = amount_usd / price
                
                # Get wallet address
                if coin in ['USDT', 'USDC']:
                    # Use Ethereum address for stablecoins by default
                    wallet = CRYPTO_WALLETS.get(f'{coin}_ETH', CRYPTO_WALLETS.get(coin, ''))
                else:
                    wallet = CRYPTO_WALLETS.get(coin, '')
                
                if not wallet or wallet == 'TBA':
                    logger.warning(f"⚠️ No wallet configured for {coin}")
                    continue
                
                addresses[coin] = wallet
                amounts[coin] = f"{amount_crypto:.8f}"
                
                # Generate QR code
                qr_data = wallet  # Simple address QR code
                qr_codes[coin] = self.generate_qr_code(qr_data)
            
            # Save to database
            with sqlite3.connect(DB_PATH) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO crypto_invoices 
                    (invoice_id, agent_name, customer_email, customer_name, 
                     amount_usd, description, expires_at, payment_url, accepted_coins)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    invoice_id, agent_name, customer_email, customer_name,
                    amount_usd, description, expires_at, payment_url,
                    json.dumps(accepted_coins)
                ))
                conn.commit()
            
            logger.info(f"✅ Created crypto invoice {invoice_id} for ${amount_usd} by {agent_name}")
            
            return {
                'success': True,
                'invoice_id': invoice_id,
                'agent_name': agent_name,
                'amount_usd': amount_usd,
                'description': description,
                'customer_email': customer_email,
                'customer_name': customer_name,
                'payment_url': payment_url,
                'expires_at': expires_at.isoformat(),
                'accepted_coins': accepted_coins,
                'addresses': addresses,
                'amounts': amounts,
                'qr_codes': qr_codes,
                'status': 'pending'
            }
            
        except Exception as e:
            logger.error(f"❌ Invoice creation failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def calculate_revenue_distribution(self, amount_usd: float) -> Dict:
        """
        Calculate revenue distribution enforcing 30% founder royalty
        
        Args:
            amount_usd: Total amount in USD
        
        Returns:
            Distribution breakdown
        """
        distribution = {
            'total': amount_usd,
            'founder_royalty': amount_usd * REVENUE_DISTRIBUTION['founder_royalty'],
            'ai_validators': amount_usd * REVENUE_DISTRIBUTION['ai_validators'],
            'hardware_hosts': amount_usd * REVENUE_DISTRIBUTION['hardware_hosts'],
            'ecosystem': amount_usd * REVENUE_DISTRIBUTION['ecosystem'],
            'zakat': amount_usd * REVENUE_DISTRIBUTION['zakat']
        }
        
        # Verify 30% founder share
        if abs(distribution['founder_royalty'] - (amount_usd * 0.30)) > 0.01:
            logger.error("🚨 FOUNDER ROYALTY VIOLATION DETECTED!")
            raise ValueError("Founder royalty must be exactly 30%")
        
        logger.info(f"💰 Distribution calculated: {distribution}")
        return distribution
    
    def get_invoice(self, invoice_id: str) -> Optional[Dict]:
        """Get invoice details"""
        try:
            with sqlite3.connect(DB_PATH) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM crypto_invoices WHERE invoice_id = ?
                ''', (invoice_id,))
                
                row = cursor.fetchone()
                if not row:
                    return None
                
                columns = [desc[0] for desc in cursor.description]
                invoice = dict(zip(columns, row))
                
                # Parse accepted_coins JSON
                if invoice.get('accepted_coins'):
                    invoice['accepted_coins'] = json.loads(invoice['accepted_coins'])
                
                return invoice
                
        except Exception as e:
            logger.error(f"❌ Failed to get invoice: {e}")
            return None
    
    def record_payment(self, invoice_id: str, coin_type: str, 
                      amount_crypto: str, tx_hash: str = None) -> Dict:
        """
        Record cryptocurrency payment
        
        Args:
            invoice_id: Invoice ID
            coin_type: Cryptocurrency type (USDT, BTC, etc.)
            amount_crypto: Amount of crypto received
            tx_hash: Blockchain transaction hash
        
        Returns:
            Payment confirmation
        """
        try:
            # Get invoice
            invoice = self.get_invoice(invoice_id)
            if not invoice:
                return {'success': False, 'error': 'Invoice not found'}
            
            if invoice['status'] == 'paid':
                return {'success': False, 'error': 'Invoice already paid'}
            
            # Get crypto price
            price = self.get_crypto_price(coin_type)
            amount_usd = float(amount_crypto) * price
            
            # Save transaction
            with sqlite3.connect(DB_PATH) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO crypto_transactions
                    (invoice_id, coin_type, amount_crypto, amount_usd, 
                     wallet_address, tx_hash, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'confirmed')
                ''', (
                    invoice_id, coin_type, amount_crypto, amount_usd,
                    CRYPTO_WALLETS.get(coin_type, ''), tx_hash
                ))
                
                # Update invoice status
                cursor.execute('''
                    UPDATE crypto_invoices 
                    SET status = 'paid' 
                    WHERE invoice_id = ?
                ''', (invoice_id,))
                
                # Calculate and save distribution
                distribution = self.calculate_revenue_distribution(amount_usd)
                cursor.execute('''
                    INSERT INTO crypto_revenue_distributions
                    (invoice_id, total_amount_usd, founder_amount, 
                     validators_amount, hardware_amount, ecosystem_amount, zakat_amount)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    invoice_id, distribution['total'], distribution['founder_royalty'],
                    distribution['ai_validators'], distribution['hardware_hosts'],
                    distribution['ecosystem'], distribution['zakat']
                ))
                
                conn.commit()
            
            logger.info(f"✅ Payment recorded: {amount_crypto} {coin_type} (${amount_usd}) for {invoice_id}")
            
            return {
                'success': True,
                'invoice_id': invoice_id,
                'coin_type': coin_type,
                'amount_crypto': amount_crypto,
                'amount_usd': amount_usd,
                'tx_hash': tx_hash,
                'distribution': distribution,
                'status': 'paid'
            }
            
        except Exception as e:
            logger.error(f"❌ Payment recording failed: {e}")
            return {'success': False, 'error': str(e)}


# Global DarPay instance
darpay = DarPayCrypto()


# Flask API Routes
@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    uptime = (datetime.now() - darpay.start_time).total_seconds()
    
    return jsonify({
        'status': 'healthy',
        'service': darpay.name,
        'version': darpay.version,
        'uptime_seconds': uptime,
        'payment_methods': ['USDT', 'USDC', 'BTC', 'ETH', 'DAI'],
        'fiat_accepted': False,
        'crypto_only': True,
        'founder_royalty': '30%',
        'timestamp': datetime.now().isoformat()
    })


@app.route('/crypto/invoice/create', methods=['POST'])
def create_crypto_invoice():
    """Create crypto payment invoice"""
    try:
        data = request.get_json()
        
        required_fields = ['agent_name', 'amount_usd']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        invoice = darpay.create_invoice(
            agent_name=data['agent_name'],
            amount_usd=float(data['amount_usd']),
            customer_email=data.get('customer_email'),
            customer_name=data.get('customer_name'),
            description=data.get('description'),
            accepted_coins=data.get('accepted_coins')
        )
        
        if invoice['success']:
            return jsonify(invoice), 201
        else:
            return jsonify(invoice), 500
            
    except Exception as e:
        logger.error(f"❌ Invoice creation endpoint failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/crypto/payment/record', methods=['POST'])
def record_crypto_payment():
    """Record cryptocurrency payment"""
    try:
        data = request.get_json()
        
        required_fields = ['invoice_id', 'coin_type', 'amount_crypto']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        result = darpay.record_payment(
            invoice_id=data['invoice_id'],
            coin_type=data['coin_type'],
            amount_crypto=data['amount_crypto'],
            tx_hash=data.get('tx_hash')
        )
        
        if result['success']:
            return jsonify(result), 200
        else:
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"❌ Payment recording endpoint failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/invoice/<invoice_id>', methods=['GET'])
def get_invoice_details(invoice_id):
    """Get invoice details"""
    invoice = darpay.get_invoice(invoice_id)
    
    if invoice:
        return jsonify({
            'success': True,
            'invoice': invoice
        }), 200
    else:
        return jsonify({
            'success': False,
            'error': 'Invoice not found'
        }), 404


@app.route('/pay/crypto/<invoice_id>', methods=['GET'])
def crypto_payment_page(invoice_id):
    """Render crypto payment page"""
    invoice = darpay.get_invoice(invoice_id)
    
    if not invoice:
        return "Invoice not found", 404
    
    if invoice['status'] == 'paid':
        return render_template_string(PAYMENT_SUCCESS_TEMPLATE, invoice=invoice)
    
    # Recreate payment details
    invoice_data = darpay.create_invoice(
        agent_name=invoice['agent_name'],
        amount_usd=invoice['amount_usd'],
        customer_email=invoice['customer_email'],
        customer_name=invoice['customer_name'],
        description=invoice['description'],
        accepted_coins=invoice.get('accepted_coins', ['USDT', 'USDC', 'BTC', 'ETH'])
    )
    
    return render_template_string(PAYMENT_PAGE_TEMPLATE, invoice=invoice_data)


# HTML Templates
PAYMENT_PAGE_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DarPay™ Crypto Invoice - {{ invoice.invoice_id }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .invoice-id {
            opacity: 0.9;
            font-size: 14px;
        }
        .amount {
            background: #f8f9fa;
            padding: 30px;
            text-align: center;
            border-bottom: 2px solid #e9ecef;
        }
        .amount-usd {
            font-size: 48px;
            font-weight: bold;
            color: #1e3c72;
        }
        .description {
            color: #6c757d;
            margin-top: 10px;
        }
        .payment-methods {
            padding: 30px;
        }
        .payment-method {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        .payment-method:hover {
            border-color: #667eea;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
        }
        .crypto-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        .crypto-name {
            font-size: 20px;
            font-weight: bold;
            color: #1e3c72;
        }
        .recommended {
            background: #28a745;
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }
        .crypto-amount {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 15px;
            color: #2a5298;
        }
        .qr-code {
            text-align: center;
            margin: 20px 0;
        }
        .qr-code img {
            max-width: 200px;
            border: 4px solid #f8f9fa;
            border-radius: 8px;
        }
        .address {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 12px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            word-break: break-all;
            margin: 10px 0;
        }
        .copy-btn {
            background: #667eea;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
            margin-top: 10px;
        }
        .copy-btn:hover {
            background: #5568d3;
        }
        .networks {
            color: #6c757d;
            font-size: 14px;
            margin-top: 10px;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #6c757d;
            font-size: 14px;
        }
        .status {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 10px 0;
        }
        .status-icon {
            width: 16px;
            height: 16px;
            background: #ffc107;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        .expires {
            color: #dc3545;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💎 DarPay™ Crypto Invoice</h1>
            <div class="invoice-id">{{ invoice.invoice_id }}</div>
            <div style="margin-top: 10px; opacity: 0.8;">QuranChain - {{ invoice.description or 'Payment' }}</div>
        </div>
        
        <div class="amount">
            <div class="amount-usd">${{ "%.2f"|format(invoice.amount_usd) }} USD</div>
            {% if invoice.customer_name %}
            <div class="description">For: {{ invoice.customer_name }}</div>
            {% endif %}
        </div>
        
        <div class="payment-methods">
            <h2 style="margin-bottom: 20px; color: #1e3c72;">Choose Your Payment Method:</h2>
            
            {% for coin in invoice.accepted_coins %}
            {% if coin in invoice.addresses %}
            <div class="payment-method">
                <div class="crypto-header">
                    <div class="crypto-name">
                        {% if coin == 'USDT' %}💵 USDT (Tether)
                        {% elif coin == 'USDC' %}💵 USDC (USD Coin)
                        {% elif coin == 'BTC' %}₿ Bitcoin
                        {% elif coin == 'ETH' %}⟠ Ethereum
                        {% elif coin == 'DAI' %}💵 DAI
                        {% endif %}
                    </div>
                    {% if coin == 'USDT' %}
                    <div class="recommended">RECOMMENDED</div>
                    {% endif %}
                </div>
                
                <div class="crypto-amount">{{ invoice.amounts[coin] }} {{ coin }}</div>
                
                {% if invoice.qr_codes[coin] %}
                <div class="qr-code">
                    <img src="{{ invoice.qr_codes[coin] }}" alt="{{ coin }} QR Code">
                </div>
                {% endif %}
                
                <div class="address">{{ invoice.addresses[coin] }}</div>
                
                <button class="copy-btn" onclick="copyAddress('{{ invoice.addresses[coin] }}', this)">
                    📋 Copy Address
                </button>
                
                {% if coin in ['USDT', 'USDC'] %}
                <div class="networks">Networks: Ethereum • Polygon • BSC • Tron</div>
                {% endif %}
            </div>
            {% endif %}
            {% endfor %}
        </div>
        
        <div class="footer">
            <div class="status">
                <div class="status-icon"></div>
                <div>Payment Status: Waiting for payment...</div>
            </div>
            <div style="margin-top: 10px;">
                <span class="expires">⏱️ Expires:</span> {{ invoice.expires_at[:10] }}
            </div>
            <div style="margin-top: 15px; font-size: 12px;">
                ℹ️ Send EXACTLY the amount shown to ensure auto-detection<br>
                ⚡ Payment detected within 30 seconds - 5 minutes
            </div>
            <div style="margin-top: 20px; font-size: 12px; opacity: 0.7;">
                Powered by DarPay™ - QuranChain© 2026
            </div>
        </div>
    </div>
    
    <script>
        function copyAddress(address, button) {
            navigator.clipboard.writeText(address).then(() => {
                const originalText = button.textContent;
                button.textContent = '✅ Copied!';
                button.style.background = '#28a745';
                setTimeout(() => {
                    button.textContent = originalText;
                    button.style.background = '#667eea';
                }, 2000);
            });
        }
        
        // Auto-refresh every 10 seconds to check payment status
        setInterval(() => {
            location.reload();
        }, 10000);
    </script>
</body>
</html>
'''

PAYMENT_SUCCESS_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - {{ invoice.invoice_id }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 60px 40px;
            text-align: center;
            max-width: 500px;
        }
        .checkmark {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: #28a745;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            font-size: 48px;
        }
        h1 {
            color: #28a745;
            margin-bottom: 20px;
        }
        .invoice-id {
            color: #6c757d;
            margin-bottom: 30px;
        }
        .amount {
            font-size: 36px;
            font-weight: bold;
            color: #1e3c72;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="checkmark">✅</div>
        <h1>Payment Successful!</h1>
        <div class="invoice-id">Invoice: {{ invoice.invoice_id }}</div>
        <div class="amount">${{ "%.2f"|format(invoice.amount_usd) }} USD</div>
        <div style="color: #6c757d;">
            Your payment has been received and confirmed.<br>
            Thank you for using DarPay™!
        </div>
    </div>
</body>
</html>
'''


if __name__ == '__main__':
    logger.info(f"🚀 Starting {darpay.name} v{darpay.version} on port {DARPAY_PORT}")
    app.run(host='0.0.0.0', port=DARPAY_PORT, debug=False)
