#!/usr/bin/env python3
"""
🖥️📱 MESH TALK OS AGENT - OPERATING SYSTEM SPECIALIST
═══════════════════════════════════════════════════════════════════════════════
Specialized AI agent for MeshTalkOs operations, system administration,
network configuration, kernel optimization, and cross-platform compatibility.

Capabilities:
  🖥️ System Administration & Monitoring
  🌐 Network Stack Configuration
  ⚙️ Kernel Parameter Optimization
  🔒 Security Policy Management
  📊 Performance Analytics
  🔄 Service Management
  🛠️ Cross-Platform Compatibility
  📈 Resource Optimization

Author: QuranChain AI Agent Team
Date: 2026-01-15
"""

import asyncio
import json
import logging
import platform
import psutil
import socket
import subprocess
import threading
import time
from blockchain_logging_handler import setup_blockchain_logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Any, Optional, Set, Tuple
import uuid
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import QuranChain dependencies
try:
    from cosmos_blockchain_integration import cosmos_blockchain_client, COSMOS_CONFIG
    COSMOS_ENABLED = True
except ImportError:
    COSMOS_ENABLED = False
    cosmos_blockchain_client = None

# Configure logging
setup_blockchain_logging()
logger = logging.getLogger(__name__)

class SystemStatus(Enum):
    """Enumeration of system states"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    MAINTENANCE = "maintenance"
    OFFLINE = "offline"

class ServiceStatus(Enum):
    """Enumeration of service states"""
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"
    STARTING = "starting"
    STOPPING = "stopping"

@dataclass
class SystemMetrics:
    """System performance metrics"""
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    disk_usage: Dict[str, float] = field(default_factory=dict)
    network_io: Dict[str, int] = field(default_factory=dict)
    load_average: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    uptime_seconds: int = 0
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class NetworkInterface:
    """Network interface information"""
    name: str
    address: str
    netmask: str
    broadcast: str = ""
    mac_address: str = ""
    status: str = "down"
    speed_mbps: int = 0

@dataclass
class SystemService:
    """System service information"""
    name: str
    status: ServiceStatus
    description: str = ""
    pid: Optional[int] = None
    memory_mb: float = 0.0
    cpu_percent: float = 0.0

class MeshTalkOsAgent:
    """
    MeshTalkOs Agent - Specialized AI for operating system operations
    """

    def __init__(self):
        self.node_id = str(uuid.uuid4())
        self.system_info = self._get_system_info()
        self.services: Dict[str, SystemService] = {}
        self.network_interfaces: Dict[str, NetworkInterface] = {}
        self.monitoring_active = False
        self.monitoring_thread: Optional[threading.Thread] = None
        self.metrics_history: List[SystemMetrics] = []

        logger.info(f"🖥️ MeshTalkOs Agent initialized on {self.system_info['os']} {self.system_info['version']}")

    def _get_system_info(self) -> Dict[str, Any]:
        """Get comprehensive system information"""
        return {
            "os": platform.system(),
            "version": platform.version(),
            "release": platform.release(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "hostname": socket.gethostname(),
            "python_version": platform.python_version(),
            "cpu_count": psutil.cpu_count(),
            "memory_total_gb": round(psutil.virtual_memory().total / (1024**3), 2)
        }

    def start_system_monitoring(self):
        """Start system monitoring"""
        if self.monitoring_active:
            logger.warning("⚠️ System monitoring already active")
            return

        logger.info("📊 Starting system monitoring...")
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

    def stop_system_monitoring(self):
        """Stop system monitoring"""
        logger.info("🛑 Stopping system monitoring...")
        self.monitoring_active = False
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)

    def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.monitoring_active:
            try:
                metrics = self._collect_system_metrics()
                self.metrics_history.append(metrics)

                # Keep only last 1000 metrics
                if len(self.metrics_history) > 1000:
                    self.metrics_history = self.metrics_history[-1000:]

                # Check for alerts
                self._check_system_alerts(metrics)

                time.sleep(30)  # Monitor every 30 seconds

            except Exception as e:
                logger.error(f"❌ Monitoring error: {e}")
                time.sleep(5)

    def _collect_system_metrics(self) -> SystemMetrics:
        """Collect current system metrics"""
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk_usage = {}
        network_io = {}

        # Disk usage
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disk_usage[partition.mountpoint] = usage.percent
            except Exception:
                continue

        # Network I/O
        net_io = psutil.net_io_counters()
        network_io = {
            "bytes_sent": net_io.bytes_sent,
            "bytes_recv": net_io.bytes_recv,
            "packets_sent": net_io.packets_sent,
            "packets_recv": net_io.packets_recv
        }

        # Load average (Unix-like systems)
        load_average = (0.0, 0.0, 0.0)
        try:
            load_average = os.getloadavg()
        except AttributeError:
            # Windows doesn't have getloadavg
            pass

        return SystemMetrics(
            cpu_percent=cpu_percent,
            memory_percent=memory.percent,
            disk_usage=disk_usage,
            network_io=network_io,
            load_average=load_average,
            uptime_seconds=int(time.time() - psutil.boot_time())
        )

    def _check_system_alerts(self, metrics: SystemMetrics):
        """Check for system alerts based on metrics"""
        alerts = []

        if metrics.cpu_percent > 90:
            alerts.append(f"⚠️ High CPU usage: {metrics.cpu_percent}%")
        if metrics.memory_percent > 90:
            alerts.append(f"⚠️ High memory usage: {metrics.memory_percent}%")

        for mount_point, usage in metrics.disk_usage.items():
            if usage > 90:
                alerts.append(f"⚠️ High disk usage on {mount_point}: {usage}%")

        for alert in alerts:
            logger.warning(alert)

    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        current_metrics = self._collect_system_metrics() if self.monitoring_active else None

        return {
            "system_info": self.system_info,
            "current_metrics": {
                "cpu_percent": current_metrics.cpu_percent if current_metrics else 0,
                "memory_percent": current_metrics.memory_percent if current_metrics else 0,
                "disk_usage": current_metrics.disk_usage if current_metrics else {},
                "network_io": current_metrics.network_io if current_metrics else {},
                "load_average": current_metrics.load_average if current_metrics else (0, 0, 0),
                "uptime_seconds": current_metrics.uptime_seconds if current_metrics else 0
            } if current_metrics else {},
            "services": {name: {
                "status": service.status.value,
                "description": service.description,
                "pid": service.pid,
                "memory_mb": service.memory_mb,
                "cpu_percent": service.cpu_percent
            } for name, service in self.services.items()},
            "network_interfaces": {name: {
                "address": iface.address,
                "netmask": iface.netmask,
                "status": iface.status,
                "speed_mbps": iface.speed_mbps
            } for name, iface in self.network_interfaces.items()},
            "monitoring_active": self.monitoring_active,
            "metrics_history_count": len(self.metrics_history)
        }

    def scan_network_interfaces(self):
        """Scan and update network interfaces"""
        logger.info("🔍 Scanning network interfaces...")

        self.network_interfaces.clear()

        # Get network interfaces
        net_if_addrs = psutil.net_if_addrs()
        net_if_stats = psutil.net_if_stats()

        for interface_name, addresses in net_if_addrs.items():
            for addr in addresses:
                if addr.family == socket.AF_INET:  # IPv4
                    iface = NetworkInterface(
                        name=interface_name,
                        address=addr.address,
                        netmask=addr.netmask or "",
                        broadcast=addr.broadcast or ""
                    )

                    # Get interface stats
                    if interface_name in net_if_stats:
                        stats = net_if_stats[interface_name]
                        iface.status = "up" if stats.isup else "down"
                        iface.speed_mbps = stats.speed

                    self.network_interfaces[interface_name] = iface
                    break  # Use first IPv4 address

        logger.info(f"📡 Found {len(self.network_interfaces)} network interfaces")

    def scan_system_services(self):
        """Scan and update system services"""
        logger.info("🔍 Scanning system services...")

        self.services.clear()

        # Get all running processes
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info', 'status']):
            try:
                service = SystemService(
                    name=proc.info['name'],
                    status=ServiceStatus.RUNNING if proc.info['status'] == 'running' else ServiceStatus.STOPPED,
                    pid=proc.info['pid'],
                    memory_mb=round(proc.info['memory_info'].rss / (1024**2), 2) if proc.info['memory_info'] else 0,
                    cpu_percent=round(proc.info['cpu_percent'], 2)
                )
                self.services[proc.info['name']] = service
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        logger.info(f"⚙️ Found {len(self.services)} running services")

    def execute_system_command(self, command: str, timeout: int = 30) -> Dict[str, Any]:
        """Execute a system command safely"""
        logger.info(f"⚡ Executing command: {command}")

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )

            return {
                "success": result.returncode == 0,
                "return_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "command": command
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": f"Command timed out after {timeout} seconds",
                "command": command
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "command": command
            }

    def optimize_system_performance(self) -> Dict[str, Any]:
        """Apply system performance optimizations"""
        logger.info("⚡ Optimizing system performance...")

        optimizations = []

        # Clear system cache (Linux)
        if platform.system() == "Linux":
            result = self.execute_system_command("sudo sync && sudo echo 3 > /proc/sys/vm/drop_caches")
            if result["success"]:
                optimizations.append("System cache cleared")
            else:
                optimizations.append(f"Cache clear failed: {result.get('error', 'Unknown error')}")

        # Optimize network settings
        network_opts = self._optimize_network_settings()
        optimizations.extend(network_opts)

        # Clean up temporary files
        temp_clean = self._cleanup_temp_files()
        optimizations.extend(temp_clean)

        return {
            "success": True,
            "optimizations_applied": optimizations,
            "timestamp": datetime.now().isoformat()
        }

    def _optimize_network_settings(self) -> List[str]:
        """Optimize network settings"""
        optimizations = []

        # Linux network optimizations
        if platform.system() == "Linux":
            commands = [
                "sudo sysctl -w net.core.somaxconn=65536",
                "sudo sysctl -w net.ipv4.tcp_max_syn_backlog=65536",
                "sudo sysctl -w net.core.netdev_max_backlog=5000"
            ]

            for cmd in commands:
                result = self.execute_system_command(cmd)
                if result["success"]:
                    optimizations.append(f"Applied: {cmd}")
                else:
                    optimizations.append(f"Failed: {cmd} - {result.get('error', 'Unknown')}")

        return optimizations

    def _cleanup_temp_files(self) -> List[str]:
        """Clean up temporary files"""
        cleanup_actions = []

        temp_dirs = ["/tmp", "/var/tmp"]
        for temp_dir in temp_dirs:
            if os.path.exists(temp_dir):
                try:
                    # Remove old files (older than 7 days)
                    result = self.execute_system_command(f"find {temp_dir} -type f -mtime +7 -delete 2>/dev/null || true")
                    cleanup_actions.append(f"Cleaned {temp_dir}")
                except Exception as e:
                    cleanup_actions.append(f"Failed to clean {temp_dir}: {e}")

        return cleanup_actions

    def get_security_status(self) -> Dict[str, Any]:
        """Get system security status"""
        security_info = {
            "firewall_status": "unknown",
            "selinux_status": "unknown",
            "open_ports": [],
            "failed_login_attempts": 0,
            "last_security_scan": datetime.now().isoformat()
        }

        # Check firewall status (Linux)
        if platform.system() == "Linux":
            # UFW
            ufw_result = self.execute_system_command("sudo ufw status | head -1")
            if "active" in ufw_result.get("stdout", "").lower():
                security_info["firewall_status"] = "active (UFW)"
            else:
                # iptables
                iptables_result = self.execute_system_command("sudo iptables -L | head -1")
                if iptables_result["success"]:
                    security_info["firewall_status"] = "active (iptables)"

            # SELinux
            selinux_result = self.execute_system_command("sestatus | grep 'SELinux status' | awk '{print $3}'")
            if selinux_result["success"]:
                security_info["selinux_status"] = selinux_result["stdout"].strip()

        # Check open ports
        try:
            import socket
            for port in range(1, 1025):  # Well-known ports
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.1)
                result = sock.connect_ex(('127.0.0.1', port))
                if result == 0:
                    security_info["open_ports"].append(port)
                sock.close()
        except Exception as e:
            logger.warning(f"❌ Error scanning ports: {e}")

        return security_info

# ═══════════════════════════════════════════════════════════════════════════════
# SINGLETON INSTANCE
# ═══════════════════════════════════════════════════════════════════════════════

meshtalk_os_agent = MeshTalkOsAgent()

# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("🖥️📱 MeshTalkOs Agent Test")
    print("=" * 50)

    agent = MeshTalkOsAgent()

    try:
        # Start monitoring
        agent.start_system_monitoring()

        # Scan system
        agent.scan_network_interfaces()
        agent.scan_system_services()

        # Get status
        status = agent.get_system_status()
        print(json.dumps(status, indent=2, default=str))

        # Test command execution
        cmd_result = agent.execute_system_command("echo 'Hello from MeshTalkOs Agent'")
        print(f"Command result: {cmd_result}")

        # Keep running for a bit
        time.sleep(10)

    except KeyboardInterrupt:
        print("\n🛑 Shutting down MeshTalkOs Agent...")
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        agent.stop_system_monitoring()