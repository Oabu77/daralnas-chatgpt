#!/usr/bin/env python3
"""
🛡️ QURANCHAIN SECURITY AI AGENT 🛡️
═══════════════════════════════════════════════════════════════
24/7 AI-Powered Security Monitoring & Threat Detection
- Real-time intrusion detection
- Network traffic analysis
- System log monitoring
- Automated threat response
- Islamic compliance & halal security

© QuranChain™ | Omar Mohammad Abunadi™
═══════════════════════════════════════════════════════════════
"""

import os
import json
import time
import psutil
import socket
import sqlite3
import logging
import threading
import subprocess
import hashlib
import ipaddress
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime, timedelta
from flask import Flask, jsonify, request
from typing import Dict, List, Optional
import re

# Configuration
AGENT_NAME = "security_ai"
PORT = int(os.environ.get("SECURITY_AI_PORT", "9020"))
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOG_DIR = os.path.join(REPO_ROOT, "logs", "ai_workforce")
SECURITY_DB = os.path.join(REPO_ROOT, "databases", "security_monitoring.db")
LOG_FILE = os.path.join(LOG_DIR, f"{AGENT_NAME}.log")

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(os.path.dirname(SECURITY_DB), exist_ok=True)

app = Flask("security_ai")

# Global state
_security_state = {
    "threats_detected": 0,
    "intrusions_blocked": 0,
    "suspicious_ips": [],
    "system_alerts": [],
    "last_scan": None,
    "active_monitoring": True,
    "islamic_compliance_score": 100
}

# Security patterns to monitor
SUSPICIOUS_PATTERNS = {
    "sql_injection": [
        r"(\bUNION\b.*\bSELECT\b)",
        r"(\bDROP\b.*\bTABLE\b)",
        r"(\bDELETE\b.*\bFROM\b.*\bWHERE\b.*=.*\bOR\b.*=.*)",
        r"(\bINSERT\b.*\bINTO\b.*\bVALUES\b.*\bEXEC\b)",
    ],
    "xss_attempts": [
        r"(<script[^>]*>.*?</script>)",
        r"(javascript:)",
        r"(on\w+\s*=)",
        r"(<iframe[^>]*>)",
    ],
    "path_traversal": [
        r"(\.\./)",
        r"(\.\.\\)",
        r"(%2e%2e/)",
        r"(%2e%2e\\)",
    ],
    "command_injection": [
        r"(\|\s*\w+)",
        r"(;\s*\w+)",
        r"(`.*`)",
        r"(\$\(.*\))",
    ],
    "suspicious_headers": [
        r"(User-Agent:\s*.*sqlmap)",
        r"(User-Agent:\s*.*nmap)",
        r"(User-Agent:\s*.*metasploit)",
    ]
}

# Islamic compliance rules
ISLAMIC_SECURITY_RULES = {
    "no_haram_content": ["porn", "alcohol", "gambling", "interest"],
    "halal_business_only": True,
    "zakat_compliance": True,
    "privacy_protection": True,
    "ethical_monitoring": True
}

class SecurityMonitor:
    def __init__(self):
        self.logger = logging.getLogger("SecurityAI")
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(LOG_FILE)
        handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)

        self.threat_database = {}
        self.blocked_ips = set()
        self.monitoring_active = True

        # Initialize database
        self.init_database()

    def init_database(self):
        """Initialize security monitoring database"""
        try:
            conn = sqlite3.connect(SECURITY_DB)
            cur = conn.cursor()

            # Threats table
            cur.execute("""
                CREATE TABLE IF NOT EXISTS security_threats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    threat_type TEXT,
                    severity TEXT,
                    source_ip TEXT,
                    details TEXT,
                    timestamp INTEGER,
                    response_taken TEXT
                )
            """)

            # System logs table
            cur.execute("""
                CREATE TABLE IF NOT EXISTS system_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    log_type TEXT,
                    message TEXT,
                    severity TEXT,
                    timestamp INTEGER
                )
            """)

            # Islamic compliance table
            cur.execute("""
                CREATE TABLE IF NOT EXISTS islamic_compliance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    check_type TEXT,
                    status TEXT,
                    score INTEGER,
                    details TEXT,
                    timestamp INTEGER
                )
            """)

            conn.commit()
            conn.close()
            self.logger.info("Security database initialized")
        except Exception as e:
            self.logger.error(f"Database initialization failed: {e}")

    def log_threat(self, threat_type: str, severity: str, source_ip: str, details: str):
        """Log detected security threat"""
        try:
            conn = sqlite3.connect(SECURITY_DB)
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO security_threats (threat_type, severity, source_ip, details, timestamp, response_taken)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (threat_type, severity, source_ip, details, int(time.time()), "logged"))
            conn.commit()
            conn.close()

            _security_state["threats_detected"] += 1
            if source_ip not in _security_state["suspicious_ips"]:
                _security_state["suspicious_ips"].append(source_ip)

            self.logger.warning(f"THREAT DETECTED: {threat_type} from {source_ip} - {details}")
        except Exception as e:
            self.logger.error(f"Failed to log threat: {e}")

    def check_islamic_compliance(self) -> Dict:
        """Check Islamic compliance of security measures"""
        compliance_score = 100
        issues = []

        # Check for haram content monitoring
        if not ISLAMIC_SECURITY_RULES["no_haram_content"]:
            compliance_score -= 20
            issues.append("Haram content monitoring not active")

        # Check privacy protection
        if not ISLAMIC_SECURITY_RULES["privacy_protection"]:
            compliance_score -= 15
            issues.append("Privacy protection not enabled")

        # Check ethical monitoring
        if not ISLAMIC_SECURITY_RULES["ethical_monitoring"]:
            compliance_score -= 10
            issues.append("Ethical monitoring not active")

        # Log compliance check
        try:
            conn = sqlite3.connect(SECURITY_DB)
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO islamic_compliance (check_type, status, score, details, timestamp)
                VALUES (?, ?, ?, ?, ?)
            """, ("full_check", "completed", compliance_score, json.dumps(issues), int(time.time())))
            conn.commit()
            conn.close()
        except Exception as e:
            self.logger.error(f"Failed to log compliance: {e}")

        _security_state["islamic_compliance_score"] = compliance_score

        return {
            "score": compliance_score,
            "issues": issues,
            "compliant": compliance_score >= 80
        }

    def scan_for_threats(self, data: str, source_ip: str = "unknown") -> List[Dict]:
        """Scan data for security threats"""
        threats_found = []

        for threat_category, patterns in SUSPICIOUS_PATTERNS.items():
            for pattern in patterns:
                matches = re.findall(pattern, data, re.IGNORECASE)
                if matches:
                    threat = {
                        "type": threat_category,
                        "severity": "high" if threat_category in ["sql_injection", "command_injection"] else "medium",
                        "matches": matches[:5],  # Limit to first 5 matches
                        "source_ip": source_ip,
                        "timestamp": int(time.time())
                    }
                    threats_found.append(threat)

                    # Log the threat
                    self.log_threat(
                        threat_category,
                        threat["severity"],
                        source_ip,
                        f"Pattern matches: {len(matches)}"
                    )

        return threats_found

    def monitor_system_logs(self):
        """Monitor system logs for security events"""
        try:
            # Check auth.log for failed login attempts
            if os.path.exists("/var/log/auth.log"):
                with open("/var/log/auth.log", "r") as f:
                    lines = f.readlines()[-100:]  # Last 100 lines

                for line in lines:
                    if "Failed password" in line or "authentication failure" in line:
                        # Extract IP if available
                        ip_match = re.search(r'from (\d+\.\d+\.\d+\.\d+)', line)
                        source_ip = ip_match.group(1) if ip_match else "unknown"

                        self.log_threat("failed_auth", "medium", source_ip, "Failed authentication attempt")

            # Check syslog for suspicious activity
            if os.path.exists("/var/log/syslog"):
                with open("/var/log/syslog", "r") as f:
                    lines = f.readlines()[-50:]  # Last 50 lines

                for line in lines:
                    if any(keyword in line.lower() for keyword in ["attack", "exploit", "hack", "intrusion"]):
                        self.log_threat("system_log_alert", "high", "system", f"Suspicious log entry: {line[:100]}")

        except Exception as e:
            self.logger.error(f"System log monitoring failed: {e}")

    def monitor_network_traffic(self):
        """Monitor network connections for suspicious activity"""
        try:
            connections = psutil.net_connections()
            suspicious_ports = [22, 23, 3389, 5900]  # SSH, Telnet, RDP, VNC

            for conn in connections:
                if conn.status == 'ESTABLISHED':
                    local_port = conn.laddr.port if conn.laddr else None
                    remote_ip = conn.raddr.ip if conn.raddr else None

                    if local_port in suspicious_ports and remote_ip:
                        # Check if this is a known suspicious IP
                        if self.is_suspicious_ip(remote_ip):
                            self.log_threat("suspicious_connection", "high", remote_ip,
                                          f"Connection to suspicious port {local_port}")

        except Exception as e:
            self.logger.error(f"Network monitoring failed: {e}")

    def is_suspicious_ip(self, ip: str) -> bool:
        """Check if IP is in suspicious list"""
        # Simple check - in real implementation, use threat intelligence feeds
        suspicious_ranges = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]  # Private ranges for demo

        try:
            ip_obj = ipaddress.ip_address(ip)
            for network in suspicious_ranges:
                if ip_obj in ipaddress.ip_network(network):
                    return True
        except:
            pass

        return False

    def automated_response(self, threat: Dict):
        """Automated response to detected threats"""
        threat_type = threat.get("type")
        source_ip = threat.get("source_ip", "unknown")

        if threat_type in ["sql_injection", "command_injection"]:
            # Block the IP
            self.block_ip(source_ip)
            _security_state["intrusions_blocked"] += 1
            self.logger.info(f"🚫 BLOCKED IP: {source_ip} due to {threat_type}")

        elif threat_type == "failed_auth" and threat.get("count", 0) > 5:
            # Too many failed auth attempts
            self.block_ip(source_ip)
            self.logger.info(f"🚫 BLOCKED IP: {source_ip} due to excessive failed auth attempts")

    def block_ip(self, ip: str):
        """Block an IP address using iptables"""
        try:
            # Add to blocked IPs set
            self.blocked_ips.add(ip)

            # In a real system, you would use iptables or firewall rules
            # For demo purposes, we'll just log it
            self.logger.info(f"Would block IP: {ip} (iptables -A INPUT -s {ip} -j DROP)")

        except Exception as e:
            self.logger.error(f"Failed to block IP {ip}: {e}")

    def continuous_monitoring(self):
        """Main monitoring loop"""
        while self.monitoring_active:
            try:
                # Monitor system logs
                self.monitor_system_logs()

                # Monitor network traffic
                self.monitor_network_traffic()

                # Check Islamic compliance
                if int(time.time()) % 3600 == 0:  # Every hour
                    self.check_islamic_compliance()

                # Update last scan time
                _security_state["last_scan"] = datetime.now().isoformat()

                time.sleep(30)  # Check every 30 seconds

            except Exception as e:
                self.logger.error(f"Monitoring loop error: {e}")
                time.sleep(60)

# Initialize security monitor
security_monitor = SecurityMonitor()

# Start monitoring thread
monitoring_thread = threading.Thread(target=security_monitor.continuous_monitoring, daemon=True)
monitoring_thread.start()

@app.get('/health')
def health():
    return jsonify({
        "agent_id": f"{AGENT_NAME}_{int(time.time())}",
        "agent_type": AGENT_NAME,
        "status": "healthy",
        "monitoring_active": _security_state["active_monitoring"],
        "threats_detected": _security_state["threats_detected"],
        "intrusions_blocked": _security_state["intrusions_blocked"],
        "islamic_compliance_score": _security_state["islamic_compliance_score"]
    })

@app.get('/metrics')
def metrics():
    return jsonify(_security_state)

@app.get('/threats')
def get_threats():
    """Get recent security threats"""
    try:
        conn = sqlite3.connect(SECURITY_DB)
        cur = conn.cursor()
        cur.execute("""
            SELECT threat_type, severity, source_ip, details, timestamp
            FROM security_threats
            ORDER BY timestamp DESC
            LIMIT 50
        """)
        threats = cur.fetchall()
        conn.close()

        return jsonify({
            "threats": [
                {
                    "type": t[0],
                    "severity": t[1],
                    "source_ip": t[2],
                    "details": t[3],
                    "timestamp": t[4]
                } for t in threats
            ]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post('/scan')
def scan_request():
    """Scan provided data for threats"""
    data = request.json
    if not data or 'content' not in data:
        return jsonify({"error": "Missing 'content' field"}), 400

    source_ip = request.remote_addr or "unknown"
    threats = security_monitor.scan_for_threats(data['content'], source_ip)

    # Automated response for detected threats
    for threat in threats:
        security_monitor.automated_response(threat)

    return jsonify({
        "threats_found": len(threats),
        "threats": threats,
        "scanned_at": datetime.now().isoformat()
    })

@app.get('/compliance')
def get_compliance():
    """Get Islamic compliance status"""
    compliance = security_monitor.check_islamic_compliance()
    return jsonify(compliance)

@app.post('/block_ip')
def block_ip_request():
    """Manually block an IP address"""
    data = request.json
    if not data or 'ip' not in data:
        return jsonify({"error": "Missing 'ip' field"}), 400

    security_monitor.block_ip(data['ip'])
    return jsonify({"status": "IP blocked", "ip": data['ip']})

if __name__ == "__main__":
    print("🛡️ Starting QuranChain Security AI Agent...")
    print("   📊 Monitoring: Active 24/7")
    print("   🔒 Threat Detection: Enabled")
    print("   🕌 Islamic Compliance: Active")
    print(f"   🌐 Port: {PORT}")
    print("   📝 Logs: security_ai.log")
    app.run(host="0.0.0.0", port=PORT, debug=False)