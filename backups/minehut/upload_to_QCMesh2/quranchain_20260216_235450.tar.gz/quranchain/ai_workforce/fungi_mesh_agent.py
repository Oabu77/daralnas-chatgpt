#!/usr/bin/env python3
"""
🕸️🧬 FUNGI MESH AGENT - PEER-TO-PEER NETWORKING SPECIALIST
═══════════════════════════════════════════════════════════════════════════════
Specialized AI agent for Fungi Mesh networking operations, distributed systems,
peer-to-peer communication, and mesh network topology management.

Capabilities:
  🔗 Mesh Network Topology Management
  🌐 Peer Discovery & Connection
  🔐 End-to-End Encryption
  📊 Network Performance Monitoring
  🛡️ Security & Authentication
  🔄 Dynamic Routing Algorithms
  📡 Multi-hop Communication
  ⚡ Load Balancing & Failover

Author: QuranChain AI Agent Team
Date: 2026-01-15
"""

import asyncio
import json
import logging
import socket
import threading
import time
from blockchain_logging_handler import setup_blockchain_logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Any, Optional, Set, Tuple
import uuid
import hashlib
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import QuranChain dependencies
try:
    from cosmos_blockchain_integration import cosmos_blockchain_client, COSMOS_CONFIG
    COSMOS_ENABLED = True
except ImportError:
    COSMOS_ENABLED = False
    cosmos_blockchain_client = None

# Gaming Server Mesh - Free gaming infrastructure as mesh backbone
try:
    from organized.services.gaming_server_mesh import (
        gaming_mesh_engine, GamingPlatform, FREE_GAMING_SERVERS,
        GamingMeshHTTPHandler, generate_minecraft_plugin_java,
    )
    GAMING_MESH_LOADED = True
except ImportError:
    GAMING_MESH_LOADED = False

# Configure logging
setup_blockchain_logging()
logger = logging.getLogger(__name__)

class MeshNodeStatus(Enum):
    """Enumeration of mesh node states"""
    DISCOVERING = "discovering"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ACTIVE = "active"
    DISCONNECTED = "disconnected"
    FAILED = "failed"

class MessageType(Enum):
    """Types of messages in the mesh network"""
    DISCOVERY = "discovery"
    HANDSHAKE = "handshake"
    DATA = "data"
    ROUTING = "routing"
    HEARTBEAT = "heartbeat"
    ERROR = "error"

@dataclass
class MeshNode:
    """Represents a node in the Fungi Mesh network"""
    node_id: str
    address: str
    port: int
    public_key: str = ""
    status: MeshNodeStatus = MeshNodeStatus.DISCOVERING
    last_seen: datetime = field(default_factory=datetime.now)
    hop_count: int = 0
    connections: Set[str] = field(default_factory=set)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class MeshMessage:
    """Represents a message in the mesh network"""
    message_id: str
    sender_id: str
    receiver_id: str
    message_type: MessageType
    payload: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)
    ttl: int = 64  # Time to live (hops)
    signature: str = ""

class FungiMeshAgent:
    """
    Fungi Mesh Agent - Specialized AI for mesh networking operations
    """

    def __init__(self, node_id: str = None, listen_port: int = 8888):
        self.node_id = node_id or str(uuid.uuid4())
        self.listen_port = listen_port
        self.nodes: Dict[str, MeshNode] = {}
        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.running = False
        self.server_thread: Optional[threading.Thread] = None
        self.discovery_thread: Optional[threading.Thread] = None

        # Initialize local node
        self.local_node = MeshNode(
            node_id=self.node_id,
            address=self._get_local_ip(),
            port=self.listen_port,
            status=MeshNodeStatus.ACTIVE
        )
        self.nodes[self.node_id] = self.local_node

        logger.info(f"🕸️ FungiMesh Agent initialized - Node ID: {self.node_id}")

    def _get_local_ip(self) -> str:
        """Get local IP address"""
        try:
            # Create a socket to get local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            return local_ip
        except Exception:
            return "127.0.0.1"

    async def start_mesh_network(self):
        """Start the mesh network operations"""
        logger.info("🌐 Starting Fungi Mesh Network...")

        self.running = True

        # Start server thread
        self.server_thread = threading.Thread(target=self._run_server, daemon=True)
        self.server_thread.start()

        # Start discovery thread
        self.discovery_thread = threading.Thread(target=self._run_discovery, daemon=True)
        self.discovery_thread.start()

        # Start message processing
        await self._process_messages()

    def stop_mesh_network(self):
        """Stop the mesh network operations"""
        logger.info("🛑 Stopping Fungi Mesh Network...")
        self.running = False

        # Wait for threads to finish
        if self.server_thread and self.server_thread.is_alive():
            self.server_thread.join(timeout=5)
        if self.discovery_thread and self.discovery_thread.is_alive():
            self.discovery_thread.join(timeout=5)

    def _run_server(self):
        """Run the mesh network server"""
        try:
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_socket.bind((self.local_node.address, self.listen_port))
            server_socket.listen(5)
            server_socket.settimeout(1.0)  # Non-blocking

            logger.info(f"🖥️ Mesh server listening on {self.local_node.address}:{self.listen_port}")

            while self.running:
                try:
                    client_socket, address = server_socket.accept()
                    logger.info(f"🔗 New connection from {address}")
                    # Handle connection in separate thread
                    threading.Thread(
                        target=self._handle_connection,
                        args=(client_socket, address),
                        daemon=True
                    ).start()
                except socket.timeout:
                    continue
                except Exception as e:
                    logger.error(f"❌ Server error: {e}")

            server_socket.close()

        except Exception as e:
            logger.error(f"❌ Failed to start mesh server: {e}")

    def _handle_connection(self, client_socket: socket.socket, address: Tuple[str, int]):
        """Handle incoming connection"""
        try:
            # Receive message
            data = client_socket.recv(4096)
            if data:
                message = json.loads(data.decode('utf-8'))
                logger.info(f"📨 Received message from {address}: {message.get('message_type')}")

                # Process message
                asyncio.run(self._handle_message(message, address))

        except Exception as e:
            logger.error(f"❌ Error handling connection from {address}: {e}")
        finally:
            client_socket.close()

    def _run_discovery(self):
        """Run peer discovery"""
        while self.running:
            try:
                self._discover_peers()
                time.sleep(30)  # Discover every 30 seconds
            except Exception as e:
                logger.error(f"❌ Discovery error: {e}")
                time.sleep(5)

    def _discover_peers(self):
        """Discover peers in the network"""
        # Broadcast discovery message
        discovery_msg = MeshMessage(
            message_id=str(uuid.uuid4()),
            sender_id=self.node_id,
            receiver_id="broadcast",
            message_type=MessageType.DISCOVERY,
            payload={
                "node_info": {
                    "node_id": self.local_node.node_id,
                    "address": self.local_node.address,
                    "port": self.local_node.port,
                    "capabilities": ["mesh", "routing", "encryption"]
                }
            }
        )

        self._broadcast_message(discovery_msg)

    def _broadcast_message(self, message: MeshMessage):
        """Broadcast message to all known nodes"""
        message_dict = {
            "message_id": message.message_id,
            "sender_id": message.sender_id,
            "receiver_id": message.receiver_id,
            "message_type": message.message_type.value,
            "payload": message.payload,
            "timestamp": message.timestamp.isoformat(),
            "ttl": message.ttl,
            "signature": message.signature
        }

        data = json.dumps(message_dict).encode('utf-8')

        for node in self.nodes.values():
            if node.node_id != self.node_id and node.status == MeshNodeStatus.CONNECTED:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(2.0)
                    sock.connect((node.address, node.port))
                    sock.send(data)
                    sock.close()
                except Exception as e:
                    logger.warning(f"❌ Failed to send to {node.node_id}: {e}")
                    node.status = MeshNodeStatus.DISCONNECTED

    async def _handle_message(self, message_dict: Dict[str, Any], sender_address: Tuple[str, int]):
        """Handle incoming message"""
        try:
            message = MeshMessage(
                message_id=message_dict["message_id"],
                sender_id=message_dict["sender_id"],
                receiver_id=message_dict["receiver_id"],
                message_type=MessageType(message_dict["message_type"]),
                payload=message_dict["payload"],
                timestamp=datetime.fromisoformat(message_dict["timestamp"]),
                ttl=message_dict.get("ttl", 64),
                signature=message_dict.get("signature", "")
            )

            # Update sender node info
            if message.sender_id not in self.nodes:
                self.nodes[message.sender_id] = MeshNode(
                    node_id=message.sender_id,
                    address=sender_address[0],
                    port=sender_address[1],
                    status=MeshNodeStatus.CONNECTED
                )

            # Process message based on type
            if message.message_type == MessageType.DISCOVERY:
                await self._handle_discovery(message)
            elif message.message_type == MessageType.DATA:
                await self._handle_data(message)
            elif message.message_type == MessageType.ROUTING:
                await self._handle_routing(message)
            elif message.message_type == MessageType.HEARTBEAT:
                await self._handle_heartbeat(message)

        except Exception as e:
            logger.error(f"❌ Error handling message: {e}")

    async def _handle_discovery(self, message: MeshMessage):
        """Handle discovery message"""
        node_info = message.payload.get("node_info", {})
        sender_id = message.sender_id

        if sender_id not in self.nodes:
            self.nodes[sender_id] = MeshNode(
                node_id=sender_id,
                address=node_info.get("address", ""),
                port=node_info.get("port", 8888),
                status=MeshNodeStatus.CONNECTED
            )

        logger.info(f"🔍 Discovered peer: {sender_id}")

        # Send handshake response
        handshake_msg = MeshMessage(
            message_id=str(uuid.uuid4()),
            sender_id=self.node_id,
            receiver_id=sender_id,
            message_type=MessageType.HANDSHAKE,
            payload={
                "node_info": {
                    "node_id": self.local_node.node_id,
                    "address": self.local_node.address,
                    "port": self.local_node.port,
                    "capabilities": ["mesh", "routing", "encryption"]
                }
            }
        )

        self._send_message(handshake_msg, sender_id)

    async def _handle_data(self, message: MeshMessage):
        """Handle data message"""
        logger.info(f"📦 Received data from {message.sender_id}: {message.payload}")

        # Add to message queue for processing
        await self.message_queue.put(message)

    async def _handle_routing(self, message: MeshMessage):
        """Handle routing message"""
        # Update routing table
        routing_info = message.payload.get("routing_table", {})
        logger.info(f"🛣️ Updated routing info from {message.sender_id}")

    async def _handle_heartbeat(self, message: MeshMessage):
        """Handle heartbeat message"""
        sender_id = message.sender_id
        if sender_id in self.nodes:
            self.nodes[sender_id].last_seen = datetime.now()
            self.nodes[sender_id].status = MeshNodeStatus.ACTIVE

    def _send_message(self, message: MeshMessage, target_node_id: str):
        """Send message to specific node"""
        if target_node_id not in self.nodes:
            logger.warning(f"❌ Target node {target_node_id} not found")
            return

        target_node = self.nodes[target_node_id]
        message_dict = {
            "message_id": message.message_id,
            "sender_id": message.sender_id,
            "receiver_id": message.receiver_id,
            "message_type": message.message_type.value,
            "payload": message.payload,
            "timestamp": message.timestamp.isoformat(),
            "ttl": message.ttl,
            "signature": message.signature
        }

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2.0)
            sock.connect((target_node.address, target_node.port))
            sock.send(json.dumps(message_dict).encode('utf-8'))
            sock.close()
            logger.info(f"📤 Sent {message.message_type.value} to {target_node_id}")
        except Exception as e:
            logger.error(f"❌ Failed to send message to {target_node_id}: {e}")

    async def _process_messages(self):
        """Process messages from the queue"""
        while self.running:
            try:
                message = await asyncio.wait_for(self.message_queue.get(), timeout=1.0)
                # Process message (implement business logic here)
                logger.info(f"⚙️ Processing message: {message.message_id}")
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"❌ Error processing message: {e}")

    def get_network_status(self) -> Dict[str, Any]:
        """Get current network status"""
        return {
            "node_id": self.node_id,
            "total_nodes": len(self.nodes),
            "active_connections": len([n for n in self.nodes.values() if n.status == MeshNodeStatus.ACTIVE]),
            "network_topology": {
                node_id: {
                    "address": node.address,
                    "port": node.port,
                    "status": node.status.value,
                    "connections": list(node.connections),
                    "last_seen": node.last_seen.isoformat()
                }
                for node_id, node in self.nodes.items()
            }
        }

    def send_data(self, target_node_id: str, data: Dict[str, Any]):
        """Send data to a specific node"""
        message = MeshMessage(
            message_id=str(uuid.uuid4()),
            sender_id=self.node_id,
            receiver_id=target_node_id,
            message_type=MessageType.DATA,
            payload=data
        )

        self._send_message(message, target_node_id)

    def broadcast_data(self, data: Dict[str, Any]):
        """Broadcast data to all connected nodes"""
        message = MeshMessage(
            message_id=str(uuid.uuid4()),
            sender_id=self.node_id,
            receiver_id="broadcast",
            message_type=MessageType.DATA,
            payload=data
        )

        self._broadcast_message(message)

    # --- Product Download / Mesh Expansion Integration ---

    def register_product_node(self, node_id: str, product_key: str,
                               node_tier: str, capabilities: List[str],
                               address: str = "", port: int = 8888) -> bool:
        """Register a new node that joined via product download"""
        try:
            node = MeshNode(
                node_id=node_id,
                address=address or "0.0.0.0",
                port=port,
                status=MeshNodeStatus.ACTIVE,
                metadata={
                    'product_key': product_key,
                    'node_tier': node_tier,
                    'capabilities': capabilities,
                    'joined_via': 'product_download',
                    'registered_at': datetime.now().isoformat(),
                }
            )
            self.nodes[node_id] = node
            logger.info(f"🕸️ Product node registered: {node_id} (tier={node_tier}, product={product_key})")

            # Broadcast new node to mesh
            self.broadcast_data({
                'type': 'new_product_node',
                'node_id': node_id,
                'product_key': product_key,
                'node_tier': node_tier,
                'capabilities': capabilities,
            })
            return True
        except Exception as e:
            logger.error(f"❌ Failed to register product node: {e}")
            return False

    def get_product_nodes(self) -> List[Dict]:
        """Get all nodes that joined via product downloads"""
        return [
            {
                'node_id': nid,
                'address': n.address,
                'port': n.port,
                'status': n.status.value,
                'product_key': n.metadata.get('product_key', ''),
                'node_tier': n.metadata.get('node_tier', ''),
                'capabilities': n.metadata.get('capabilities', []),
            }
            for nid, n in self.nodes.items()
            if n.metadata.get('joined_via') == 'product_download'
        ]

    def get_mesh_expansion_stats(self) -> Dict:
        """Get stats on mesh expansion from product downloads"""
        product_nodes = [n for n in self.nodes.values()
                         if n.metadata.get('joined_via') == 'product_download']
        tiers = {}
        for n in product_nodes:
            t = n.metadata.get('node_tier', 'unknown')
            tiers[t] = tiers.get(t, 0) + 1
        return {
            'total_mesh_nodes': len(self.nodes),
            'product_download_nodes': len(product_nodes),
            'organic_nodes': len(self.nodes) - len(product_nodes),
            'tiers': tiers,
            'expansion_message': (
                f"🕸️ {len(product_nodes)} customer hardware nodes joined "
                f"via product downloads — every sale expands the mesh!"
            ),
        }

# ═══════════════════════════════════════════════════════════════════════════════
# SINGLETON INSTANCE
# ═══════════════════════════════════════════════════════════════════════════════

fungi_mesh_agent = FungiMeshAgent()

# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("🕸️🧬 FungiMesh Agent Test")
    print("=" * 50)

    agent = FungiMeshAgent()

    try:
        # Start mesh network
        asyncio.run(agent.start_mesh_network())
    except KeyboardInterrupt:
        print("\n🛑 Shutting down FungiMesh Agent...")
        agent.stop_mesh_network()
    except Exception as e:
        print(f"❌ Error: {e}")
        agent.stop_mesh_network()