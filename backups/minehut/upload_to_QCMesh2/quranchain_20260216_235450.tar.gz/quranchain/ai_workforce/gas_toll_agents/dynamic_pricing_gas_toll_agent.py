#!/usr/bin/env python3
"""
Dynamic Pricing Gas Toll Agent - AI-Powered Agent for Real-Time Gas Toll Optimization
Uses machine learning to dynamically adjust gas toll rates based on network congestion, transaction patterns, and market conditions
"""


import sys
sys.path.insert(0, "/home/omar/Desktop/QuranChain")
# Add project root to path

from flask import Flask, jsonify, request
import sqlite3
import requests
import json
import time
import threading
import os
import logging
import numpy as np
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        GAS_TOLL_PRODUCTS, BLOCKCHAIN_SERVICE_PRODUCTS,
        PRODUCTS as STRIPE_CATALOG,
        create_checkout_session, create_payment_link,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

# Simple Linear Regression implementation (no sklearn dependency)
class SimpleLinearRegression:
    """Simple linear regression without sklearn dependency"""
    def __init__(self):
        self.weights = None
        self.bias = None
        self.fitted = False

    def fit(self, X, y):
        """Fit the model using normal equation"""
        # Add bias term
        X_b = np.c_[np.ones((X.shape[0], 1)), X]

        # Normal equation: w = (X^T * X)^(-1) * X^T * y
        try:
            self.weights = np.linalg.inv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)
            self.bias = self.weights[0]
            self.weights = self.weights[1:]
            self.fitted = True
        except np.linalg.LinAlgError:
            # Fallback to simple averaging if matrix is singular
            self.bias = np.mean(y)
            self.weights = np.zeros(X.shape[1])
            self.fitted = True

    def predict(self, X):
        """Make predictions"""
        if not self.fitted:
            return np.full(X.shape[0], 0.025)  # Return base rate if not fitted
        return X.dot(self.weights) + self.bias

# Simple Standard Scaler implementation
class SimpleStandardScaler:
    """Simple standard scaler without sklearn dependency"""
    def __init__(self):
        self.mean_ = None
        self.scale_ = None
        self.fitted = False

    def fit_transform(self, X):
        """Fit and transform data"""
        self.mean_ = np.mean(X, axis=0)
        self.scale_ = np.std(X, axis=0)
        self.scale_[self.scale_ == 0] = 1  # Avoid division by zero
        self.fitted = True
        return (X - self.mean_) / self.scale_

    def transform(self, X):
        """Transform data"""
        if not self.fitted:
            return X
        return (X - self.mean_) / self.scale_

app = Flask(__name__)
PORT = 9512  # Unique port for Dynamic Pricing agent

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty
AI_VALIDATOR_RATE = 0.40      # 40% to AI validators
HARDWARE_HOST_RATE = 0.10     # 10% to hardware hosts
ECOSYSTEM_RATE = 0.18         # 18% to ecosystem
ZAKAT_RATE = 0.02            # 2% to zakat

# Agent Configuration
AGENT_CONFIG = {
    "name": "dynamic-pricing-gas-toll-agent",
    "network": "multi-chain",
    "contract_address": "0xcf35Cc6634C0532925a3b844Bc454e4438f44o",  # Unique contract
    "base_commission_rate": 0.025,  # Base 2.5% rate (dynamically adjusted)
    "specialization": "ai_powered_dynamic_pricing",
    "expertise": [
        "real_time_network_congestion_analysis",
        "machine_learning_price_optimization",
        "transaction_pattern_recognition",
        "market_demand_prediction",
        "gas_price_correlation_modeling",
        "dynamic_rate_adjustment_algorithms",
        "revenue_maximization_strategies",
        "user_behavior_prediction",
        "seasonal_trend_analysis",
        "cross_chain_price_arbitrage"
    ]
}

class PricingModel(Enum):
    """AI pricing model types"""
    LINEAR_REGRESSION = "linear_regression"
    TIME_SERIES_FORECASTING = "time_series_forecasting"
    NEURAL_NETWORK = "neural_network"
    REINFORCEMENT_LEARNING = "reinforcement_learning"
    ENSEMBLE_MODEL = "ensemble_model"

@dataclass
class DynamicPricingData:
    """Dynamic pricing data point"""
    timestamp: str
    network: str
    gas_price_gwei: float
    network_congestion: float
    transaction_volume: int
    transaction_value_usd: float
    predicted_optimal_rate: float
    actual_rate_used: float
    revenue_generated: float
    market_conditions: Dict
    ai_confidence_score: float

@dataclass
class GasTollTransaction:
    """Gas toll transaction record"""
    tx_hash: str
    sender: str
    recipient: str
    amount_usd: float
    gas_used: int
    gas_price_gwei: float
    toll_collected_usd: float
    dynamic_rate: float
    timestamp: str
    block_number: int
    founder_royalty: float
    ai_validator_share: float
    hardware_host_share: float
    network: str
    congestion_level: float
    predicted_vs_actual: float

class DynamicPricingGasTollAgent:
    """AI-Powered Dynamic Pricing Gas Toll Collection Agent"""

    def __init__(self):
        self.agent_name = AGENT_CONFIG["name"]
        self.network = AGENT_CONFIG["network"]
        self.contract_address = AGENT_CONFIG["contract_address"]
        self.base_commission_rate = AGENT_CONFIG["base_commission_rate"]

        # Revenue tracking
        self.revenue_stats = {
            "total_toll_collected_usd": 0.0,
            "founder_royalty_paid": 0.0,
            "transactions_processed": 0,
            "dynamic_rate_adjustments": 0,
            "ai_predictions_accuracy": 0.0,
            "avg_dynamic_rate": 0.0,
            "peak_congestion_events": 0,
            "revenue_optimization_events": 0,
            "total_prediction_accuracy": 0.0,
            "model_training_sessions": 0
        }

        # Transaction history
        self.transactions: List[GasTollTransaction] = []

        # AI Learning data for dynamic pricing
        self.pricing_data: List[DynamicPricingData] = []
        self.pricing_models = {}
        self.feature_scalers = {}

        # Logging setup (moved up before model initialization)
        self.log_dir = "/home/omar/Desktop/QuranChain/logs/ai_workforce/gas_toll_agents"
        os.makedirs(self.log_dir, exist_ok=True)

        self.logger = logging.getLogger(f'{self.agent_name}')
        self.logger.setLevel(logging.INFO)

        handler = logging.FileHandler(f"{self.log_dir}/{self.agent_name}.log")
        formatter = logging.Formatter(
            '[%(asctime)s] DYNAMIC PRICING GAS TOLL - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        # Real-time market data
        self.market_conditions = {
            "ethereum": {"congestion": 0.0, "gas_price": 0.0, "volume": 0},
            "polygon": {"congestion": 0.0, "gas_price": 0.0, "volume": 0},
            "arbitrum": {"congestion": 0.0, "gas_price": 0.0, "volume": 0},
            "bsc": {"congestion": 0.0, "gas_price": 0.0, "volume": 0},
            "avalanche": {"congestion": 0.0, "gas_price": 0.0, "volume": 0},
            "solana": {"congestion": 0.0, "gas_price": 0.0, "volume": 0}
        }

        # AI Model performance tracking
        self.model_performance = {
            "prediction_accuracy": [],
            "revenue_impact": [],
            "model_versions": {},
            "feature_importance": {},
            "training_history": []
        }

        # Initialize AI models for each network
        self.initialize_pricing_models()

        # CRM database
        self.crm_db = "/home/omar/Desktop/QuranChain/crm/crm.db"

        # Start background threads
        self.market_data_thread = threading.Thread(target=self.update_market_data, daemon=True)
        self.market_data_thread.start()

        self.model_training_thread = threading.Thread(target=self.train_models_periodically, daemon=True)
        self.model_training_thread.start()

        self.logger.info(f"🚀 Dynamic Pricing Gas Toll Agent initialized | Contract: {self.contract_address}")
        self.logger.info(f"   💰 Base Commission Rate: {self.base_commission_rate * 100}% (Dynamic)")
        self.logger.info(f"   🎯 Specialization: {AGENT_CONFIG['specialization']}")

    def initialize_pricing_models(self):
        """Initialize AI pricing models for each network"""
        for network in self.market_conditions.keys():
            # Simple linear regression model for price prediction
            self.pricing_models[network] = SimpleLinearRegression()
            self.feature_scalers[network] = SimpleStandardScaler()

            # Initialize with historical data (simplified)
            self.train_initial_model(network)

    def train_initial_model(self, network: str):
        """Train initial pricing model with synthetic historical data"""
        # Generate synthetic training data
        np.random.seed(42)
        n_samples = 1000

        # Features: gas_price, congestion, volume, hour_of_day, day_of_week
        gas_prices = np.random.normal(50, 20, n_samples)  # Gwei
        congestion = np.random.uniform(0, 1, n_samples)
        volume = np.random.poisson(100, n_samples)
        hour_of_day = np.random.randint(0, 24, n_samples)
        day_of_week = np.random.randint(0, 7, n_samples)

        # Target: optimal commission rate (0.01 to 0.10)
        # Higher rates for high congestion, high gas prices, high volume
        optimal_rates = (
            0.025 +  # base rate
            congestion * 0.03 +  # congestion factor
            (gas_prices / 100) * 0.02 +  # gas price factor
            (volume / 200) * 0.015 +  # volume factor
            np.random.normal(0, 0.005, n_samples)  # noise
        )
        optimal_rates = np.clip(optimal_rates, 0.01, 0.10)

        # Prepare features
        X = np.column_stack([gas_prices, congestion, volume, hour_of_day, day_of_week])
        y = optimal_rates

        # Scale features
        X_scaled = self.feature_scalers[network].fit_transform(X)

        # Train model
        self.pricing_models[network].fit(X_scaled, y)

        self.logger.info(f"✅ Initial pricing model trained for {network}")

    def update_market_data(self):
        """Background thread to update real-time market data"""
        while True:
            try:
                for network in self.market_conditions.keys():
                    # Simulate real-time data updates (would use APIs in production)
                    self.market_conditions[network] = {
                        "congestion": np.random.uniform(0, 1),
                        "gas_price": np.random.normal(50, 15),
                        "volume": np.random.poisson(100),
                        "timestamp": datetime.utcnow().isoformat()
                    }
                time.sleep(30)  # Update every 30 seconds
            except Exception as e:
                self.logger.error(f"Market data update failed: {str(e)}")
                time.sleep(60)

    def train_models_periodically(self):
        """Background thread to retrain models with new data"""
        while True:
            try:
                time.sleep(3600)  # Retrain every hour

                if len(self.pricing_data) > 100:  # Need minimum data
                    for network in self.market_conditions.keys():
                        network_data = [d for d in self.pricing_data if d.network == network]
                        if len(network_data) > 50:
                            self.retrain_model(network, network_data)
                            self.revenue_stats["model_training_sessions"] += 1

            except Exception as e:
                self.logger.error(f"Model training failed: {str(e)}")

    def retrain_model(self, network: str, data: List[DynamicPricingData]):
        """Retrain pricing model with recent data"""
        try:
            # Prepare training data
            df = pd.DataFrame([{
                'gas_price': d.gas_price_gwei,
                'congestion': d.network_congestion,
                'volume': d.transaction_volume,
                'hour': pd.to_datetime(d.timestamp).hour,
                'day': pd.to_datetime(d.timestamp).dayofweek,
                'optimal_rate': d.predicted_optimal_rate
            } for d in data])

            X = df[['gas_price', 'congestion', 'volume', 'hour', 'day']].values
            y = df['optimal_rate'].values

            # Scale features
            X_scaled = self.feature_scalers[network].fit_transform(X)

            # Retrain model
            self.pricing_models[network].fit(X_scaled, y)

            self.logger.info(f"🔄 Retrained pricing model for {network} with {len(data)} samples")

        except Exception as e:
            self.logger.error(f"Model retraining failed for {network}: {str(e)}")

    def predict_optimal_rate(self, network: str, gas_price: float, congestion: float,
                           volume: int, timestamp: str) -> Tuple[float, float]:
        """Predict optimal commission rate using AI model"""
        try:
            # Prepare features
            hour = pd.to_datetime(timestamp).hour
            day = pd.to_datetime(timestamp).dayofweek

            features = np.array([[gas_price, congestion, volume, hour, day]])
            features_scaled = self.feature_scalers[network].transform(features)

            # Predict optimal rate
            predicted_rate = self.pricing_models[network].predict(features_scaled)[0]

            # Ensure rate is within bounds
            optimal_rate = np.clip(predicted_rate, 0.015, 0.08)  # 1.5% to 8%

            # Calculate confidence score (simplified)
            confidence = min(0.95, len(self.pricing_data) / 1000)  # Increases with more data

            return optimal_rate, confidence

        except Exception as e:
            self.logger.error(f"Rate prediction failed for {network}: {str(e)}")
            return self.base_commission_rate, 0.5  # Fallback

    def calculate_dynamic_gas_toll(self, gas_used: int, gas_price_gwei: float, tx_value_usd: float,
                                  network: str, congestion_level: float, transaction_volume: int) -> Tuple[float, float, float]:
        """Calculate gas toll using dynamic AI-powered pricing"""
        # Base toll calculation (in USD for cross-chain compatibility)
        gas_cost_usd = (gas_used * gas_price_gwei * 1e-9) * self.get_gas_price_usd(network)

        # Get AI-predicted optimal rate
        timestamp = datetime.utcnow().isoformat()
        optimal_rate, confidence = self.predict_optimal_rate(
            network, gas_price_gwei, congestion_level, transaction_volume, timestamp
        )

        # Apply dynamic rate
        dynamic_toll = gas_cost_usd * optimal_rate

        # High-value transaction bonus
        if tx_value_usd > 10000:
            dynamic_toll *= 1.2  # 20% bonus

        # Peak congestion bonus
        if congestion_level > 0.8:
            dynamic_toll *= 1.3  # 30% bonus
            self.revenue_stats["peak_congestion_events"] += 1

        return dynamic_toll, optimal_rate, confidence

    def get_gas_price_usd(self, network: str) -> float:
        """Get current gas price in USD for network"""
        gas_prices = {
            "ethereum": 2000, "polygon": 0.8, "arbitrum": 2000,
            "bsc": 300, "avalanche": 20, "solana": 100
        }
        return gas_prices.get(network.lower(), 1.0)

    def distribute_revenue(self, toll_amount: float) -> Dict:
        """Distribute collected toll according to QuranChain economics"""
        founder_share = toll_amount * FOUNDER_ROYALTY_RATE
        ai_validator_share = toll_amount * AI_VALIDATOR_RATE
        hardware_host_share = toll_amount * HARDWARE_HOST_RATE
        ecosystem_share = toll_amount * ECOSYSTEM_RATE
        zakat_share = toll_amount * ZAKAT_RATE

        distribution = {
            "founder": founder_share,
            "ai_validators": ai_validator_share,
            "hardware_hosts": hardware_host_share,
            "ecosystem": ecosystem_share,
            "zakat": zakat_share,
            "total_distributed": founder_share + ai_validator_share + hardware_host_share + ecosystem_share + zakat_share
        }

        # Update revenue stats
        self.revenue_stats["founder_royalty_paid"] += founder_share
        self.revenue_stats["total_toll_collected_usd"] += toll_amount

        return distribution

    def process_transaction(self, tx_data: Dict) -> Dict:
        """Process a transaction with dynamic AI pricing"""
        try:
            tx_hash = tx_data.get("hash")
            sender = tx_data.get("from")
            recipient = tx_data.get("to")
            value_usd = float(tx_data.get("valueUSD", 0))
            gas_used = int(tx_data.get("gasUsed", 0))
            gas_price = float(tx_data.get("gasPrice", 0)) / 1e-9  # Convert wei to gwei
            block_number = int(tx_data.get("blockNumber", 0))
            network = tx_data.get("network", "ethereum")

            # Get current market conditions
            market_data = self.market_conditions.get(network, {"congestion": 0.5, "volume": 100})
            congestion_level = market_data["congestion"]
            transaction_volume = market_data["volume"]

            # Calculate dynamic toll
            toll_amount, dynamic_rate, ai_confidence = self.calculate_dynamic_gas_toll(
                gas_used, gas_price, value_usd, network, congestion_level, transaction_volume
            )

            # Create transaction record
            transaction = GasTollTransaction(
                tx_hash=tx_hash,
                sender=sender,
                recipient=recipient,
                amount_usd=value_usd,
                gas_used=gas_used,
                gas_price_gwei=gas_price,
                toll_collected_usd=toll_amount,
                dynamic_rate=dynamic_rate,
                timestamp=datetime.utcnow().isoformat(),
                block_number=block_number,
                founder_royalty=toll_amount * FOUNDER_ROYALTY_RATE,
                ai_validator_share=toll_amount * AI_VALIDATOR_RATE,
                hardware_host_share=toll_amount * HARDWARE_HOST_RATE,
                network=network,
                congestion_level=congestion_level,
                predicted_vs_actual=ai_confidence
            )

            # Distribute revenue
            distribution = self.distribute_revenue(toll_amount)

            # Store transaction
            self.transactions.append(transaction)
            self.revenue_stats["transactions_processed"] += 1
            self.revenue_stats["dynamic_rate_adjustments"] += 1

            # Update AI learning data
            pricing_data_point = DynamicPricingData(
                timestamp=transaction.timestamp,
                network=network,
                gas_price_gwei=gas_price,
                network_congestion=congestion_level,
                transaction_volume=transaction_volume,
                transaction_value_usd=value_usd,
                predicted_optimal_rate=dynamic_rate,
                actual_rate_used=dynamic_rate,
                revenue_generated=toll_amount,
                market_conditions=self.market_conditions[network],
                ai_confidence_score=ai_confidence
            )
            self.pricing_data.append(pricing_data_point)

            # Update model performance
            self.update_model_performance(dynamic_rate, toll_amount, ai_confidence)

            # Log to CRM
            self.log_to_crm(transaction, distribution)

            self.logger.info(f"🤖 AI Dynamic Pricing: Collected ${toll_amount:.2f} toll from {tx_hash[:10]}... (Rate: {dynamic_rate:.4f}, Confidence: {ai_confidence:.2f})")

            return {
                "success": True,
                "transaction": asdict(transaction),
                "distribution": distribution,
                "ai_insights": self.generate_dynamic_pricing_insights(transaction, pricing_data_point)
            }

        except Exception as e:
            self.logger.error(f"❌ Transaction processing failed: {str(e)}")
            return {"success": False, "error": str(e)}

    def update_model_performance(self, predicted_rate: float, revenue: float, confidence: float):
        """Update AI model performance metrics"""
        # Track prediction accuracy (simplified - would compare to optimal rates)
        self.model_performance["prediction_accuracy"].append(confidence)
        self.model_performance["revenue_impact"].append(revenue)

        # Calculate average accuracy
        if self.model_performance["prediction_accuracy"]:
            self.revenue_stats["ai_predictions_accuracy"] = np.mean(self.model_performance["prediction_accuracy"][-100:])  # Last 100 predictions

        # Calculate average dynamic rate
        if self.transactions:
            rates = [t.dynamic_rate for t in self.transactions[-100:]]  # Last 100 transactions
            self.revenue_stats["avg_dynamic_rate"] = np.mean(rates)

    def generate_dynamic_pricing_insights(self, transaction: GasTollTransaction, pricing_data: DynamicPricingData) -> Dict:
        """Generate AI-powered dynamic pricing insights"""
        insights = {
            "dynamic_rate_used": transaction.dynamic_rate,
            "ai_confidence": pricing_data.ai_confidence_score,
            "network_congestion": transaction.congestion_level,
            "rate_optimization": "optimal" if pricing_data.ai_confidence_score > 0.8 else "moderate",
            "market_conditions": pricing_data.market_conditions,
            "model_performance": self.revenue_stats["ai_predictions_accuracy"]
        }

        # AI-powered recommendations
        recommendations = []
        if transaction.congestion_level > 0.8:
            recommendations.append("High network congestion detected - rate increased for optimization")

        if pricing_data.ai_confidence_score > 0.9:
            recommendations.append("High confidence AI prediction - optimal pricing achieved")

        if transaction.dynamic_rate > self.base_commission_rate * 1.5:
            recommendations.append("Premium pricing applied due to market conditions")

        if len(self.pricing_data) > 100:
            recommendations.append("AI model well-trained with sufficient data")

        insights["recommendations"] = recommendations

        return insights

    def log_to_crm(self, transaction: GasTollTransaction, distribution: Dict):
        """Log transaction to CRM database"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            # Insert transaction record
            cursor.execute("""
                INSERT INTO gas_toll_transactions
                (agent_name, network, tx_hash, sender, recipient, amount, toll_collected,
                 founder_royalty, ai_validator_share, hardware_host_share, timestamp,
                 dynamic_rate, congestion_level, ai_confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.agent_name,
                transaction.network,
                transaction.tx_hash,
                transaction.sender,
                transaction.recipient,
                transaction.amount_usd,
                transaction.toll_collected_usd,
                distribution["founder"],
                distribution["ai_validators"],
                distribution["hardware_hosts"],
                transaction.timestamp,
                transaction.dynamic_rate,
                transaction.congestion_level,
                transaction.predicted_vs_actual
            ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"CRM logging failed: {str(e)}")

    def get_revenue_stats(self) -> Dict:
        """Get comprehensive revenue statistics"""
        return {
            "agent": self.agent_name,
            "network": self.network,
            "contract_address": self.contract_address,
            "base_commission_rate": f"{self.base_commission_rate * 100}% (Dynamic)",
            "founder_royalty_rate": f"{FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)",
            "total_toll_collected_usd": self.revenue_stats["total_toll_collected_usd"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "transactions_processed": self.revenue_stats["transactions_processed"],
            "dynamic_rate_adjustments": self.revenue_stats["dynamic_rate_adjustments"],
            "ai_predictions_accuracy": f"{self.revenue_stats['ai_predictions_accuracy']:.3f}",
            "avg_dynamic_rate": f"{self.revenue_stats['avg_dynamic_rate']:.4f}",
            "peak_congestion_events": self.revenue_stats["peak_congestion_events"],
            "revenue_optimization_events": self.revenue_stats["revenue_optimization_events"],
            "model_training_sessions": self.revenue_stats["model_training_sessions"],
            "market_conditions": self.market_conditions,
            "model_performance": {
                "avg_accuracy": np.mean(self.model_performance["prediction_accuracy"][-100:]) if self.model_performance["prediction_accuracy"] else 0,
                "total_predictions": len(self.model_performance["prediction_accuracy"]),
                "revenue_impact": sum(self.model_performance["revenue_impact"][-100:]) if self.model_performance["revenue_impact"] else 0
            },
            "timestamp": datetime.utcnow().isoformat()
        }

# Global agent instance
dynamic_pricing_agent = DynamicPricingGasTollAgent()

# Flask Routes
@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "agent": dynamic_pricing_agent.agent_name,
        "network": dynamic_pricing_agent.network,
        "contract": dynamic_pricing_agent.contract_address,
        "ai_models_active": len(dynamic_pricing_agent.pricing_models),
        "timestamp": datetime.utcnow().isoformat()
    })

@app.route('/metrics', methods=['GET'])
def metrics():
    """Performance metrics endpoint"""
    return jsonify({
        "agent_metrics": dynamic_pricing_agent.get_revenue_stats(),
        "ai_performance": {
            "models_trained": len(dynamic_pricing_agent.pricing_models),
            "data_points": len(dynamic_pricing_agent.pricing_data),
            "prediction_accuracy": dynamic_pricing_agent.revenue_stats["ai_predictions_accuracy"],
            "model_versions": list(dynamic_pricing_agent.model_performance["model_versions"].keys())
        },
        "market_data": dynamic_pricing_agent.market_conditions,
        "system_health": {
            "transactions_in_memory": len(dynamic_pricing_agent.transactions),
            "log_file_size": os.path.getsize(f"{dynamic_pricing_agent.log_dir}/{dynamic_pricing_agent.agent_name}.log") if os.path.exists(f"{dynamic_pricing_agent.log_dir}/{dynamic_pricing_agent.agent_name}.log") else 0
        }
    })

@app.route('/revenue', methods=['GET'])
def revenue():
    """Revenue statistics endpoint"""
    return jsonify(dynamic_pricing_agent.get_revenue_stats())

@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    """Process a transaction with AI dynamic pricing"""
    try:
        tx_data = request.get_json()
        if not tx_data:
            return jsonify({"error": "No transaction data provided"}), 400

        result = dynamic_pricing_agent.process_transaction(tx_data)
        return jsonify(result)

    except Exception as e:
        dynamic_pricing_agent.logger.error(f"Transaction processing error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/ai_insights', methods=['GET'])
def ai_insights():
    """Get AI-powered dynamic pricing insights"""
    return jsonify({
        "pricing_models": {network: "active" for network in dynamic_pricing_agent.pricing_models.keys()},
        "market_conditions": dynamic_pricing_agent.market_conditions,
        "model_performance": {
            "prediction_accuracy": dynamic_pricing_agent.revenue_stats["ai_predictions_accuracy"],
            "avg_dynamic_rate": dynamic_pricing_agent.revenue_stats["avg_dynamic_rate"],
            "training_sessions": dynamic_pricing_agent.revenue_stats["model_training_sessions"],
            "data_points": len(dynamic_pricing_agent.pricing_data)
        },
        "recommendations": [
            "AI models are continuously learning from market conditions",
            f"Current prediction accuracy: {dynamic_pricing_agent.revenue_stats['ai_predictions_accuracy']:.1%}",
            f"Average dynamic rate: {dynamic_pricing_agent.revenue_stats['avg_dynamic_rate']:.2%}",
            "Models retrain hourly with new market data",
            "Dynamic pricing optimizes revenue during peak congestion",
            "AI confidence improves with more transaction data",
            "Real-time market data drives pricing decisions"
        ]
    })

@app.route('/predict_rate', methods=['POST'])
def predict_rate():
    """Predict optimal rate for given market conditions"""
    try:
        data = request.get_json()
        network = data.get("network", "ethereum")
        gas_price = data.get("gas_price_gwei", 50)
        congestion = data.get("congestion", 0.5)
        volume = data.get("volume", 100)
        timestamp = data.get("timestamp", datetime.utcnow().isoformat())

        optimal_rate, confidence = dynamic_pricing_agent.predict_optimal_rate(
            network, gas_price, congestion, volume, timestamp
        )

        return jsonify({
            "network": network,
            "predicted_rate": optimal_rate,
            "confidence": confidence,
            "timestamp": timestamp
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/contract_info', methods=['GET'])
def contract_info():
    """Get contract information"""
    return jsonify({
        "contract_address": dynamic_pricing_agent.contract_address,
        "network": dynamic_pricing_agent.network,
        "base_commission_rate": dynamic_pricing_agent.base_commission_rate,
        "specialization": AGENT_CONFIG["specialization"],
        "expertise": AGENT_CONFIG["expertise"],
        "ai_capabilities": ["real_time_pricing", "machine_learning", "market_prediction", "dynamic_adjustment"],
        "supported_networks": list(dynamic_pricing_agent.market_conditions.keys())
    })

if __name__ == "__main__":
    print("🤖 Starting AI Dynamic Pricing Gas Toll Agent...")
    print(f"   📡 Port: {PORT}")
    print(f"   🌐 Network: {dynamic_pricing_agent.network}")
    print(f"   📋 Contract: {dynamic_pricing_agent.contract_address}")
    print(f"   💰 Base Commission: {dynamic_pricing_agent.base_commission_rate * 100}% (AI Dynamic)")
    print(f"   👑 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print(f"   🧠 AI Models: {len(dynamic_pricing_agent.pricing_models)} networks")
    print("=" * 60)

    app.run(host='localhost', port=PORT, debug=False)