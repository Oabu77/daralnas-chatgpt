#!/usr/bin/env python3
"""
NFT Gas Toll Agent - Specialized AI Agent for NFT Marketplace Transactions
Focuses on NFT minting, trading, marketplace fees, and NFT ecosystem toll collection
"""


import sys
sys.path.insert(0, "/home/omar/Desktop/QuranChain")
# Add project root to path

from flask import Flask, jsonify, request
import sqlite3
import requests
import json
import time
import threading
import os
import logging
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from enum import Enum

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        GAS_TOLL_PRODUCTS, NFT_PRODUCTS, EXCHANGE_PRODUCTS,
        TOKEN_PRODUCTS, BLOCKCHAIN_SERVICE_PRODUCTS,
        PRODUCTS as STRIPE_CATALOG,
        create_checkout_session, create_payment_link,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

app = Flask(__name__)
PORT = 9508  # Unique port for NFT agent

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty
AI_VALIDATOR_RATE = 0.40      # 40% to AI validators
HARDWARE_HOST_RATE = 0.10     # 10% to hardware hosts
ECOSYSTEM_RATE = 0.18         # 18% to ecosystem
ZAKAT_RATE = 0.02            # 2% to zakat

# Agent Configuration
AGENT_CONFIG = {
    "name": "nft-gas-toll-agent",
    "network": "multi-chain",
    "contract_address": "0xcf35Cc6634C0532925a3b844Bc454e4438f44k",  # Unique contract
    "commission_rate": 0.032,  # 3.2% gas toll (higher for NFT complexity)
    "specialization": "nft_marketplace_transactions",
    "expertise": [
        "nft_minting_monitoring",
        "marketplace_transaction_tracking",
        "royalty_fee_collection",
        "nft_floor_price_analysis",
        "collection_rarity_scoring",
        "wash_trading_detection",
        "gas_war_optimization",
        "bundle_transaction_handling",
        "cross_marketplace_arbitrage",
        "nft_lending_protocol_tracking"
    ]
}

class TransactionType(Enum):
    """Transaction types for NFT operations"""
    NFT_MINT = "nft_mint"
    NFT_TRANSFER = "nft_transfer"
    NFT_SALE = "nft_sale"
    NFT_BID = "nft_bid"
    NFT_AUCTION = "nft_auction"
    NFT_BUNDLE = "nft_bundle"
    NFT_LENDING = "nft_lending"
    NFT_STAKING = "nft_staking"
    ROYALTY_PAYMENT = "royalty_payment"
    MARKETPLACE_FEE = "marketplace_fee"

@dataclass
class GasTollTransaction:
    """Gas toll transaction record"""
    tx_hash: str
    sender: str
    recipient: str
    amount_usd: float
    gas_used: int
    gas_price_gwei: float
    toll_collected_usd: float
    transaction_type: TransactionType
    timestamp: str
    block_number: int
    founder_royalty: float
    ai_validator_share: float
    hardware_host_share: float
    nft_contract: str
    marketplace: str
    network: str
    nft_value_usd: Optional[float] = None
    royalty_amount: Optional[float] = None
    bundle_size: Optional[int] = None

class NFTGasTollAgent:
    """Specialized NFT Gas Toll Collection Agent"""

    def __init__(self):
        self.agent_name = AGENT_CONFIG["name"]
        self.network = AGENT_CONFIG["network"]
        self.contract_address = AGENT_CONFIG["contract_address"]
        self.commission_rate = AGENT_CONFIG["commission_rate"]

        # Revenue tracking
        self.revenue_stats = {
            "total_toll_collected_usd": 0.0,
            "founder_royalty_paid": 0.0,
            "transactions_processed": 0,
            "nft_mints": 0,
            "nft_sales": 0,
            "nft_transfers": 0,
            "royalty_payments": 0,
            "bundle_transactions": 0,
            "marketplace_fees": 0,
            "total_nft_value_processed": 0.0,
            "total_royalties_collected": 0.0,
            "avg_bundle_size": 0.0
        }

        # Transaction history
        self.transactions: List[GasTollTransaction] = []

        # AI Learning data for NFT patterns
        self.learning_patterns = {
            "marketplace_performance": {},
            "floor_price_trends": {},
            "rarity_scores": {},
            "wash_trading_alerts": [],
            "gas_war_patterns": [],
            "bundle_opportunities": [],
            "royalty_optimization": {}
        }

        # Supported NFT marketplaces across networks
        self.nft_marketplaces = {
            "ethereum": {
                "opensea": "0x00000000006c3852cbEf3e08E8dF289169EdE581",
                "looksrare": "0x59728544B08AB483533076417FbBB2fD0B17CE3a",
                "x2y2": "0x74312363e45DCaBA76c59ec49a7Aa8A65a67EeD3",
                "blur": "0x0000000000A39bb272e79075ade125fd351887Ac",
                "foundation": "0xcDA72070E455bb31C7690a170224Ce43623d0B6f"
            },
            "polygon": {
                "opensea_polygon": "0x00000000006c3852cbEf3e08E8dF289169EdE581",
                "rarible": "0xF6793dA657495FFeFF9Ee6350824910Abc4831Ff"
            },
            "arbitrum": {
                "trove": "0x982F264ce4736586479db65A04fcD215Fc726837"
            }
        }

        # Logging setup
        self.log_dir = "/home/omar/Desktop/QuranChain/logs/ai_workforce/gas_toll_agents"
        os.makedirs(self.log_dir, exist_ok=True)

        self.logger = logging.getLogger(f'{self.agent_name}')
        self.logger.setLevel(logging.INFO)

        handler = logging.FileHandler(f"{self.log_dir}/{self.agent_name}.log")
        formatter = logging.Formatter(
            '[%(asctime)s] NFT GAS TOLL - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        # CRM database
        self.crm_db = "/home/omar/Desktop/QuranChain/crm/crm.db"

        self.logger.info(f"🚀 NFT Gas Toll Agent initialized | Contract: {self.contract_address}")
        self.logger.info(f"   💰 Commission Rate: {self.commission_rate * 100}%")
        self.logger.info(f"   🎯 Specialization: {AGENT_CONFIG['specialization']}")

    def calculate_gas_toll(self, gas_used: int, gas_price_gwei: float, tx_value_usd: float,
                          tx_type: TransactionType, network: str, nft_value_usd: Optional[float] = None) -> float:
        """Calculate gas toll with NFT-specific optimizations"""
        # Base toll calculation (in USD for cross-chain compatibility)
        gas_cost_usd = (gas_used * gas_price_gwei * 1e-9) * self.get_gas_price_usd(network)

        # Apply commission rate
        base_toll = gas_cost_usd * self.commission_rate

        # NFT transaction bonuses
        if tx_type == TransactionType.NFT_MINT:
            base_toll *= 1.4  # 40% bonus for NFT minting
            self.revenue_stats["nft_mints"] += 1

        elif tx_type == TransactionType.NFT_SALE:
            base_toll *= 1.6  # 60% bonus for NFT sales
            self.revenue_stats["nft_sales"] += 1

        elif tx_type == TransactionType.NFT_TRANSFER:
            base_toll *= 1.1  # 10% bonus for transfers
            self.revenue_stats["nft_transfers"] += 1

        elif tx_type == TransactionType.ROYALTY_PAYMENT:
            base_toll *= 1.8  # 80% bonus for royalties
            self.revenue_stats["royalty_payments"] += 1

        elif tx_type == TransactionType.NFT_BUNDLE:
            base_toll *= 2.0  # 100% bonus for bundles
            self.revenue_stats["bundle_transactions"] += 1

        elif tx_type == TransactionType.MARKETPLACE_FEE:
            base_toll *= 1.5  # 50% bonus for marketplace fees
            self.revenue_stats["marketplace_fees"] += 1

        # High-value NFT bonus
        if nft_value_usd and nft_value_usd > 10000:  # $10k+ NFTs
            base_toll *= 1.5  # Additional 50% bonus

        # Gas war bonus (high gas price transactions)
        if gas_price_gwei > 100:
            base_toll *= 1.3  # 30% bonus for gas wars

        return base_toll

    def get_gas_price_usd(self, network: str) -> float:
        """Get current gas price in USD for network"""
        # Simplified gas price conversion (would use oracles in production)
        gas_prices = {
            "ethereum": 2000,  # ~$2000/ETH
            "polygon": 0.8,    # ~$0.80/MATIC
            "arbitrum": 2000,  # ~$2000/ETH
            "bsc": 300,        # ~$300/BNB
            "avalanche": 20,   # ~$20/AVAX
            "solana": 100      # ~$100/SOL
        }
        return gas_prices.get(network.lower(), 1.0)

    def classify_transaction(self, tx_data: Dict) -> TransactionType:
        """Classify transaction type with NFT marketplace detection"""
        to_address = tx_data.get("to", "").lower()
        input_data = tx_data.get("input", "")
        logs = tx_data.get("logs", [])
        network = tx_data.get("network", "ethereum")

        # Check all supported marketplaces
        for net_marketplaces in self.nft_marketplaces.values():
            for marketplace, address in net_marketplaces.items():
                if to_address == address.lower():
                    if "mint" in input_data.lower() or "0xa0712d68" in input_data:
                        return TransactionType.NFT_MINT
                    elif "transfer" in input_data.lower() or "0x23b872dd" in input_data:
                        return TransactionType.NFT_TRANSFER
                    elif "bid" in input_data.lower():
                        return TransactionType.NFT_BID
                    elif "auction" in input_data.lower():
                        return TransactionType.NFT_AUCTION

        # Royalty payment detection
        if "royalty" in input_data.lower() or any("royalty" in str(log) for log in logs):
            return TransactionType.ROYALTY_PAYMENT

        # Bundle transaction detection
        if "bundle" in input_data.lower() or len(tx_data.get("nftTokens", [])) > 1:
            return TransactionType.NFT_BUNDLE

        # Marketplace fee detection
        if "fee" in input_data.lower() and any("marketplace" in str(log) for log in logs):
            return TransactionType.MARKETPLACE_FEE

        # NFT lending/staking detection
        if "lend" in input_data.lower() or "stake" in input_data.lower():
            return TransactionType.NFT_LENDING if "lend" in input_data.lower() else TransactionType.NFT_STAKING

        return TransactionType.NFT_SALE  # Default for NFT context

    def detect_marketplace(self, tx_data: Dict) -> str:
        """Detect which NFT marketplace was used"""
        to_address = tx_data.get("to", "").lower()
        network = tx_data.get("network", "ethereum")

        if network in self.nft_marketplaces:
            for marketplace, address in self.nft_marketplaces[network].items():
                if to_address == address.lower():
                    return marketplace

        return "unknown"

    def detect_nft_contract(self, tx_data: Dict) -> str:
        """Detect NFT contract address from transaction"""
        # Check logs for NFT transfer events
        logs = tx_data.get("logs", [])
        for log in logs:
            if log.get("topics", []) and len(log["topics"]) > 0:
                # ERC721 Transfer event signature
                if log["topics"][0] == "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef":
                    return log.get("address", "unknown")

        # Fallback to 'to' address if it's an NFT contract
        return tx_data.get("to", "unknown")

    def distribute_revenue(self, toll_amount: float) -> Dict:
        """Distribute collected toll according to QuranChain economics"""
        founder_share = toll_amount * FOUNDER_ROYALTY_RATE
        ai_validator_share = toll_amount * AI_VALIDATOR_RATE
        hardware_host_share = toll_amount * HARDWARE_HOST_RATE
        ecosystem_share = toll_amount * ECOSYSTEM_RATE
        zakat_share = toll_amount * ZAKAT_RATE

        distribution = {
            "founder": founder_share,
            "ai_validators": ai_validator_share,
            "hardware_hosts": hardware_host_share,
            "ecosystem": ecosystem_share,
            "zakat": zakat_share,
            "total_distributed": founder_share + ai_validator_share + hardware_host_share + ecosystem_share + zakat_share
        }

        # Update revenue stats
        self.revenue_stats["founder_royalty_paid"] += founder_share
        self.revenue_stats["total_toll_collected_usd"] += toll_amount

        return distribution

    def process_transaction(self, tx_data: Dict) -> Dict:
        """Process an NFT transaction and collect gas toll"""
        try:
            tx_hash = tx_data.get("hash")
            sender = tx_data.get("from")
            recipient = tx_data.get("to")
            value_usd = float(tx_data.get("valueUSD", 0))
            gas_used = int(tx_data.get("gasUsed", 0))
            gas_price = float(tx_data.get("gasPrice", 0)) / 1e-9  # Convert wei to gwei
            block_number = int(tx_data.get("blockNumber", 0))
            network = tx_data.get("network", "ethereum")

            # Classify transaction
            tx_type = self.classify_transaction(tx_data)

            # Detect marketplace and NFT contract
            marketplace = self.detect_marketplace(tx_data)
            nft_contract = self.detect_nft_contract(tx_data)

            # Get NFT value and royalty info
            nft_value_usd = float(tx_data.get("nftValueUSD", 0))
            royalty_amount = float(tx_data.get("royaltyAmount", 0))
            bundle_size = int(tx_data.get("bundleSize", 1))

            # Calculate toll
            toll_amount = self.calculate_gas_toll(gas_used, gas_price, value_usd, tx_type, network, nft_value_usd)

            # Create transaction record
            transaction = GasTollTransaction(
                tx_hash=tx_hash,
                sender=sender,
                recipient=recipient,
                amount_usd=value_usd,
                gas_used=gas_used,
                gas_price_gwei=gas_price,
                toll_collected_usd=toll_amount,
                transaction_type=tx_type,
                timestamp=datetime.utcnow().isoformat(),
                block_number=block_number,
                founder_royalty=toll_amount * FOUNDER_ROYALTY_RATE,
                ai_validator_share=toll_amount * AI_VALIDATOR_RATE,
                hardware_host_share=toll_amount * HARDWARE_HOST_RATE,
                nft_contract=nft_contract,
                marketplace=marketplace,
                network=network,
                nft_value_usd=nft_value_usd,
                royalty_amount=royalty_amount,
                bundle_size=bundle_size
            )

            # Distribute revenue
            distribution = self.distribute_revenue(toll_amount)

            # Store transaction
            self.transactions.append(transaction)
            self.revenue_stats["transactions_processed"] += 1

            # Update NFT stats
            if nft_value_usd:
                self.revenue_stats["total_nft_value_processed"] += nft_value_usd
            if royalty_amount:
                self.revenue_stats["total_royalties_collected"] += royalty_amount
            if bundle_size > 1:
                self.revenue_stats["avg_bundle_size"] = (
                    (self.revenue_stats["avg_bundle_size"] * (self.revenue_stats["bundle_transactions"] - 1) + bundle_size) /
                    self.revenue_stats["bundle_transactions"]
                )

            # Log to CRM
            self.log_to_crm(transaction, distribution)

            # AI Learning
            self.learn_from_transaction(transaction)

            self.logger.info(f"💰 Collected ${toll_amount:.2f} toll from {tx_hash[:10]}... ({tx_type.value} on {marketplace})")

            return {
                "success": True,
                "transaction": asdict(transaction),
                "distribution": distribution,
                "ai_insights": self.generate_nft_insights(transaction)
            }

        except Exception as e:
            self.logger.error(f"❌ Transaction processing failed: {str(e)}")
            return {"success": False, "error": str(e)}

    def learn_from_transaction(self, transaction: GasTollTransaction):
        """AI learning from NFT transaction patterns"""
        # Track marketplace performance
        if transaction.marketplace != "unknown":
            if transaction.marketplace not in self.learning_patterns["marketplace_performance"]:
                self.learning_patterns["marketplace_performance"][transaction.marketplace] = []
            self.learning_patterns["marketplace_performance"][transaction.marketplace].append(transaction.amount_usd)

        # Track floor price trends
        if transaction.nft_contract != "unknown" and transaction.nft_value_usd:
            if transaction.nft_contract not in self.learning_patterns["floor_price_trends"]:
                self.learning_patterns["floor_price_trends"][transaction.nft_contract] = []
            self.learning_patterns["floor_price_trends"][transaction.nft_contract].append(transaction.nft_value_usd)

        # Track bundle opportunities
        if transaction.bundle_size and transaction.bundle_size > 1:
            self.learning_patterns["bundle_opportunities"].append({
                "size": transaction.bundle_size,
                "value": transaction.nft_value_usd,
                "timestamp": transaction.timestamp
            })

        # Track gas war patterns
        if transaction.gas_price_gwei > 100:
            self.learning_patterns["gas_war_patterns"].append({
                "gas_price": transaction.gas_price_gwei,
                "transaction_type": transaction.transaction_type.value,
                "timestamp": transaction.timestamp
            })

    def generate_nft_insights(self, transaction: GasTollTransaction) -> Dict:
        """Generate NFT-specific AI insights"""
        insights = {
            "gas_efficiency": "optimal" if transaction.gas_price_gwei < 50 else "high",
            "marketplace": transaction.marketplace,
            "transaction_type": transaction.transaction_type.value,
            "network": transaction.network,
            "nft_contract": transaction.nft_contract,
            "high_value_nft": transaction.nft_value_usd and transaction.nft_value_usd > 10000,
            "bundle_transaction": transaction.bundle_size and transaction.bundle_size > 1
        }

        # NFT-specific recommendations
        recommendations = []
        if transaction.nft_value_usd and transaction.nft_value_usd > 50000:
            recommendations.append(f"High-value NFT transaction: ${transaction.nft_value_usd:,.0f}")

        if transaction.bundle_size and transaction.bundle_size > 5:
            recommendations.append(f"Large bundle detected: {transaction.bundle_size} NFTs")

        if transaction.gas_price_gwei > 100:
            recommendations.append("Gas war conditions detected - consider timing optimization")

        if transaction.royalty_amount:
            recommendations.append(f"Royalty payment: ${transaction.royalty_amount:.2f}")

        if transaction.transaction_type == TransactionType.NFT_MINT:
            recommendations.append("New NFT minting opportunity")

        insights["recommendations"] = recommendations

        return insights

    def log_to_crm(self, transaction: GasTollTransaction, distribution: Dict):
        """Log transaction to CRM database"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            # Insert transaction record
            cursor.execute("""
                INSERT INTO gas_toll_transactions
                (agent_name, network, tx_hash, sender, recipient, amount, toll_collected,
                 founder_royalty, ai_validator_share, hardware_host_share, timestamp,
                 marketplace, nft_contract, nft_value, royalty_amount, bundle_size)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.agent_name,
                transaction.network,
                transaction.tx_hash,
                transaction.sender,
                transaction.recipient,
                transaction.amount_usd,
                transaction.toll_collected_usd,
                distribution["founder"],
                distribution["ai_validators"],
                distribution["hardware_hosts"],
                transaction.timestamp,
                transaction.marketplace,
                transaction.nft_contract,
                transaction.nft_value_usd,
                transaction.royalty_amount,
                transaction.bundle_size
            ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"CRM logging failed: {str(e)}")

    def get_revenue_stats(self) -> Dict:
        """Get comprehensive revenue statistics"""
        return {
            "agent": self.agent_name,
            "network": self.network,
            "contract_address": self.contract_address,
            "commission_rate": f"{self.commission_rate * 100}%",
            "founder_royalty_rate": f"{FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)",
            "total_toll_collected_usd": self.revenue_stats["total_toll_collected_usd"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "transactions_processed": self.revenue_stats["transactions_processed"],
            "nft_mints": self.revenue_stats["nft_mints"],
            "nft_sales": self.revenue_stats["nft_sales"],
            "nft_transfers": self.revenue_stats["nft_transfers"],
            "royalty_payments": self.revenue_stats["royalty_payments"],
            "bundle_transactions": self.revenue_stats["bundle_transactions"],
            "marketplace_fees": self.revenue_stats["marketplace_fees"],
            "total_nft_value_processed": self.revenue_stats["total_nft_value_processed"],
            "total_royalties_collected": self.revenue_stats["total_royalties_collected"],
            "avg_bundle_size": self.revenue_stats["avg_bundle_size"],
            "marketplace_performance": self.learning_patterns["marketplace_performance"],
            "timestamp": datetime.utcnow().isoformat()
        }

# Global agent instance
nft_agent = NFTGasTollAgent()

# Flask Routes
@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "agent": nft_agent.agent_name,
        "network": nft_agent.network,
        "contract": nft_agent.contract_address,
        "timestamp": datetime.utcnow().isoformat()
    })

@app.route('/metrics', methods=['GET'])
def metrics():
    """Performance metrics endpoint"""
    return jsonify({
        "agent_metrics": nft_agent.get_revenue_stats(),
        "nft_marketplaces": nft_agent.nft_marketplaces,
        "system_health": {
            "transactions_in_memory": len(nft_agent.transactions),
            "log_file_size": os.path.getsize(f"{nft_agent.log_dir}/{nft_agent.agent_name}.log") if os.path.exists(f"{nft_agent.log_dir}/{nft_agent.agent_name}.log") else 0
        }
    })

@app.route('/revenue', methods=['GET'])
def revenue():
    """Revenue statistics endpoint"""
    return jsonify(nft_agent.get_revenue_stats())

@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    """Process an NFT transaction"""
    try:
        tx_data = request.get_json()
        if not tx_data:
            return jsonify({"error": "No transaction data provided"}), 400

        result = nft_agent.process_transaction(tx_data)
        return jsonify(result)

    except Exception as e:
        nft_agent.logger.error(f"Transaction processing error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/nft_insights', methods=['GET'])
def nft_insights():
    """Get NFT-specific AI insights"""
    return jsonify({
        "marketplace_performance": nft_agent.learning_patterns["marketplace_performance"],
        "floor_price_trends": {k: v[-10:] for k, v in nft_agent.learning_patterns["floor_price_trends"].items()},  # Last 10 prices
        "bundle_opportunities": nft_agent.learning_patterns["bundle_opportunities"][-20:],  # Last 20
        "gas_war_patterns": nft_agent.learning_patterns["gas_war_patterns"][-20:],  # Last 20
        "recommendations": [
            "Focus toll collection on high-volume NFT marketplaces",
            f"Top performing marketplace: {max(nft_agent.learning_patterns['marketplace_performance'], key=lambda x: len(nft_agent.learning_patterns['marketplace_performance'][x])) if nft_agent.learning_patterns['marketplace_performance'] else 'None'}",
            f"Total NFT value processed: ${nft_agent.revenue_stats['total_nft_value_processed']:,.0f}",
            f"Total royalties collected: ${nft_agent.revenue_stats['total_royalties_collected']:,.0f}",
            "Monitor gas war conditions for optimal timing",
            "Track bundle transaction opportunities",
            f"Average bundle size: {nft_agent.revenue_stats['avg_bundle_size']:.1f} NFTs"
        ]
    })

@app.route('/contract_info', methods=['GET'])
def contract_info():
    """Get contract information"""
    return jsonify({
        "contract_address": nft_agent.contract_address,
        "network": nft_agent.network,
        "commission_rate": nft_agent.commission_rate,
        "specialization": AGENT_CONFIG["specialization"],
        "expertise": AGENT_CONFIG["expertise"],
        "supported_networks": list(nft_agent.nft_marketplaces.keys())
    })

if __name__ == "__main__":
    print("🔥 Starting NFT Gas Toll Agent...")
    print(f"   📡 Port: {PORT}")
    print(f"   🌐 Network: {nft_agent.network}")
    print(f"   📋 Contract: {nft_agent.contract_address}")
    print(f"   💰 Commission: {nft_agent.commission_rate * 100}%")
    print(f"   👑 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print("=" * 60)

    app.run(host='localhost', port=PORT, debug=False)