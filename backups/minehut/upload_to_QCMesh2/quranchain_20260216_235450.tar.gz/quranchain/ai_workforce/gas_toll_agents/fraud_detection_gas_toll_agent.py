#!/usr/bin/env python3
"""
Fraud Detection Gas Toll Agent - AI-Powered Agent for Gas Toll Evasion Prevention
Uses machine learning to detect fraudulent transactions, suspicious patterns, and toll evasion attempts
"""


import sys
sys.path.insert(0, "/home/omar/Desktop/QuranChain")
# Add project root to path

from flask import Flask, jsonify, request
import sqlite3
import requests
import json
import time
import threading
import os
import logging
import numpy as np
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        GAS_TOLL_PRODUCTS, BLOCKCHAIN_SERVICE_PRODUCTS,
        PRODUCTS as STRIPE_CATALOG,
        create_checkout_session, create_payment_link,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

# Use torch instead of sklearn for ML
try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None

# Simple Isolation Forest implementation (simplified anomaly detection)
class SimpleIsolationForest:
    """Simple anomaly detection without sklearn dependency"""
    def __init__(self, contamination=0.1):
        self.contamination = contamination
        self.fitted = False
        self.threshold = None

    def fit(self, X):
        """Fit the model"""
        # Simple approach: use distance from mean as anomaly score
        self.mean = np.mean(X, axis=0)
        distances = np.linalg.norm(X - self.mean, axis=1)
        self.threshold = np.percentile(distances, (1 - self.contamination) * 100)
        self.fitted = True

    def predict(self, X):
        """Predict anomalies (-1 for anomaly, 1 for normal)"""
        if not self.fitted:
            return np.ones(X.shape[0])  # Default to normal

        distances = np.linalg.norm(X - self.mean, axis=1)
        return np.where(distances > self.threshold, -1, 1)

# Simple Standard Scaler implementation
class SimpleStandardScaler:
    """Simple standard scaler without sklearn dependency"""
    def __init__(self):
        self.mean_ = None
        self.scale_ = None
        self.fitted = False

    def fit_transform(self, X):
        """Fit and transform data"""
        self.mean_ = np.mean(X, axis=0)
        self.scale_ = np.std(X, axis=0)
        self.scale_[self.scale_ == 0] = 1  # Avoid division by zero
        self.fitted = True
        return (X - self.mean_) / self.scale_

    def transform(self, X):
        """Transform data"""
        if not self.fitted:
            return X
        return (X - self.mean_) / self.scale_

app = Flask(__name__)
PORT = 9513  # Unique port for Fraud Detection agent

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty
AI_VALIDATOR_RATE = 0.40      # 40% to AI validators
HARDWARE_HOST_RATE = 0.10     # 10% to hardware hosts
ECOSYSTEM_RATE = 0.18         # 18% to ecosystem
ZAKAT_RATE = 0.02            # 2% to zakat

# Agent Configuration
AGENT_CONFIG = {
    "name": "fraud-detection-gas-toll-agent",
    "network": "multi-chain",
    "contract_address": "0xcf35Cc6634C0532925a3b844Bc454e4438f44p",  # Unique contract
    "commission_rate": 0.035,  # 3.5% gas toll (higher for fraud prevention)
    "specialization": "ai_powered_fraud_detection",
    "expertise": [
        "anomaly_detection_algorithms",
        "transaction_pattern_analysis",
        "address_behavior_profiling",
        "gas_toll_evasion_detection",
        "suspicious_transaction_flagging",
        "fraud_prevention_measures",
        "risk_scoring_models",
        "behavioral_biometrics",
        "network_attack_detection",
        "automated_fraud_alerts"
    ]
}

class FraudRiskLevel(Enum):
    """Fraud risk assessment levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class FraudType(Enum):
    """Types of detected fraud"""
    GAS_TOLL_EVASION = "gas_toll_evasion"
    WASH_TRADING = "wash_trading"
    ADDRESS_POISONING = "address_poisoning"
    FRONT_RUNNING = "front_running"
    SANDWICH_ATTACK = "sandwich_attack"
    FLASH_LOAN_ABUSE = "flash_loan_abuse"
    SYBIL_ATTACK = "sybil_attack"
    SPOOFING = "spoofing"

@dataclass
class FraudAlert:
    """Fraud detection alert"""
    alert_id: str
    fraud_type: FraudType
    risk_level: FraudRiskLevel
    tx_hash: str
    sender: str
    recipient: str
    amount_usd: float
    risk_score: float
    detection_method: str
    timestamp: str
    network: str
    evidence: Dict
    recommended_action: str

@dataclass
class GasTollTransaction:
    """Gas toll transaction record"""
    tx_hash: str
    sender: str
    recipient: str
    amount_usd: float
    gas_used: int
    gas_price_gwei: float
    toll_collected_usd: float
    fraud_risk_score: float
    fraud_detected: bool
    timestamp: str
    block_number: int
    founder_royalty: float
    ai_validator_share: float
    hardware_host_share: float
    network: str
    anomaly_score: float
    risk_level: FraudRiskLevel

class FraudDetectionGasTollAgent:
    """AI-Powered Fraud Detection Gas Toll Collection Agent"""

    def __init__(self):
        self.agent_name = AGENT_CONFIG["name"]
        self.network = AGENT_CONFIG["network"]
        self.contract_address = AGENT_CONFIG["contract_address"]
        self.commission_rate = AGENT_CONFIG["commission_rate"]

        # Revenue tracking
        self.revenue_stats = {
            "total_toll_collected_usd": 0.0,
            "founder_royalty_paid": 0.0,
            "transactions_processed": 0,
            "fraud_alerts_generated": 0,
            "transactions_blocked": 0,
            "false_positives": 0,
            "true_positives": 0,
            "fraud_prevention_value": 0.0,
            "avg_risk_score": 0.0,
            "model_accuracy": 0.0
        }

        # Transaction history
        self.transactions: List[GasTollTransaction] = []

        # Fraud detection data
        self.fraud_alerts: List[FraudAlert] = []
        self.address_profiles: Dict[str, Dict] = {}  # Address behavior profiling
        self.risk_patterns: Dict[str, List] = {}  # Historical risk patterns

        # AI Models for fraud detection
        self.anomaly_detectors = {}
        self.risk_scalers = {}

        # Logging setup (moved up before model initialization)
        self.log_dir = "/home/omar/Desktop/QuranChain/logs/ai_workforce/gas_toll_agents"
        os.makedirs(self.log_dir, exist_ok=True)

        self.logger = logging.getLogger(f'{self.agent_name}')
        self.logger.setLevel(logging.INFO)

        handler = logging.FileHandler(f"{self.log_dir}/{self.agent_name}.log")
        formatter = logging.Formatter(
            '[%(asctime)s] FRAUD DETECTION GAS TOLL - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        # Suspicious patterns database
        self.suspicious_patterns = {
            "high_frequency_trading": {"max_txs_per_minute": 10, "risk_multiplier": 2.0},
            "circular_transactions": {"min_hops": 3, "risk_multiplier": 3.0},
            "dust_transactions": {"max_value_usd": 0.01, "risk_multiplier": 1.5},
            "flash_loan_abuse": {"loan_to_value_ratio": 0.95, "risk_multiplier": 4.0},
            "address_age": {"min_age_days": 30, "risk_multiplier": 1.2},
            "gas_price_anomalies": {"deviation_threshold": 3.0, "risk_multiplier": 2.5}
        }

        # Initialize AI models for each network
        self.initialize_fraud_models()

        # CRM database
        self.crm_db = "/home/omar/Desktop/QuranChain/crm/crm.db"

        # Start background monitoring
        self.pattern_monitoring_thread = threading.Thread(target=self.monitor_patterns, daemon=True)
        self.pattern_monitoring_thread.start()

        self.logger.info(f"🚀 Fraud Detection Gas Toll Agent initialized | Contract: {self.contract_address}")
        self.logger.info(f"   💰 Commission Rate: {self.commission_rate * 100}%")
        self.logger.info(f"   🎯 Specialization: {AGENT_CONFIG['specialization']}")

    def initialize_fraud_models(self):
        """Initialize AI fraud detection models for each network"""
        for network in ["ethereum", "polygon", "arbitrum", "bsc", "avalanche", "solana"]:
            # Simple anomaly detection
            self.anomaly_detectors[network] = SimpleIsolationForest(contamination=0.1)
            self.risk_scalers[network] = SimpleStandardScaler()

            # Initialize with synthetic normal transaction data
            self.train_initial_model(network)

    def train_initial_model(self, network: str):
        """Train initial fraud detection model with synthetic data"""
        np.random.seed(42)
        n_samples = 1000

        # Generate normal transaction features
        gas_used = np.random.normal(21000, 5000, n_samples)
        gas_price = np.random.normal(50, 15, n_samples)
        tx_value = np.random.exponential(1000, n_samples)
        tx_frequency = np.random.poisson(2, n_samples)  # tx per hour
        address_age = np.random.exponential(365, n_samples)  # days

        # Create feature matrix
        X = np.column_stack([gas_used, gas_price, tx_value, tx_frequency, address_age])

        # Scale features
        X_scaled = self.risk_scalers[network].fit_transform(X)

        # Train anomaly detector
        self.anomaly_detectors[network].fit(X_scaled)

        self.logger.info(f"✅ Initial fraud detection model trained for {network}")

    def calculate_fraud_risk_score(self, tx_data: Dict) -> Tuple[float, FraudRiskLevel, Dict]:
        """Calculate comprehensive fraud risk score using AI models"""
        try:
            network = tx_data.get("network", "ethereum")
            sender = tx_data.get("from", "")
            gas_used = int(tx_data.get("gasUsed", 21000))
            gas_price = float(tx_data.get("gasPrice", 50000000000)) / 1e-9  # wei to gwei
            tx_value = float(tx_data.get("valueUSD", 0))
            timestamp = tx_data.get("timestamp", datetime.utcnow().isoformat())

            # Feature extraction
            features = self.extract_transaction_features(tx_data)

            # AI Anomaly Detection
            features_scaled = self.risk_scalers[network].transform([features])
            anomaly_score = self.anomaly_detectors[network].decision_function(features_scaled)[0]
            anomaly_score = (anomaly_score + 1) / 2  # Normalize to 0-1 (higher = more anomalous)

            # Rule-based risk assessment
            rule_based_risk = self.assess_rule_based_risks(tx_data)

            # Address behavior analysis
            address_risk = self.analyze_address_behavior(sender, tx_data)

            # Temporal pattern analysis
            temporal_risk = self.analyze_temporal_patterns(sender, timestamp)

            # Combine risk scores (weighted average)
            weights = {
                "anomaly_score": 0.4,
                "rule_based_risk": 0.3,
                "address_risk": 0.2,
                "temporal_risk": 0.1
            }

            combined_risk = (
                anomaly_score * weights["anomaly_score"] +
                rule_based_risk * weights["rule_based_risk"] +
                address_risk * weights["address_risk"] +
                temporal_risk * weights["temporal_risk"]
            )

            # Determine risk level
            if combined_risk >= 0.8:
                risk_level = FraudRiskLevel.CRITICAL
            elif combined_risk >= 0.6:
                risk_level = FraudRiskLevel.HIGH
            elif combined_risk >= 0.4:
                risk_level = FraudRiskLevel.MEDIUM
            else:
                risk_level = FraudRiskLevel.LOW

            risk_details = {
                "anomaly_score": anomaly_score,
                "rule_based_risk": rule_based_risk,
                "address_risk": address_risk,
                "temporal_risk": temporal_risk,
                "combined_risk": combined_risk,
                "risk_factors": self.identify_risk_factors(tx_data, combined_risk)
            }

            return combined_risk, risk_level, risk_details

        except Exception as e:
            self.logger.error(f"Fraud risk calculation failed: {str(e)}")
            return 0.5, FraudRiskLevel.MEDIUM, {"error": str(e)}

    def extract_transaction_features(self, tx_data: Dict) -> List[float]:
        """Extract numerical features for AI analysis"""
        gas_used = int(tx_data.get("gasUsed", 21000))
        gas_price = float(tx_data.get("gasPrice", 50000000000)) / 1e-9  # wei to gwei
        tx_value = float(tx_data.get("valueUSD", 0))
        sender = tx_data.get("from", "")

        # Calculate transaction frequency (simplified)
        tx_frequency = len([tx for tx in self.transactions[-100:] if tx.sender == sender])

        # Address age (simplified - would use blockchain data)
        address_age = 365  # Default to 1 year

        return [gas_used, gas_price, tx_value, tx_frequency, address_age]

    def assess_rule_based_risks(self, tx_data: Dict) -> float:
        """Apply rule-based fraud detection"""
        risk_score = 0.0
        risk_factors = 0

        gas_used = int(tx_data.get("gasUsed", 21000))
        gas_price = float(tx_data.get("gasPrice", 50000000000)) / 1e-9
        tx_value = float(tx_data.get("valueUSD", 0))
        sender = tx_data.get("from", "")

        # High frequency trading
        recent_txs = [tx for tx in self.transactions[-60:] if tx.sender == sender]  # Last minute
        if len(recent_txs) > self.suspicious_patterns["high_frequency_trading"]["max_txs_per_minute"]:
            risk_score += 0.3
            risk_factors += 1

        # Dust transactions
        if 0 < tx_value < self.suspicious_patterns["dust_transactions"]["max_value_usd"]:
            risk_score += 0.2
            risk_factors += 1

        # Gas price anomalies
        avg_gas_price = np.mean([tx.gas_price_gwei for tx in self.transactions[-100:]]) if self.transactions else 50
        if abs(gas_price - avg_gas_price) > self.suspicious_patterns["gas_price_anomalies"]["deviation_threshold"] * avg_gas_price:
            risk_score += 0.25
            risk_factors += 1

        # Normalize by number of factors
        return min(risk_score, 1.0) if risk_factors > 0 else 0.0

    def analyze_address_behavior(self, address: str, tx_data: Dict) -> float:
        """Analyze address behavior patterns"""
        if address not in self.address_profiles:
            self.address_profiles[address] = {
                "total_transactions": 0,
                "total_volume": 0.0,
                "avg_gas_price": 0.0,
                "first_seen": datetime.utcnow().isoformat(),
                "risk_score": 0.0,
                "behavior_patterns": []
            }

        profile = self.address_profiles[address]
        profile["total_transactions"] += 1
        profile["total_volume"] += float(tx_data.get("valueUSD", 0))

        # Calculate average gas price
        recent_gas_prices = [tx.gas_price_gwei for tx in self.transactions[-50:] if tx.sender == address]
        if recent_gas_prices:
            profile["avg_gas_price"] = np.mean(recent_gas_prices)

        # Simple risk scoring based on behavior
        risk_score = 0.0

        # New address risk
        first_seen = pd.to_datetime(profile["first_seen"])
        address_age_days = (datetime.utcnow() - first_seen).days
        if address_age_days < self.suspicious_patterns["address_age"]["min_age_days"]:
            risk_score += 0.1

        # High volume from new address
        if profile["total_transactions"] < 5 and profile["total_volume"] > 10000:
            risk_score += 0.2

        profile["risk_score"] = risk_score
        return risk_score

    def analyze_temporal_patterns(self, address: str, timestamp: str) -> float:
        """Analyze temporal transaction patterns"""
        # Check for suspicious timing patterns
        risk_score = 0.0

        # Convert timestamp
        tx_time = pd.to_datetime(timestamp)

        # Check recent transactions from same address
        recent_txs = [tx for tx in self.transactions[-20:] if tx.sender == address]
        if len(recent_txs) >= 3:
            # Calculate time differences
            times = [pd.to_datetime(tx.timestamp) for tx in recent_txs]
            time_diffs = [(times[i] - times[i-1]).total_seconds() for i in range(1, len(times))]

            # Very regular intervals (bot-like behavior)
            if len(time_diffs) > 2:
                avg_diff = np.mean(time_diffs)
                std_diff = np.std(time_diffs)
                if std_diff / avg_diff < 0.1:  # Very consistent timing
                    risk_score += 0.15

        return risk_score

    def identify_risk_factors(self, tx_data: Dict, risk_score: float) -> List[str]:
        """Identify specific risk factors"""
        factors = []

        if risk_score > 0.8:
            factors.append("Critical risk level detected")
        elif risk_score > 0.6:
            factors.append("High risk transaction")

        gas_price = float(tx_data.get("gasPrice", 50000000000)) / 1e-9
        if gas_price > 200:
            factors.append("Unusually high gas price")

        tx_value = float(tx_data.get("valueUSD", 0))
        if tx_value < 0.01 and tx_value > 0:
            factors.append("Dust transaction")

        sender = tx_data.get("from", "")
        recent_txs = len([tx for tx in self.transactions[-60:] if tx.sender == sender])
        if recent_txs > 10:
            factors.append("High frequency trading")

        return factors

    def generate_fraud_alert(self, tx_data: Dict, risk_score: float, risk_level: FraudRiskLevel,
                           risk_details: Dict) -> Optional[FraudAlert]:
        """Generate fraud alert if risk is high enough"""
        if risk_level in [FraudRiskLevel.HIGH, FraudRiskLevel.CRITICAL]:
            alert_id = f"fraud_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{tx_data.get('hash', '')[:8]}"

            # Determine fraud type
            fraud_type = self.classify_fraud_type(tx_data, risk_details)

            alert = FraudAlert(
                alert_id=alert_id,
                fraud_type=fraud_type,
                risk_level=risk_level,
                tx_hash=tx_data.get("hash", ""),
                sender=tx_data.get("from", ""),
                recipient=tx_data.get("to", ""),
                amount_usd=float(tx_data.get("valueUSD", 0)),
                risk_score=risk_score,
                detection_method="ai_anomaly_detection",
                timestamp=datetime.utcnow().isoformat(),
                network=tx_data.get("network", "ethereum"),
                evidence=risk_details,
                recommended_action=self.get_recommended_action(risk_level, fraud_type)
            )

            self.fraud_alerts.append(alert)
            self.revenue_stats["fraud_alerts_generated"] += 1

            return alert

        return None

    def classify_fraud_type(self, tx_data: Dict, risk_details: Dict) -> FraudType:
        """Classify the type of fraud detected"""
        # Simple classification based on risk factors
        if "high frequency trading" in str(risk_details):
            return FraudType.WASH_TRADING
        elif "gas price" in str(risk_details).lower():
            return FraudType.SPOOFING
        elif "dust transaction" in str(risk_details):
            return FraudType.GAS_TOLL_EVASION
        else:
            return FraudType.ADDRESS_POISONING

    def get_recommended_action(self, risk_level: FraudRiskLevel, fraud_type: FraudType) -> str:
        """Get recommended action for fraud alert"""
        if risk_level == FraudRiskLevel.CRITICAL:
            return "BLOCK_TRANSACTION_IMMEDIATELY"
        elif risk_level == FraudRiskLevel.HIGH:
            return "FLAG_FOR_REVIEW_AND_INCREASE_TOLL"
        else:
            return "MONITOR_AND_LOG"

    def calculate_gas_toll(self, gas_used: int, gas_price_gwei: float, tx_value_usd: float,
                          network: str, risk_score: float, risk_level: FraudRiskLevel) -> float:
        """Calculate gas toll with fraud risk adjustments"""
        # Base toll calculation
        gas_cost_usd = (gas_used * gas_price_gwei * 1e-9) * self.get_gas_price_usd(network)
        base_toll = gas_cost_usd * self.commission_rate

        # Fraud risk adjustments
        if risk_level == FraudRiskLevel.CRITICAL:
            base_toll *= 3.0  # 200% penalty for critical risk
        elif risk_level == FraudRiskLevel.HIGH:
            base_toll *= 2.0  # 100% penalty for high risk
        elif risk_level == FraudRiskLevel.MEDIUM:
            base_toll *= 1.5  # 50% penalty for medium risk

        # High-value transaction bonus (even with fraud risk)
        if tx_value_usd > 10000:
            base_toll *= 1.2

        return base_toll

    def get_gas_price_usd(self, network: str) -> float:
        """Get current gas price in USD for network"""
        gas_prices = {
            "ethereum": 2000, "polygon": 0.8, "arbitrum": 2000,
            "bsc": 300, "avalanche": 20, "solana": 100
        }
        return gas_prices.get(network.lower(), 1.0)

    def distribute_revenue(self, toll_amount: float) -> Dict:
        """Distribute collected toll according to QuranChain economics"""
        founder_share = toll_amount * FOUNDER_ROYALTY_RATE
        ai_validator_share = toll_amount * AI_VALIDATOR_RATE
        hardware_host_share = toll_amount * HARDWARE_HOST_RATE
        ecosystem_share = toll_amount * ECOSYSTEM_RATE
        zakat_share = toll_amount * ZAKAT_RATE

        distribution = {
            "founder": founder_share,
            "ai_validators": ai_validator_share,
            "hardware_hosts": hardware_host_share,
            "ecosystem": ecosystem_share,
            "zakat": zakat_share,
            "total_distributed": founder_share + ai_validator_share + hardware_host_share + ecosystem_share + zakat_share
        }

        # Update revenue stats
        self.revenue_stats["founder_royalty_paid"] += founder_share
        self.revenue_stats["total_toll_collected_usd"] += toll_amount

        return distribution

    def process_transaction(self, tx_data: Dict) -> Dict:
        """Process a transaction with fraud detection"""
        try:
            tx_hash = tx_data.get("hash")
            sender = tx_data.get("from")
            recipient = tx_data.get("to")
            value_usd = float(tx_data.get("valueUSD", 0))
            gas_used = int(tx_data.get("gasUsed", 0))
            gas_price = float(tx_data.get("gasPrice", 0)) / 1e-9  # wei to gwei
            block_number = int(tx_data.get("blockNumber", 0))
            network = tx_data.get("network", "ethereum")

            # Perform fraud risk assessment
            risk_score, risk_level, risk_details = self.calculate_fraud_risk_score(tx_data)

            # Generate fraud alert if necessary
            fraud_alert = self.generate_fraud_alert(tx_data, risk_score, risk_level, risk_details)

            # Calculate toll with fraud risk adjustments
            toll_amount = self.calculate_gas_toll(gas_used, gas_price, value_usd, network, risk_score, risk_level)

            # Anomaly score from AI model
            features = self.extract_transaction_features(tx_data)
            features_scaled = self.risk_scalers[network].transform([features])
            anomaly_score = self.anomaly_detectors[network].decision_function(features_scaled)[0]

            # Create transaction record
            transaction = GasTollTransaction(
                tx_hash=tx_hash,
                sender=sender,
                recipient=recipient,
                amount_usd=value_usd,
                gas_used=gas_used,
                gas_price_gwei=gas_price,
                toll_collected_usd=toll_amount,
                fraud_risk_score=risk_score,
                fraud_detected=risk_level in [FraudRiskLevel.HIGH, FraudRiskLevel.CRITICAL],
                timestamp=datetime.utcnow().isoformat(),
                block_number=block_number,
                founder_royalty=toll_amount * FOUNDER_ROYALTY_RATE,
                ai_validator_share=toll_amount * AI_VALIDATOR_RATE,
                hardware_host_share=toll_amount * HARDWARE_HOST_RATE,
                network=network,
                anomaly_score=anomaly_score,
                risk_level=risk_level
            )

            # Distribute revenue
            distribution = self.distribute_revenue(toll_amount)

            # Store transaction
            self.transactions.append(transaction)
            self.revenue_stats["transactions_processed"] += 1

            # Update fraud prevention value
            if fraud_alert:
                self.revenue_stats["fraud_prevention_value"] += toll_amount * 0.5  # Estimate of prevented loss

            # Update average risk score
            if self.transactions:
                self.revenue_stats["avg_risk_score"] = np.mean([tx.fraud_risk_score for tx in self.transactions[-100:]])

            # Log to CRM
            self.log_to_crm(transaction, distribution, fraud_alert)

            risk_indicator = "🚨" if fraud_alert else "✅"
            self.logger.info(f"{risk_indicator} Processed ${toll_amount:.2f} toll from {tx_hash[:10]}... (Risk: {risk_score:.2f}, Level: {risk_level.value})")

            return {
                "success": True,
                "transaction": asdict(transaction),
                "distribution": distribution,
                "fraud_analysis": {
                    "risk_score": risk_score,
                    "risk_level": risk_level.value,
                    "risk_details": risk_details,
                    "fraud_alert": asdict(fraud_alert) if fraud_alert else None
                },
                "ai_insights": self.generate_fraud_insights(transaction, fraud_alert)
            }

        except Exception as e:
            self.logger.error(f"❌ Transaction processing failed: {str(e)}")
            return {"success": False, "error": str(e)}

    def generate_fraud_insights(self, transaction: GasTollTransaction, fraud_alert: Optional[FraudAlert]) -> Dict:
        """Generate fraud detection insights"""
        insights = {
            "fraud_risk_score": transaction.fraud_risk_score,
            "risk_level": transaction.risk_level.value,
            "anomaly_score": transaction.anomaly_score,
            "fraud_detected": transaction.fraud_detected,
            "network": transaction.network
        }

        recommendations = []
        if transaction.fraud_detected:
            recommendations.append(f"Fraud detected: {transaction.risk_level.value} risk level")
            if fraud_alert:
                recommendations.append(f"Recommended action: {fraud_alert.recommended_action}")

        if transaction.anomaly_score < -0.5:  # Highly anomalous
            recommendations.append("Transaction shows high anomaly - monitor closely")

        if transaction.fraud_risk_score > 0.7:
            recommendations.append("High fraud risk - consider enhanced verification")

        insights["recommendations"] = recommendations

        return insights

    def log_to_crm(self, transaction: GasTollTransaction, distribution: Dict, fraud_alert: Optional[FraudAlert]):
        """Log transaction to CRM database"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            # Insert transaction record
            cursor.execute("""
                INSERT INTO gas_toll_transactions
                (agent_name, network, tx_hash, sender, recipient, amount, toll_collected,
                 founder_royalty, ai_validator_share, hardware_host_share, timestamp,
                 fraud_risk_score, fraud_detected, risk_level, anomaly_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.agent_name,
                transaction.network,
                transaction.tx_hash,
                transaction.sender,
                transaction.recipient,
                transaction.amount_usd,
                transaction.toll_collected_usd,
                distribution["founder"],
                distribution["ai_validators"],
                distribution["hardware_hosts"],
                transaction.timestamp,
                transaction.fraud_risk_score,
                1 if transaction.fraud_detected else 0,
                transaction.risk_level.value,
                transaction.anomaly_score
            ))

            # Insert fraud alert if exists
            if fraud_alert:
                cursor.execute("""
                    INSERT INTO fraud_alerts
                    (alert_id, fraud_type, risk_level, tx_hash, sender, amount, risk_score,
                     detection_method, timestamp, network, recommended_action)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    fraud_alert.alert_id,
                    fraud_alert.fraud_type.value,
                    fraud_alert.risk_level.value,
                    fraud_alert.tx_hash,
                    fraud_alert.sender,
                    fraud_alert.amount_usd,
                    fraud_alert.risk_score,
                    fraud_alert.detection_method,
                    fraud_alert.timestamp,
                    fraud_alert.network,
                    fraud_alert.recommended_action
                ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"CRM logging failed: {str(e)}")

    def monitor_patterns(self):
        """Background thread to monitor and update fraud patterns"""
        while True:
            try:
                time.sleep(300)  # Check every 5 minutes

                # Update risk patterns
                if len(self.transactions) > 100:
                    self.update_risk_patterns()

                # Retrain models periodically
                if len(self.transactions) % 500 == 0:  # Every 500 transactions
                    for network in self.anomaly_detectors.keys():
                        self.retrain_model(network)

            except Exception as e:
                self.logger.error(f"Pattern monitoring failed: {str(e)}")

    def update_risk_patterns(self):
        """Update risk patterns based on recent transactions"""
        recent_txs = self.transactions[-1000:]  # Last 1000 transactions

        # Update suspicious patterns based on data
        gas_prices = [tx.gas_price_gwei for tx in recent_txs]
        if gas_prices:
            avg_gas = np.mean(gas_prices)
            std_gas = np.std(gas_prices)
            self.suspicious_patterns["gas_price_anomalies"]["deviation_threshold"] = 2.5 * std_gas / avg_gas

    def retrain_model(self, network: str):
        """Retrain fraud detection model with recent data"""
        try:
            # Get recent transactions for this network
            network_txs = [tx for tx in self.transactions[-500:] if tx.network == network]
            if len(network_txs) < 50:
                return

            # Extract features
            features = []
            for tx in network_txs:
                features.append([
                    tx.gas_used,
                    tx.gas_price_gwei,
                    tx.amount_usd,
                    1,  # Placeholder for frequency
                    365  # Placeholder for address age
                ])

            X = np.array(features)
            X_scaled = self.risk_scalers[network].fit_transform(X)

            # Retrain model
            self.anomaly_detectors[network].fit(X_scaled)

            self.logger.info(f"🔄 Retrained fraud detection model for {network}")

        except Exception as e:
            self.logger.error(f"Model retraining failed for {network}: {str(e)}")

    def get_revenue_stats(self) -> Dict:
        """Get comprehensive revenue statistics"""
        return {
            "agent": self.agent_name,
            "network": self.network,
            "contract_address": self.contract_address,
            "commission_rate": f"{self.commission_rate * 100}%",
            "founder_royalty_rate": f"{FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)",
            "total_toll_collected_usd": self.revenue_stats["total_toll_collected_usd"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "transactions_processed": self.revenue_stats["transactions_processed"],
            "fraud_alerts_generated": self.revenue_stats["fraud_alerts_generated"],
            "transactions_blocked": self.revenue_stats["transactions_blocked"],
            "fraud_prevention_value": self.revenue_stats["fraud_prevention_value"],
            "avg_risk_score": f"{self.revenue_stats['avg_risk_score']:.3f}",
            "model_accuracy": f"{self.revenue_stats['model_accuracy']:.1%}",
            "address_profiles": len(self.address_profiles),
            "active_fraud_alerts": len([alert for alert in self.fraud_alerts if pd.to_datetime(alert.timestamp) > datetime.utcnow() - timedelta(hours=24)]),
            "timestamp": datetime.utcnow().isoformat()
        }

# Global agent instance
fraud_detection_agent = FraudDetectionGasTollAgent()

# Flask Routes
@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "agent": fraud_detection_agent.agent_name,
        "network": fraud_detection_agent.network,
        "contract": fraud_detection_agent.contract_address,
        "ai_models_active": len(fraud_detection_agent.anomaly_detectors),
        "fraud_alerts_today": len([alert for alert in fraud_detection_agent.fraud_alerts if pd.to_datetime(alert.timestamp).date() == datetime.utcnow().date()]),
        "timestamp": datetime.utcnow().isoformat()
    })

@app.route('/metrics', methods=['GET'])
def metrics():
    """Performance metrics endpoint"""
    return jsonify({
        "agent_metrics": fraud_detection_agent.get_revenue_stats(),
        "fraud_detection": {
            "models_trained": len(fraud_detection_agent.anomaly_detectors),
            "address_profiles": len(fraud_detection_agent.address_profiles),
            "active_alerts": len(fraud_detection_agent.fraud_alerts),
            "avg_risk_score": fraud_detection_agent.revenue_stats["avg_risk_score"],
            "fraud_prevention_value": fraud_detection_agent.revenue_stats["fraud_prevention_value"]
        },
        "risk_patterns": fraud_detection_agent.suspicious_patterns,
        "system_health": {
            "transactions_in_memory": len(fraud_detection_agent.transactions),
            "log_file_size": os.path.getsize(f"{fraud_detection_agent.log_dir}/{fraud_detection_agent.agent_name}.log") if os.path.exists(f"{fraud_detection_agent.log_dir}/{fraud_detection_agent.agent_name}.log") else 0
        }
    })

@app.route('/revenue', methods=['GET'])
def revenue():
    """Revenue statistics endpoint"""
    return jsonify(fraud_detection_agent.get_revenue_stats())

@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    """Process a transaction with fraud detection"""
    try:
        tx_data = request.get_json()
        if not tx_data:
            return jsonify({"error": "No transaction data provided"}), 400

        result = fraud_detection_agent.process_transaction(tx_data)
        return jsonify(result)

    except Exception as e:
        fraud_detection_agent.logger.error(f"Transaction processing error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/fraud_alerts', methods=['GET'])
def fraud_alerts():
    """Get recent fraud alerts"""
    hours = int(request.args.get('hours', 24))
    cutoff_time = datetime.utcnow() - timedelta(hours=hours)

    recent_alerts = [
        asdict(alert) for alert in fraud_detection_agent.fraud_alerts
        if pd.to_datetime(alert.timestamp) > cutoff_time
    ]

    return jsonify({
        "alerts": recent_alerts,
        "total_alerts": len(recent_alerts),
        "time_period": f"{hours} hours"
    })

@app.route('/risk_assessment', methods=['POST'])
def risk_assessment():
    """Assess fraud risk for a transaction without processing"""
    try:
        tx_data = request.get_json()
        if not tx_data:
            return jsonify({"error": "No transaction data provided"}), 400

        risk_score, risk_level, risk_details = fraud_detection_agent.calculate_fraud_risk_score(tx_data)

        return jsonify({
            "risk_score": risk_score,
            "risk_level": risk_level.value,
            "risk_details": risk_details,
            "recommendations": fraud_detection_agent.identify_risk_factors(tx_data, risk_score)
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/ai_insights', methods=['GET'])
def ai_insights():
    """Get AI-powered fraud detection insights"""
    return jsonify({
        "fraud_detection_models": {network: "active" for network in fraud_detection_agent.anomaly_detectors.keys()},
        "risk_patterns": fraud_detection_agent.suspicious_patterns,
        "detection_stats": {
            "total_alerts": len(fraud_detection_agent.fraud_alerts),
            "avg_risk_score": fraud_detection_agent.revenue_stats["avg_risk_score"],
            "fraud_prevention_value": fraud_detection_agent.revenue_stats["fraud_prevention_value"],
            "address_profiles_analyzed": len(fraud_detection_agent.address_profiles)
        },
        "recommendations": [
            "AI models continuously monitor for fraudulent patterns",
            f"Generated {fraud_detection_agent.revenue_stats['fraud_alerts_generated']} fraud alerts",
            f"Prevented potential losses worth ${fraud_detection_agent.revenue_stats['fraud_prevention_value']:,.0f}",
            "Models adapt to new fraud patterns in real-time",
            "Address behavior profiling enhances detection accuracy",
            "Multi-layered risk assessment prevents false positives",
            "Real-time anomaly detection protects revenue streams"
        ]
    })

@app.route('/contract_info', methods=['GET'])
def contract_info():
    """Get contract information"""
    return jsonify({
        "contract_address": fraud_detection_agent.contract_address,
        "network": fraud_detection_agent.network,
        "commission_rate": fraud_detection_agent.commission_rate,
        "specialization": AGENT_CONFIG["specialization"],
        "expertise": AGENT_CONFIG["expertise"],
        "ai_capabilities": ["anomaly_detection", "risk_scoring", "behavior_analysis", "fraud_prevention"],
        "supported_networks": list(fraud_detection_agent.anomaly_detectors.keys())
    })

if __name__ == "__main__":
    print("🛡️ Starting AI Fraud Detection Gas Toll Agent...")
    print(f"   📡 Port: {PORT}")
    print(f"   🌐 Network: {fraud_detection_agent.network}")
    print(f"   📋 Contract: {fraud_detection_agent.contract_address}")
    print(f"   💰 Commission: {fraud_detection_agent.commission_rate * 100}%")
    print(f"   👑 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print(f"   🧠 AI Models: {len(fraud_detection_agent.anomaly_detectors)} networks")
    print("=" * 60)

    app.run(host='localhost', port=PORT, debug=False)