#!/usr/bin/env python3
"""
Network Congestion Gas Toll Agent - AI-Powered Agent for Network Congestion Exploitation
Uses machine learning to monitor network congestion patterns and optimize toll collection during peak times
"""


import sys
sys.path.insert(0, "/home/omar/Desktop/QuranChain")
# Add project root to path

from flask import Flask, jsonify, request
import sqlite3
import requests
import json
import time
import threading
import os
import logging
import numpy as np
from blockchain_logging_handler import setup_blockchain_logging
# import pandas as pd  # Removed due to sklearn dependency issues
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        GAS_TOLL_PRODUCTS, BLOCKCHAIN_SERVICE_PRODUCTS,
        PRODUCTS as STRIPE_CATALOG,
        create_checkout_session, create_payment_link,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

# Custom ML implementations to replace sklearn
class SimpleRandomForestClassifier:
    def __init__(self, n_estimators=10, random_state=42):
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.trees = []

    def fit(self, X, y):
        np.random.seed(self.random_state)
        n_samples, n_features = X.shape
        for _ in range(self.n_estimators):
            # Bootstrap sampling
            indices = np.random.choice(n_samples, n_samples, replace=True)
            X_boot = X[indices]
            y_boot = y[indices]
            # Simple decision tree (just store mean for each class)
            tree = {}
            for class_val in np.unique(y_boot):
                mask = y_boot == class_val
                tree[class_val] = np.mean(X_boot[mask], axis=0)
            self.trees.append(tree)

    def predict(self, X):
        predictions = []
        for x in X:
            votes = []
            for tree in self.trees:
                # Find closest class based on euclidean distance
                min_dist = float('inf')
                best_class = None
                for class_val, centroid in tree.items():
                    dist = np.linalg.norm(x - centroid)
                    if dist < min_dist:
                        min_dist = dist
                        best_class = class_val
                votes.append(best_class)
            # Majority vote
            predictions.append(np.argmax(np.bincount(votes)))
        return np.array(predictions)

class SimpleGradientBoostingRegressor:
    def __init__(self, n_estimators=10, learning_rate=0.1, random_state=42):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.random_state = random_state
        self.models = []
        self.initial_prediction = None

    def fit(self, X, y):
        np.random.seed(self.random_state)
        self.initial_prediction = np.mean(y)
        current_prediction = np.full_like(y, self.initial_prediction, dtype=float)

        for _ in range(self.n_estimators):
            residuals = y - current_prediction
            # Simple linear model for residuals
            model = SimpleLinearRegression()
            model.fit(X, residuals)
            self.models.append(model)
            current_prediction += self.learning_rate * model.predict(X)

    def predict(self, X):
        prediction = np.full(X.shape[0], self.initial_prediction, dtype=float)
        for model in self.models:
            prediction += self.learning_rate * model.predict(X)
        return prediction

class SimpleLinearRegression:
    def __init__(self):
        self.coef_ = None
        self.intercept_ = None

    def fit(self, X, y):
        # Add bias term
        X_b = np.c_[np.ones((X.shape[0], 1)), X]
        # Normal equation
        try:
            theta = np.linalg.inv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)
            self.intercept_ = theta[0]
            self.coef_ = theta[1:]
        except np.linalg.LinAlgError:
            # Fallback for singular matrix
            self.coef_ = np.zeros(X.shape[1])
            self.intercept_ = np.mean(y)

    def predict(self, X):
        return X.dot(self.coef_) + self.intercept_

class SimpleStandardScaler:
    def __init__(self):
        self.mean_ = None
        self.scale_ = None

    def fit(self, X):
        self.mean_ = np.mean(X, axis=0)
        self.scale_ = np.std(X, axis=0)
        # Avoid division by zero
        self.scale_[self.scale_ == 0] = 1
        return self

    def transform(self, X):
        return (X - self.mean_) / self.scale_

    def fit_transform(self, X):
        return self.fit(X).transform(X)

class SimpleLabelEncoder:
    def __init__(self):
        self.classes_ = None

    def fit(self, y):
        self.classes_ = np.unique(y)
        return self

    def fit_transform(self, y):
        self.fit(y)
        return self.transform(y)

    def transform(self, y):
        return np.array([np.where(self.classes_ == val)[0][0] for val in y])

    def inverse_transform(self, y):
        return np.array([self.classes_[int(val)] for val in y])

def simple_train_test_split(X, y, test_size=0.2, random_state=42):
    np.random.seed(random_state)
    n_samples = len(X)
    n_test = int(n_samples * test_size)
    indices = np.random.permutation(n_samples)
    test_indices = indices[:n_test]
    train_indices = indices[n_test:]
    return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

def simple_accuracy_score(y_true, y_pred):
    return np.mean(y_true == y_pred)

def simple_classification_report(y_true, y_pred, target_names=None):
    if target_names is None:
        target_names = [f"class_{i}" for i in np.unique(y_true)]
    report = {}
    for i, name in enumerate(target_names):
        mask = y_true == i
        if np.sum(mask) > 0:
            report[name] = {
                'precision': np.mean(y_pred[mask] == i),
                'recall': np.mean(y_pred[mask] == i),
                'f1-score': 2 * np.mean(y_pred[mask] == i) * np.mean(y_pred[mask] == i) / (np.mean(y_pred[mask] == i) + np.mean(y_pred[mask] == i)) if (np.mean(y_pred[mask] == i) + np.mean(y_pred[mask] == i)) > 0 else 0,
                'support': np.sum(mask)
            }
    return report

app = Flask(__name__)
PORT = 9515  # Unique port for Network Congestion agent

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty
AI_VALIDATOR_RATE = 0.40      # 40% to AI validators
HARDWARE_HOST_RATE = 0.10     # 10% to hardware hosts
ECOSYSTEM_RATE = 0.18         # 18% to ecosystem
ZAKAT_RATE = 0.02            # 2% to zakat

# Agent Configuration
AGENT_CONFIG = {
    "name": "network-congestion-gas-toll-agent",
    "network": "multi-chain",
    "contract_address": "0xcf35Cc6634C0532925a3b844Bc454e4438f44p",  # Unique contract
    "commission_rate": 0.028,  # 2.8% base rate (optimized for congestion)
    "specialization": "ai_powered_network_congestion",
    "expertise": [
        "network_congestion_monitoring",
        "peak_hour_detection",
        "congestion_pattern_analysis",
        "gas_price_volatility_tracking",
        "transaction_queue_analysis",
        "mempool_monitoring",
        "congestion_exploitation_strategies",
        "real_time_network_metrics",
        "congestion_forecasting",
        "dynamic_congestion_pricing"
    ]
}

class CongestionLevel(Enum):
    """Network congestion levels"""
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"
    EXTREME = "extreme"

class CongestionStrategy(Enum):
    """Congestion exploitation strategies"""
    PEAK_PRICING = "peak_pricing"
    QUEUE_EXPLOITATION = "queue_exploitation"
    MEMPOOL_MONITORING = "mempool_monitoring"
    CONGESTION_FORECASTING = "congestion_forecasting"
    DYNAMIC_SCALING = "dynamic_scaling"
    NETWORK_ARBITRAGE = "network_arbitrage"

@dataclass
class CongestionAlert:
    """Network congestion alert"""
    alert_id: str
    network: str
    congestion_level: CongestionLevel
    congestion_score: float
    predicted_duration_minutes: int
    recommended_action: str
    expected_revenue_impact: float
    gas_price_spike: float
    transaction_queue_depth: int
    timestamp: str

@dataclass
class GasTollTransaction:
    """Gas toll transaction record"""
    tx_hash: str
    sender: str
    recipient: str
    amount_usd: float
    gas_used: int
    gas_price_gwei: float
    toll_collected_usd: float
    congestion_level: CongestionLevel
    congestion_bonus_applied: bool
    congestion_score: float
    timestamp: str
    block_number: int
    founder_royalty: float
    ai_validator_share: float
    hardware_host_share: float
    network: str
    queue_position: int
    mempool_pressure: float

class NetworkCongestionGasTollAgent:
    """AI-Powered Network Congestion Gas Toll Collection Agent"""

    def __init__(self):
        self.agent_name = AGENT_CONFIG["name"]
        self.network = AGENT_CONFIG["network"]
        self.contract_address = AGENT_CONFIG["contract_address"]
        self.commission_rate = AGENT_CONFIG["commission_rate"]

        # Revenue tracking
        self.revenue_stats = {
            "total_toll_collected_usd": 0.0,
            "founder_royalty_paid": 0.0,
            "transactions_processed": 0,
            "congestion_alerts_generated": 0,
            "congestion_bonuses_applied": 0,
            "revenue_from_congestion": 0.0,
            "avg_congestion_bonus": 0.0,
            "peak_hour_revenue_multiplier": 0.0,
            "congestion_prediction_accuracy": 0.0,
            "network_arbitrage_opportunities": 0,
            "extreme_congestion_events": 0
        }

        # Transaction history
        self.transactions: List[GasTollTransaction] = []

        # Congestion alerts
        self.congestion_alerts: List[CongestionAlert] = []

        # Logging setup (moved up before model initialization)
        self.log_dir = "/home/omar/Desktop/QuranChain/logs/ai_workforce/gas_toll_agents"
        os.makedirs(self.log_dir, exist_ok=True)

        self.logger = logging.getLogger(f'{self.agent_name}')
        self.logger.setLevel(logging.INFO)

        handler = logging.FileHandler(f"{self.log_dir}/{self.agent_name}.log")
        formatter = logging.Formatter(
            '[%(asctime)s] NETWORK CONGESTION GAS TOLL - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        # Network congestion data
        self.network_metrics = {
            "gas_prices": {},
            "block_times": {},
            "transaction_queues": {},
            "mempool_sizes": {},
            "congestion_history": {},
            "peak_patterns": {}
        }

        # AI Models for congestion analysis
        self.congestion_classifiers = {}
        self.congestion_predictors = {}
        self.peak_hour_detectors = {}
        self.scalers = {}
        self.label_encoders = {}

        # Congestion thresholds
        self.congestion_thresholds = {
            "gas_price_spike": {
                "low": 1.2, "moderate": 1.5, "high": 2.0, "critical": 3.0, "extreme": 5.0
            },
            "queue_depth": {
                "low": 50, "moderate": 100, "high": 200, "critical": 500, "extreme": 1000
            },
            "block_time_increase": {
                "low": 1.1, "moderate": 1.3, "high": 1.5, "critical": 2.0, "extreme": 3.0
            }
        }

        # Initialize AI models for each network
        self.initialize_congestion_models()

        # CRM database
        self.crm_db = "/home/omar/Desktop/QuranChain/crm/crm.db"

        # Start background monitoring
        self.network_monitoring_thread = threading.Thread(target=self.monitor_network_congestion, daemon=True)
        self.network_monitoring_thread.start()

        self.congestion_analysis_thread = threading.Thread(target=self.analyze_congestion_patterns, daemon=True)
        self.congestion_analysis_thread.start()

        self.logger.info(f"🚀 Network Congestion Gas Toll Agent initialized | Contract: {self.contract_address}")
        self.logger.info(f"   💰 Base Commission Rate: {self.commission_rate * 100}%")
        self.logger.info(f"   🎯 Specialization: {AGENT_CONFIG['specialization']}")

    def initialize_congestion_models(self):
        """Initialize AI models for network congestion analysis"""
        for network in ["ethereum", "polygon", "arbitrum", "bsc", "avalanche", "solana"]:
            # Congestion level classifier
            self.congestion_classifiers[network] = SimpleRandomForestClassifier(
                n_estimators=10,  # Reduced for simplicity
                random_state=42
            )

            # Congestion duration predictor
            self.congestion_predictors[network] = SimpleGradientBoostingRegressor(
                n_estimators=10,  # Reduced for simplicity
                learning_rate=0.1,
                random_state=42
            )

            # Peak hour detector
            self.peak_hour_detectors[network] = SimpleRandomForestClassifier(
                n_estimators=5,  # Reduced for simplicity
                random_state=42
            )

            self.scalers[network] = SimpleStandardScaler()
            self.label_encoders[network] = SimpleLabelEncoder()

            # Initialize with synthetic data
            self.train_initial_congestion_models(network)

    def train_initial_congestion_models(self, network: str):
        """Train initial congestion models with synthetic data"""
        np.random.seed(42)
        n_samples = 1000

        # Generate synthetic congestion data
        gas_prices = np.random.normal(50, 15, n_samples)
        block_times = np.random.normal(12, 3, n_samples)  # seconds
        queue_depths = np.random.exponential(100, n_samples)
        mempool_sizes = np.random.exponential(2000, n_samples)
        hour_of_day = np.random.randint(0, 24, n_samples)
        day_of_week = np.random.randint(0, 7, n_samples)

        # Create congestion levels based on thresholds
        congestion_levels = []
        for i in range(n_samples):
            score = 0
            if gas_prices[i] > 60: score += 1
            if block_times[i] > 15: score += 1
            if queue_depths[i] > 150: score += 1
            if mempool_sizes[i] > 3000: score += 1

            if score >= 3:
                level = "extreme"
            elif score >= 2:
                level = "critical"
            elif score >= 1:
                level = "high"
            else:
                level = "low"
            congestion_levels.append(level)

        # Features for classification
        X = np.column_stack([
            gas_prices, block_times, queue_depths, mempool_sizes,
            hour_of_day, day_of_week
        ])

        y_congestion = np.array(congestion_levels)
        y_duration = np.random.exponential(30, n_samples)  # minutes
        y_peak = np.array([1 if level in ["high", "critical", "extreme"] else 0 for level in congestion_levels])

        # Encode labels
        y_encoded = self.label_encoders[network].fit_transform(y_congestion)

        # Scale features
        X_scaled = self.scalers[network].fit_transform(X)

        # Split data for training
        X_train, X_test, y_train, y_test = simple_train_test_split(
            X_scaled, y_encoded, test_size=0.2, random_state=42
        )
        _, _, y_duration_train, y_duration_test = simple_train_test_split(
            X_scaled, y_duration, test_size=0.2, random_state=42
        )
        _, _, y_peak_train, y_peak_test = simple_train_test_split(
            X_scaled, y_peak, test_size=0.2, random_state=42
        )

        # Train models
        self.congestion_classifiers[network].fit(X_train, y_train)
        self.congestion_predictors[network].fit(X_train, y_duration_train)
        self.peak_hour_detectors[network].fit(X_train, y_peak_train)

        # Log training performance
        y_pred_class = self.congestion_classifiers[network].predict(X_test)
        accuracy = simple_accuracy_score(y_test, y_pred_class)
        self.logger.info(f"Network {network} - Congestion classifier accuracy: {accuracy:.3f}")

        y_pred_peak = self.peak_hour_detectors[network].predict(X_test)
        peak_accuracy = simple_accuracy_score(y_peak_test, y_pred_peak)
        self.logger.info(f"Network {network} - Peak hour detector accuracy: {peak_accuracy:.3f}")

        self.logger.info(f"✅ Initial congestion models trained for {network}")

    def get_network_congestion_metrics(self, network: str) -> Dict:
        """Get current network congestion metrics"""
        # In a real implementation, this would fetch live data from blockchain APIs
        # For now, simulate realistic congestion data
        current_hour = datetime.utcnow().hour
        current_day = datetime.utcnow().weekday()

        # Simulate realistic congestion patterns
        base_gas_price = 50
        base_block_time = 12
        base_queue_depth = 50
        base_mempool_size = 1000

        # Add time-based congestion
        if current_hour in [9, 10, 11, 14, 15, 16]:  # Business hours
            congestion_multiplier = np.random.uniform(1.5, 2.5)
        elif current_hour in [0, 1, 2, 3, 4, 5]:  # Night hours
            congestion_multiplier = np.random.uniform(0.5, 1.0)
        else:
            congestion_multiplier = np.random.uniform(1.0, 1.8)

        # Weekend effect
        if current_day >= 5:
            congestion_multiplier *= np.random.uniform(0.8, 1.2)

        return {
            "gas_price_gwei": base_gas_price * congestion_multiplier * np.random.uniform(0.8, 1.2),
            "block_time_seconds": base_block_time * congestion_multiplier * np.random.uniform(0.9, 1.1),
            "transaction_queue_depth": int(base_queue_depth * congestion_multiplier * np.random.uniform(0.7, 1.3)),
            "mempool_size": int(base_mempool_size * congestion_multiplier * np.random.uniform(0.8, 1.2)),
            "hour_of_day": current_hour,
            "day_of_week": current_day,
            "network_utilization": min(1.0, congestion_multiplier * np.random.uniform(0.6, 1.0)),
            "timestamp": datetime.utcnow().isoformat()
        }

    def assess_congestion_level(self, network: str, metrics: Dict) -> Tuple[CongestionLevel, float]:
        """Assess network congestion level using AI models"""
        try:
            # Extract features
            features = [
                metrics["gas_price_gwei"],
                metrics["block_time_seconds"],
                metrics["transaction_queue_depth"],
                metrics["mempool_size"],
                metrics["hour_of_day"],
                metrics["day_of_week"]
            ]

            # Scale features
            features_scaled = self.scalers[network].transform([features])

            # Get congestion prediction
            congestion_encoded = self.congestion_classifiers[network].predict(features_scaled)[0]
            congestion_level = self.label_encoders[network].inverse_transform([congestion_encoded])[0]

            # Calculate congestion score (0-1 scale)
            base_score = congestion_encoded / (len(self.label_encoders[network].classes_) - 1)

            # Adjust based on metrics
            gas_spike = metrics["gas_price_gwei"] / 50  # Relative to base
            queue_factor = min(1.0, metrics["transaction_queue_depth"] / 500)
            block_time_factor = metrics["block_time_seconds"] / 12

            congestion_score = (base_score + gas_spike * 0.3 + queue_factor * 0.3 + block_time_factor * 0.2) / 1.8

            # Map to congestion level
            if congestion_score >= 0.8:
                level = CongestionLevel.EXTREME
            elif congestion_score >= 0.6:
                level = CongestionLevel.CRITICAL
            elif congestion_score >= 0.4:
                level = CongestionLevel.HIGH
            elif congestion_score >= 0.2:
                level = CongestionLevel.MODERATE
            else:
                level = CongestionLevel.LOW

            return level, congestion_score

        except Exception as e:
            self.logger.error(f"Congestion assessment failed: {str(e)}")
            return CongestionLevel.LOW, 0.0

    def predict_congestion_duration(self, network: str, metrics: Dict) -> int:
        """Predict how long congestion will last in minutes"""
        try:
            features = [
                metrics["gas_price_gwei"],
                metrics["block_time_seconds"],
                metrics["transaction_queue_depth"],
                metrics["mempool_size"],
                metrics["hour_of_day"],
                metrics["day_of_week"]
            ]

            features_scaled = self.scalers[network].transform([features])
            duration = self.congestion_predictors[network].predict(features_scaled)[0]

            return max(5, min(300, int(duration)))  # Between 5 minutes and 5 hours

        except Exception as e:
            self.logger.error(f"Duration prediction failed: {str(e)}")
            return 30  # Default 30 minutes

    def generate_congestion_alert(self, network: str, metrics: Dict, level: CongestionLevel,
                                score: float, duration: int) -> Optional[CongestionAlert]:
        """Generate congestion alert if conditions warrant it"""
        if level in [CongestionLevel.HIGH, CongestionLevel.CRITICAL, CongestionLevel.EXTREME]:
            alert_id = f"congestion_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{network}"

            # Calculate expected revenue impact
            base_gas_price = 50
            gas_spike = metrics["gas_price_gwei"] / base_gas_price
            expected_impact = gas_spike * metrics["transaction_queue_depth"] * 0.001 * score

            alert = CongestionAlert(
                alert_id=alert_id,
                network=network,
                congestion_level=level,
                congestion_score=score,
                predicted_duration_minutes=duration,
                recommended_action=self.get_congestion_action(level, score),
                expected_revenue_impact=expected_impact,
                gas_price_spike=gas_spike,
                transaction_queue_depth=metrics["transaction_queue_depth"],
                timestamp=datetime.utcnow().isoformat()
            )

            self.congestion_alerts.append(alert)
            self.revenue_stats["congestion_alerts_generated"] += 1

            if level == CongestionLevel.EXTREME:
                self.revenue_stats["extreme_congestion_events"] += 1

            return alert

        return None

    def get_congestion_action(self, level: CongestionLevel, score: float) -> str:
        """Get recommended action for congestion level"""
        if level == CongestionLevel.EXTREME:
            return "MAXIMIZE_TOLL_RATES_IMMEDIATELY"
        elif level == CongestionLevel.CRITICAL:
            return "INCREASE_TOLL_RATES_AGGRESSIVELY"
        elif level == CongestionLevel.HIGH:
            return "APPLY_CONGESTION_BONUS"
        else:
            return "MONITOR_AND_PREPARE"

    def calculate_congestion_bonus(self, base_toll: float, level: CongestionLevel,
                                 score: float, metrics: Dict) -> Tuple[float, bool]:
        """Calculate congestion-based toll bonus"""
        if level == CongestionLevel.LOW:
            return base_toll, False

        # Base multipliers
        multipliers = {
            CongestionLevel.MODERATE: 1.2,
            CongestionLevel.HIGH: 1.5,
            CongestionLevel.CRITICAL: 2.0,
            CongestionLevel.EXTREME: 3.0
        }

        multiplier = multipliers.get(level, 1.0)

        # Adjust based on congestion score and metrics
        gas_bonus = metrics["gas_price_gwei"] / 50  # Gas price relative to base
        queue_bonus = min(2.0, metrics["transaction_queue_depth"] / 200)  # Queue depth factor

        total_multiplier = multiplier * (1 + gas_bonus * 0.2) * (1 + queue_bonus * 0.1)
        total_multiplier = min(total_multiplier, 5.0)  # Cap at 5x

        bonus_amount = base_toll * (total_multiplier - 1)
        final_toll = base_toll * total_multiplier

        return final_toll, total_multiplier > 1.2  # Applied if >20% increase

    def calculate_gas_toll(self, gas_used: int, gas_price_gwei: float, tx_value_usd: float,
                          network: str, queue_position: int = 0) -> Tuple[float, CongestionLevel, float, Dict]:
        """Calculate gas toll with congestion analysis"""
        # Get network congestion metrics
        metrics = self.get_network_congestion_metrics(network)

        # Assess congestion level
        congestion_level, congestion_score = self.assess_congestion_level(network, metrics)

        # Predict congestion duration
        predicted_duration = self.predict_congestion_duration(network, metrics)

        # Generate congestion alert if needed
        congestion_alert = self.generate_congestion_alert(network, metrics, congestion_level,
                                                        congestion_score, predicted_duration)

        # Calculate base toll
        gas_cost_usd = (gas_used * gas_price_gwei * 1e-9) * self.get_gas_price_usd(network)
        base_toll = gas_cost_usd * self.commission_rate

        # Apply congestion bonus
        final_toll, bonus_applied = self.calculate_congestion_bonus(base_toll, congestion_level, congestion_score, metrics)

        # Queue position bonus (higher position = higher toll)
        if queue_position > 0:
            queue_multiplier = min(1.5, 1 + (queue_position / 100))
            final_toll *= queue_multiplier

        congestion_details = {
            "congestion_level": congestion_level.value,
            "congestion_score": congestion_score,
            "predicted_duration_minutes": predicted_duration,
            "base_toll": base_toll,
            "final_toll": final_toll,
            "bonus_applied": bonus_applied,
            "bonus_amount": final_toll - base_toll,
            "network_metrics": metrics,
            "congestion_alert": asdict(congestion_alert) if congestion_alert else None
        }

        return final_toll, congestion_level, congestion_score, congestion_details

    def get_gas_price_usd(self, network: str) -> float:
        """Get current gas price in USD for network"""
        gas_prices = {
            "ethereum": 2000, "polygon": 0.8, "arbitrum": 2000,
            "bsc": 300, "avalanche": 20, "solana": 100
        }
        return gas_prices.get(network.lower(), 1.0)

    def distribute_revenue(self, toll_amount: float) -> Dict:
        """Distribute collected toll according to QuranChain economics"""
        founder_share = toll_amount * FOUNDER_ROYALTY_RATE
        ai_validator_share = toll_amount * AI_VALIDATOR_RATE
        hardware_host_share = toll_amount * HARDWARE_HOST_RATE
        ecosystem_share = toll_amount * ECOSYSTEM_RATE
        zakat_share = toll_amount * ZAKAT_RATE

        distribution = {
            "founder": founder_share,
            "ai_validators": ai_validator_share,
            "hardware_hosts": hardware_host_share,
            "ecosystem": ecosystem_share,
            "zakat": zakat_share,
            "total_distributed": founder_share + ai_validator_share + hardware_host_share + ecosystem_share + zakat_share
        }

        # Update revenue stats
        self.revenue_stats["founder_royalty_paid"] += founder_share
        self.revenue_stats["total_toll_collected_usd"] += toll_amount

        return distribution

    def process_transaction(self, tx_data: Dict) -> Dict:
        """Process a transaction with congestion analysis"""
        try:
            tx_hash = tx_data.get("hash")
            sender = tx_data.get("from")
            recipient = tx_data.get("to")
            value_usd = float(tx_data.get("valueUSD", 0))
            gas_used = int(tx_data.get("gasUsed", 0))
            gas_price = float(tx_data.get("gasPrice", 0)) / 1e-9  # wei to gwei
            block_number = int(tx_data.get("blockNumber", 0))
            network = tx_data.get("network", "ethereum")
            queue_position = int(tx_data.get("queuePosition", 0))

            # Calculate congestion-aware toll
            toll_amount, congestion_level, congestion_score, congestion_details = self.calculate_gas_toll(
                gas_used, gas_price, value_usd, network, queue_position
            )

            # Create transaction record
            transaction = GasTollTransaction(
                tx_hash=tx_hash,
                sender=sender,
                recipient=recipient,
                amount_usd=value_usd,
                gas_used=gas_used,
                gas_price_gwei=gas_price,
                toll_collected_usd=toll_amount,
                congestion_level=congestion_level,
                congestion_bonus_applied=congestion_details["bonus_applied"],
                congestion_score=congestion_score,
                timestamp=datetime.utcnow().isoformat(),
                block_number=block_number,
                founder_royalty=toll_amount * FOUNDER_ROYALTY_RATE,
                ai_validator_share=toll_amount * AI_VALIDATOR_RATE,
                hardware_host_share=toll_amount * HARDWARE_HOST_RATE,
                network=network,
                queue_position=queue_position,
                mempool_pressure=congestion_details["network_metrics"]["mempool_size"]
            )

            # Distribute revenue
            distribution = self.distribute_revenue(toll_amount)

            # Store transaction
            self.transactions.append(transaction)
            self.revenue_stats["transactions_processed"] += 1

            if congestion_details["bonus_applied"]:
                self.revenue_stats["congestion_bonuses_applied"] += 1
                bonus_amount = congestion_details["bonus_amount"]
                self.revenue_stats["revenue_from_congestion"] += bonus_amount

            # Update average congestion bonus
            if self.revenue_stats["congestion_bonuses_applied"] > 0:
                self.revenue_stats["avg_congestion_bonus"] = (
                    self.revenue_stats["revenue_from_congestion"] /
                    self.revenue_stats["congestion_bonuses_applied"]
                )

            # Log to CRM
            self.log_to_crm(transaction, distribution, congestion_details)

            congestion_indicator = "🔴" if congestion_level in [CongestionLevel.CRITICAL, CongestionLevel.EXTREME] else "🟡" if congestion_level == CongestionLevel.HIGH else "🟢"
            self.logger.info(f"{congestion_indicator} Processed ${toll_amount:.2f} congestion toll from {tx_hash[:10]}... (Level: {congestion_level.value}, Score: {congestion_score:.2f})")

            return {
                "success": True,
                "transaction": asdict(transaction),
                "distribution": distribution,
                "congestion_analysis": congestion_details,
                "ai_insights": self.generate_congestion_insights(transaction, congestion_details)
            }

        except Exception as e:
            self.logger.error(f"❌ Transaction processing failed: {str(e)}")
            return {"success": False, "error": str(e)}

    def generate_congestion_insights(self, transaction: GasTollTransaction, congestion_details: Dict) -> Dict:
        """Generate congestion analysis insights"""
        insights = {
            "congestion_level": transaction.congestion_level.value,
            "congestion_score": transaction.congestion_score,
            "bonus_applied": transaction.congestion_bonus_applied,
            "network": transaction.network,
            "queue_position": transaction.queue_position,
            "mempool_pressure": transaction.mempool_pressure
        }

        recommendations = []
        if transaction.congestion_level in [CongestionLevel.CRITICAL, CongestionLevel.EXTREME]:
            recommendations.append(f"Critical congestion detected - toll increased by {(congestion_details['final_toll']/congestion_details['base_toll'] - 1)*100:.0f}%")
            recommendations.append("Network experiencing extreme congestion - maximum toll rates applied")

        if transaction.congestion_bonus_applied:
            bonus_pct = (congestion_details['bonus_amount'] / congestion_details['base_toll']) * 100
            recommendations.append(f"Congestion bonus applied: +${congestion_details['bonus_amount']:.2f} ({bonus_pct:.1f}%)")

        if transaction.queue_position > 50:
            recommendations.append("High queue position - additional toll applied for priority processing")

        insights["recommendations"] = recommendations

        return insights

    def log_to_crm(self, transaction: GasTollTransaction, distribution: Dict, congestion_details: Dict):
        """Log transaction to CRM database"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            # Insert transaction record
            cursor.execute("""
                INSERT INTO gas_toll_transactions
                (agent_name, network, tx_hash, sender, recipient, amount, toll_collected,
                 founder_royalty, ai_validator_share, hardware_host_share, timestamp,
                 congestion_level, congestion_bonus_applied, congestion_score, queue_position)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.agent_name,
                transaction.network,
                transaction.tx_hash,
                transaction.sender,
                transaction.recipient,
                transaction.amount_usd,
                transaction.toll_collected_usd,
                distribution["founder"],
                distribution["ai_validators"],
                distribution["hardware_hosts"],
                transaction.timestamp,
                transaction.congestion_level.value,
                1 if transaction.congestion_bonus_applied else 0,
                transaction.congestion_score,
                transaction.queue_position
            ))

            # Insert congestion alert if exists
            if congestion_details.get("congestion_alert"):
                alert = congestion_details["congestion_alert"]
                cursor.execute("""
                    INSERT INTO congestion_alerts
                    (alert_id, network, congestion_level, congestion_score, predicted_duration,
                     recommended_action, expected_revenue_impact, gas_price_spike, queue_depth, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    alert["alert_id"],
                    alert["network"],
                    alert["congestion_level"],
                    alert["congestion_score"],
                    alert["predicted_duration_minutes"],
                    alert["recommended_action"],
                    alert["expected_revenue_impact"],
                    alert["gas_price_spike"],
                    alert["transaction_queue_depth"],
                    alert["timestamp"]
                ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"CRM logging failed: {str(e)}")

    def monitor_network_congestion(self):
        """Background thread to monitor network congestion"""
        while True:
            try:
                time.sleep(30)  # Check every 30 seconds

                for network in self.congestion_classifiers.keys():
                    metrics = self.get_network_congestion_metrics(network)

                    # Store metrics
                    if network not in self.network_metrics["gas_prices"]:
                        self.network_metrics["gas_prices"][network] = []
                        self.network_metrics["block_times"][network] = []
                        self.network_metrics["transaction_queues"][network] = []
                        self.network_metrics["mempool_sizes"][network] = []

                    self.network_metrics["gas_prices"][network].append(metrics["gas_price_gwei"])
                    self.network_metrics["block_times"][network].append(metrics["block_time_seconds"])
                    self.network_metrics["transaction_queues"][network].append(metrics["transaction_queue_depth"])
                    self.network_metrics["mempool_sizes"][network].append(metrics["mempool_size"])

                    # Keep only last 1000 data points
                    for key in self.network_metrics.keys():
                        if isinstance(self.network_metrics[key], dict) and network in self.network_metrics[key]:
                            self.network_metrics[key][network] = self.network_metrics[key][network][-1000:]

            except Exception as e:
                self.logger.error(f"Network monitoring failed: {str(e)}")

    def analyze_congestion_patterns(self):
        """Background thread to analyze congestion patterns"""
        while True:
            try:
                time.sleep(300)  # Analyze every 5 minutes

                # Analyze patterns and retrain models
                for network in self.congestion_classifiers.keys():
                    if len(self.transactions) > 100:
                        self.update_congestion_patterns(network)
                        self.retrain_congestion_models(network)

            except Exception as e:
                self.logger.error(f"Congestion analysis failed: {str(e)}")

    def update_congestion_patterns(self, network: str):
        """Update congestion patterns based on recent data"""
        recent_txs = [tx for tx in self.transactions[-500:] if tx.network == network]
        if len(recent_txs) < 50:
            return

        # Analyze peak patterns
        congestion_scores = [tx.congestion_score for tx in recent_txs]
        if congestion_scores:
            avg_congestion = np.mean(congestion_scores)
            peak_congestion = np.max(congestion_scores)

            self.network_metrics["congestion_history"][network] = {
                "avg_congestion": avg_congestion,
                "peak_congestion": peak_congestion,
                "last_updated": datetime.utcnow().isoformat()
            }

    def retrain_congestion_models(self, network: str):
        """Retrain congestion models with recent data"""
        try:
            # Get recent transactions for this network
            network_txs = [tx for tx in self.transactions[-500:] if tx.network == network]
            if len(network_txs) < 100:
                return

            # Extract features and targets
            features = []
            congestion_levels = []

            for tx in network_txs:
                features.append([
                    tx.gas_price_gwei,
                    12,  # Simplified block time
                    tx.queue_position,
                    tx.mempool_pressure,
                    pd.to_datetime(tx.timestamp).hour,
                    pd.to_datetime(tx.timestamp).weekday()
                ])
                congestion_levels.append(tx.congestion_level.value)

            X = np.array(features)
            y = np.array(congestion_levels)

            # Encode labels
            y_encoded = self.label_encoders[network].transform(y)

            # Scale features
            X_scaled = self.scalers[network].fit_transform(X)

            # Retrain classifier
            self.congestion_classifiers[network].fit(X_scaled, y_encoded)

            # Calculate accuracy
            predictions = self.congestion_classifiers[network].predict(X_scaled)
            self.revenue_stats["congestion_prediction_accuracy"] = accuracy_score(y_encoded, predictions)

            self.logger.info(f"🔄 Retrained congestion models for {network} (Accuracy: {self.revenue_stats['congestion_prediction_accuracy']:.3f})")

        except Exception as e:
            self.logger.error(f"Model retraining failed for {network}: {str(e)}")

    def get_revenue_stats(self) -> Dict:
        """Get comprehensive revenue statistics"""
        return {
            "agent": self.agent_name,
            "network": self.network,
            "contract_address": self.contract_address,
            "commission_rate": f"{self.commission_rate * 100}%",
            "founder_royalty_rate": f"{FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)",
            "total_toll_collected_usd": self.revenue_stats["total_toll_collected_usd"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "transactions_processed": self.revenue_stats["transactions_processed"],
            "congestion_alerts_generated": self.revenue_stats["congestion_alerts_generated"],
            "congestion_bonuses_applied": self.revenue_stats["congestion_bonuses_applied"],
            "revenue_from_congestion": self.revenue_stats["revenue_from_congestion"],
            "avg_congestion_bonus": f"{self.revenue_stats['avg_congestion_bonus']:.4f}",
            "congestion_prediction_accuracy": f"{self.revenue_stats['congestion_prediction_accuracy']:.1%}",
            "extreme_congestion_events": self.revenue_stats["extreme_congestion_events"],
            "active_congestion_alerts": len([alert for alert in self.congestion_alerts if pd.to_datetime(alert.timestamp) > datetime.utcnow() - timedelta(hours = 1)]),
            "timestamp": datetime.utcnow().isoformat()
        }

# Global agent instance
network_congestion_agent = NetworkCongestionGasTollAgent()

# Flask Routes
@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "agent": network_congestion_agent.agent_name,
        "network": network_congestion_agent.network,
        "contract": network_congestion_agent.contract_address,
        "ai_models_active": len(network_congestion_agent.congestion_classifiers),
        "congestion_alerts_today": len([alert for alert in network_congestion_agent.congestion_alerts if pd.to_datetime(alert.timestamp).date() == datetime.utcnow().date()]),
        "timestamp": datetime.utcnow().isoformat()
    })

@app.route('/metrics', methods=['GET'])
def metrics():
    """Performance metrics endpoint"""
    return jsonify({
        "agent_metrics": network_congestion_agent.get_revenue_stats(),
        "congestion_performance": {
            "models_trained": len(network_congestion_agent.congestion_classifiers),
            "active_alerts": len(network_congestion_agent.congestion_alerts),
            "avg_congestion_bonus": network_congestion_agent.revenue_stats["avg_congestion_bonus"],
            "prediction_accuracy": network_congestion_agent.revenue_stats["congestion_prediction_accuracy"],
            "revenue_from_congestion": network_congestion_agent.revenue_stats["revenue_from_congestion"]
        },
        "network_monitoring": {
            "networks_monitored": list(network_congestion_agent.network_metrics["gas_prices"].keys()),
            "data_points": {network: len(prices) for network, prices in network_congestion_agent.network_metrics["gas_prices"].items()}
        },
        "system_health": {
            "transactions_in_memory": len(network_congestion_agent.transactions),
            "log_file_size": os.path.getsize(f"{network_congestion_agent.log_dir}/{network_congestion_agent.agent_name}.log") if os.path.exists(f"{network_congestion_agent.log_dir}/{network_congestion_agent.agent_name}.log") else 0
        }
    })

@app.route('/revenue', methods=['GET'])
def revenue():
    """Revenue statistics endpoint"""
    return jsonify(network_congestion_agent.get_revenue_stats())

@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    """Process a transaction with congestion analysis"""
    try:
        tx_data = request.get_json()
        if not tx_data:
            return jsonify({"error": "No transaction data provided"}), 400

        result = network_congestion_agent.process_transaction(tx_data)
        return jsonify(result)

    except Exception as e:
        network_congestion_agent.logger.error(f"Transaction processing error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/congestion_alerts', methods=['GET'])
def congestion_alerts():
    """Get recent congestion alerts"""
    hours = int(request.args.get('hours', 1))
    cutoff_time = datetime.utcnow() - timedelta(hours=hours)

    recent_alerts = [
        asdict(alert) for alert in network_congestion_agent.congestion_alerts
        if pd.to_datetime(alert.timestamp) > cutoff_time
    ]

    return jsonify({
        "alerts": recent_alerts,
        "total_alerts": len(recent_alerts),
        "time_period": f"{hours} hours"
    })

@app.route('/network_congestion', methods=['GET'])
def network_congestion():
    """Get current network congestion status"""
    network = request.args.get('network')
    if network:
        metrics = network_congestion_agent.get_network_congestion_metrics(network)
        level, score = network_congestion_agent.assess_congestion_level(network, metrics)
        return jsonify({
            network: {
                "congestion_level": level.value,
                "congestion_score": score,
                "metrics": metrics
            }
        })
    else:
        status = {}
        for net in network_congestion_agent.congestion_classifiers.keys():
            metrics = network_congestion_agent.get_network_congestion_metrics(net)
            level, score = network_congestion_agent.assess_congestion_level(net, metrics)
            status[net] = {
                "congestion_level": level.value,
                "congestion_score": score,
                "metrics": metrics
            }
        return jsonify(status)

@app.route('/predict_congestion', methods=['POST'])
def predict_congestion():
    """Predict congestion level for given network conditions"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        network = data.get("network", "ethereum")
        metrics = network_congestion_agent.get_network_congestion_metrics(network)

        # Override with provided data
        for key, value in data.items():
            if key in metrics:
                metrics[key] = value

        level, score = network_congestion_agent.assess_congestion_level(network, metrics)
        duration = network_congestion_agent.predict_congestion_duration(network, metrics)

        return jsonify({
            "network": network,
            "predicted_congestion_level": level.value,
            "congestion_score": score,
            "predicted_duration_minutes": duration,
            "metrics_used": metrics
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/ai_insights', methods=['GET'])
def ai_insights():
    """Get AI-powered congestion analysis insights"""
    return jsonify({
        "congestion_models": {network: "active" for network in network_congestion_agent.congestion_classifiers.keys()},
        "performance_metrics": {
            "total_alerts": network_congestion_agent.revenue_stats["congestion_alerts_generated"],
            "congestion_bonuses": network_congestion_agent.revenue_stats["congestion_bonuses_applied"],
            "revenue_from_congestion": network_congestion_agent.revenue_stats["revenue_from_congestion"],
            "prediction_accuracy": network_congestion_agent.revenue_stats["congestion_prediction_accuracy"],
            "extreme_events": network_congestion_agent.revenue_stats["extreme_congestion_events"]
        },
        "congestion_levels": [level.value for level in CongestionLevel],
        "recommendations": [
            "AI models continuously monitor network congestion patterns",
            f"Generated {network_congestion_agent.revenue_stats['congestion_alerts_generated']} congestion alerts",
            f"Applied {network_congestion_agent.revenue_stats['congestion_bonuses_applied']} congestion bonuses",
            f"Generated ${network_congestion_agent.revenue_stats['revenue_from_congestion']:,.0f} from congestion exploitation",
            "Real-time congestion assessment prevents revenue loss during network stress",
            "Predictive models forecast congestion duration and intensity",
            "Dynamic toll adjustment maximizes revenue during peak congestion",
            "Multi-network monitoring enables congestion arbitrage opportunities"
        ]
    })

@app.route('/contract_info', methods=['GET'])
def contract_info():
    """Get contract information"""
    return jsonify({
        "contract_address": network_congestion_agent.contract_address,
        "network": network_congestion_agent.network,
        "commission_rate": network_congestion_agent.commission_rate,
        "specialization": AGENT_CONFIG["specialization"],
        "expertise": AGENT_CONFIG["expertise"],
        "ai_capabilities": ["congestion_detection", "duration_prediction", "revenue_optimization", "network_monitoring"],
        "supported_networks": list(network_congestion_agent.congestion_classifiers.keys()),
        "congestion_levels": [level.value for level in CongestionLevel],
        "congestion_strategies": [strategy.value for strategy in CongestionStrategy]
    })

if __name__ == "__main__":
    print("🚦 Starting AI Network Congestion Gas Toll Agent...")
    print(f"   📡 Port: {PORT}")
    print(f"   🌐 Network: {network_congestion_agent.network}")
    print(f"   📋 Contract: {network_congestion_agent.contract_address}")
    print(f"   💰 Base Commission: {network_congestion_agent.commission_rate * 100}%")
    print(f"   👑 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print(f"   🧠 AI Models: {len(network_congestion_agent.congestion_classifiers)} networks")
    print("=" * 60)

    app.run(host='localhost', port=PORT, debug=False)