#!/usr/bin/env python3
"""
Staking Gas Toll Agent - Specialized AI Agent for Staking and Validator Transactions
Focuses on staking deposits, validator operations, and staking reward toll collection
"""


import sys
sys.path.insert(0, "/home/omar/Desktop/QuranChain")
# Add project root to path

from flask import Flask, jsonify, request
import sqlite3
import requests
import json
import time
import threading
import os
import logging
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from enum import Enum

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        STAKING_PRODUCTS, VALIDATOR_PRODUCTS, GAS_TOLL_PRODUCTS,
        BLOCKCHAIN_SERVICE_PRODUCTS, PRODUCTS as STRIPE_CATALOG,
        create_checkout_session, create_payment_link,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

app = Flask(__name__)
PORT = 9510  # Unique port for Staking agent

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty
AI_VALIDATOR_RATE = 0.40      # 40% to AI validators
HARDWARE_HOST_RATE = 0.10     # 10% to hardware hosts
ECOSYSTEM_RATE = 0.18         # 18% to ecosystem
ZAKAT_RATE = 0.02            # 2% to zakat

# Agent Configuration
AGENT_CONFIG = {
    "name": "staking-gas-toll-agent",
    "network": "multi-chain",
    "contract_address": "0xcf35Cc6634C0532925a3b844Bc454e4438f44m",  # Unique contract
    "commission_rate": 0.025,  # 2.5% gas toll (lower for staking frequency)
    "specialization": "staking_validator_transactions",
    "expertise": [
        "staking_deposit_monitoring",
        "validator_operation_tracking",
        "staking_reward_distribution",
        "slashing_event_detection",
        "validator_performance_analysis",
        "delegation_pool_management",
        "unstaking_process_tracking",
        "yield_farming_staking",
        "liquid_staking_token_operations",
        "validator_election_optimization"
    ]
}

class TransactionType(Enum):
    """Transaction types for staking operations"""
    STAKING_DEPOSIT = "staking_deposit"
    STAKING_WITHDRAWAL = "staking_withdrawal"
    VALIDATOR_REGISTRATION = "validator_registration"
    VALIDATOR_EXIT = "validator_exit"
    REWARD_CLAIM = "reward_claim"
    SLASHING_REPORT = "slashing_report"
    DELEGATION_UPDATE = "delegation_update"
    LIQUID_STAKING_MINT = "liquid_staking_mint"
    LIQUID_STAKING_REDEEM = "liquid_staking_redeem"
    VALIDATOR_MAINTENANCE = "validator_maintenance"

@dataclass
class GasTollTransaction:
    """Gas toll transaction record"""
    tx_hash: str
    sender: str
    recipient: str
    amount_usd: float
    gas_used: int
    gas_price_gwei: float
    toll_collected_usd: float
    transaction_type: TransactionType
    timestamp: str
    block_number: int
    founder_royalty: float
    ai_validator_share: float
    hardware_host_share: float
    validator_address: str
    staking_protocol: str
    network: str
    staked_amount: Optional[float] = None
    reward_amount: Optional[float] = None
    validator_uptime: Optional[float] = None

class StakingGasTollAgent:
    """Specialized Staking Gas Toll Collection Agent"""

    def __init__(self):
        self.agent_name = AGENT_CONFIG["name"]
        self.network = AGENT_CONFIG["network"]
        self.contract_address = AGENT_CONFIG["contract_address"]
        self.commission_rate = AGENT_CONFIG["commission_rate"]

        # Revenue tracking
        self.revenue_stats = {
            "total_toll_collected_usd": 0.0,
            "founder_royalty_paid": 0.0,
            "transactions_processed": 0,
            "staking_deposits": 0,
            "staking_withdrawals": 0,
            "validator_registrations": 0,
            "reward_claims": 0,
            "slashing_reports": 0,
            "delegation_updates": 0,
            "liquid_staking_operations": 0,
            "total_staked_amount": 0.0,
            "total_rewards_distributed": 0.0,
            "avg_validator_uptime": 0.0
        }

        # Transaction history
        self.transactions: List[GasTollTransaction] = []

        # AI Learning data for staking patterns
        self.learning_patterns = {
            "validator_performance": {},
            "staking_yields": {},
            "slashing_events": [],
            "reward_patterns": [],
            "delegation_trends": {},
            "uptime_analytics": {},
            "staking_efficiency": {}
        }

        # Supported staking protocols across networks
        self.staking_protocols = {
            "ethereum": {
                "ethereum_staking_contract": "0x00000000219ab540356cBB839Cbe05303d7705Fa",
                "lido": "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84",
                "rocket_pool": "0x1d8f8f00cfa6758d7bE78336684788Fb0ee0Fa46",
                "fractions": "0x24A42f73c68a4Dd4c62cA8D25B4E1c1C53e8c4F"
            },
            "polygon": {
                "polygon_staking": "0x5e3Ef299fDDf15eAa0432E6e66473ace8c13D908",
                "matic_staking": "0x5e3Ef299fDDf15eAa0432E6e66473ace8c13D908"
            },
            "solana": {
                "solana_stake_program": "Stake11111111111111111111111111111111111111",
                "marinade": "MarBmsSgKXdrN1egZf5sqe1TMai9K1rChYNDJgjq7aD",
                "socean": "5ocnV1qiCgaQR8Jb8xWnVbApfayVZxes3rq9eC6vEbB"
            },
            "avalanche": {
                "avalanche_staking": "0x0000000000000000000000000000000000000000",
                "benqi": "0x486Af39519B4Dc9a7fCcd318217352830E8AD9b4"
            },
            "cosmos": {
                "cosmos_staking": "cosmosvaloper1...",
                "osmosis_staking": "osmovaloper1..."
            }
        }

        # Logging setup
        self.log_dir = "/home/omar/Desktop/QuranChain/logs/ai_workforce/gas_toll_agents"
        os.makedirs(self.log_dir, exist_ok=True)

        self.logger = logging.getLogger(f'{self.agent_name}')
        self.logger.setLevel(logging.INFO)

        handler = logging.FileHandler(f"{self.log_dir}/{self.agent_name}.log")
        formatter = logging.Formatter(
            '[%(asctime)s] STAKING GAS TOLL - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        # CRM database
        self.crm_db = "/home/omar/Desktop/QuranChain/crm/crm.db"

        self.logger.info(f"🚀 Staking Gas Toll Agent initialized | Contract: {self.contract_address}")
        self.logger.info(f"   💰 Commission Rate: {self.commission_rate * 100}%")
        self.logger.info(f"   🎯 Specialization: {AGENT_CONFIG['specialization']}")

    def calculate_gas_toll(self, gas_used: int, gas_price_gwei: float, tx_value_usd: float,
                          tx_type: TransactionType, network: str, staked_amount: Optional[float] = None) -> float:
        """Calculate gas toll with staking-specific optimizations"""
        # Base toll calculation (in USD for cross-chain compatibility)
        gas_cost_usd = (gas_used * gas_price_gwei * 1e-9) * self.get_gas_price_usd(network)

        # Apply commission rate
        base_toll = gas_cost_usd * self.commission_rate

        # Staking transaction bonuses
        if tx_type == TransactionType.STAKING_DEPOSIT:
            base_toll *= 1.3  # 30% bonus for staking deposits
            self.revenue_stats["staking_deposits"] += 1

        elif tx_type == TransactionType.STAKING_WITHDRAWAL:
            base_toll *= 1.2  # 20% bonus for staking withdrawals
            self.revenue_stats["staking_withdrawals"] += 1

        elif tx_type == TransactionType.VALIDATOR_REGISTRATION:
            base_toll *= 2.0  # 100% bonus for validator registration
            self.revenue_stats["validator_registrations"] += 1

        elif tx_type == TransactionType.REWARD_CLAIM:
            base_toll *= 1.5  # 50% bonus for reward claims
            self.revenue_stats["reward_claims"] += 1

        elif tx_type == TransactionType.SLASHING_REPORT:
            base_toll *= 1.8  # 80% bonus for slashing reports
            self.revenue_stats["slashing_reports"] += 1

        elif tx_type == TransactionType.DELEGATION_UPDATE:
            base_toll *= 1.1  # 10% bonus for delegation updates
            self.revenue_stats["delegation_updates"] += 1

        elif tx_type in [TransactionType.LIQUID_STAKING_MINT, TransactionType.LIQUID_STAKING_REDEEM]:
            base_toll *= 1.4  # 40% bonus for liquid staking operations
            self.revenue_stats["liquid_staking_operations"] += 1

        # High-value staking bonus
        if staked_amount and staked_amount > 10000:  # $10k+ staked
            base_toll *= 1.25  # Additional 25% bonus

        # Validator maintenance bonus (recurring operations)
        if tx_type == TransactionType.VALIDATOR_MAINTENANCE:
            base_toll *= 0.8  # 20% discount for maintenance operations

        return base_toll

    def get_gas_price_usd(self, network: str) -> float:
        """Get current gas price in USD for network"""
        # Simplified gas price conversion (would use oracles in production)
        gas_prices = {
            "ethereum": 2000,  # ~$2000/ETH
            "polygon": 0.8,    # ~$0.80/MATIC
            "arbitrum": 2000,  # ~$2000/ETH
            "bsc": 300,        # ~$300/BNB
            "avalanche": 20,   # ~$20/AVAX
            "solana": 100,     # ~$100/SOL
            "cosmos": 5        # ~$5/ATOM
        }
        return gas_prices.get(network.lower(), 1.0)

    def classify_transaction(self, tx_data: Dict) -> TransactionType:
        """Classify transaction type with staking protocol detection"""
        to_address = tx_data.get("to", "").lower()
        input_data = tx_data.get("input", "")
        logs = tx_data.get("logs", [])
        network = tx_data.get("network", "ethereum")

        # Check all supported staking protocols
        for net_protocols in self.staking_protocols.values():
            for protocol, address in net_protocols.items():
                if to_address == address.lower():
                    if "deposit" in input_data.lower() or "0x47e7ef24" in input_data:
                        return TransactionType.STAKING_DEPOSIT
                    elif "withdraw" in input_data.lower() or "0x69328dec" in input_data:
                        return TransactionType.STAKING_WITHDRAWAL
                    elif "register" in input_data.lower() and "validator" in input_data.lower():
                        return TransactionType.VALIDATOR_REGISTRATION
                    elif "claim" in input_data.lower() and "reward" in input_data.lower():
                        return TransactionType.REWARD_CLAIM
                    elif "slash" in input_data.lower():
                        return TransactionType.SLASHING_REPORT

        # Liquid staking detection
        if "liquid" in input_data.lower() and "staking" in input_data.lower():
            if "mint" in input_data.lower():
                return TransactionType.LIQUID_STAKING_MINT
            elif "redeem" in input_data.lower():
                return TransactionType.LIQUID_STAKING_REDEEM

        # Delegation update detection
        if "delegate" in input_data.lower() or "undelegate" in input_data.lower():
            return TransactionType.DELEGATION_UPDATE

        # Validator exit detection
        if "exit" in input_data.lower() and "validator" in input_data.lower():
            return TransactionType.VALIDATOR_EXIT

        # Validator maintenance detection (recurring operations)
        if "maintenance" in input_data.lower() or "heartbeat" in input_data.lower():
            return TransactionType.VALIDATOR_MAINTENANCE

        return TransactionType.STAKING_DEPOSIT  # Default for staking context

    def detect_staking_protocol(self, tx_data: Dict) -> str:
        """Detect which staking protocol was used"""
        to_address = tx_data.get("to", "").lower()
        network = tx_data.get("network", "ethereum")

        if network in self.staking_protocols:
            for protocol, address in self.staking_protocols[network].items():
                if to_address == address.lower():
                    return protocol

        return "unknown"

    def detect_validator_address(self, tx_data: Dict) -> str:
        """Detect validator address from transaction"""
        # Check logs for validator-related events
        logs = tx_data.get("logs", [])
        for log in logs:
            if log.get("topics", []) and len(log["topics"]) > 0:
                # Look for validator registration or delegation events
                if any("validator" in str(topic) for topic in log["topics"]):
                    return log.get("address", "unknown")

        # Fallback to recipient if it's a validator operation
        return tx_data.get("to", "unknown")

    def distribute_revenue(self, toll_amount: float) -> Dict:
        """Distribute collected toll according to QuranChain economics"""
        founder_share = toll_amount * FOUNDER_ROYALTY_RATE
        ai_validator_share = toll_amount * AI_VALIDATOR_RATE
        hardware_host_share = toll_amount * HARDWARE_HOST_RATE
        ecosystem_share = toll_amount * ECOSYSTEM_RATE
        zakat_share = toll_amount * ZAKAT_RATE

        distribution = {
            "founder": founder_share,
            "ai_validators": ai_validator_share,
            "hardware_hosts": hardware_host_share,
            "ecosystem": ecosystem_share,
            "zakat": zakat_share,
            "total_distributed": founder_share + ai_validator_share + hardware_host_share + ecosystem_share + zakat_share
        }

        # Update revenue stats
        self.revenue_stats["founder_royalty_paid"] += founder_share
        self.revenue_stats["total_toll_collected_usd"] += toll_amount

        return distribution

    def process_transaction(self, tx_data: Dict) -> Dict:
        """Process a staking transaction and collect gas toll"""
        try:
            tx_hash = tx_data.get("hash")
            sender = tx_data.get("from")
            recipient = tx_data.get("to")
            value_usd = float(tx_data.get("valueUSD", 0))
            gas_used = int(tx_data.get("gasUsed", 0))
            gas_price = float(tx_data.get("gasPrice", 0)) / 1e-9  # Convert wei to gwei
            block_number = int(tx_data.get("blockNumber", 0))
            network = tx_data.get("network", "ethereum")

            # Classify transaction
            tx_type = self.classify_transaction(tx_data)

            # Detect staking protocol and validator
            staking_protocol = self.detect_staking_protocol(tx_data)
            validator_address = self.detect_validator_address(tx_data)

            # Get staking-specific data
            staked_amount = float(tx_data.get("stakedAmount", 0))
            reward_amount = float(tx_data.get("rewardAmount", 0))
            validator_uptime = float(tx_data.get("validatorUptime", 0))

            # Calculate toll
            toll_amount = self.calculate_gas_toll(gas_used, gas_price, value_usd, tx_type, network, staked_amount)

            # Create transaction record
            transaction = GasTollTransaction(
                tx_hash=tx_hash,
                sender=sender,
                recipient=recipient,
                amount_usd=value_usd,
                gas_used=gas_used,
                gas_price_gwei=gas_price,
                toll_collected_usd=toll_amount,
                transaction_type=tx_type,
                timestamp=datetime.utcnow().isoformat(),
                block_number=block_number,
                founder_royalty=toll_amount * FOUNDER_ROYALTY_RATE,
                ai_validator_share=toll_amount * AI_VALIDATOR_RATE,
                hardware_host_share=toll_amount * HARDWARE_HOST_RATE,
                validator_address=validator_address,
                staking_protocol=staking_protocol,
                network=network,
                staked_amount=staked_amount,
                reward_amount=reward_amount,
                validator_uptime=validator_uptime
            )

            # Distribute revenue
            distribution = self.distribute_revenue(toll_amount)

            # Store transaction
            self.transactions.append(transaction)
            self.revenue_stats["transactions_processed"] += 1

            # Update staking stats
            if staked_amount:
                self.revenue_stats["total_staked_amount"] += staked_amount
            if reward_amount:
                self.revenue_stats["total_rewards_distributed"] += reward_amount
            if validator_uptime:
                # Calculate running average uptime
                current_count = len([t for t in self.transactions if t.validator_uptime])
                if current_count > 0:
                    total_uptime = sum(t.validator_uptime for t in self.transactions if t.validator_uptime)
                    self.revenue_stats["avg_validator_uptime"] = total_uptime / current_count

            # Log to CRM
            self.log_to_crm(transaction, distribution)

            # AI Learning
            self.learn_from_transaction(transaction)

            self.logger.info(f"💰 Collected ${toll_amount:.2f} toll from {tx_hash[:10]}... ({tx_type.value} via {staking_protocol})")

            return {
                "success": True,
                "transaction": asdict(transaction),
                "distribution": distribution,
                "ai_insights": self.generate_staking_insights(transaction)
            }

        except Exception as e:
            self.logger.error(f"❌ Transaction processing failed: {str(e)}")
            return {"success": False, "error": str(e)}

    def learn_from_transaction(self, transaction: GasTollTransaction):
        """AI learning from staking transaction patterns"""
        # Track validator performance
        if transaction.validator_address != "unknown":
            if transaction.validator_address not in self.learning_patterns["validator_performance"]:
                self.learning_patterns["validator_performance"][transaction.validator_address] = []
            self.learning_patterns["validator_performance"][transaction.validator_address].append({
                "uptime": transaction.validator_uptime,
                "rewards": transaction.reward_amount,
                "timestamp": transaction.timestamp
            })

        # Track staking yields
        if transaction.staking_protocol != "unknown" and transaction.reward_amount:
            if transaction.staking_protocol not in self.learning_patterns["staking_yields"]:
                self.learning_patterns["staking_yields"][transaction.staking_protocol] = []
            self.learning_patterns["staking_yields"][transaction.staking_protocol].append(transaction.reward_amount)

        # Track slashing events
        if transaction.transaction_type == TransactionType.SLASHING_REPORT:
            self.learning_patterns["slashing_events"].append({
                "validator": transaction.validator_address,
                "amount": transaction.amount_usd,
                "timestamp": transaction.timestamp
            })

        # Track reward patterns
        if transaction.reward_amount:
            self.learning_patterns["reward_patterns"].append({
                "protocol": transaction.staking_protocol,
                "amount": transaction.reward_amount,
                "timestamp": transaction.timestamp
            })

        # Track delegation trends
        if transaction.transaction_type == TransactionType.DELEGATION_UPDATE:
            if transaction.validator_address not in self.learning_patterns["delegation_trends"]:
                self.learning_patterns["delegation_trends"][transaction.validator_address] = []
            self.learning_patterns["delegation_trends"][transaction.validator_address].append({
                "amount": transaction.amount_usd,
                "timestamp": transaction.timestamp
            })

    def generate_staking_insights(self, transaction: GasTollTransaction) -> Dict:
        """Generate staking-specific AI insights"""
        insights = {
            "gas_efficiency": "optimal" if transaction.gas_price_gwei < 50 else "high",
            "staking_protocol": transaction.staking_protocol,
            "transaction_type": transaction.transaction_type.value,
            "validator_address": transaction.validator_address,
            "network": transaction.network,
            "high_stake_amount": transaction.staked_amount and transaction.staked_amount > 10000,
            "validator_performance": transaction.validator_uptime is not None
        }

        # Staking-specific recommendations
        recommendations = []
        if transaction.staked_amount and transaction.staked_amount > 32000:  # 32 ETH equivalent
            recommendations.append(f"Large staking deposit: ${transaction.staked_amount:,.0f}")

        if transaction.reward_amount:
            recommendations.append(f"Staking reward claimed: ${transaction.reward_amount:.2f}")

        if transaction.validator_uptime and transaction.validator_uptime < 95:
            recommendations.append(f"Low validator uptime: {transaction.validator_uptime:.1f}%")

        if transaction.transaction_type == TransactionType.SLASHING_REPORT:
            recommendations.append("Slashing event detected - validator penalization")

        if transaction.transaction_type == TransactionType.VALIDATOR_REGISTRATION:
            recommendations.append("New validator registered in network")

        if transaction.transaction_type == TransactionType.LIQUID_STAKING_MINT:
            recommendations.append("Liquid staking token minted")

        insights["recommendations"] = recommendations

        return insights

    def log_to_crm(self, transaction: GasTollTransaction, distribution: Dict):
        """Log transaction to CRM database"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            # Insert transaction record
            cursor.execute("""
                INSERT INTO gas_toll_transactions
                (agent_name, network, tx_hash, sender, recipient, amount, toll_collected,
                 founder_royalty, ai_validator_share, hardware_host_share, timestamp,
                 staking_protocol, validator_address, staked_amount, reward_amount, validator_uptime)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.agent_name,
                transaction.network,
                transaction.tx_hash,
                transaction.sender,
                transaction.recipient,
                transaction.amount_usd,
                transaction.toll_collected_usd,
                distribution["founder"],
                distribution["ai_validators"],
                distribution["hardware_hosts"],
                transaction.timestamp,
                transaction.staking_protocol,
                transaction.validator_address,
                transaction.staked_amount,
                transaction.reward_amount,
                transaction.validator_uptime
            ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"CRM logging failed: {str(e)}")

    def get_revenue_stats(self) -> Dict:
        """Get comprehensive revenue statistics"""
        return {
            "agent": self.agent_name,
            "network": self.network,
            "contract_address": self.contract_address,
            "commission_rate": f"{self.commission_rate * 100}%",
            "founder_royalty_rate": f"{FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)",
            "total_toll_collected_usd": self.revenue_stats["total_toll_collected_usd"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "transactions_processed": self.revenue_stats["transactions_processed"],
            "staking_deposits": self.revenue_stats["staking_deposits"],
            "staking_withdrawals": self.revenue_stats["staking_withdrawals"],
            "validator_registrations": self.revenue_stats["validator_registrations"],
            "reward_claims": self.revenue_stats["reward_claims"],
            "slashing_reports": self.revenue_stats["slashing_reports"],
            "delegation_updates": self.revenue_stats["delegation_updates"],
            "liquid_staking_operations": self.revenue_stats["liquid_staking_operations"],
            "total_staked_amount": self.revenue_stats["total_staked_amount"],
            "total_rewards_distributed": self.revenue_stats["total_rewards_distributed"],
            "avg_validator_uptime": self.revenue_stats["avg_validator_uptime"],
            "validator_performance": self.learning_patterns["validator_performance"],
            "staking_yields": self.learning_patterns["staking_yields"],
            "timestamp": datetime.utcnow().isoformat()
        }

# Global agent instance
staking_agent = StakingGasTollAgent()

# Flask Routes
@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "agent": staking_agent.agent_name,
        "network": staking_agent.network,
        "contract": staking_agent.contract_address,
        "timestamp": datetime.utcnow().isoformat()
    })

@app.route('/metrics', methods=['GET'])
def metrics():
    """Performance metrics endpoint"""
    return jsonify({
        "agent_metrics": staking_agent.get_revenue_stats(),
        "staking_protocols": staking_agent.staking_protocols,
        "system_health": {
            "transactions_in_memory": len(staking_agent.transactions),
            "log_file_size": os.path.getsize(f"{staking_agent.log_dir}/{staking_agent.agent_name}.log") if os.path.exists(f"{staking_agent.log_dir}/{staking_agent.agent_name}.log") else 0
        }
    })

@app.route('/revenue', methods=['GET'])
def revenue():
    """Revenue statistics endpoint"""
    return jsonify(staking_agent.get_revenue_stats())

@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    """Process a staking transaction"""
    try:
        tx_data = request.get_json()
        if not tx_data:
            return jsonify({"error": "No transaction data provided"}), 400

        result = staking_agent.process_transaction(tx_data)
        return jsonify(result)

    except Exception as e:
        staking_agent.logger.error(f"Transaction processing error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/staking_insights', methods=['GET'])
def staking_insights():
    """Get staking-specific AI insights"""
    return jsonify({
        "validator_performance": staking_agent.learning_patterns["validator_performance"],
        "staking_yields": staking_agent.learning_patterns["staking_yields"],
        "slashing_events": staking_agent.learning_patterns["slashing_events"][-20:],  # Last 20
        "reward_patterns": staking_agent.learning_patterns["reward_patterns"][-20:],  # Last 20
        "delegation_trends": staking_agent.learning_patterns["delegation_trends"],
        "recommendations": [
            "Focus toll collection on high-yield staking protocols",
            f"Top performing protocol: {max(staking_agent.learning_patterns['staking_yields'], key=lambda x: len(staking_agent.learning_patterns['staking_yields'][x])) if staking_agent.learning_patterns['staking_yields'] else 'None'}",
            f"Total staked amount: ${staking_agent.revenue_stats['total_staked_amount']:,.0f}",
            f"Total rewards distributed: ${staking_agent.revenue_stats['total_rewards_distributed']:,.0f}",
            f"Average validator uptime: {staking_agent.revenue_stats['avg_validator_uptime']:.1f}%",
            "Monitor validator performance and slashing events",
            "Track delegation trends for network health",
            "Optimize toll collection during reward claiming periods"
        ]
    })

@app.route('/contract_info', methods=['GET'])
def contract_info():
    """Get contract information"""
    return jsonify({
        "contract_address": staking_agent.contract_address,
        "network": staking_agent.network,
        "commission_rate": staking_agent.commission_rate,
        "specialization": AGENT_CONFIG["specialization"],
        "expertise": AGENT_CONFIG["expertise"],
        "supported_networks": list(staking_agent.staking_protocols.keys())
    })

if __name__ == "__main__":
    print("🔥 Starting Staking Gas Toll Agent...")
    print(f"   📡 Port: {PORT}")
    print(f"   🌐 Network: {staking_agent.network}")
    print(f"   📋 Contract: {staking_agent.contract_address}")
    print(f"   💰 Commission: {staking_agent.commission_rate * 100}%")
    print(f"   👑 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print("=" * 60)

    app.run(host='localhost', port=PORT, debug=False)