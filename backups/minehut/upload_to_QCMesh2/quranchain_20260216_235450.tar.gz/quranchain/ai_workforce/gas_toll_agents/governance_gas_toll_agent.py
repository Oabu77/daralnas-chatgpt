#!/usr/bin/env python3
"""
Governance Gas Toll Agent - Specialized AI Agent for DAO Governance Transactions
Focuses on proposal creation, voting, governance token operations, and DAO toll collection
"""


import sys
sys.path.insert(0, "/home/omar/Desktop/QuranChain")
# Add project root to path

from flask import Flask, jsonify, request
import sqlite3
import requests
import json
import time
import threading
import os
import logging
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from enum import Enum

# Stripe Payment Catalog - All product/price IDs
try:
    from organized.revenue.stripe_payment_catalog import (
        GOVERNANCE_PRODUCTS, GAS_TOLL_PRODUCTS, TOKEN_PRODUCTS,
        BLOCKCHAIN_SERVICE_PRODUCTS, PRODUCTS as STRIPE_CATALOG,
        create_checkout_session, create_payment_link,
        FOUNDER_ROYALTY_RATE as STRIPE_FOUNDER_RATE
    )
    STRIPE_CATALOG_LOADED = True
except ImportError:
    STRIPE_CATALOG_LOADED = False

app = Flask(__name__)
PORT = 9511  # Unique port for Governance agent

# Revenue Distribution Constants
FOUNDER_ROYALTY_RATE = 0.30  # Immutable 30% founder royalty
AI_VALIDATOR_RATE = 0.40      # 40% to AI validators
HARDWARE_HOST_RATE = 0.10     # 10% to hardware hosts
ECOSYSTEM_RATE = 0.18         # 18% to ecosystem
ZAKAT_RATE = 0.02            # 2% to zakat

# Agent Configuration
AGENT_CONFIG = {
    "name": "governance-gas-toll-agent",
    "network": "multi-chain",
    "contract_address": "0xcf35Cc6634C0532925a3b844Bc454e4438f44n",  # Unique contract
    "commission_rate": 0.031,  # 3.1% gas toll (higher for governance importance)
    "specialization": "dao_governance_transactions",
    "expertise": [
        "proposal_creation_monitoring",
        "voting_transaction_tracking",
        "governance_token_operations",
        "dao_treasury_management",
        "delegation_power_tracking",
        "proposal_execution_monitoring",
        "governance_attack_detection",
        "quorum_achievement_analysis",
        "voting_power_optimization",
        "cross_dao_governance_coordination"
    ]
}

class TransactionType(Enum):
    """Transaction types for governance operations"""
    PROPOSAL_CREATION = "proposal_creation"
    PROPOSAL_VOTING = "proposal_voting"
    PROPOSAL_EXECUTION = "proposal_execution"
    DELEGATION_UPDATE = "delegation_update"
    GOVERNANCE_TOKEN_MINT = "governance_token_mint"
    GOVERNANCE_TOKEN_BURN = "governance_token_burn"
    TREASURY_OPERATION = "treasury_operation"
    VETO_TRANSACTION = "veto_transaction"
    QUORUM_UPDATE = "quorum_update"
    GOVERNANCE_MAINTENANCE = "governance_maintenance"

@dataclass
class GasTollTransaction:
    """Gas toll transaction record"""
    tx_hash: str
    sender: str
    recipient: str
    amount_usd: float
    gas_used: int
    gas_price_gwei: float
    toll_collected_usd: float
    transaction_type: TransactionType
    timestamp: str
    block_number: int
    founder_royalty: float
    ai_validator_share: float
    hardware_host_share: float
    dao_address: str
    governance_protocol: str
    network: str
    voting_power: Optional[float] = None
    proposal_id: Optional[str] = None
    treasury_amount: Optional[float] = None

class GovernanceGasTollAgent:
    """Specialized Governance Gas Toll Collection Agent"""

    def __init__(self):
        self.agent_name = AGENT_CONFIG["name"]
        self.network = AGENT_CONFIG["network"]
        self.contract_address = AGENT_CONFIG["contract_address"]
        self.commission_rate = AGENT_CONFIG["commission_rate"]

        # Revenue tracking
        self.revenue_stats = {
            "total_toll_collected_usd": 0.0,
            "founder_royalty_paid": 0.0,
            "transactions_processed": 0,
            "proposal_creations": 0,
            "proposal_votings": 0,
            "proposal_executions": 0,
            "delegation_updates": 0,
            "governance_token_operations": 0,
            "treasury_operations": 0,
            "veto_transactions": 0,
            "total_voting_power_processed": 0.0,
            "total_treasury_operations": 0.0,
            "avg_proposal_success_rate": 0.0
        }

        # Transaction history
        self.transactions: List[GasTollTransaction] = []

        # AI Learning data for governance patterns
        self.learning_patterns = {
            "dao_performance": {},
            "voting_patterns": {},
            "proposal_success_rates": {},
            "governance_attacks": [],
            "delegation_trends": {},
            "treasury_efficiency": {},
            "quorum_analytics": {},
            "voting_power_distribution": {}
        }

        # Supported governance protocols across networks
        self.governance_protocols = {
            "ethereum": {
                "uniswap_governance": "0x1a9C8182C09F50C8318d769245beA52c32BE35BC",
                "compound_governance": "0xc00e94Cb662C3520282E6f5717214004A7f26888",
                "maker_dao": "0x9ef05f7f6deb616fd37ac3c959a2ddd25a54e4f5",
                "aave_governance": "0xEC568fffba86c094cf06b22134B23074DFE2252c",
                "synthetix_governance": "0xeb3107117fead7de89cd14d463d3405721c3d352"
            },
            "polygon": {
                "polygon_dao": "0x26B2c1eB5a4E8e5b12E3A5B5E5F5E5F5E5F5E5F",
                "quickswap_governance": "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"
            },
            "arbitrum": {
                "arbitrum_dao": "0x789fC99093B09aD01C34DC7251D0C89ce743e5a4"
            },
            "optimism": {
                "optimism_governance": "0xc72a49B6e8Fc3b7E3b4F1E0b3b6b3b6b3b6b3b6"
            },
            "polygon": {
                "polygon_governance": "0x26B2c1eB5a4E8e5b12E3A5B5E5F5E5F5E5F5E5F"
            }
        }

        # Logging setup
        self.log_dir = "/home/omar/Desktop/QuranChain/logs/ai_workforce/gas_toll_agents"
        os.makedirs(self.log_dir, exist_ok=True)

        self.logger = logging.getLogger(f'{self.agent_name}')
        self.logger.setLevel(logging.INFO)

        handler = logging.FileHandler(f"{self.log_dir}/{self.agent_name}.log")
        formatter = logging.Formatter(
            '[%(asctime)s] GOVERNANCE GAS TOLL - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        # CRM database
        self.crm_db = "/home/omar/Desktop/QuranChain/crm/crm.db"

        self.logger.info(f"🚀 Governance Gas Toll Agent initialized | Contract: {self.contract_address}")
        self.logger.info(f"   💰 Commission Rate: {self.commission_rate * 100}%")
        self.logger.info(f"   🎯 Specialization: {AGENT_CONFIG['specialization']}")

    def calculate_gas_toll(self, gas_used: int, gas_price_gwei: float, tx_value_usd: float,
                          tx_type: TransactionType, network: str, voting_power: Optional[float] = None) -> float:
        """Calculate gas toll with governance-specific optimizations"""
        # Base toll calculation (in USD for cross-chain compatibility)
        gas_cost_usd = (gas_used * gas_price_gwei * 1e-9) * self.get_gas_price_usd(network)

        # Apply commission rate
        base_toll = gas_cost_usd * self.commission_rate

        # Governance transaction bonuses
        if tx_type == TransactionType.PROPOSAL_CREATION:
            base_toll *= 1.8  # 80% bonus for proposal creation
            self.revenue_stats["proposal_creations"] += 1

        elif tx_type == TransactionType.PROPOSAL_VOTING:
            base_toll *= 1.5  # 50% bonus for voting
            self.revenue_stats["proposal_votings"] += 1

        elif tx_type == TransactionType.PROPOSAL_EXECUTION:
            base_toll *= 2.0  # 100% bonus for proposal execution
            self.revenue_stats["proposal_executions"] += 1

        elif tx_type == TransactionType.DELEGATION_UPDATE:
            base_toll *= 1.3  # 30% bonus for delegation updates
            self.revenue_stats["delegation_updates"] += 1

        elif tx_type in [TransactionType.GOVERNANCE_TOKEN_MINT, TransactionType.GOVERNANCE_TOKEN_BURN]:
            base_toll *= 1.4  # 40% bonus for governance token operations
            self.revenue_stats["governance_token_operations"] += 1

        elif tx_type == TransactionType.TREASURY_OPERATION:
            base_toll *= 1.7  # 70% bonus for treasury operations
            self.revenue_stats["treasury_operations"] += 1

        elif tx_type == TransactionType.VETO_TRANSACTION:
            base_toll *= 2.5  # 150% bonus for veto transactions
            self.revenue_stats["veto_transactions"] += 1

        # High voting power bonus
        if voting_power and voting_power > 100000:  # 100k+ voting power
            base_toll *= 1.25  # Additional 25% bonus

        # Treasury operation bonus (high-value operations)
        if tx_type == TransactionType.TREASURY_OPERATION and tx_value_usd > 100000:
            base_toll *= 1.5  # Additional 50% bonus

        return base_toll

    def get_gas_price_usd(self, network: str) -> float:
        """Get current gas price in USD for network"""
        # Simplified gas price conversion (would use oracles in production)
        gas_prices = {
            "ethereum": 2000,  # ~$2000/ETH
            "polygon": 0.8,    # ~$0.80/MATIC
            "arbitrum": 2000,  # ~$2000/ETH
            "bsc": 300,        # ~$300/BNB
            "avalanche": 20,   # ~$20/AVAX
            "solana": 100,     # ~$100/SOL
            "optimism": 2000   # ~$2000/ETH
        }
        return gas_prices.get(network.lower(), 1.0)

    def classify_transaction(self, tx_data: Dict) -> TransactionType:
        """Classify transaction type with governance protocol detection"""
        to_address = tx_data.get("to", "").lower()
        input_data = tx_data.get("input", "")
        logs = tx_data.get("logs", [])
        network = tx_data.get("network", "ethereum")

        # Check all supported governance protocols
        for net_protocols in self.governance_protocols.values():
            for protocol, address in net_protocols.items():
                if to_address == address.lower():
                    if "propose" in input_data.lower() or "0x765e827f" in input_data:
                        return TransactionType.PROPOSAL_CREATION
                    elif "vote" in input_data.lower() or "0x15373e3d" in input_data:
                        return TransactionType.PROPOSAL_VOTING
                    elif "execute" in input_data.lower() and "proposal" in input_data.lower():
                        return TransactionType.PROPOSAL_EXECUTION
                    elif "delegate" in input_data.lower() or "0xc3cda520" in input_data:
                        return TransactionType.DELEGATION_UPDATE

        # Treasury operation detection
        if "treasury" in input_data.lower() or any("treasury" in str(log) for log in logs):
            return TransactionType.TREASURY_OPERATION

        # Governance token operations
        if "governance" in input_data.lower() and ("mint" in input_data.lower() or "burn" in input_data.lower()):
            if "mint" in input_data.lower():
                return TransactionType.GOVERNANCE_TOKEN_MINT
            else:
                return TransactionType.GOVERNANCE_TOKEN_BURN

        # Veto transaction detection
        if "veto" in input_data.lower():
            return TransactionType.VETO_TRANSACTION

        # Quorum update detection
        if "quorum" in input_data.lower():
            return TransactionType.QUORUM_UPDATE

        # Governance maintenance detection
        if "maintenance" in input_data.lower() or "admin" in input_data.lower():
            return TransactionType.GOVERNANCE_MAINTENANCE

        return TransactionType.PROPOSAL_VOTING  # Default for governance context

    def detect_governance_protocol(self, tx_data: Dict) -> str:
        """Detect which governance protocol was used"""
        to_address = tx_data.get("to", "").lower()
        network = tx_data.get("network", "ethereum")

        if network in self.governance_protocols:
            for protocol, address in self.governance_protocols[network].items():
                if to_address == address.lower():
                    return protocol

        return "unknown"

    def detect_dao_address(self, tx_data: Dict) -> str:
        """Detect DAO address from transaction"""
        # Check logs for governance events
        logs = tx_data.get("logs", [])
        for log in logs:
            if log.get("topics", []) and len(log["topics"]) > 0:
                # Look for governance-related events
                if any("governance" in str(topic) or "proposal" in str(topic) for topic in log["topics"]):
                    return log.get("address", "unknown")

        # Fallback to recipient if it's a governance operation
        return tx_data.get("to", "unknown")

    def distribute_revenue(self, toll_amount: float) -> Dict:
        """Distribute collected toll according to QuranChain economics"""
        founder_share = toll_amount * FOUNDER_ROYALTY_RATE
        ai_validator_share = toll_amount * AI_VALIDATOR_RATE
        hardware_host_share = toll_amount * HARDWARE_HOST_RATE
        ecosystem_share = toll_amount * ECOSYSTEM_RATE
        zakat_share = toll_amount * ZAKAT_RATE

        distribution = {
            "founder": founder_share,
            "ai_validators": ai_validator_share,
            "hardware_hosts": hardware_host_share,
            "ecosystem": ecosystem_share,
            "zakat": zakat_share,
            "total_distributed": founder_share + ai_validator_share + hardware_host_share + ecosystem_share + zakat_share
        }

        # Update revenue stats
        self.revenue_stats["founder_royalty_paid"] += founder_share
        self.revenue_stats["total_toll_collected_usd"] += toll_amount

        return distribution

    def process_transaction(self, tx_data: Dict) -> Dict:
        """Process a governance transaction and collect gas toll"""
        try:
            tx_hash = tx_data.get("hash")
            sender = tx_data.get("from")
            recipient = tx_data.get("to")
            value_usd = float(tx_data.get("valueUSD", 0))
            gas_used = int(tx_data.get("gasUsed", 0))
            gas_price = float(tx_data.get("gasPrice", 0)) / 1e-9  # Convert wei to gwei
            block_number = int(tx_data.get("blockNumber", 0))
            network = tx_data.get("network", "ethereum")

            # Classify transaction
            tx_type = self.classify_transaction(tx_data)

            # Detect governance protocol and DAO
            governance_protocol = self.detect_governance_protocol(tx_data)
            dao_address = self.detect_dao_address(tx_data)

            # Get governance-specific data
            voting_power = float(tx_data.get("votingPower", 0))
            proposal_id = tx_data.get("proposalId")
            treasury_amount = float(tx_data.get("treasuryAmount", 0))

            # Calculate toll
            toll_amount = self.calculate_gas_toll(gas_used, gas_price, value_usd, tx_type, network, voting_power)

            # Create transaction record
            transaction = GasTollTransaction(
                tx_hash=tx_hash,
                sender=sender,
                recipient=recipient,
                amount_usd=value_usd,
                gas_used=gas_used,
                gas_price_gwei=gas_price,
                toll_collected_usd=toll_amount,
                transaction_type=tx_type,
                timestamp=datetime.utcnow().isoformat(),
                block_number=block_number,
                founder_royalty=toll_amount * FOUNDER_ROYALTY_RATE,
                ai_validator_share=toll_amount * AI_VALIDATOR_RATE,
                hardware_host_share=toll_amount * HARDWARE_HOST_RATE,
                dao_address=dao_address,
                governance_protocol=governance_protocol,
                network=network,
                voting_power=voting_power,
                proposal_id=proposal_id,
                treasury_amount=treasury_amount
            )

            # Distribute revenue
            distribution = self.distribute_revenue(toll_amount)

            # Store transaction
            self.transactions.append(transaction)
            self.revenue_stats["transactions_processed"] += 1

            # Update governance stats
            if voting_power:
                self.revenue_stats["total_voting_power_processed"] += voting_power
            if treasury_amount:
                self.revenue_stats["total_treasury_operations"] += treasury_amount

            # Log to CRM
            self.log_to_crm(transaction, distribution)

            # AI Learning
            self.learn_from_transaction(transaction)

            self.logger.info(f"💰 Collected ${toll_amount:.2f} toll from {tx_hash[:10]}... ({tx_type.value} via {governance_protocol})")

            return {
                "success": True,
                "transaction": asdict(transaction),
                "distribution": distribution,
                "ai_insights": self.generate_governance_insights(transaction)
            }

        except Exception as e:
            self.logger.error(f"❌ Transaction processing failed: {str(e)}")
            return {"success": False, "error": str(e)}

    def learn_from_transaction(self, transaction: GasTollTransaction):
        """AI learning from governance transaction patterns"""
        # Track DAO performance
        if transaction.dao_address != "unknown":
            if transaction.dao_address not in self.learning_patterns["dao_performance"]:
                self.learning_patterns["dao_performance"][transaction.dao_address] = []
            self.learning_patterns["dao_performance"][transaction.dao_address].append({
                "voting_power": transaction.voting_power,
                "treasury_amount": transaction.treasury_amount,
                "timestamp": transaction.timestamp
            })

        # Track voting patterns
        if transaction.voting_power:
            if transaction.governance_protocol not in self.learning_patterns["voting_patterns"]:
                self.learning_patterns["voting_patterns"][transaction.governance_protocol] = []
            self.learning_patterns["voting_patterns"][transaction.governance_protocol].append({
                "power": transaction.voting_power,
                "transaction_type": transaction.transaction_type.value,
                "timestamp": transaction.timestamp
            })

        # Track proposal success rates
        if transaction.proposal_id:
            if transaction.governance_protocol not in self.learning_patterns["proposal_success_rates"]:
                self.learning_patterns["proposal_success_rates"][transaction.governance_protocol] = {}
            if transaction.proposal_id not in self.learning_patterns["proposal_success_rates"][transaction.governance_protocol]:
                self.learning_patterns["proposal_success_rates"][transaction.governance_protocol][transaction.proposal_id] = []
            self.learning_patterns["proposal_success_rates"][transaction.governance_protocol][transaction.proposal_id].append({
                "transaction_type": transaction.transaction_type.value,
                "timestamp": transaction.timestamp
            })

        # Track delegation trends
        if transaction.transaction_type == TransactionType.DELEGATION_UPDATE:
            if transaction.dao_address not in self.learning_patterns["delegation_trends"]:
                self.learning_patterns["delegation_trends"][transaction.dao_address] = []
            self.learning_patterns["delegation_trends"][transaction.dao_address].append({
                "voting_power": transaction.voting_power,
                "timestamp": transaction.timestamp
            })

        # Track treasury efficiency
        if transaction.treasury_amount:
            if transaction.dao_address not in self.learning_patterns["treasury_efficiency"]:
                self.learning_patterns["treasury_efficiency"][transaction.dao_address] = []
            self.learning_patterns["treasury_efficiency"][transaction.dao_address].append({
                "amount": transaction.treasury_amount,
                "operation_type": transaction.transaction_type.value,
                "timestamp": transaction.timestamp
            })

    def generate_governance_insights(self, transaction: GasTollTransaction) -> Dict:
        """Generate governance-specific AI insights"""
        insights = {
            "gas_efficiency": "optimal" if transaction.gas_price_gwei < 50 else "high",
            "governance_protocol": transaction.governance_protocol,
            "transaction_type": transaction.transaction_type.value,
            "dao_address": transaction.dao_address,
            "network": transaction.network,
            "high_voting_power": transaction.voting_power and transaction.voting_power > 100000,
            "treasury_operation": transaction.treasury_amount is not None
        }

        # Governance-specific recommendations
        recommendations = []
        if transaction.voting_power and transaction.voting_power > 1000000:
            recommendations.append(f"High voting power transaction: {transaction.voting_power:,.0f}")

        if transaction.treasury_amount and transaction.treasury_amount > 100000:
            recommendations.append(f"Large treasury operation: ${transaction.treasury_amount:,.0f}")

        if transaction.transaction_type == TransactionType.PROPOSAL_CREATION:
            recommendations.append("New governance proposal created")

        if transaction.transaction_type == TransactionType.PROPOSAL_EXECUTION:
            recommendations.append("Governance proposal executed successfully")

        if transaction.transaction_type == TransactionType.VETO_TRANSACTION:
            recommendations.append("Governance veto exercised")

        if transaction.proposal_id:
            recommendations.append(f"Proposal {transaction.proposal_id} activity detected")

        insights["recommendations"] = recommendations

        return insights

    def log_to_crm(self, transaction: GasTollTransaction, distribution: Dict):
        """Log transaction to CRM database"""
        try:
            conn = sqlite3.connect(self.crm_db)
            cursor = conn.cursor()

            # Insert transaction record
            cursor.execute("""
                INSERT INTO gas_toll_transactions
                (agent_name, network, tx_hash, sender, recipient, amount, toll_collected,
                 founder_royalty, ai_validator_share, hardware_host_share, timestamp,
                 governance_protocol, dao_address, voting_power, proposal_id, treasury_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.agent_name,
                transaction.network,
                transaction.tx_hash,
                transaction.sender,
                transaction.recipient,
                transaction.amount_usd,
                transaction.toll_collected_usd,
                distribution["founder"],
                distribution["ai_validators"],
                distribution["hardware_hosts"],
                transaction.timestamp,
                transaction.governance_protocol,
                transaction.dao_address,
                transaction.voting_power,
                transaction.proposal_id,
                transaction.treasury_amount
            ))

            conn.commit()
            conn.close()

        except Exception as e:
            self.logger.error(f"CRM logging failed: {str(e)}")

    def get_revenue_stats(self) -> Dict:
        """Get comprehensive revenue statistics"""
        return {
            "agent": self.agent_name,
            "network": self.network,
            "contract_address": self.contract_address,
            "commission_rate": f"{self.commission_rate * 100}%",
            "founder_royalty_rate": f"{FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)",
            "total_toll_collected_usd": self.revenue_stats["total_toll_collected_usd"],
            "founder_royalty_paid": self.revenue_stats["founder_royalty_paid"],
            "transactions_processed": self.revenue_stats["transactions_processed"],
            "proposal_creations": self.revenue_stats["proposal_creations"],
            "proposal_votings": self.revenue_stats["proposal_votings"],
            "proposal_executions": self.revenue_stats["proposal_executions"],
            "delegation_updates": self.revenue_stats["delegation_updates"],
            "governance_token_operations": self.revenue_stats["governance_token_operations"],
            "treasury_operations": self.revenue_stats["treasury_operations"],
            "veto_transactions": self.revenue_stats["veto_transactions"],
            "total_voting_power_processed": self.revenue_stats["total_voting_power_processed"],
            "total_treasury_operations": self.revenue_stats["total_treasury_operations"],
            "dao_performance": self.learning_patterns["dao_performance"],
            "voting_patterns": self.learning_patterns["voting_patterns"],
            "timestamp": datetime.utcnow().isoformat()
        }

# Global agent instance
governance_agent = GovernanceGasTollAgent()

# Flask Routes
@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "agent": governance_agent.agent_name,
        "network": governance_agent.network,
        "contract": governance_agent.contract_address,
        "timestamp": datetime.utcnow().isoformat()
    })

@app.route('/metrics', methods=['GET'])
def metrics():
    """Performance metrics endpoint"""
    return jsonify({
        "agent_metrics": governance_agent.get_revenue_stats(),
        "governance_protocols": governance_agent.governance_protocols,
        "system_health": {
            "transactions_in_memory": len(governance_agent.transactions),
            "log_file_size": os.path.getsize(f"{governance_agent.log_dir}/{governance_agent.agent_name}.log") if os.path.exists(f"{governance_agent.log_dir}/{governance_agent.agent_name}.log") else 0
        }
    })

@app.route('/revenue', methods=['GET'])
def revenue():
    """Revenue statistics endpoint"""
    return jsonify(governance_agent.get_revenue_stats())

@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    """Process a governance transaction"""
    try:
        tx_data = request.get_json()
        if not tx_data:
            return jsonify({"error": "No transaction data provided"}), 400

        result = governance_agent.process_transaction(tx_data)
        return jsonify(result)

    except Exception as e:
        governance_agent.logger.error(f"Transaction processing error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/governance_insights', methods=['GET'])
def governance_insights():
    """Get governance-specific AI insights"""
    return jsonify({
        "dao_performance": governance_agent.learning_patterns["dao_performance"],
        "voting_patterns": governance_agent.learning_patterns["voting_patterns"],
        "proposal_success_rates": governance_agent.learning_patterns["proposal_success_rates"],
        "delegation_trends": governance_agent.learning_patterns["delegation_trends"],
        "treasury_efficiency": governance_agent.learning_patterns["treasury_efficiency"],
        "recommendations": [
            "Focus toll collection on active DAO governance periods",
            f"Most active DAO: {max(governance_agent.learning_patterns['dao_performance'], key=lambda x: len(governance_agent.learning_patterns['dao_performance'][x])) if governance_agent.learning_patterns['dao_performance'] else 'None'}",
            f"Total voting power processed: {governance_agent.revenue_stats['total_voting_power_processed']:,.0f}",
            f"Total treasury operations: ${governance_agent.revenue_stats['total_treasury_operations']:,.0f}",
            "Monitor proposal creation and execution patterns",
            "Track delegation trends for voting power analysis",
            "Optimize toll collection during high governance activity periods",
            "Detect potential governance attacks or manipulation attempts"
        ]
    })

@app.route('/contract_info', methods=['GET'])
def contract_info():
    """Get contract information"""
    return jsonify({
        "contract_address": governance_agent.contract_address,
        "network": governance_agent.network,
        "commission_rate": governance_agent.commission_rate,
        "specialization": AGENT_CONFIG["specialization"],
        "expertise": AGENT_CONFIG["expertise"],
        "supported_networks": list(governance_agent.governance_protocols.keys())
    })

if __name__ == "__main__":
    print("🔥 Starting Governance Gas Toll Agent...")
    print(f"   📡 Port: {PORT}")
    print(f"   🌐 Network: {governance_agent.network}")
    print(f"   📋 Contract: {governance_agent.contract_address}")
    print(f"   💰 Commission: {governance_agent.commission_rate * 100}%")
    print(f"   👑 Founder Royalty: {FOUNDER_ROYALTY_RATE * 100}% (IMMUTABLE)")
    print("=" * 60)

    app.run(host='localhost', port=PORT, debug=False)