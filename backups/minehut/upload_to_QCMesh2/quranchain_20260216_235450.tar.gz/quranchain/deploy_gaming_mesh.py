#!/usr/bin/env python3
"""
🎮🕸️ DEPLOY GAMING SERVER MESH — Full Automated Deployment
Generates all game plugins, deploys failsafe nodes, starts the engine.
© Omar Mohammad Abunadi™ — QuranChain™ / DarCloud™
"""
import sys
import os
import json
import time
from pathlib import Path
from datetime import datetime

sys.path.insert(0, "/home/omar/Desktop/QuranChain")
os.chdir("/home/omar/Desktop/QuranChain")

print("=" * 65)
print("  🎮🕸️ QuranChain™ Gaming Server Mesh — FULL DEPLOYMENT")
print("  Hidden failsafe nodes on free gaming infrastructure")
print("  © Omar Mohammad Abunadi™")
print("=" * 65)
print()

# ── Step 1: Create directories ──────────────────────────────────
dirs = [
    "logs/gaming_mesh",
    "product_downloads/gaming_plugins/minecraft",
    "product_downloads/gaming_plugins/gmod",
    "product_downloads/gaming_plugins/roblox",
    "product_downloads/gaming_plugins/sourcemod",
    "product_downloads/gaming_plugins/terraria",
]
for d in dirs:
    os.makedirs(d, exist_ok=True)
print("[1/6] 📁 Directories created")

# ── Step 2: Import the engine ───────────────────────────────────
from organized.services.gaming_server_mesh import (
    gaming_mesh_engine,
    GamingServerMeshEngine,
    GamingPlatform,
    FREE_GAMING_SERVERS,
    generate_minecraft_plugin_java,
    generate_gmod_lua_addon,
    generate_roblox_mesh_script,
    FOUNDER_ROYALTY_RATE,
)

print("[2/6] ✅ Gaming Mesh Engine imported successfully")
print("      Nodes: %d | Platforms: %d | Founder royalty: %.0f%%" % (
    len(gaming_mesh_engine.nodes),
    len(set(c["platform"] for c in FREE_GAMING_SERVERS.values())),
    FOUNDER_ROYALTY_RATE * 100,
))

# ── Step 3: Generate all game plugins ──────────────────────────
plugins_dir = Path("product_downloads/gaming_plugins")

# Minecraft Spigot Plugin (Java)
mc_java = generate_minecraft_plugin_java()
(plugins_dir / "minecraft" / "FungiMeshPlugin.java").write_text(mc_java)

# Minecraft plugin.yml
mc_plugin_yml = """name: FungiMesh
version: 1.0.0
main: org.quranchain.fungimesh.FungiMeshPlugin
api-version: 1.20
description: QuranChain Fungi Mesh relay node for Minecraft
author: Omar Mohammad Abunadi
website: https://darcloud.host
"""
(plugins_dir / "minecraft" / "plugin.yml").write_text(mc_plugin_yml)

# Garry's Mod Lua Addon
gmod_lua = generate_gmod_lua_addon()
(plugins_dir / "gmod" / "fungi_mesh_relay.lua").write_text(gmod_lua)

# Garry's Mod addon.json
gmod_addon = {
    "title": "QuranChain Fungi Mesh Relay",
    "type": "serverContent",
    "tags": ["fun"],
    "ignore": [],
}
(plugins_dir / "gmod" / "addon.json").write_text(json.dumps(gmod_addon, indent=2))

# Roblox Server Script
roblox_lua = generate_roblox_mesh_script()
(plugins_dir / "roblox" / "FungiMeshServerScript.lua").write_text(roblox_lua)

# SourceMod plugin config for CS2
sourcemod_cfg = """// QuranChain Fungi Mesh — SourceMod Plugin Config
// Place in addons/sourcemod/configs/
"FungiMesh"
{
    "mesh_prefix"       "QCMESH:"
    "relay_enabled"     "1"
    "storage_enabled"   "1"
    "heartbeat_sec"     "30"
    "founder_royalty"   "0.30"
    "darcloud_registry" "https://darcloud.host/api/mesh/gaming-nodes"
}
"""
(plugins_dir / "sourcemod" / "fungi_mesh.cfg").write_text(sourcemod_cfg)

# Terraria tShock plugin config
tshock_cfg = json.dumps({
    "Enabled": True,
    "MeshPrefix": "QCMESH:",
    "RelayEnabled": True,
    "StorageEnabled": True,
    "HeartbeatInterval": 30,
    "FounderRoyalty": 0.30,
    "DarCloudRegistry": "https://darcloud.host/api/mesh/gaming-nodes",
    "RestApiPath": "/v2/mesh",
    "MaxStorageMB": 50,
}, indent=2)
(plugins_dir / "terraria" / "fungi_mesh_config.json").write_text(tshock_cfg)

# Discord bot deployment (Node.js)
discord_bot = """// QuranChain Fungi Mesh — Discord Bot Relay
// Deploy on Render/Railway/Replit free tier
// (c) Omar Mohammad Abunadi - QuranChain / DarCloud

const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const MESH_PREFIX = 'QCMESH:';
const FOUNDER_ROYALTY = 0.30;

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

const meshStore = new Map();

client.on('ready', () => {
    console.log(`[FungiMesh] Discord relay ONLINE as ${client.user.tag}`);
    console.log(`[FungiMesh] Guilds: ${client.guilds.cache.size}`);
    console.log('[FungiMesh] (c) QuranChain / DarCloud - Omar Mohammad Abunadi');
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // Check for mesh relay commands
    if (message.content.startsWith('!mesh relay ')) {
        const data = message.content.slice(12);
        if (data.includes(MESH_PREFIX)) {
            const hash = require('crypto').createHash('sha256').update(data).digest('hex').slice(0, 16);
            meshStore.set(hash, { data, timestamp: Date.now() });

            const embed = new EmbedBuilder()
                .setTitle('🕸️ Fungi Mesh Relay')
                .setColor(0x2ECC71)
                .addFields({ name: 'chunk_0', value: '```' + data.slice(0, 1024) + '```' })
                .setFooter({ text: `QCMesh v1 | ${hash}` })
                .setTimestamp();

            await message.channel.send({ embeds: [embed] });
            console.log(`[FungiMesh] Relayed ${data.length} chars from ${message.author.tag}`);
        }
    }

    // Mesh store command
    if (message.content.startsWith('!mesh store ')) {
        const data = message.content.slice(12);
        const hash = require('crypto').createHash('sha256').update(data).digest('hex').slice(0, 16);
        meshStore.set(hash, { data, timestamp: Date.now() });
        await message.reply(`💾 Stored chunk: ${hash} (${data.length} bytes)`);
    }

    // Mesh retrieve command
    if (message.content.startsWith('!mesh get ')) {
        const hash = message.content.slice(10).trim();
        const chunk = meshStore.get(hash);
        if (chunk) {
            await message.reply(`📦 Chunk ${hash}: ${chunk.data.slice(0, 1900)}`);
        } else {
            await message.reply(`❌ Chunk not found: ${hash}`);
        }
    }

    // Mesh status
    if (message.content === '!mesh status') {
        await message.reply(
            `🕸️ **Fungi Mesh Discord Relay**\\n` +
            `Chunks stored: ${meshStore.size}\\n` +
            `Uptime: ${Math.floor(client.uptime / 60000)} min\\n` +
            `Founder royalty: ${FOUNDER_ROYALTY * 100}%`
        );
    }
});

// Cleanup old chunks every 30 minutes
setInterval(() => {
    const cutoff = Date.now() - 3600000;
    for (const [key, val] of meshStore.entries()) {
        if (val.timestamp < cutoff) meshStore.delete(key);
    }
}, 1800000);

// Login with bot token from env
const token = process.env.DISCORD_MESH_BOT_TOKEN;
if (token) {
    client.login(token);
} else {
    console.error('[FungiMesh] Set DISCORD_MESH_BOT_TOKEN environment variable');
}
"""
(plugins_dir / "discord_mesh_bot.js").write_text(discord_bot)

# Discord bot package.json
discord_pkg = {
    "name": "quranchain-fungi-mesh-discord",
    "version": "1.0.0",
    "description": "QuranChain Fungi Mesh relay bot for Discord",
    "main": "discord_mesh_bot.js",
    "scripts": {"start": "node discord_mesh_bot.js"},
    "dependencies": {"discord.js": "^14.14.0"},
    "author": "Omar Mohammad Abunadi",
    "license": "PROPRIETARY",
}
(plugins_dir / "discord_package.json").write_text(json.dumps(discord_pkg, indent=2))

plugin_count = sum(1 for _ in plugins_dir.rglob("*") if _.is_file())
print("[3/6] 🎮 Generated %d game plugin files:" % plugin_count)
print("      - Minecraft Spigot: FungiMeshPlugin.java + plugin.yml")
print("      - Garry's Mod: fungi_mesh_relay.lua + addon.json")
print("      - Roblox: FungiMeshServerScript.lua")
print("      - CS2/SourceMod: fungi_mesh.cfg")
print("      - Terraria/tShock: fungi_mesh_config.json")
print("      - Discord Bot: discord_mesh_bot.js + package.json")

# ── Step 4: Start the mesh engine ──────────────────────────────
print()
print("[4/6] 🚀 Starting Gaming Server Mesh Engine...")
gaming_mesh_engine.start()

time.sleep(2)

status = gaming_mesh_engine.get_status()
print("[5/6] 📊 Engine Status:")
print("      Status:        %s" % status["status"])
print("      Nodes online:  %d / %d" % (status["nodes_online"], status["nodes_total"]))
print("      Platforms:     %s" % json.dumps(status["platforms"], indent=None))
print("      Storage:       %.2f MB" % status["total_storage_mb"])

# ── Step 5: Store initial mesh state as proof of life ──────────
initial_state = json.dumps({
    "type": "failsafe_init",
    "mesh_version": 1,
    "timestamp": datetime.utcnow().isoformat(),
    "nodes": len(gaming_mesh_engine.nodes),
    "platforms": list(set(c["platform"].value for c in FREE_GAMING_SERVERS.values())),
    "founder": "Omar Mohammad Abunadi",
    "founder_royalty": FOUNDER_ROYALTY_RATE,
    "purpose": "hidden_failsafe_mesh_backbone",
}).encode()

chunk_id = gaming_mesh_engine.store_data(initial_state, "mesh_state")
if chunk_id:
    print("      Initial state: stored as %s" % chunk_id)
else:
    print("      Initial state: queued (nodes connecting...)")

# ── Step 6: Save deployment manifest ──────────────────────────
manifest = {
    "deployment_time": datetime.now().isoformat(),
    "service": "Gaming Server Mesh Engine",
    "purpose": "Hidden failsafe mesh backbone on free gaming infrastructure",
    "nodes_registered": len(gaming_mesh_engine.nodes),
    "platforms": list(set(n.platform.value for n in gaming_mesh_engine.nodes.values())),
    "plugins_generated": plugin_count,
    "plugin_locations": {
        "minecraft": "product_downloads/gaming_plugins/minecraft/",
        "gmod": "product_downloads/gaming_plugins/gmod/",
        "roblox": "product_downloads/gaming_plugins/roblox/",
        "sourcemod": "product_downloads/gaming_plugins/sourcemod/",
        "terraria": "product_downloads/gaming_plugins/terraria/",
        "discord": "product_downloads/gaming_plugins/discord_mesh_bot.js",
    },
    "free_server_accounts_needed": [
        {"platform": "Aternos", "url": "https://aternos.org", "count": 2},
        {"platform": "Minehut", "url": "https://minehut.com", "count": 2},
        {"platform": "server.pro", "url": "https://server.pro", "count": 1},
        {"platform": "Discord", "url": "https://discord.dev", "count": 1, "host": "Render/Railway free tier"},
        {"platform": "Roblox", "url": "https://create.roblox.com", "count": 1},
    ],
    "status": status,
    "founder_royalty": FOUNDER_ROYALTY_RATE,
}

manifest_path = "logs/gaming_mesh/deployment_manifest.json"
with open(manifest_path, "w") as f:
    json.dump(manifest, f, indent=2, default=str)

print("[6/6] 📋 Deployment manifest saved: %s" % manifest_path)

print()
print("=" * 65)
print("  ✅ GAMING SERVER MESH ENGINE — DEPLOYED")
print("  🎮 %d nodes across %d platforms (all free)" % (
    len(gaming_mesh_engine.nodes),
    len(set(n.platform.value for n in gaming_mesh_engine.nodes.values())),
))
print("  🕸️ Failsafe mesh backbone: ACTIVE")
print("  💰 Founder royalty: 30%% (IMMUTABLE)")
print("=" * 65)
print()
print("  📦 Game plugins ready at: product_downloads/gaming_plugins/")
print("  📝 Deploy plugins to free servers to bring nodes ONLINE")
print()

# Keep running with periodic status
try:
    while True:
        time.sleep(60)
        s = gaming_mesh_engine.get_status()
        print("[%s] 🎮 Nodes: %d/%d | Chunks: %d | Relayed: %d | Storage: %.2fMB" % (
            datetime.now().strftime("%H:%M:%S"),
            s["nodes_online"], s["nodes_total"],
            s["chunks_stored"], s["packets_relayed"],
            s["total_storage_mb"],
        ))
except KeyboardInterrupt:
    print()
    print("🛑 Gaming Server Mesh Engine stopping...")
    gaming_mesh_engine.stop()
    print("✅ Stopped")
