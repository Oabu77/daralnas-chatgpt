#!/usr/bin/env python3
"""
QuranChain™ AI Agent Task Scheduler
Activates background tasks for all AI agents to execute business logic
"""

import schedule
import time
import requests
import logging
import sqlite3
from blockchain_logging_handler import setup_blockchain_logging
from datetime import datetime
from pathlib import Path

# Configure logging
LOG_DIR = Path('logs/ai_workforce')
LOG_DIR.mkdir(parents=True, exist_ok=True)

setup_blockchain_logging()
logger = logging.getLogger('AI_Scheduler')

CRM_DB_PATH = Path('crm/crm.db')

def generate_marketing_leads():
    """Marketing AI: Generate new leads"""
    conn = sqlite3.connect(str(CRM_DB_PATH))
    cursor = conn.cursor()
    
    sources = ['website', 'linkedin', 'twitter', 'reddit']
    leads_generated = 0
    
    for source in sources:
        email = f"prospect_{source}_{int(time.time())}@example.com"
        try:
            cursor.execute("""
                INSERT INTO leads (name, email, company, phone, source, score, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                f"Prospect from {source}",
                email,
                f"Company via {source}",
                f"+1-555-{1000 + leads_generated}",
                source,
                70 + (leads_generated * 5) % 30,
                'NEW',
                datetime.now().isoformat(),
                datetime.now().isoformat()
            ))
            leads_generated += 1
        except sqlite3.IntegrityError:
            pass
    
    conn.commit()
    conn.close()
    logger.info(f"💼 Generated {leads_generated} new leads")
    return leads_generated

def follow_up_sales_leads():
    """Sales AI: Follow up on high-scoring leads"""
    conn = sqlite3.connect(str(CRM_DB_PATH))
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT id, name, score 
        FROM leads 
        WHERE score >= 75 AND status != 'CONVERTED'
        ORDER BY score DESC LIMIT 10
    """)
    
    leads = cursor.fetchall()
    deals_created = 0
    
    for lead_id, name, score in leads:
        amount = 5000 + (score * 100)
        try:
            cursor.execute("""
                INSERT INTO deals (lead_id, name, stage, deal_value, currency, probability, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                lead_id,
                f"Deal for {name}",
                'PROPOSAL',
                amount,
                'USD',
                35,
                datetime.now().isoformat(),
                datetime.now().isoformat()
            ))
            deals_created += 1
            cursor.execute("UPDATE leads SET status = 'IN_PROGRESS', updated_at = ? WHERE id = ?",
                         (datetime.now().isoformat(), lead_id))
        except sqlite3.IntegrityError:
            pass
    
    conn.commit()
    conn.close()
    logger.info(f"💰 Created {deals_created} new deals")
    return deals_created

def activate_pending_merchants():
    """Onboarding AI: Activate merchants from closed deals"""
    conn = sqlite3.connect(str(CRM_DB_PATH))
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT d.id, d.lead_id, l.name, l.email, d.deal_value
        FROM deals d
        JOIN leads l ON d.lead_id = l.id
        WHERE d.stage = 'CLOSED'
        AND NOT EXISTS (SELECT 1 FROM merchants m WHERE m.email = l.email)
        LIMIT 5
    """)
    
    pending = cursor.fetchall()
    merchants_activated = 0
    
    for deal_id, lead_id, name, email, amount in pending:
        try:
            cursor.execute("""
                INSERT INTO merchants (business_name, contact_name, email, status, api_key_issued, 
                                     monthly_volume, onboarded_at, onboarded_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                name, name, email, 'ACTIVE', 1, amount or 10000,
                datetime.now().isoformat(), 'onboarding_ai', datetime.now().isoformat()
            ))
            merchants_activated += 1
        except sqlite3.IntegrityError:
            pass
    
    conn.commit()
    conn.close()
    logger.info(f"🏪 Activated {merchants_activated} merchants")
    return merchants_activated

def setup_schedule():
    """Setup schedule for all AI agent tasks"""
    logger.info("🤖 QuranChain™ AI Agent Scheduler - Starting")
    
    # Marketing AI tasks
    schedule.every(1).hours.do(generate_marketing_leads)
    schedule.every(2).hours.do(lambda: logger.info("📢 Marketing campaigns running..."))
    
    # Sales AI tasks
    schedule.every(30).minutes.do(follow_up_sales_leads)
    
    # Onboarding AI tasks
    schedule.every(15).minutes.do(activate_pending_merchants)
    
    logger.info(f"✅ Scheduled {len(schedule.get_jobs())} tasks")
    
    # Run initial tasks
    logger.info("🚀 Executing initial tasks...")
    generate_marketing_leads()
    follow_up_sales_leads()
    activate_pending_merchants()
    logger.info("✅ Initial tasks completed")

def main():
    """Main scheduler loop"""
    setup_schedule()
    logger.info("📅 SCHEDULER RUNNING")
    
    while True:
        try:
            schedule.run_pending()
            time.sleep(60)
        except KeyboardInterrupt:
            logger.info("⏹️  Scheduler stopped")
            break
        except Exception as e:
            logger.error(f"Scheduler error: {e}")
            time.sleep(60)

if __name__ == '__main__':
    main()

